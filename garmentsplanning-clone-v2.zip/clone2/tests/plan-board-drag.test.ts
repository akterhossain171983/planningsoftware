import { describe, it, expect } from "vitest";
import { simulateDrop, type PlanRow } from "../src/components/planning/planBoardSim";
import { buildLinePresetLookup, canonicalLineName } from "../src/components/planning/lineLookup";

const MOCK_PRESETS = [
  "Line - 15",
  "Line - 16",
  "Line - 17",
  "Line - 18",
  "Line - 19",
  "Line - 20",
  "Line - 21",
  "Line - 22",
  "Line - 23",
  "Line - 24",
  "Line - 25",
  "Line - 26",
  "Line - 27",
  "Line - 28",
  "Line - 29",
  "Line - 30",
  "Line - 31",
  "Line - 32",
  "Line - 33",
  "Line - 34",
  "Line - 35",
  "Line - A",
  "Line - B",
  "Line - C",
  "Line - D",
  "Line - E",
  "Line - F",
  "Line - G",
  "Line - H",
  "Line - I",
  "Line - J",
  "Line - K",
  "Line - L",
  "Line - M",
  "Line - N",
  "Line - O",
  "Line - P",
  "Line - Q",
  "Line - R",
  "Line - S",
];

const PRESET_LOOKUP = buildLinePresetLookup(MOCK_PRESETS);

describe("Plan Board Drag-and-Drop Synchronization", () => {
  const mockPlans: PlanRow[] = [
    {
      id: "plan-1",
      buyer: "Buyer A",
      style: "Style X",
      order_qty: 1000,
      excess_pct: 0,
      daily_target: 100,
      shipment_date: "2026-09-01",
      config: {
        lines: [{ name: "Line - 15", startDateStr: "2026-08-01", allocatedOrderQty: 1000 }],
        customHolidays: [],
      },
      calc_result: {
        lines: [
          {
            name: "Line - 15",
            startDateStr: "2026-08-01",
            finishDateStr: "2026-08-10",
            plannedQty: 1000,
            dailyProduction: [],
          },
        ],
        totalPlannedQty: 1000,
        remainingQty: 0,
        isCompleted: false,
      },
    },
  ];

  it('should correctly simulate moving a plan to a numeric line ("Line - 16")', () => {
    const origLineName = "Line - 15";
    const newLineCanonical = "Line - 16";
    const newLineName = canonicalLineName(newLineCanonical, PRESET_LOOKUP);

    const { after, changes } = simulateDrop({
      plans: mockPlans,
      editPlanId: "plan-1",
      origLineName: origLineName,
      newLineName: newLineName,
      deltaDays: 2,
      globalHolidays: [],
    });

    expect(changes).toHaveLength(1);
    expect(changes[0].reason).toBe("moved");
    expect(changes[0].lineName).toBe("Line - 16");
    expect(changes[0].newStart).toBe("2026-08-03");
    expect(after[0].config.lines[0].name).toBe("Line - 16");
  });

  it('should correctly simulate moving a plan to a lettered line ("Line - A")', () => {
    const origLineName = "Line - 15";
    const newLineCanonical = "Line - A";
    const newLineName = canonicalLineName(newLineCanonical, PRESET_LOOKUP);

    const { after, changes } = simulateDrop({
      plans: mockPlans,
      editPlanId: "plan-1",
      origLineName: origLineName,
      newLineName: newLineName,
      deltaDays: 0,
      globalHolidays: [],
    });

    expect(changes).toHaveLength(1);
    expect(changes[0].lineName).toBe("Line - A");
    expect(after[0].config.lines[0].name).toBe("Line - A");
  });

  it("should maintain normalization consistency between raw and canonical names", () => {
    // This simulates the check done in PlanBoardView.tsx onBarPointerUp
    const rawInput = "Line-15"; // Variation in spacing
    const canonical = canonicalLineName(rawInput, PRESET_LOOKUP);
    expect(canonical).toBe("Line - 15");

    const rawLetter = "line A";
    const canonicalLetter = canonicalLineName(rawLetter, PRESET_LOOKUP);
    expect(canonicalLetter).toBe("Line - A");
  });
});
