import { describe, it, expect } from "vitest";
import { countWorkingDays, nextWorkingDay } from "../src/lib/plan-calc";
import {
  normLine,
  canonicalLineName,
  buildLinePresetLookup,
} from "../src/components/planning/lineLookup";

describe("Line Allocation & Capacity Calculations", () => {
  const linePresets = ["Line - 15", "Line - 16", "Line - 17", "Line - A", "Line - B"];
  const lookup = buildLinePresetLookup(linePresets);

  it("calculates working days in a date window excluding Fridays and holidays", () => {
    // 2026-09-01 is Tuesday, 2026-09-07 is Monday (7 days, 1 Friday on Sep 4)
    const holidays = ["2026-09-02"]; // 1 holiday
    const days = countWorkingDays("2026-09-01", "2026-09-07", holidays);
    // 7 total days - 1 Friday - 1 holiday = 5 working days
    expect(days).toBe(5);
  });

  it("calculates factory line capacity from working days and target rate", () => {
    const workingDays = 26;
    const dailyTarget = 1000;
    const maxCapacity = workingDays * dailyTarget;
    const allocated = 20800;
    const utilizationPct = (allocated / maxCapacity) * 100;
    const remaining = maxCapacity - allocated;

    expect(maxCapacity).toBe(26000);
    expect(utilizationPct).toBe(80);
    expect(remaining).toBe(5200);
  });

  it("computes prospective capacity delta when a task is moved to a target line", () => {
    const targetCurrentAllocated = 18000;
    const maxCapacity = 24000;
    const currentUtil = (targetCurrentAllocated / maxCapacity) * 100; // 75%

    const movingTaskQty = 6000;
    const prospectiveAllocated = targetCurrentAllocated + movingTaskQty;
    const prospectiveUtil = (prospectiveAllocated / maxCapacity) * 100; // 100%
    const deltaUtil = prospectiveUtil - currentUtil;

    expect(currentUtil).toBe(75);
    expect(prospectiveAllocated).toBe(24000);
    expect(prospectiveUtil).toBe(100);
    expect(deltaUtil).toBe(25);
  });

  it("flags overload when prospective utilization exceeds 100%", () => {
    const targetCurrentAllocated = 22000;
    const maxCapacity = 24000;
    const movingTaskQty = 5000;
    const prospectiveAllocated = targetCurrentAllocated + movingTaskQty;
    const prospectiveUtil = (prospectiveAllocated / maxCapacity) * 100; // 112.5%

    expect(prospectiveUtil).toBeGreaterThan(100);
  });

  it("chains task start date correctly to next working day after preceding task finish", () => {
    // 2026-09-03 is Thursday -> next working day is Saturday 2026-09-05 (Friday Sep 4 is non-working in BD)
    const finishDate = "2026-09-03";
    const nextStart = nextWorkingDay(finishDate, []);
    expect(nextStart).toBe("2026-09-05");
  });

  it("normalizes and canonicalizes line names accurately across variations", () => {
    expect(normLine("Line - 15")).toBe("15");
    expect(normLine("Line 15")).toBe("15");
    expect(normLine("15")).toBe("15");
    expect(canonicalLineName("15", lookup)).toBe("Line - 15");
    expect(canonicalLineName("Line A", lookup)).toBe("Line - A");
  });
});
