# Style & Line Summary View (Buyer, Season, Style, Line Sum & Details)

A dedicated analytical view tab within the garments ERP navigation displaying a clean, scannable table grouped by **Buyer**, **Season**, and **Style**, detailing the **Sum of Plan Lines** (count of distinct active lines) and **Mention Plan Lines** (comma-separated list of lines), with search filters and one-click export to Excel (.xlsx) and CSV.

## User Review & Critical Decisions

> [!IMPORTANT]
> The requirements and design choices below were confirmed during Phase 1 interactive clarification:
>
> - **Navigation Location**: Dedicated tab in the main sidebar/app shell alongside _Plan Board_ and _Production Update_, labeled **Style Lines Summary** (স্টাইল লাইন সামারি).
> - **Calculation Formula for "Sum of Plan Lines"**: Count of all unique, distinct production lines assigned to the style across active plan allocations.
> - **Mention Plan Lines Format**: Naturally sorted, comma-separated line names (e.g. `Line 01, Line 03, Line 07`).
> - **Export Capability**: Direct export to formatted Excel (.xlsx) and CSV files for production reporting and merchandising meetings.

---

## 1. Overview & Core Concept

- **What It Does**: Merchandisers, planning managers, and production chiefs frequently need an immediate summary of which lines are running each style, how many total lines are committed, and how allocations break down by Buyer and Season. This view aggregates live plan records into a consolidated report table with the exact columns requested:
  1. **Buyer** (বায়ার)
  2. **Season** (সিজন)
  3. **Style** (স্টাইল)
  4. **Sum of Plan Lines** (মোট প্ল্যান লাইন সংখ্যা)
  5. **Mention Plan Lines with Comma** (নির্ধারিত লাইনসমূহ — কমা দিয়ে)
  6. _Additional context columns_: Total Order Qty, Total Planned Qty, Active Schedule Window (Start → End).
- **Target Audience**: Garments planning managers, IE managers, merchandisers, and factory directors.
- **Key Value**: Replaces tedious manual checking across multiple lines on the planning board with a single unified, exportable summary table.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Accessing the Tab**: The user clicks the new **Style Lines Summary** (স্টাইল লাইন সামারি) tab in the left sidebar navigation (represented with a clean `GitFork` or `Network` icon).
2. **Filter & Search**:
   - Live search input: search across Style name, Buyer name, Season, or Line name.
   - Multi-select filters: filter by Buyer and Season.
3. **Reading the Table**:
   - Clean, high-density table following the SaaS design constitution (left-aligned text, right-aligned tabular numerals for counts and quantities).
   - "Sum of Plan Lines" displayed with a clear tabular counter.
   - "Plan Lines" rendered as clean, comma-separated typography with subtle line highlights for fast recognition.
4. **Exporting Data**:
   - **Export to Excel (.xlsx)**: Generates a styled spreadsheet with headers, column widths, and proper cell data types.
   - **Export to CSV**: Quick UTF-8 formatted CSV download for instant import into other systems or Google Sheets.
5. **Quick Inspection**:
   - Clicking a style row reveals its underlying line schedule breakdown (per-line start/finish dates, daily targets, and quantities).

### Visual Identity & Theme

- **Layout & Contrast**: Single-elevation flat surface matching the app's dark slate palette (`bg-panel-1`, `bg-panel-2`, `border-border`).
- **Typography & Data Alignment**: Headings in clean sans; all line counts, quantities, and dates styled with tabular figures (`font-mono tabular-nums`).
- **Zero-Pill Discipline**: Metadata displayed as unboxed clean text separated by subtle typographic dots (`·`) or slashes (`/`), avoiding pill-badge clutter.
- **Single-Line Controls**: Action buttons and search inputs formatted with single-line labels (`whitespace-nowrap shrink-0`).

---

## 3. Key Product Decisions & Trade-Offs

- **Dedicated View vs. Modal**:
  - _Decision_: Implemented as a dedicated navigation tab (`tab = "stylelines"`) alongside _Plan Board_ and _Production Update_, per user selection.
  - _Rationale_: Allows users to keep the summary open, filter, compare across buyers/seasons, and perform exports without being constrained by a popup modal dialog.
- **Style-Level Aggregation Across Multi-Plans**:
  - _Decision_: Group plans by composite key `Buyer + Season + Style`.
  - _Rationale_: If a style is allocated across multiple split planning entries or orders, all distinct assigned lines are merged deduplicated and sorted naturally (`Line 1, Line 2, Line 10` rather than alphabetical `Line 1, Line 10, Line 2`).
- **Export Architecture**:
  - _Decision_: Client-side dynamic generation of both XLSX (via existing `xlsx` library or standard XML/CSV generator) and CSV with full BOM encoding for seamless Excel compatibility.

---

## 4. Technical Architecture & Data Strategy

### System & Component Hierarchy

```
┌─────────────────────────────────────────────────────────────┐
│ AppShell (src/routes/_authenticated/app.tsx)                │
│  ├── Sidebar Navigation Link: "Style Lines Summary"         │
│  └── Tab Router: tab === "stylelines"                       │
└──────────────────────────────┬──────────────────────────────┘
                               │ renders
┌──────────────────────────────▼──────────────────────────────┐
│ StyleLinesSummaryView (src/components/planning/...)        │
│  ├── Top Toolbar                                            │
│  │    ├── Search Input (Buyer / Season / Style / Line)      │
│  │    ├── Buyer Filter & Season Filter Dropdowns            │
│  │    └── Action Buttons: [Export Excel] [Export CSV]       │
│  │                                                          │
│  ├── Summary KPI Cards                                      │
│  │    ├── Total Styles Analyzed                             │
│  │    ├── Total Distinct Lines Utilized                     │
│  │    └── Total Planned Quantity                            │
│  │                                                          │
│  └── High-Density Summary Table                             │
│       ├── Columns:                                          │
│       │    1. Buyer (বায়ার)                                │
│       │    2. Season (সিজন)                                 │
│       │    3. Style (স্টাইল)                                │
│       │    4. Sum of Plan Lines (মোট লাইন)                  │
│       │    5. Mention Plan Lines (লাইনসমূহ - কমা দিয়ে)      │
│       │    6. Total Order Qty & Planned Qty                 │
│       │    7. Date Range (Start → Finish)                   │
│       └── Expandable Row: Per-Line Breakdown Details        │
└─────────────────────────────────────────────────────────────┘
```

### Data Pipeline & Query

- **Data Source**: Live query against Supabase `plans` table (`is("completed_at", null)`), matching the cache and realtime channel used in `BuyerMonthlyView` and `PlanBoardView`.
- **Transformation Function**:
  - Iterate through `plans`.
  - Extract `p.buyer`, `p.season`, `p.style`, and `p.calc_result.lines`.
  - Group into `Map<string, StyleLineGroup>`.
  - Compute distinct line set `Array.from(new Set(allLines)).sort(naturalSort)`.
  - Calculate `sumOfLines = distinctLines.length`.
  - Format `mentionedLines = distinctLines.join(", ")`.
