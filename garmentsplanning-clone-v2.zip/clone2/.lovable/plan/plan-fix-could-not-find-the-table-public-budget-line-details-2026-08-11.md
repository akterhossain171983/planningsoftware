# Plan: Fix 'Could not find the table public.budget_line_details' Error

The user is encountering an error message: "Could not find the table 'public.budget_line_details' in the schema cache". This typically happens when a table exists in the database but the local PostgREST/Supabase schema cache hasn't updated, or there's a disconnect between the code's expectations and the database state.

## Proposed Changes

### 1. Database Synchronization

- The table `budget_line_details` is defined in migration `20260811050000_budget_expansion.sql`.
- I will re-apply the relevant parts of the migrations to ensure the tables and their permissions are correctly established in the backend.
- I will explicitly include `GRANT` and `RLS` statements to ensure the `authenticated` role has full access.

### 2. Schema Cache Refresh

- The error "Could not find the table... in the schema cache" often requires a PostgREST reload. Since I don't have direct access to reload the server, I will perform a safe "dummy" mutation or read to trigger a cache refresh if possible, but primarily I will ensure the `src/integrations/supabase/types.ts` is updated if it's missing the table definitions.
- _Note_: I noticed `budget_line_details` and `budget_department_details` are missing from the `Tables` list in `src/integrations/supabase/types.ts` despite being in migrations. I will add them to the types file to ensure the client-side library recognizes them.

### 3. Code Verification

- Review `src/components/planning/MonthlyBudgetView.tsx` to ensure it uses the correct table names and types.

## Technical Details

### Migration Re-run (SQL)

```sql
-- Ensure tables exist and permissions are granted
CREATE TABLE IF NOT EXISTS public.budget_line_details (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    factory_id uuid NOT NULL REFERENCES public.factories(id),
    month date NOT NULL,
    line_name text NOT NULL,
    cost_head text NOT NULL,
    budget_value numeric DEFAULT 0,
    actual_value numeric DEFAULT 0,
    entry_date date DEFAULT CURRENT_DATE,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    UNIQUE(factory_id, month, line_name, cost_head, entry_date)
);

CREATE TABLE IF NOT EXISTS public.budget_department_details (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    factory_id uuid NOT NULL REFERENCES public.factories(id),
    month date NOT NULL,
    department text NOT NULL,
    cost_head text NOT NULL,
    budget_value numeric DEFAULT 0,
    actual_value numeric DEFAULT 0,
    entry_date date DEFAULT CURRENT_DATE,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    UNIQUE(factory_id, month, department, cost_head, entry_date)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_line_details TO authenticated;
GRANT ALL ON public.budget_line_details TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_department_details TO authenticated;
GRANT ALL ON public.budget_department_details TO service_role;

ALTER TABLE public.budget_line_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budget_department_details ENABLE ROW LEVEL SECURITY;

-- Re-create policies to ensure they are correct
DROP POLICY IF EXISTS "Manage factory budget line details" ON public.budget_line_details;
CREATE POLICY "Manage factory budget line details" ON public.budget_line_details
    FOR ALL TO authenticated
    USING (factory_id IN (SELECT factory_id FROM public.profiles WHERE id = auth.uid()))
    WITH CHECK (factory_id IN (SELECT factory_id FROM public.profiles WHERE id = auth.uid()));

DROP POLICY IF EXISTS "Manage factory budget dept details" ON public.budget_department_details;
CREATE POLICY "Manage factory budget dept details" ON public.budget_department_details
    FOR ALL TO authenticated
    USING (factory_id IN (SELECT factory_id FROM public.profiles WHERE id = auth.uid()))
    WITH CHECK (factory_id IN (SELECT factory_id FROM public.profiles WHERE id = auth.uid()));
```

### Type Update

I will manually add the missing table definitions to `src/integrations/supabase/types.ts` to resolve TypeScript and runtime lookup issues.

## User Impact

- The budget saving and loading should work without the "table not found" error.
- Data persistence for line and department budgets will be restored.
