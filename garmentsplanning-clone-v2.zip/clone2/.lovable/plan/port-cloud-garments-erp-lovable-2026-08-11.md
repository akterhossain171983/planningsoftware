# Port Cloud Garments ERP → Lovable

## What the source file does

A single 710-line HTML app in Bengali with Tailwind CDN + Firebase Realtime Database. Features:

- **Auth** — username/password login, admin/manager roles, active/blocked flag, system-wide lock. Users stored in Firebase.
- **Admin panel** — add/block/delete users, toggle system lock.
- **Production planning (Input tab)** — form: buyer, style, order qty, excess %, daily target, number of production lines (1–10), per-line start dates, shipment date, custom holidays, per-line date-range target adjustments. On submit, calculates a full production plan.
- **Matrix tab** — renders the calculated plan output; supports edit/delete of saved plans.
- **Realtime sync** — all data (users, plans, lock flag) lives in Firebase and syncs live across clients.

## Target architecture

- **TanStack Start** routes: `/` login, `/app` main (tabs), `/app/admin` modal-route.
- **Lovable Cloud** (Supabase) replaces Firebase:
  - `auth.users` for accounts, `profiles` + `user_roles` table (admin/manager) — per project conventions, roles in a separate table with `has_role()` security-definer function.
  - `plans` table (buyer, style, order_qty, excess_pct, daily_target, num_lines, shipment_date, config jsonb, calc_result jsonb, created_by, timestamps).
  - `system_settings` (single row) for the `locked` flag.
  - Supabase Realtime subscriptions replace Firebase `.on('value')`.
- **UI** — keep the dark slate/blue/emerald look, Bengali labels. Build with shadcn + Tailwind design tokens (no ad-hoc colors in components).
- **Plan calculation** — port the JS logic verbatim into `src/lib/plan-calc.ts` (pure function, unit-testable).

## Phased delivery (recommend approving Phase 1 first)

**Phase 1 — Foundation (this turn if approved)**

1. Enable Lovable Cloud.
2. Migrations: `profiles`, `app_role` enum + `user_roles` + `has_role()`, `plans`, `system_settings`, RLS + GRANTs.
3. Auth: sign-up/sign-in pages in Bengali, seed one admin user, wire session, system-lock check on login.
4. App shell: header, tab switcher (Input / Matrix), logout, admin button (role-gated).
5. Dark design system in `src/styles.css` matching the source (slate-900 bg, blue→teal→emerald accents, Inter font).

**Phase 2 — Planning form + calculation**

- Full Input-tab form with all fields, holiday chips, per-line date pickers, target-adjustment rows.
- Port `calculateAndAddPlan` logic to `plan-calc.ts`.
- Save/edit/cancel to `plans` table.

**Phase 3 — Matrix tab**

- Render saved plans, per-line day-by-day matrix, edit/delete actions, realtime updates.

**Phase 4 — Admin panel**

- User list, add user (calls admin edge function using service role — the browser cannot create Supabase users directly), block/unblock via `profiles.active`, delete, system-lock toggle.

## Open questions I'll assume unless you say otherwise

- Keep all UI **in Bengali** (matching source). English toggle not included.
- Default admin credentials on first run: `admin` / a password you'll set at signup (Supabase requires email — I'll use `admin@local` as the login email and show "admin" as display name). Confirm if you want a different email scheme.
- Skip the "excess production" and target-adjustment features only if you say so; otherwise ported as-is.

Approve to proceed with **Phase 1**, or tell me to adjust scope / do it all in one shot.
