import fs from "node:fs";
import path from "node:path";

const rootDir = process.cwd();
const distDir = path.join(rootDir, "dist");
const distClientDir = path.join(distDir, "client");
const netlifyInternalDir = path.join(rootDir, ".netlify", "functions-internal");
const netlifyServerDir = path.join(netlifyInternalDir, "server");
const distServerDir = path.join(distDir, "server");

const isNetlify = !!process.env.NETLIFY;

if (isNetlify) {
  console.log("[postbuild] Running Netlify deployment asset preparation...");

  // 1. Ensure dist directory exists
  if (!fs.existsSync(distDir)) {
    fs.mkdirSync(distDir, { recursive: true });
  }

  // 2. Ensure .netlify/functions-internal directory exists so Netlify doesn't fail
  if (!fs.existsSync(netlifyInternalDir)) {
    fs.mkdirSync(netlifyInternalDir, { recursive: true });
  }

  // 3. If Nitro output server into dist/server, sync it to .netlify/functions-internal/server
  if (fs.existsSync(distServerDir)) {
    console.log("[postbuild] Syncing dist/server to .netlify/functions-internal/server...");
    fs.mkdirSync(netlifyServerDir, { recursive: true });
    fs.cpSync(distServerDir, netlifyServerDir, { recursive: true, force: true });
  } else if (fs.existsSync(netlifyServerDir) && !fs.existsSync(distServerDir)) {
    console.log("[postbuild] Syncing .netlify/functions-internal/server to dist/server...");
    fs.mkdirSync(distServerDir, { recursive: true });
    fs.cpSync(netlifyServerDir, distServerDir, { recursive: true, force: true });
  }

  // 4. Ensure dist/client directory exists
  if (!fs.existsSync(distClientDir)) {
    fs.mkdirSync(distClientDir, { recursive: true });
  }

  // 5. Ensure all static client assets are present in BOTH dist and dist/client
  try {
    if (fs.existsSync(distClientDir)) {
      const clientEntries = fs.readdirSync(distClientDir, { withFileTypes: true });
      for (const entry of clientEntries) {
        const srcPath = path.join(distClientDir, entry.name);
        const destPath = path.join(distDir, entry.name);
        fs.cpSync(srcPath, destPath, { recursive: true, force: true });
      }
    }

    const distEntries = fs.readdirSync(distDir, { withFileTypes: true });
    for (const entry of distEntries) {
      if (entry.name === "client" || entry.name === "server" || entry.name === "nitro.json") {
        continue;
      }
      const srcPath = path.join(distDir, entry.name);
      const destPath = path.join(distClientDir, entry.name);
      fs.cpSync(srcPath, destPath, { recursive: true, force: true });
    }
  } catch (err) {
    console.warn("[postbuild] Warning while syncing client assets:", err);
  }

  // 6. Ensure _redirects is present in both dist and dist/client for Netlify SSR routing
  const redirectRule = "/*  /.netlify/functions/server  200\n";
  const distRedirects = path.join(distDir, "_redirects");
  const distClientRedirects = path.join(distClientDir, "_redirects");

  fs.writeFileSync(distRedirects, redirectRule, "utf8");
  fs.writeFileSync(distClientRedirects, redirectRule, "utf8");

  console.log("[postbuild] Successfully prepared Netlify deployment assets.");
} else {
  console.log("[postbuild] Running Cloudflare / standard deployment asset preparation...");

  // For Cloudflare Pages, if client directory exists inside dist, copy any missing root assets
  if (fs.existsSync(distClientDir) && fs.existsSync(distDir)) {
    try {
      const clientEntries = fs.readdirSync(distClientDir, { withFileTypes: true });
      for (const entry of clientEntries) {
        const destPath = path.join(distDir, entry.name);
        if (!fs.existsSync(destPath)) {
          const srcPath = path.join(distClientDir, entry.name);
          fs.cpSync(srcPath, destPath, { recursive: true, force: true });
        }
      }
    } catch (err) {
      console.warn("[postbuild] Warning while syncing Cloudflare assets:", err);
    }
  }

  console.log("[postbuild] Successfully prepared Cloudflare Pages / dist assets.");
}
