import { recordAuditLog } from "@/lib/audit-logs.functions";
import type { AuditActionType } from "@/lib/audit-logs.types";

interface LogActivityParams {
  action: AuditActionType;
  details: string;
  targetId?: string;
  targetName?: string;
  factoryId?: string | null;
  factoryName?: string | null;
  metadata?: Record<string, unknown>;
}

/**
 * Dispatches an audit log entry to the server in the background.
 * Fails silently so it never interrupts the user's primary workflow.
 */
export async function logActivity(params: LogActivityParams): Promise<void> {
  try {
    // Non-blocking fire-and-forget
    recordAuditLog({
      data: {
        action: params.action,
        details: params.details,
        targetId: params.targetId,
        targetName: params.targetName,
        factoryId: params.factoryId ?? null,
        factoryName: params.factoryName ?? null,
        metadata: params.metadata,
      },
    }).catch((err) => {
      console.warn("[AuditLogger] Failed to record audit log:", err);
    });
  } catch (err) {
    console.warn("[AuditLogger] Error triggering audit log:", err);
  }
}
