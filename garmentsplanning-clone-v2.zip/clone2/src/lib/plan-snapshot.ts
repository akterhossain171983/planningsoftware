import type { PlanResult } from "./plan-calc";

export type PlanLineSnapshot = {
  name: string;
  firstOutput: string;
  lastOutput: string;
  startDate: string;
};

export type PlanSnapshot = {
  savedAt: string;
  finishDate: string;
  lines: PlanLineSnapshot[];
};

export function buildPlanSnapshot(calc: PlanResult | null | undefined): PlanSnapshot | null {
  if (!calc) return null;
  const lines: PlanLineSnapshot[] = (calc.lines ?? []).map((l) => {
    const daily = l.dailyProduction ?? [];
    return {
      name: l.name,
      startDate: l.startDateStr ?? "",
      firstOutput: daily.length ? daily[0].date : (l.startDateStr ?? ""),
      lastOutput: l.finishDateStr ?? (daily.length ? daily[daily.length - 1].date : ""),
    };
  });
  return {
    savedAt: new Date().toISOString(),
    finishDate: calc.finishDate ?? "",
    lines,
  };
}

export function daysBetween(a: string, b: string): number {
  if (!a || !b) return 0;
  return Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400000);
}
