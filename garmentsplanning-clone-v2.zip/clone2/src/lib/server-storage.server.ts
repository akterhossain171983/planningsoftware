import * as fs from "node:fs/promises";
import * as path from "node:path";
import { SUPER_ADMIN_EMAIL } from "@/lib/permissions.types";
import type { AuditLogEntry } from "@/lib/audit-logs.types";

const getBaseDir = () => {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd();
  }
  return ".";
};

const PERMS_FILE = path.join(getBaseDir(), "data", "work_permissions.json");
const SUPER_ADMINS_FILE = path.join(getBaseDir(), "data", "super_admins.json");
const AUDIT_FILE = path.join(getBaseDir(), "data", "audit_logs.json");
const MAX_LOG_ENTRIES = 1200;

// Permissions file helpers
export async function loadPermissionsFromDisk(): Promise<Record<string, Record<string, boolean>>> {
  try {
    const raw = await fs.readFile(PERMS_FILE, "utf-8");
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

export async function savePermissionsToDisk(
  data: Record<string, Record<string, boolean>>,
): Promise<void> {
  try {
    await fs.mkdir(path.dirname(PERMS_FILE), { recursive: true });
    await fs.writeFile(PERMS_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save permissions to disk:", err);
  }
}

// Super Admins file helpers
export async function loadSuperAdminsFromDisk(): Promise<string[]> {
  try {
    const raw = await fs.readFile(SUPER_ADMINS_FILE, "utf-8");
    const parsed = JSON.parse(raw);
    const list = Array.isArray(parsed) ? parsed : [];
    const set = new Set(list.map((s: string) => s.toLowerCase().trim()));
    set.add(SUPER_ADMIN_EMAIL.toLowerCase());
    set.add("akterplanning83");
    return Array.from(set);
  } catch {
    return [SUPER_ADMIN_EMAIL.toLowerCase(), "akterplanning83"];
  }
}

export async function saveSuperAdminsToDisk(list: string[]): Promise<void> {
  try {
    await fs.mkdir(path.dirname(SUPER_ADMINS_FILE), { recursive: true });
    const set = new Set(list.map((s: string) => s.toLowerCase().trim()));
    set.add(SUPER_ADMIN_EMAIL.toLowerCase());
    set.add("akterplanning83");
    await fs.writeFile(SUPER_ADMINS_FILE, JSON.stringify(Array.from(set), null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save super admins to disk:", err);
  }
}

export async function writeSuperAdminsDirect(list: string[]): Promise<void> {
  try {
    await fs.mkdir(path.dirname(SUPER_ADMINS_FILE), { recursive: true });
    await fs.writeFile(SUPER_ADMINS_FILE, JSON.stringify(list, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to direct write super admins to disk:", err);
  }
}

// Audit Logs file helpers
export async function readAuditLogsFromDisk(): Promise<AuditLogEntry[]> {
  try {
    const raw = await fs.readFile(AUDIT_FILE, "utf-8");
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export async function writeAuditLogsToDisk(entries: AuditLogEntry[]): Promise<void> {
  try {
    await fs.mkdir(path.dirname(AUDIT_FILE), { recursive: true });
    const trimmed = entries.slice(0, MAX_LOG_ENTRIES);
    await fs.writeFile(AUDIT_FILE, JSON.stringify(trimmed, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write audit logs to disk:", err);
  }
}
