import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "./use-current-user";

const LS_KEY = "cg:line-presets";
const DEFAULT_LINE_PRESETS = [
  ...Array.from({ length: 21 }, (_, i) => `Line - ${i + 15}`),
  "Line - A",
  "Line - B",
  "Line - C",
  "Line - D",
  "Line - E",
  "Line - F",
  "Line - G",
  "Line - H",
  "Line - I",
  "Line - J",
  "Line - K",
  "Line - L",
  "Line - M",
  "Line - N",
  "Line - O",
  "Line - P",
  "Line - Q",
  "Line - R",
  "Line - S",
];

function readCache(): string[] {
  if (typeof window === "undefined") return DEFAULT_LINE_PRESETS;
  try {
    const raw = window.localStorage.getItem(LS_KEY);
    if (!raw) return DEFAULT_LINE_PRESETS;
    const arr = JSON.parse(raw);
    if (Array.isArray(arr) && arr.every((x) => typeof x === "string") && arr.length) {
      return arr;
    }
  } catch {
    /* noop */
  }
  return DEFAULT_LINE_PRESETS;
}

function writeCache(list: string[]) {
  try {
    window.localStorage.setItem(LS_KEY, JSON.stringify(list));
  } catch {
    /* noop */
  }
}

/**
 * Shared, factory-scoped line presets stored in `public.line_presets`.
 * Falls back to localStorage cache so first paint is instant.
 */
export function useLinePresets() {
  const { data: user } = useCurrentUser();
  const [presets, setPresetsState] = useState<string[]>(() => readCache());
  const [loaded, setLoaded] = useState(false);

  // Fetch shared presets for the user's factory
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data: prof } = await supabase
        .from("profiles")
        .select("factory_id")
        .eq("id", user?.id ?? "")
        .maybeSingle();
      const factoryId = prof?.factory_id;
      if (!factoryId) {
        setLoaded(true);
        return;
      }
      const { data } = await supabase
        .from("line_presets")
        .select("presets")
        .eq("factory_id", factoryId)
        .maybeSingle();
      if (cancelled) return;
      if (data?.presets && data.presets.length) {
        setPresetsState(data.presets);
        writeCache(data.presets);
      }
      setLoaded(true);
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  // Realtime sync so other users see changes live
  useEffect(() => {
    const channel = supabase
      .channel("line_presets-watch")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "line_presets" },
        (payload) => {
          const row = payload.new as { presets?: string[] } | null;
          if (row?.presets && Array.isArray(row.presets)) {
            setPresetsState(row.presets);
            writeCache(row.presets);
          }
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const setPresets = useCallback(
    async (next: string[] | ((prev: string[]) => string[])) => {
      const resolved =
        typeof next === "function" ? (next as (p: string[]) => string[])(presets) : next;
      setPresetsState(resolved);
      writeCache(resolved);

      if (!user?.id) return;
      const { data: prof } = await supabase
        .from("profiles")
        .select("factory_id")
        .eq("id", user.id)
        .maybeSingle();
      const factoryId = prof?.factory_id;
      if (!factoryId) return; // no factory → local-only
      await supabase
        .from("line_presets")
        .upsert(
          { factory_id: factoryId, presets: resolved, updated_by: user.id },
          { onConflict: "factory_id" },
        );
    },
    [presets, user?.id],
  );

  return { presets, setPresets, loaded };
}

export { DEFAULT_LINE_PRESETS };
