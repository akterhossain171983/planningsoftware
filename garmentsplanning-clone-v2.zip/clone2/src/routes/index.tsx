import { createFileRoute, redirect, isRedirect } from "@tanstack/react-router";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  ssr: false,
  beforeLoad: async () => {
    try {
      const { data } = await supabase.auth.getSession();
      if (data?.session) {
        throw redirect({ to: "/app" });
      }
    } catch (err) {
      if (isRedirect(err)) throw err;
      console.warn("Session check error on root route, redirecting to /auth:", err);
    }
    throw redirect({ to: "/auth" });
  },
  component: Index,
});

function Index() {
  useEffect(() => {}, []);
  return null;
}
