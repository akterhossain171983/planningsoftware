// This file gates every route under /_authenticated/*.
// It is client-only (`ssr: false`) because Supabase stores the session in
// localStorage. See tanstack-supabase-integration.
import { createFileRoute, Outlet, redirect, isRedirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async ({ location }) => {
    // If the user tries to access the pathless layout segment directly (e.g. /_authenticated/app),
    // redirect them to the actual canonical path.
    if (location.pathname === "/_authenticated/app") {
      throw redirect({ to: "/app" });
    }

    try {
      const { data, error } = await supabase.auth.getUser();
      if (error || !data?.user) throw redirect({ to: "/auth" });
      return { user: data.user };
    } catch (err) {
      if (isRedirect(err)) throw err;
      console.warn("Auth check failed in _authenticated layout, redirecting to /auth:", err);
      throw redirect({ to: "/auth" });
    }
  },
  component: () => <Outlet />,
});
