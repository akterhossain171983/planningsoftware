import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Component, type ReactNode, type ErrorInfo, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/hooks/use-current-user";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  RefreshCw,
  LogOut,
  Shield,
  Loader2,
  ListChecks,
  Grid3x3,
  Clock,
  CalendarRange,
  FileText,
  Factory,
  LayoutGrid,
  GaugeCircle,
  Scissors,
  Timer,
  TrendingUp,
  ArrowLeftRight,
  PackageCheck,
  History,
  PanelLeftClose,
  PanelLeftOpen,
  ClipboardList,
  Layers,
  PackageOpen,
  ListOrdered,
} from "lucide-react";
import { PlanInputForm } from "@/components/planning/PlanInputForm";
import { UnplannedOrdersView } from "@/components/planning/UnplannedOrdersView";
import { MatrixView } from "@/components/planning/MatrixView";
import { LineOpenDaysView } from "@/components/planning/LineOpenDaysView";
import { FreeSlotsView } from "@/components/planning/FreeSlotsView";
import { LineSummaryView } from "@/components/planning/LineSummaryView";
import { ProductionUpdateView } from "@/components/planning/ProductionUpdateView";
import { PlanBoardView } from "@/components/planning/PlanBoardView";
import { StyleLinesSummaryView } from "@/components/planning/StyleLinesSummaryView";
import { LineAllocationView } from "@/components/planning/LineAllocationView";
import { EarlyDelayView } from "@/components/planning/EarlyDelayView";
import { FriPlanView } from "@/components/planning/FriPlanView";
import { WorkingHoursView } from "@/components/planning/WorkingHoursView";
import { EfficiencyView } from "@/components/planning/EfficiencyView";
import { ShiftTrackerView } from "@/components/planning/ShiftTrackerView";
import { CompleteOrderView } from "@/components/planning/CompleteOrderView";
import { RevisionHistoryView } from "@/components/planning/RevisionHistoryView";
import { BuyerMonthlyView } from "@/components/planning/BuyerMonthlyView";
import MonthlyBudgetView from "@/components/planning/MonthlyBudgetView";
import { AdminPanel } from "@/components/admin/AdminPanel";

export const Route = createFileRoute("/_authenticated/app")({
  head: () => ({
    meta: [{ title: "ড্যাশবোর্ড — Cloud Garments ERP" }],
  }),
  component: AppShell,
});

type Tab =
  | "input"
  | "unplanned"
  | "allocation"
  | "matrix"
  | "buyermonthly"
  | "budget"
  | "open"
  | "free"
  | "summary"
  | "production"
  | "board"
  | "stylelines"
  | "earlydelay"
  | "fri"
  | "hours"
  | "efficiency"
  | "shift"
  | "complete"
  | "revisions";

interface TabErrorBoundaryProps {
  children: ReactNode;
  tabKey: string;
}

interface TabErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class TabErrorBoundary extends Component<TabErrorBoundaryProps, TabErrorBoundaryState> {
  constructor(props: TabErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): TabErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("[TabErrorBoundary] Error caught in tab:", this.props.tabKey, error, info);
  }

  componentDidUpdate(prevProps: TabErrorBoundaryProps) {
    if (prevProps.tabKey !== this.props.tabKey && this.state.hasError) {
      this.setState({ hasError: false, error: null });
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-8 max-w-xl mx-auto my-12 rounded-2xl border border-destructive/40 bg-panel shadow-2xl text-center space-y-4">
          <div className="w-14 h-14 mx-auto rounded-full bg-destructive/10 text-destructive flex items-center justify-center border border-destructive/20">
            <AlertTriangle className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-foreground">
              এই পৃষ্ঠাটি লোড হতে সমস্যা হয়েছে
            </h3>
            <p className="text-xs text-muted-foreground mt-1 max-w-md mx-auto">
              {this.state.error?.message ||
                "একটি অনাকাঙ্ক্ষিত এরর ঘটেছে। অনুগ্রহ করে পুনরায় চেষ্টা করুন।"}
            </p>
          </div>
          <button
            onClick={() => this.setState({ hasError: false, error: null })}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/20 transition cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" /> পুনরায় চেষ্টা করুন
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

function AppShell() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: user, isLoading } = useCurrentUser();
  const [tab, setTab] = useState<Tab>("input");
  const [systemLocked, setSystemLocked] = useState<boolean | null>(null);
  const [adminOpen, setAdminOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const [pendingEditId, setPendingEditId] = useState<string | null>(null);

  useEffect(() => {
    const onEdit = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      const id = typeof detail === "string" ? detail : detail?.id;
      if (!id) return;
      setTab("input");
      setPendingEditId(id);
    };
    window.addEventListener("cg:edit-plan", onEdit as EventListener);
    return () => window.removeEventListener("cg:edit-plan", onEdit as EventListener);
  }, []);

  useEffect(() => {
    const onSwitch = (e: Event) => {
      const target = (e as CustomEvent).detail;
      if (typeof target === "string") setTab(target as Tab);
    };
    window.addEventListener("cg:switch-tab", onSwitch as EventListener);
    return () => window.removeEventListener("cg:switch-tab", onSwitch as EventListener);
  }, []);

  useEffect(() => {
    let mounted = true;
    supabase
      .from("system_settings")
      .select("locked")
      .eq("id", 1)
      .maybeSingle()
      .then(({ data }) => mounted && setSystemLocked(!!data?.locked));
    const channel = supabase
      .channel("system_settings-watch")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "system_settings" },
        (payload) => {
          const row = payload.new as { locked?: boolean } | null;
          if (row && typeof row.locked === "boolean") setSystemLocked(row.locked);
        },
      )
      .subscribe();
    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, []);

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    toast.success("লগ আউট হয়েছেন।");
    navigate({ to: "/auth", replace: true });
  }

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  const navItems: { key: Tab; label: string; icon: React.ReactNode; activeClass: string }[] = [
    {
      key: "input",
      label: "প্ল্যান ইনপুট",
      icon: <ListChecks className="w-4 h-4" />,
      activeClass: "bg-primary text-primary-foreground",
    },
    {
      key: "unplanned",
      label: "আনপ্ল্যান্ড অর্ডার",
      icon: <PackageOpen className="w-4 h-4" />,
      activeClass: "bg-amber-600 text-white",
    },
    {
      key: "allocation",
      label: "Line Allocation",
      icon: <Layers className="w-4 h-4" />,
      activeClass: "bg-blue-600 text-white",
    },
    {
      key: "matrix",
      label: "ম্যাট্রিক্স ভিউ",
      icon: <Grid3x3 className="w-4 h-4" />,
      activeClass: "bg-emerald-600 text-white",
    },
    {
      key: "buyermonthly",
      label: "Buyer × Season",
      icon: <ClipboardList className="w-4 h-4" />,
      activeClass: "bg-cyan-700 text-white",
    },
    {
      key: "budget",
      label: "Monthly Budget",
      icon: <TrendingUp className="w-4 h-4" />,
      activeClass: "bg-amber-700 text-white",
    },
    {
      key: "open",
      label: "Line Open Days",
      icon: <Clock className="w-4 h-4" />,
      activeClass: "bg-amber-600 text-white",
    },
    {
      key: "free",
      label: "Free Slots",
      icon: <CalendarRange className="w-4 h-4" />,
      activeClass: "bg-sky-600 text-white",
    },
    {
      key: "summary",
      label: "Line Summary",
      icon: <FileText className="w-4 h-4" />,
      activeClass: "bg-indigo-600 text-white",
    },
    {
      key: "production",
      label: "Production Update",
      icon: <Factory className="w-4 h-4" />,
      activeClass: "bg-rose-600 text-white",
    },
    {
      key: "board",
      label: "Plan Board",
      icon: <LayoutGrid className="w-4 h-4" />,
      activeClass: "bg-fuchsia-600 text-white",
    },
    {
      key: "stylelines",
      label: "Style Lines Summary",
      icon: <ListOrdered className="w-4 h-4" />,
      activeClass: "bg-teal-600 text-white",
    },
    {
      key: "earlydelay",
      label: "Early/Delay",
      icon: <GaugeCircle className="w-4 h-4" />,
      activeClass: "bg-orange-600 text-white",
    },
    {
      key: "fri",
      label: "FRI Plan",
      icon: <Scissors className="w-4 h-4" />,
      activeClass: "bg-cyan-600 text-white",
    },
    {
      key: "hours",
      label: "Working Hours",
      icon: <Timer className="w-4 h-4" />,
      activeClass: "bg-teal-600 text-white",
    },
    {
      key: "efficiency",
      label: "Efficiency",
      icon: <TrendingUp className="w-4 h-4" />,
      activeClass: "bg-purple-600 text-white",
    },
    {
      key: "shift",
      label: "Shift Tracker",
      icon: <ArrowLeftRight className="w-4 h-4" />,
      activeClass: "bg-pink-600 text-white",
    },
    {
      key: "complete",
      label: "Complete Order",
      icon: <PackageCheck className="w-4 h-4" />,
      activeClass: "bg-emerald-700 text-white",
    },
    {
      key: "revisions",
      label: "Revision History",
      icon: <History className="w-4 h-4" />,
      activeClass: "bg-slate-600 text-white",
    },
  ];

  return (
    <div className="min-h-screen flex w-full">
      <aside
        className={`${sidebarOpen ? "w-60" : "w-14"} shrink-0 border-r border-border bg-panel/80 backdrop-blur sticky top-0 h-screen overflow-y-auto transition-all duration-200`}
      >
        <div className="flex items-center justify-between px-3 py-3 border-b border-border">
          {sidebarOpen && (
            <div className="min-w-0">
              <div className="text-sm font-extrabold bn-gradient-text leading-tight truncate">
                ☁️ Cloud ERP
              </div>
              <div className="text-[10px] text-muted-foreground truncate">PPC &amp; Matrix</div>
            </div>
          )}
          <button
            onClick={() => setSidebarOpen((v) => !v)}
            className="p-1.5 rounded-md hover:bg-panel-2 text-muted-foreground"
            title={sidebarOpen ? "সাইডবার ছোট করুন" : "সাইডবার বড় করুন"}
          >
            {sidebarOpen ? (
              <PanelLeftClose className="w-4 h-4" />
            ) : (
              <PanelLeftOpen className="w-4 h-4" />
            )}
          </button>
        </div>

        <nav className="p-2 flex flex-col gap-1">
          {navItems.map((item) => {
            const active = tab === item.key;
            return (
              <button
                key={item.key}
                onClick={() => setTab(item.key)}
                title={item.label}
                className={`inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold shadow-sm transition border text-left ${
                  active
                    ? `${item.activeClass} border-transparent`
                    : "bg-transparent hover:bg-panel-2 text-muted-foreground border-transparent"
                } ${sidebarOpen ? "" : "justify-center px-2"}`}
              >
                {item.icon}
                {sidebarOpen && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}

          {(user.role === "admin" || user.isSuperAdmin) && (
            <button
              onClick={() => setAdminOpen(true)}
              title="অ্যাডমিন প্যানেল"
              className={`inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold shadow-sm transition border text-left mt-2 bg-gradient-to-r from-purple-950/60 to-indigo-950/60 text-purple-200 border-purple-500/40 hover:from-purple-900/60 hover:to-indigo-900/60 ${
                sidebarOpen ? "" : "justify-center px-2"
              }`}
            >
              <Shield className="w-4 h-4 text-purple-400 shrink-0" />
              {sidebarOpen && <span className="truncate font-extrabold">অ্যাডমিন প্যানেল</span>}
            </button>
          )}
        </nav>
      </aside>

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-30 border-b border-border bg-panel/80 backdrop-blur">
          <div className="px-4 md:px-6 py-3 flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <h1 className="text-lg md:text-xl font-extrabold bn-gradient-text leading-tight truncate">
                ☁️ Cloud Garments ERP
              </h1>
              <p className="text-[11px] text-muted-foreground">
                PPC &amp; Matrix — রিয়েল-টাইম ক্লাউড
              </p>
            </div>

            <div className="hidden sm:flex items-center gap-2 rounded-xl border border-border/80 bg-input/80 backdrop-blur px-3 py-1.5 shadow-sm">
              <div className="text-right">
                <div className="text-xs font-bold text-foreground flex items-center justify-end gap-1.5">
                  {user.isSuperAdmin && <span className="text-amber-400">👑</span>}
                  <span>{user.username}</span>
                </div>
                <div className="text-[10px] text-muted-foreground tracking-wide flex items-center justify-end gap-1">
                  <span className={user.isSuperAdmin ? "text-purple-300 font-extrabold" : ""}>
                    {user.isSuperAdmin
                      ? "👑 সুপার অ্যাডমিন"
                      : user.role === "admin"
                        ? "👑 অ্যাডমিন"
                        : user.role === "team_leader"
                          ? "🎯 টিম লিডার"
                          : "👤 ইউজার"}
                  </span>
                  {user.factoryName && (
                    <span className="text-slate-400 font-semibold">• 🏢 {user.factoryName}</span>
                  )}
                </div>
              </div>
            </div>

            {(user.role === "admin" || user.isSuperAdmin) && (
              <button
                onClick={() => setAdminOpen(true)}
                title="অ্যাডমিন প্যানেল"
                className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-indigo-700 px-3 py-1.5 md:px-3.5 md:py-2 text-xs font-extrabold text-white shadow-lg shadow-purple-600/20 hover:opacity-95 transition"
              >
                <Shield className="w-3.5 h-3.5 text-amber-300" />
                <span className="hidden sm:inline">অ্যাডমিন প্যানেল</span>
              </button>
            )}

            <button
              onClick={handleSignOut}
              className="inline-flex items-center gap-1.5 rounded-xl border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs font-bold text-red-300 hover:bg-destructive hover:text-white transition"
            >
              <LogOut className="w-3.5 h-3.5" /> লগ আউট
            </button>
          </div>

          {systemLocked && user.role === "admin" && (
            <div className="border-t border-destructive/40 bg-destructive/10 text-center py-1.5 text-[11px] font-bold text-red-300">
              🔒 সিস্টেম বর্তমানে লক করা — শুধুমাত্র অ্যাডমিন অ্যাক্সেস করতে পারছেন।
            </div>
          )}
        </header>

        <main className={`flex-1 w-full px-3 md:px-6 ${tab === "board" ? "py-2" : "py-6"}`}>
          <TabErrorBoundary tabKey={tab}>
            {tab === "input" ? (
              <PlanInputForm
                pendingEditId={pendingEditId}
                onConsumePendingEdit={() => setPendingEditId(null)}
              />
            ) : tab === "unplanned" ? (
              <UnplannedOrdersView
                onPlanOrder={(id) => {
                  setTab("input");
                  setPendingEditId(id);
                }}
              />
            ) : tab === "allocation" ? (
              <LineAllocationView onSwitchTab={(t) => setTab(t as Tab)} />
            ) : tab === "matrix" ? (
              <MatrixView />
            ) : tab === "buyermonthly" ? (
              <BuyerMonthlyView />
            ) : tab === "budget" ? (
              <MonthlyBudgetView />
            ) : tab === "open" ? (
              <LineOpenDaysView />
            ) : tab === "free" ? (
              <FreeSlotsView />
            ) : tab === "summary" ? (
              <LineSummaryView />
            ) : tab === "production" ? (
              <ProductionUpdateView />
            ) : tab === "board" ? (
              <PlanBoardView />
            ) : tab === "stylelines" ? (
              <StyleLinesSummaryView />
            ) : tab === "earlydelay" ? (
              <EarlyDelayView />
            ) : tab === "fri" ? (
              <FriPlanView />
            ) : tab === "hours" ? (
              <WorkingHoursView />
            ) : tab === "efficiency" ? (
              <EfficiencyView />
            ) : tab === "shift" ? (
              <ShiftTrackerView />
            ) : tab === "complete" ? (
              <CompleteOrderView />
            ) : (
              <RevisionHistoryView />
            )}
          </TabErrorBoundary>
        </main>
      </div>

      <AdminPanel open={adminOpen} onClose={() => setAdminOpen(false)} />
    </div>
  );
}
