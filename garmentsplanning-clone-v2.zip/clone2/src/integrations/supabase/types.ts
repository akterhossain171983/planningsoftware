export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5";
  };
  public: {
    Tables: {
      budget_department_details: {
        Row: {
          actual_value: number | null;
          budget_value: number | null;
          cost_head: string;
          created_at: string | null;
          department: string;
          entry_date: string;
          factory_id: string;
          id: string;
          month: string;
          updated_at: string | null;
        };
        Insert: {
          actual_value?: number | null;
          budget_value?: number | null;
          cost_head: string;
          created_at?: string | null;
          department: string;
          entry_date?: string;
          factory_id: string;
          id?: string;
          month: string;
          updated_at?: string | null;
        };
        Update: {
          actual_value?: number | null;
          budget_value?: number | null;
          cost_head?: string;
          created_at?: string | null;
          department?: string;
          entry_date?: string;
          factory_id?: string;
          id?: string;
          month?: string;
          updated_at?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "budget_department_details_factory_id_fkey";
            columns: ["factory_id"];
            isOneToOne: false;
            referencedRelation: "factories";
            referencedColumns: ["id"];
          },
        ];
      };
      budget_floor_clusters: {
        Row: {
          cluster_name: string;
          created_at: string | null;
          factory_id: string;
          id: string;
          line_names: string[];
          updated_at: string | null;
        };
        Insert: {
          cluster_name: string;
          created_at?: string | null;
          factory_id: string;
          id?: string;
          line_names?: string[];
          updated_at?: string | null;
        };
        Update: {
          cluster_name?: string;
          created_at?: string | null;
          factory_id?: string;
          id?: string;
          line_names?: string[];
          updated_at?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "budget_floor_clusters_factory_id_fkey";
            columns: ["factory_id"];
            isOneToOne: false;
            referencedRelation: "factories";
            referencedColumns: ["id"];
          },
        ];
      };
      budget_line_details: {
        Row: {
          actual_value: number | null;
          budget_value: number | null;
          cost_head: string;
          created_at: string | null;
          entry_date: string;
          factory_id: string;
          id: string;
          line_name: string;
          month: string;
          updated_at: string | null;
        };
        Insert: {
          actual_value?: number | null;
          budget_value?: number | null;
          cost_head: string;
          created_at?: string | null;
          entry_date?: string;
          factory_id: string;
          id?: string;
          line_name: string;
          month: string;
          updated_at?: string | null;
        };
        Update: {
          actual_value?: number | null;
          budget_value?: number | null;
          cost_head?: string;
          created_at?: string | null;
          entry_date?: string;
          factory_id?: string;
          id?: string;
          line_name?: string;
          month?: string;
          updated_at?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "budget_line_details_factory_id_fkey";
            columns: ["factory_id"];
            isOneToOne: false;
            referencedRelation: "factories";
            referencedColumns: ["id"];
          },
        ];
      };
      factories: {
        Row: {
          created_at: string;
          id: string;
          name: string;
          updated_at: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          name: string;
          updated_at?: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          name?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      global_holidays: {
        Row: {
          created_at: string;
          created_by: string | null;
          date: string;
          label: string | null;
        };
        Insert: {
          created_at?: string;
          created_by?: string | null;
          date: string;
          label?: string | null;
        };
        Update: {
          created_at?: string;
          created_by?: string | null;
          date?: string;
          label?: string | null;
        };
        Relationships: [];
      };
      line_presets: {
        Row: {
          created_at: string;
          factory_id: string;
          id: string;
          presets: string[];
          updated_at: string;
          updated_by: string | null;
        };
        Insert: {
          created_at?: string;
          factory_id: string;
          id?: string;
          presets?: string[];
          updated_at?: string;
          updated_by?: string | null;
        };
        Update: {
          created_at?: string;
          factory_id?: string;
          id?: string;
          presets?: string[];
          updated_at?: string;
          updated_by?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "line_presets_factory_id_fkey";
            columns: ["factory_id"];
            isOneToOne: true;
            referencedRelation: "factories";
            referencedColumns: ["id"];
          },
        ];
      };
      monthly_budgets: {
        Row: {
          budget_amount: number;
          created_at: string | null;
          factory_id: string;
          id: string;
          month: string;
          updated_at: string | null;
        };
        Insert: {
          budget_amount?: number;
          created_at?: string | null;
          factory_id: string;
          id?: string;
          month: string;
          updated_at?: string | null;
        };
        Update: {
          budget_amount?: number;
          created_at?: string | null;
          factory_id?: string;
          id?: string;
          month?: string;
          updated_at?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "monthly_budgets_factory_id_fkey";
            columns: ["factory_id"];
            isOneToOne: false;
            referencedRelation: "factories";
            referencedColumns: ["id"];
          },
        ];
      };
      plan_notes: {
        Row: {
          created_at: string;
          created_by: string;
          id: string;
          note: string;
          note_date: string;
          plan_id: string;
          updated_at: string;
        };
        Insert: {
          created_at?: string;
          created_by: string;
          id?: string;
          note: string;
          note_date?: string;
          plan_id: string;
          updated_at?: string;
        };
        Update: {
          created_at?: string;
          created_by?: string;
          id?: string;
          note?: string;
          note_date?: string;
          plan_id?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "plan_notes_plan_id_fkey";
            columns: ["plan_id"];
            isOneToOne: false;
            referencedRelation: "plans";
            referencedColumns: ["id"];
          },
        ];
      };
      plan_revisions: {
        Row: {
          buyer: string | null;
          created_at: string;
          created_by: string | null;
          finish_date: string | null;
          id: string;
          lines: Json;
          plan_id: string;
          revision_no: number;
          style: string | null;
        };
        Insert: {
          buyer?: string | null;
          created_at?: string;
          created_by?: string | null;
          finish_date?: string | null;
          id?: string;
          lines?: Json;
          plan_id: string;
          revision_no: number;
          style?: string | null;
        };
        Update: {
          buyer?: string | null;
          created_at?: string;
          created_by?: string | null;
          finish_date?: string | null;
          id?: string;
          lines?: Json;
          plan_id?: string;
          revision_no?: number;
          style?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "plan_revisions_plan_id_fkey";
            columns: ["plan_id"];
            isOneToOne: false;
            referencedRelation: "plans";
            referencedColumns: ["id"];
          },
        ];
      };
      plans: {
        Row: {
          buyer: string;
          calc_result: Json;
          completed_at: string | null;
          config: Json;
          created_at: string;
          created_by: string;
          daily_target: number;
          excess_pct: number;
          factory_id: string | null;
          id: string;
          num_lines: number;
          order_qty: number;
          previous_snapshot: Json | null;
          season: string | null;
          shipment_date: string;
          style: string;
          team_leader_id: string | null;
          updated_at: string;
        };
        Insert: {
          buyer: string;
          calc_result?: Json;
          completed_at?: string | null;
          config?: Json;
          created_at?: string;
          created_by: string;
          daily_target: number;
          excess_pct?: number;
          factory_id?: string | null;
          id?: string;
          num_lines: number;
          order_qty: number;
          previous_snapshot?: Json | null;
          season?: string | null;
          shipment_date: string;
          style: string;
          team_leader_id?: string | null;
          updated_at?: string;
        };
        Update: {
          buyer?: string;
          calc_result?: Json;
          completed_at?: string | null;
          config?: Json;
          created_at?: string;
          created_by?: string;
          daily_target?: number;
          excess_pct?: number;
          factory_id?: string | null;
          id?: string;
          num_lines?: number;
          order_qty?: number;
          previous_snapshot?: Json | null;
          season?: string | null;
          shipment_date?: string;
          style?: string;
          team_leader_id?: string | null;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "plans_factory_id_fkey";
            columns: ["factory_id"];
            isOneToOne: false;
            referencedRelation: "factories";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "plans_team_leader_id_fkey";
            columns: ["team_leader_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      production_updates: {
        Row: {
          actual_qty: number;
          created_at: string;
          created_by: string | null;
          id: string;
          line_name: string;
          plan_id: string;
          remarks: string | null;
          update_date: string;
          updated_at: string;
        };
        Insert: {
          actual_qty?: number;
          created_at?: string;
          created_by?: string | null;
          id?: string;
          line_name: string;
          plan_id: string;
          remarks?: string | null;
          update_date: string;
          updated_at?: string;
        };
        Update: {
          actual_qty?: number;
          created_at?: string;
          created_by?: string | null;
          id?: string;
          line_name?: string;
          plan_id?: string;
          remarks?: string | null;
          update_date?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "production_updates_plan_id_fkey";
            columns: ["plan_id"];
            isOneToOne: false;
            referencedRelation: "plans";
            referencedColumns: ["id"];
          },
        ];
      };
      profiles: {
        Row: {
          active: boolean;
          created_at: string;
          factory_id: string | null;
          id: string;
          team_leader_id: string | null;
          updated_at: string;
          username: string;
        };
        Insert: {
          active?: boolean;
          created_at?: string;
          factory_id?: string | null;
          id: string;
          team_leader_id?: string | null;
          updated_at?: string;
          username: string;
        };
        Update: {
          active?: boolean;
          created_at?: string;
          factory_id?: string | null;
          id?: string;
          team_leader_id?: string | null;
          updated_at?: string;
          username?: string;
        };
        Relationships: [
          {
            foreignKeyName: "profiles_factory_id_fkey";
            columns: ["factory_id"];
            isOneToOne: false;
            referencedRelation: "factories";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "profiles_team_leader_id_fkey";
            columns: ["team_leader_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      system_settings: {
        Row: {
          id: number;
          locked: boolean;
          updated_at: string;
        };
        Insert: {
          id?: number;
          locked?: boolean;
          updated_at?: string;
        };
        Update: {
          id?: number;
          locked?: boolean;
          updated_at?: string;
        };
        Relationships: [];
      };
      user_roles: {
        Row: {
          id: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Insert: {
          id?: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Update: {
          id?: string;
          role?: Database["public"]["Enums"]["app_role"];
          user_id?: string;
        };
        Relationships: [];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"];
          _user_id: string;
        };
        Returns: boolean;
      };
      same_team: { Args: { _a: string; _b: string }; Returns: boolean };
    };
    Enums: {
      app_role: "admin" | "manager" | "team_leader" | "user";
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    keyof DefaultSchema["Enums"] | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    keyof DefaultSchema["CompositeTypes"] | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "manager", "team_leader", "user"],
    },
  },
} as const;
