import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Loader2,
  Save,
  FileDown,
  FileUp,
  Download,
  AlertCircle,
  Table as TableIcon,
  Check,
  Clock,
  Sparkles,
  Scissors,
  ArrowRight,
  Shirt,
  Droplets,
  PackageCheck,
  ChevronDown,
  ChevronUp,
  CheckSquare,
  Square,
  Layers,
  X,
  Edit3,
  HelpCircle,
  Pin,
  Maximize2,
} from "lucide-react";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import { formatDate, type PlanResult } from "@/lib/plan-calc";
import { FilterSelect } from "./LineSummaryView";
import { useLinePresets } from "@/hooks/use-line-presets";
import { buildLinePresetLookup, canonicalLineName, uniqueCanonicalLineNames } from "./lineLookup";

export type PlanRow = {
  id: string;
  buyer: string;
  style: string;
  season: string | null;
  order_qty: number;
  shipment_date: string;
  calc_result: PlanResult;
  config?: any;
};

export type UpdateRow = {
  id: string;
  plan_id: string;
  line_name: string;
  update_date: string;
  actual_qty: number;
  remarks: string | null;
};

export type ProductionTrackingDetails = {
  po?: string;
  color?: string;
  size?: string;
  block?: string;
  orderQty?: number;
  poShipDate?: string;
  proposedDate?: string;
  dayCutting?: number;
  dayInput?: number;
  dayOutput?: number; // matches actual_qty (Day Output / Day Sewing)
  dayWashSent?: number;
  dayWashRcvd?: number;
  dayFinishingLotPass?: number;
  dayPoly?: number;
  dayPack?: number;
  dayDfiOffer?: number;
  dayDfiPass?: number;
  friDoneQty?: number;
};

export type EntryRow = {
  planId: string;
  buyer: string;
  style: string;
  season: string;
  line: string;
  rawLine: string;
  plannedQty: number;
  cumulativePlanned: number;
  existingId: string | null;
  originalActualQty: number | null;
  originalRemarks: string | null;
  dirty: boolean;

  // Granular production tracking fields
  po: string;
  color: string;
  size: string;
  block: string;
  orderQty: number;
  poShipDate: string;
  proposedDate: string;
  dayCutting: number;
  dayInput: number;
  dayOutput: number; // day output / sewing actual
  dayWashSent: number;
  dayWashRcvd: number;
  dayFinishingLotPass: number;
  dayPoly: number;
  dayPack: number;
  dayDfiOffer: number;
  dayDfiPass: number;
  friDoneQty: number;
  remarks: string;

  // Cumulative quantities across all dates for this plan & line
  totalCutting: number;
  totalInput: number;
  totalOutput: number;
  totalWashSent: number;
  totalPack: number;
};

function todayStr() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

// Parses JSON or key-value from remarks safely
function parseTrackingDetails(remarksStr: string | null | undefined): {
  details: ProductionTrackingDetails;
  userRemarks: string;
} {
  const empty: ProductionTrackingDetails = {};
  if (!remarksStr) return { details: empty, userRemarks: "" };

  const trimmed = remarksStr.trim();
  if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
    try {
      const parsed = JSON.parse(trimmed);
      const userRemarks = parsed._userRemarks || parsed.remarks || "";
      delete parsed._userRemarks;
      return { details: parsed, userRemarks };
    } catch {
      // not pure JSON, fall back
    }
  }

  const tagMatch = trimmed.match(/^\[PROD_DETAILS:(.*?)\]\s*(.*)$/s);
  if (tagMatch) {
    try {
      const parsed = JSON.parse(tagMatch[1]);
      return { details: parsed, userRemarks: tagMatch[2] || "" };
    } catch {
      // continue
    }
  }

  return { details: empty, userRemarks: trimmed };
}

function serializeRemarks(details: ProductionTrackingDetails, userRemarks: string): string {
  const cleaned: Record<string, any> = {};
  let hasData = false;

  const keys: (keyof ProductionTrackingDetails)[] = [
    "po",
    "color",
    "size",
    "block",
    "orderQty",
    "poShipDate",
    "proposedDate",
    "dayCutting",
    "dayInput",
    "dayOutput",
    "dayWashSent",
    "dayWashRcvd",
    "dayFinishingLotPass",
    "dayPoly",
    "dayPack",
    "dayDfiOffer",
    "dayDfiPass",
    "friDoneQty",
  ];

  for (const k of keys) {
    const val = details[k];
    if (val !== undefined && val !== "" && val !== 0 && !Number.isNaN(val)) {
      cleaned[k] = val;
      hasData = true;
    }
  }

  if (!hasData && !userRemarks.trim()) {
    return "";
  }

  if (hasData) {
    cleaned._userRemarks = userRemarks.trim();
    return JSON.stringify(cleaned);
  }

  return userRemarks.trim();
}

/**
 * Visual Progress Stepper Component:
 * Stages: Cutting -> Input -> Output -> Wash -> Pack
 * Displays percentage completed relative to target/order quantity,
 * color codes (Completed=Emerald, In Progress=Blue/Amber, Pending=Muted),
 * and an interactive expanded details tooltip.
 */
function ProductionProgressStepper({ row, compact = false }: { row: EntryRow; compact?: boolean }) {
  const targetQty =
    row.orderQty > 0
      ? row.orderQty
      : row.cumulativePlanned > 0
        ? row.cumulativePlanned
        : row.plannedQty > 0
          ? row.plannedQty
          : 1;

  // Use the larger of cumulative total or today's recorded quantity
  const qtyCutting = Math.max(row.totalCutting || 0, row.dayCutting || 0);
  const qtyInput = Math.max(row.totalInput || 0, row.dayInput || 0);
  const qtyOutput = Math.max(row.totalOutput || 0, row.dayOutput || 0);
  const qtyWash = Math.max(row.totalWashSent || 0, row.dayWashSent || 0);
  const qtyPack = Math.max(row.totalPack || 0, row.dayPack || 0);

  const stages = [
    {
      key: "cutting",
      label: "Cutting",
      short: "Cut",
      icon: Scissors,
      qty: qtyCutting,
      pct: Math.min(100, Math.round((qtyCutting / targetQty) * 100)),
    },
    {
      key: "input",
      label: "Input",
      short: "In",
      icon: ArrowRight,
      qty: qtyInput,
      pct: Math.min(100, Math.round((qtyInput / targetQty) * 100)),
    },
    {
      key: "output",
      label: "Output",
      short: "Out",
      icon: Shirt,
      qty: qtyOutput,
      pct: Math.min(100, Math.round((qtyOutput / targetQty) * 100)),
    },
    {
      key: "wash",
      label: "Wash",
      short: "Wash",
      icon: Droplets,
      qty: qtyWash,
      pct: Math.min(100, Math.round((qtyWash / targetQty) * 100)),
    },
    {
      key: "pack",
      label: "Pack",
      short: "Pack",
      icon: PackageCheck,
      qty: qtyPack,
      pct: Math.min(100, Math.round((qtyPack / targetQty) * 100)),
    },
  ];

  // Overall milestone status: which is the latest stage that has begun
  let currentStageIdx = -1;
  for (let i = stages.length - 1; i >= 0; i--) {
    if (stages[i].qty > 0) {
      currentStageIdx = i;
      break;
    }
  }

  const isCompletedAll = stages[4].pct >= 100;

  if (compact) {
    return (
      <div
        className="flex items-center gap-1 group relative cursor-pointer"
        title={`Status: ${stages.map((s) => `${s.label}: ${s.pct}% (${s.qty.toLocaleString()})`).join(" → ")}`}
      >
        <div className="flex items-center gap-0.5">
          {stages.map((st, idx) => {
            const isDone = st.pct >= 100;
            const inProg = st.qty > 0 && !isDone;
            return (
              <div key={st.key} className="flex items-center">
                <span
                  className={`inline-flex items-center justify-center rounded px-1.5 py-0.5 text-[9px] font-bold font-mono transition-all ${
                    isDone
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                      : inProg
                        ? "bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse"
                        : "bg-muted/30 text-muted-foreground/50 border border-border/50"
                  }`}
                >
                  {st.short}
                </span>
                {idx < stages.length - 1 && (
                  <span className="text-[8px] text-muted-foreground/40 mx-0.5">›</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Small overall percentage tag */}
        <span
          className={`text-[9px] font-mono font-bold px-1 py-0.2 rounded ml-1 ${
            isCompletedAll
              ? "bg-emerald-500/20 text-emerald-300"
              : currentStageIdx >= 0
                ? "bg-blue-500/20 text-blue-300"
                : "bg-muted/30 text-muted-foreground"
          }`}
        >
          {stages[stages.length - 1].pct}%
        </span>
      </div>
    );
  }

  return (
    <div className="min-w-[280px] bg-panel-2/70 border border-border/80 rounded-xl p-2.5 shadow-sm space-y-2">
      {/* Top Header of Stepper */}
      <div className="flex items-center justify-between text-[11px]">
        <div className="flex items-center gap-1.5">
          <span className="font-bold text-foreground truncate max-w-[120px]">
            {row.po ? `PO: ${row.po}` : `Style: ${row.style}`}
          </span>
          {row.color && (
            <span className="text-[10px] text-muted-foreground font-mono bg-input px-1.5 py-0.2 rounded border border-border/60">
              {row.color}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 font-mono text-[10px]">
          <span className="text-muted-foreground">Target:</span>
          <span className="text-yellow-300 font-bold">{targetQty.toLocaleString()}</span>
        </div>
      </div>

      {/* Visual Stepper Nodes & Connector Bar */}
      <div className="relative pt-1 pb-1">
        {/* Background line */}
        <div className="absolute top-[18px] left-3 right-3 h-0.5 bg-border/80 -z-0" />

        <div className="flex items-center justify-between relative z-10">
          {stages.map((st, i) => {
            const isDone = st.pct >= 100;
            const inProg = st.qty > 0 && !isDone;
            const isCurrent = i === currentStageIdx;

            return (
              <div key={st.key} className="flex flex-col items-center group">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold border transition-transform ${
                    isDone
                      ? "bg-emerald-500 text-white border-emerald-400 shadow-emerald-500/20 shadow-md"
                      : inProg
                        ? "bg-amber-500/20 text-amber-300 border-amber-400 ring-2 ring-amber-500/30 font-extrabold"
                        : "bg-panel text-muted-foreground/60 border-border"
                  } ${isCurrent ? "scale-110" : ""}`}
                  title={`${st.label}: ${st.qty.toLocaleString()} (${st.pct}%)`}
                >
                  {isDone ? (
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  ) : inProg ? (
                    <Clock className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <span>{i + 1}</span>
                  )}
                </div>

                <span
                  className={`text-[10px] font-semibold mt-1 tracking-tight ${
                    isDone
                      ? "text-emerald-400"
                      : inProg
                        ? "text-amber-300"
                        : "text-muted-foreground/60"
                  }`}
                >
                  {st.short}
                </span>

                <span className="text-[9px] font-mono text-muted-foreground/80">{st.pct}%</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Mini Progress Bar */}
      <div className="w-full bg-input rounded-full h-1.5 overflow-hidden flex">
        {stages.map((st) => {
          const widthPct = Math.min(20, (st.pct / 100) * 20);
          return (
            <div
              key={st.key}
              style={{ width: `${widthPct}%` }}
              className={`h-full transition-all ${
                st.pct >= 100 ? "bg-emerald-500" : st.qty > 0 ? "bg-amber-400" : "bg-transparent"
              }`}
            />
          );
        })}
      </div>
    </div>
  );
}

const EMPTY_PLANS: PlanRow[] = [];
const EMPTY_UPDATES: UpdateRow[] = [];
const EMPTY_HISTORY_MAP = new Map<
  string,
  {
    totalCutting: number;
    totalInput: number;
    totalOutput: number;
    totalWashSent: number;
    totalPack: number;
  }
>();

export function ProductionUpdateView() {
  const qc = useQueryClient();
  const { presets: linePresets } = useLinePresets();
  const [date, setDate] = useState<string>(todayStr());
  const [lineFilter, setLineFilter] = useState<string[]>([]);
  const [buyerFilter, setBuyerFilter] = useState<string[]>([]);
  const [styleFilter, setStyleFilter] = useState<string[]>([]);
  const [rows, setRows] = useState<EntryRow[]>([]);
  const [saving, setSaving] = useState(false);
  const [importModalOpen, setImportModalOpen] = useState(false);
  const [stepperExpanded, setStepperExpanded] = useState(true);
  const [freezeMode, setFreezeMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("cg_prod_freeze_mode");
      return saved !== null ? saved === "true" : true;
    } catch {
      return true;
    }
  });
  const [selectedRowKeys, setSelectedRowKeys] = useState<Set<string>>(new Set());
  const [batchModalOpen, setBatchModalOpen] = useState(false);
  const [batchStage, setBatchStage] = useState<
    | "Poly"
    | "Pack"
    | "Cut"
    | "Input"
    | "Output"
    | "WashSent"
    | "WashRcvd"
    | "FinPass"
    | "DfiOffer"
    | "DfiPass"
    | "FriDone"
  >("Pack");
  const [batchMode, setBatchMode] = useState<"order_qty" | "fixed_qty" | "day_output" | "clear">(
    "order_qty",
  );
  const [batchCustomValue, setBatchCustomValue] = useState<string>("");
  const [batchProposedDate, setBatchProposedDate] = useState<string>("");
  const [batchAppendRemarks, setBatchAppendRemarks] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: plansData, isLoading: plansLoading } = useQuery({
    queryKey: ["plans", "production-update"],
    queryFn: async (): Promise<PlanRow[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("id, buyer, style, season, order_qty, shipment_date, calc_result, config")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as PlanRow[];
    },
  });
  const plans = plansData ?? EMPTY_PLANS;

  // Query updates for selected date
  const { data: updatesData, isLoading: updLoading } = useQuery({
    queryKey: ["production_updates", date],
    queryFn: async (): Promise<UpdateRow[]> => {
      const { data, error } = await supabase
        .from("production_updates")
        .select("id, plan_id, line_name, update_date, actual_qty, remarks")
        .eq("update_date", date);
      if (error) throw error;
      return (data ?? []) as UpdateRow[];
    },
  });
  const updates = updatesData ?? EMPTY_UPDATES;

  // Query all historical updates to compute cumulative progress per PO / Plan & Line
  const { data: allUpdatesData } = useQuery({
    queryKey: ["production_updates", "all_history"],
    queryFn: async (): Promise<UpdateRow[]> => {
      const { data, error } = await supabase
        .from("production_updates")
        .select("plan_id, line_name, update_date, actual_qty, remarks");
      if (error) throw error;
      return (data ?? []) as UpdateRow[];
    },
  });
  const allUpdates = allUpdatesData ?? EMPTY_UPDATES;

  useEffect(() => {
    const ch = supabase
      .channel("prod-updates-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "production_updates" }, () => {
        qc.invalidateQueries({ queryKey: ["production_updates"] });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  // Aggregate all-time task numbers per plan_id & line_name
  const historyMap = useMemo(() => {
    if (allUpdates.length === 0) return EMPTY_HISTORY_MAP;
    const map = new Map<
      string,
      {
        totalCutting: number;
        totalInput: number;
        totalOutput: number;
        totalWashSent: number;
        totalPack: number;
      }
    >();

    for (const u of allUpdates) {
      const key = `${u.plan_id}::${u.line_name}`;
      const existing = map.get(key) || {
        totalCutting: 0,
        totalInput: 0,
        totalOutput: 0,
        totalWashSent: 0,
        totalPack: 0,
      };

      const { details } = parseTrackingDetails(u.remarks);
      existing.totalCutting += details.dayCutting || 0;
      existing.totalInput += details.dayInput || 0;
      existing.totalOutput +=
        details.dayOutput !== undefined ? details.dayOutput : u.actual_qty || 0;
      existing.totalWashSent += details.dayWashSent || 0;
      existing.totalPack += details.dayPack || 0;

      map.set(key, existing);
    }
    return map;
  }, [allUpdates]);

  // Build entry rows from plans + selected date
  useEffect(() => {
    if (plansLoading && plans.length === 0) return;

    const built: EntryRow[] = [];
    const presetLookup = buildLinePresetLookup(linePresets);
    for (const p of plans) {
      const lines = p.calc_result?.lines ?? [];
      for (const l of lines) {
        if (!l?.name) continue;
        const daily = l.dailyProduction ?? [];
        const todayItem = daily.find((d) => d.date === date);
        if (!todayItem) continue;
        let cum = 0;
        for (const d of daily) {
          if (d.date <= date) cum += d.qty || 0;
        }
        const existing = updates.find(
          (u) => u.plan_id === p.id && u.line_name === l.name && u.update_date === date,
        );

        const { details, userRemarks } = parseTrackingDetails(existing?.remarks);

        const dayOutputVal =
          details.dayOutput !== undefined ? details.dayOutput : (existing?.actual_qty ?? 0);

        const hist = historyMap.get(`${p.id}::${l.name}`) || {
          totalCutting: 0,
          totalInput: 0,
          totalOutput: 0,
          totalWashSent: 0,
          totalPack: 0,
        };

        built.push({
          planId: p.id,
          buyer: p.buyer,
          style: p.style,
          season: p.season || "",
          line: canonicalLineName(l.name, presetLookup),
          rawLine: l.name,
          plannedQty: todayItem.qty,
          cumulativePlanned: cum,
          existingId: existing?.id ?? null,
          originalActualQty: existing ? existing.actual_qty : null,
          originalRemarks: existing ? (existing.remarks ?? "") : null,
          dirty: false,

          po: details.po || "",
          color: details.color || "",
          size: details.size || "",
          block: details.block || "",
          orderQty: details.orderQty ?? p.order_qty ?? 0,
          poShipDate: details.poShipDate || p.shipment_date || "",
          proposedDate: details.proposedDate || l.finishDateStr || p.shipment_date || "",
          dayCutting: details.dayCutting ?? 0,
          dayInput: details.dayInput ?? 0,
          dayOutput: dayOutputVal,
          dayWashSent: details.dayWashSent ?? 0,
          dayWashRcvd: details.dayWashRcvd ?? 0,
          dayFinishingLotPass: details.dayFinishingLotPass ?? 0,
          dayPoly: details.dayPoly ?? 0,
          dayPack: details.dayPack ?? 0,
          dayDfiOffer: details.dayDfiOffer ?? 0,
          dayDfiPass: details.dayDfiPass ?? 0,
          friDoneQty: details.friDoneQty ?? 0,
          remarks: userRemarks,

          totalCutting: hist.totalCutting,
          totalInput: hist.totalInput,
          totalOutput: hist.totalOutput,
          totalWashSent: hist.totalWashSent,
          totalPack: hist.totalPack,
        });
      }
    }
    built.sort((a, b) =>
      a.line.localeCompare(b.line, undefined, { numeric: true, sensitivity: "base" }),
    );

    setRows((prev) => {
      if (prev.length === 0 && built.length === 0) return prev;

      const dirtyMap = new Map(
        prev.filter((r) => r.dirty).map((r) => [`${r.planId}::${r.rawLine}`, r]),
      );
      if (dirtyMap.size === 0) {
        return built;
      }
      return built.map((r) => {
        const d = dirtyMap.get(`${r.planId}::${r.rawLine}`);
        if (!d) return r;
        return {
          ...r,
          po: d.po,
          color: d.color,
          size: d.size,
          block: d.block,
          orderQty: d.orderQty,
          poShipDate: d.poShipDate,
          proposedDate: d.proposedDate,
          dayCutting: d.dayCutting,
          dayInput: d.dayInput,
          dayOutput: d.dayOutput,
          dayWashSent: d.dayWashSent,
          dayWashRcvd: d.dayWashRcvd,
          dayFinishingLotPass: d.dayFinishingLotPass,
          dayPoly: d.dayPoly,
          dayPack: d.dayPack,
          dayDfiOffer: d.dayDfiOffer,
          dayDfiPass: d.dayDfiPass,
          friDoneQty: d.friDoneQty,
          remarks: d.remarks,
          dirty: true,
        };
      });
    });

    setSelectedRowKeys((prev) => {
      // Retain only selected keys that still exist in the newly built rows
      if (prev.size === 0) return prev;
      const valid = new Set<string>();
      for (const row of built) {
        const key = `${row.planId}::${row.rawLine}`;
        if (prev.has(key)) valid.add(key);
      }
      if (valid.size === prev.size && Array.from(valid).every((k) => prev.has(k))) {
        return prev;
      }
      return valid;
    });
  }, [plans, plansLoading, updates, date, linePresets, historyMap]);

  const lineOptions = useMemo(
    () =>
      uniqueCanonicalLineNames(
        rows.map((r) => r.line),
        linePresets,
      ),
    [rows, linePresets],
  );
  const buyerOptions = useMemo(() => Array.from(new Set(rows.map((r) => r.buyer))).sort(), [rows]);
  const styleOptions = useMemo(() => Array.from(new Set(rows.map((r) => r.style))).sort(), [rows]);

  const filteredRows = useMemo(
    () =>
      rows.filter(
        (r) =>
          (lineFilter.length === 0 || lineFilter.includes(r.line)) &&
          (buyerFilter.length === 0 || buyerFilter.includes(r.buyer)) &&
          (styleFilter.length === 0 || styleFilter.includes(r.style)),
      ),
    [rows, lineFilter, buyerFilter, styleFilter],
  );

  const totals = useMemo(
    () =>
      filteredRows.reduce(
        (acc, r) => {
          acc.planned += r.plannedQty;
          acc.dayCutting += r.dayCutting || 0;
          acc.dayInput += r.dayInput || 0;
          acc.dayOutput += r.dayOutput || 0;
          acc.dayWashSent += r.dayWashSent || 0;
          acc.dayWashRcvd += r.dayWashRcvd || 0;
          acc.dayFinishingLotPass += r.dayFinishingLotPass || 0;
          acc.dayPoly += r.dayPoly || 0;
          acc.dayPack += r.dayPack || 0;
          acc.dayDfiOffer += r.dayDfiOffer || 0;
          acc.dayDfiPass += r.dayDfiPass || 0;
          acc.friDoneQty += r.friDoneQty || 0;
          return acc;
        },
        {
          planned: 0,
          dayCutting: 0,
          dayInput: 0,
          dayOutput: 0,
          dayWashSent: 0,
          dayWashRcvd: 0,
          dayFinishingLotPass: 0,
          dayPoly: 0,
          dayPack: 0,
          dayDfiOffer: 0,
          dayDfiPass: 0,
          friDoneQty: 0,
        },
      ),
    [filteredRows],
  );

  const correctionsCount = useMemo(
    () =>
      rows.filter(
        (r) =>
          r.existingId !== null &&
          (r.dayOutput !== (r.originalActualQty ?? 0) ||
            r.remarks !== (parseTrackingDetails(r.originalRemarks).userRemarks ?? "")),
      ).length,
    [rows],
  );
  const isBackdate = date < todayStr();

  function updateRow(idx: number, patch: Partial<EntryRow>) {
    setRows((prev) => {
      const next = [...prev];
      const target = filteredRows[idx];
      const fullIdx = prev.indexOf(target);
      if (fullIdx === -1) return prev;
      next[fullIdx] = { ...next[fullIdx], ...patch, dirty: true };
      return next;
    });
  }

  // Row selection helpers
  function toggleRowSelection(key: string) {
    setSelectedRowKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  }

  function toggleSelectAllFiltered() {
    if (selectedRowKeys.size === filteredRows.length && filteredRows.length > 0) {
      setSelectedRowKeys(new Set());
    } else {
      setSelectedRowKeys(new Set(filteredRows.map((r) => `${r.planId}::${r.rawLine}`)));
    }
  }

  function clearSelection() {
    setSelectedRowKeys(new Set());
  }

  // Batch update multiple selected POs
  type BatchUpdateAction = {
    stage?:
      | "Poly"
      | "Pack"
      | "Cut"
      | "Input"
      | "Output"
      | "WashSent"
      | "WashRcvd"
      | "FinPass"
      | "DfiOffer"
      | "DfiPass"
      | "FriDone";
    mode?: "order_qty" | "fixed_qty" | "day_output" | "clear";
    customValue?: number;
    appendRemarks?: string;
    overrideRemarks?: string;
    newProposedDate?: string;
  };

  function applyBatchUpdate(action: BatchUpdateAction) {
    if (selectedRowKeys.size === 0) {
      toast.warning("কোনো সারি নির্বাচন করা হয়নি।");
      return;
    }

    let affectedCount = 0;

    setRows((prev) =>
      prev.map((row) => {
        const key = `${row.planId}::${row.rawLine}`;
        if (!selectedRowKeys.has(key)) return row;

        affectedCount++;
        const patch: Partial<EntryRow> = { dirty: true };

        // Determine qty value to apply
        let qtyToApply = 0;
        if (action.mode === "order_qty") {
          qtyToApply = row.orderQty || 0;
        } else if (action.mode === "day_output") {
          qtyToApply = row.dayOutput || 0;
        } else if (action.mode === "fixed_qty") {
          qtyToApply = Number(action.customValue) || 0;
        } else if (action.mode === "clear") {
          qtyToApply = 0;
        }

        if (action.stage) {
          switch (action.stage) {
            case "Poly":
              patch.dayPoly = qtyToApply;
              break;
            case "Pack":
              patch.dayPack = qtyToApply;
              break;
            case "Cut":
              patch.dayCutting = qtyToApply;
              break;
            case "Input":
              patch.dayInput = qtyToApply;
              break;
            case "Output":
              patch.dayOutput = qtyToApply;
              break;
            case "WashSent":
              patch.dayWashSent = qtyToApply;
              break;
            case "WashRcvd":
              patch.dayWashRcvd = qtyToApply;
              break;
            case "FinPass":
              patch.dayFinishingLotPass = qtyToApply;
              break;
            case "DfiOffer":
              patch.dayDfiOffer = qtyToApply;
              break;
            case "DfiPass":
              patch.dayDfiPass = qtyToApply;
              break;
            case "FriDone":
              patch.friDoneQty = qtyToApply;
              break;
          }
        }

        if (action.newProposedDate !== undefined && action.newProposedDate !== "") {
          patch.proposedDate = action.newProposedDate;
        }

        if (action.overrideRemarks !== undefined && action.overrideRemarks !== "") {
          patch.remarks = action.overrideRemarks;
        } else if (action.appendRemarks && action.appendRemarks.trim() !== "") {
          const trimmed = action.appendRemarks.trim();
          patch.remarks = row.remarks ? `${row.remarks} | ${trimmed}` : trimmed;
        }

        return { ...row, ...patch };
      }),
    );

    toast.success(
      `${affectedCount}টি PO রো সফলভাবে আপডেট করা হয়েছে। 'সব সেভ করুন' বাটনে ক্লিক করে ডেটাবেজে সংরক্ষণ করুন।`,
    );
  }

  async function saveAll() {
    const dirty = rows.filter((r) => r.dirty);
    if (dirty.length === 0) {
      toast.info("কোনো পরিবর্তন নেই।");
      return;
    }
    setSaving(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user?.id ?? null;
      const payload = dirty.map((r) => {
        const details: ProductionTrackingDetails = {
          po: r.po,
          color: r.color,
          size: r.size,
          block: r.block,
          orderQty: r.orderQty,
          poShipDate: r.poShipDate,
          proposedDate: r.proposedDate,
          dayCutting: r.dayCutting,
          dayInput: r.dayInput,
          dayOutput: r.dayOutput,
          dayWashSent: r.dayWashSent,
          dayWashRcvd: r.dayWashRcvd,
          dayFinishingLotPass: r.dayFinishingLotPass,
          dayPoly: r.dayPoly,
          dayPack: r.dayPack,
          dayDfiOffer: r.dayDfiOffer,
          dayDfiPass: r.dayDfiPass,
          friDoneQty: r.friDoneQty,
        };

        const serialized = serializeRemarks(details, r.remarks);

        return {
          plan_id: r.planId,
          line_name: r.rawLine,
          update_date: date,
          actual_qty: Number(r.dayOutput) || 0,
          remarks: serialized || null,
          created_by: uid,
        };
      });

      const { error } = await supabase
        .from("production_updates")
        .upsert(payload, { onConflict: "plan_id,line_name,update_date" });
      if (error) throw error;
      toast.success(`${dirty.length}টি এন্ট্রি সফলভাবে সেভ হয়েছে।`);
      qc.invalidateQueries({ queryKey: ["production_updates"] });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      toast.error("সেভ ব্যর্থ: " + msg);
    } finally {
      setSaving(false);
    }
  }

  // Excel Export matching exact requested columns
  function exportExcel() {
    if (filteredRows.length === 0) {
      toast.error("এক্সপোর্ট করার মতো ডেটা নেই।");
      return;
    }
    const headers = [
      "Date",
      "Line",
      "Buyer",
      "Style",
      "Season",
      "PO",
      "Color",
      "Size",
      "Block",
      "Order Qty",
      "PO Ship Date",
      "Proposed Date",
      "Day Cutting",
      "Day Input",
      "Day Output",
      "Day Wash Sent",
      "Day Wash Rcvd",
      "Day Finishing Lot Pass",
      "Day Poly",
      "Day Pack",
      "Day DFI Offer",
      "Day DFI Pass",
      "FRI Done Qty",
      "Remarks",
    ];

    const dataRows = filteredRows.map((r) => [
      date,
      r.line,
      r.buyer,
      r.style,
      r.season,
      r.po,
      r.color,
      r.size,
      r.block,
      r.orderQty || 0,
      r.poShipDate,
      r.proposedDate,
      r.dayCutting,
      r.dayInput,
      r.dayOutput,
      r.dayWashSent,
      r.dayWashRcvd,
      r.dayFinishingLotPass,
      r.dayPoly,
      r.dayPack,
      r.dayDfiOffer,
      r.dayDfiPass,
      r.friDoneQty,
      r.remarks,
    ]);

    const totalRow = [
      "TOTAL",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      totals.dayCutting,
      totals.dayInput,
      totals.dayOutput,
      totals.dayWashSent,
      totals.dayWashRcvd,
      totals.dayFinishingLotPass,
      totals.dayPoly,
      totals.dayPack,
      totals.dayDfiOffer,
      totals.dayDfiPass,
      totals.friDoneQty,
      "",
    ];

    const aoa: (string | number)[][] = [
      [`Garments Daily Production & Flow Update — ${formatDate(date)}`],
      [],
      headers,
      ...dataRows,
      [],
      totalRow,
    ];

    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [
      { wch: 12 },
      { wch: 12 },
      { wch: 15 },
      { wch: 18 },
      { wch: 12 },
      { wch: 14 },
      { wch: 12 },
      { wch: 10 },
      { wch: 10 },
      { wch: 12 },
      { wch: 14 },
      { wch: 14 },
      { wch: 12 },
      { wch: 12 },
      { wch: 12 },
      { wch: 14 },
      { wch: 14 },
      { wch: 18 },
      { wch: 12 },
      { wch: 12 },
      { wch: 14 },
      { wch: 14 },
      { wch: 14 },
      { wch: 24 },
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Production Update");
    XLSX.writeFile(wb, `detailed-production-update-${date}.xlsx`);
    toast.success("Excel ফাইল সফলভাবে ডাউনলোড হয়েছে।");
  }

  // Download template for Excel Import
  function downloadTemplate() {
    const headers = [
      "Date (YYYY-MM-DD)",
      "Line",
      "Buyer",
      "Style",
      "Season",
      "PO",
      "Color",
      "Size",
      "Block",
      "Order Qty",
      "PO Ship Date",
      "Proposed Date",
      "Day Cutting",
      "Day Input",
      "Day Output",
      "Day Wash Sent",
      "Day Wash Rcvd",
      "Day Finishing Lot Pass",
      "Day Poly",
      "Day Pack",
      "Day DFI Offer",
      "Day DFI Pass",
      "FRI Done Qty",
      "Remarks",
    ];

    const sampleRow = [
      date,
      "Line - 15",
      "H&M",
      "HM-TW-402",
      "Summer 26",
      "PO-99481",
      "Navy Blue",
      "M, L, XL",
      "Block A",
      15000,
      "2026-10-15",
      "2026-10-10",
      1200,
      1150,
      1100,
      1000,
      950,
      900,
      900,
      880,
      850,
      850,
      850,
      "Good flow",
    ];

    const ws = XLSX.utils.aoa_to_sheet([
      ["Production Data Import Template (Daily & Back Data)"],
      [
        "নোট: Date, Line, Buyer, Style মিলিয়ে সিস্টেম অটোমেটিক প্ল্যানের সাথে ম্যাচ করবে। নতুন ব্যাক-ডেটা থাকলেও ইনসার্ট হবে।",
      ],
      [],
      headers,
      sampleRow,
    ]);

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Template");
    XLSX.writeFile(wb, `production-import-template.xlsx`);
    toast.info("Excel Template ডাউনলোড হয়েছে।");
  }

  // Handle Excel Import
  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: "binary", cellDates: true });
        const sheetName = wb.SheetNames[0];
        const ws = wb.Sheets[sheetName];
        const data = XLSX.utils.sheet_to_json<any>(ws, { header: 1, defval: "" });

        if (!data || data.length < 2) {
          toast.error("ফাইলে কোনো ডেটা পাওয়া যায়নি।");
          return;
        }

        let headerRowIdx = -1;
        for (let i = 0; i < Math.min(10, data.length); i++) {
          const rowStr = (data[i] as any[]).join(" ").toLowerCase();
          if (rowStr.includes("line") && (rowStr.includes("style") || rowStr.includes("buyer"))) {
            headerRowIdx = i;
            break;
          }
        }

        if (headerRowIdx === -1) {
          toast.error("হেডার রো পাওয়া যায়নি! Line, Buyer, Style কলাম থাকা আবশ্যক।");
          return;
        }

        const headers = (data[headerRowIdx] as string[]).map((h) => String(h).trim().toLowerCase());

        const colIdx = {
          date: headers.findIndex(
            (h) => h.includes("date") && !h.includes("ship") && !h.includes("propos"),
          ),
          line: headers.findIndex((h) => h.includes("line")),
          buyer: headers.findIndex((h) => h.includes("buyer")),
          style: headers.findIndex((h) => h.includes("style")),
          season: headers.findIndex((h) => h.includes("season")),
          po: headers.findIndex((h) => h === "po" || h.includes("po #") || h.includes("order no")),
          color: headers.findIndex((h) => h.includes("color")),
          size: headers.findIndex((h) => h.includes("size")),
          block: headers.findIndex((h) => h.includes("block")),
          orderQty: headers.findIndex((h) => h.includes("order qty") || h.includes("order_qty")),
          poShipDate: headers.findIndex((h) => h.includes("ship date") || h.includes("po ship")),
          proposedDate: headers.findIndex((h) => h.includes("proposed") || h.includes("prop date")),
          dayCutting: headers.findIndex((h) => h.includes("cut")),
          dayInput: headers.findIndex((h) => h.includes("input")),
          dayOutput: headers.findIndex(
            (h) => h.includes("output") || h.includes("sewing") || h.includes("actual"),
          ),
          dayWashSent: headers.findIndex((h) => h.includes("wash sent")),
          dayWashRcvd: headers.findIndex(
            (h) => h.includes("wash rcv") || h.includes("wash receive"),
          ),
          dayFinishingLotPass: headers.findIndex(
            (h) => h.includes("finishing") || h.includes("lot pass"),
          ),
          dayPoly: headers.findIndex((h) => h.includes("poly")),
          dayPack: headers.findIndex((h) => h.includes("pack")),
          dayDfiOffer: headers.findIndex((h) => h.includes("dfi offer")),
          dayDfiPass: headers.findIndex((h) => h.includes("dfi pass")),
          friDoneQty: headers.findIndex((h) => h.includes("fri")),
          remarks: headers.findIndex((h) => h.includes("remark")),
        };

        const rowsToProcess = data.slice(headerRowIdx + 1);
        const { data: userData } = await supabase.auth.getUser();
        const uid = userData.user?.id ?? null;

        const importedPayload: any[] = [];
        let skipped = 0;

        for (const r of rowsToProcess) {
          if (!r || r.length === 0 || (!r[colIdx.line] && !r[colIdx.style])) continue;

          const getCell = (idx: number) =>
            idx >= 0 && r[idx] !== undefined ? String(r[idx]).trim() : "";
          const getNum = (idx: number) => {
            if (idx < 0 || r[idx] === undefined || r[idx] === "") return 0;
            const n = Number(String(r[idx]).replace(/,/g, ""));
            return Number.isNaN(n) ? 0 : n;
          };

          const rawDate = getCell(colIdx.date) || date;
          let rowDate = rawDate;
          if (rawDate.includes("T")) rowDate = rawDate.split("T")[0];
          else if (/^\d{4}-\d{2}-\d{2}$/.test(rawDate)) rowDate = rawDate;
          else if (r[colIdx.date] instanceof Date) {
            rowDate = (r[colIdx.date] as Date).toISOString().slice(0, 10);
          }

          const rawLineName = getCell(colIdx.line);
          const rawBuyer = getCell(colIdx.buyer).toLowerCase();
          const rawStyle = getCell(colIdx.style).toLowerCase();

          let targetPlan = plans.find(
            (p) =>
              (rawStyle && p.style.toLowerCase() === rawStyle) ||
              (rawBuyer &&
                rawStyle &&
                p.buyer.toLowerCase() === rawBuyer &&
                p.style.toLowerCase() === rawStyle),
          );

          if (!targetPlan && plans.length > 0) {
            targetPlan = plans.find(
              (p) =>
                p.style.toLowerCase().includes(rawStyle) ||
                rawStyle.includes(p.style.toLowerCase()),
            );
          }

          if (!targetPlan) {
            skipped++;
            continue;
          }

          const details: ProductionTrackingDetails = {
            po: getCell(colIdx.po),
            color: getCell(colIdx.color),
            size: getCell(colIdx.size),
            block: getCell(colIdx.block),
            orderQty: getNum(colIdx.orderQty) || targetPlan.order_qty,
            poShipDate: getCell(colIdx.poShipDate) || targetPlan.shipment_date,
            proposedDate: getCell(colIdx.proposedDate) || targetPlan.shipment_date,
            dayCutting: getNum(colIdx.dayCutting),
            dayInput: getNum(colIdx.dayInput),
            dayOutput: getNum(colIdx.dayOutput),
            dayWashSent: getNum(colIdx.dayWashSent),
            dayWashRcvd: getNum(colIdx.dayWashRcvd),
            dayFinishingLotPass: getNum(colIdx.dayFinishingLotPass),
            dayPoly: getNum(colIdx.dayPoly),
            dayPack: getNum(colIdx.dayPack),
            dayDfiOffer: getNum(colIdx.dayDfiOffer),
            dayDfiPass: getNum(colIdx.dayDfiPass),
            friDoneQty: getNum(colIdx.friDoneQty),
          };

          const userRemarks = getCell(colIdx.remarks);
          const serializedRemarks = serializeRemarks(details, userRemarks);

          importedPayload.push({
            plan_id: targetPlan.id,
            line_name: rawLineName || "Line - 15",
            update_date: rowDate,
            actual_qty: details.dayOutput || 0,
            remarks: serializedRemarks || null,
            created_by: uid,
          });
        }

        if (importedPayload.length === 0) {
          toast.error(
            "কোনো ভ্যালিড ডেটা রো ম্যাচ করা যায়নি। প্ল্যানের সাথে Style ও Line মিলিয়ে ফাইল তৈরি করুন।",
          );
          return;
        }

        setSaving(true);
        for (let i = 0; i < importedPayload.length; i += 100) {
          const chunk = importedPayload.slice(i, i + 100);
          const { error } = await supabase
            .from("production_updates")
            .upsert(chunk, { onConflict: "plan_id,line_name,update_date" });
          if (error) throw error;
        }

        toast.success(
          `সফলভাবে ${importedPayload.length}টি রো ইমপোর্ট ও আপডেট হয়েছে! (Skipped: ${skipped})`,
        );
        qc.invalidateQueries({ queryKey: ["production_updates"] });
        setImportModalOpen(false);
      } catch (err: any) {
        console.error(err);
        toast.error("ইমপোর্ট প্রক্রিয়া ব্যর্থ হয়েছে: " + (err.message || String(err)));
      } finally {
        setSaving(false);
        if (fileInputRef.current) fileInputRef.current.value = "";
      }
    };
    reader.readAsBinaryString(file);
  }

  const isLoading = plansLoading || updLoading;

  return (
    <div className="rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl space-y-4">
      {/* Top Header Card */}
      <div className="p-4 md:p-6 border-b border-border bg-panel-2/40 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base md:text-lg font-bold text-rose-400 flex items-center gap-1.5">
              <TableIcon className="w-5 h-5 text-rose-400" /> Daily Production &amp; Flow Detail
            </h2>
            <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-emerald-400" /> Live PO Stepper Enabled
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            লাইন, Buyer, Style, Season, PO, Color, Size, Block, Order Qty, PO Ship Date, Proposed
            Date ও দৈনন্দিন কাটিং থেকে FRI পর্যন্ত সম্পূর্ণ ট্র্যাকিং।
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1.5 bg-input/80 border border-border rounded-lg px-2.5 py-1">
            <label className="text-xs font-bold text-muted-foreground">তারিখ:</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="bg-transparent text-xs text-foreground font-mono focus:outline-none"
            />
          </div>

          <button
            onClick={() => setImportModalOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-purple-500/50 bg-purple-500/10 text-purple-300 hover:bg-purple-500/20 px-3 py-2 text-xs font-bold transition"
            title="Excel ফাইল থেকে ব্যাক-ডেটা বা বাল্ক ডেটা ইমপোর্ট করুন"
          >
            <FileUp className="w-3.5 h-3.5" /> Data Import
          </button>

          <button
            onClick={exportExcel}
            className="inline-flex items-center gap-1.5 rounded-lg border border-sky-500/50 bg-sky-500/10 text-sky-300 hover:bg-sky-500/20 px-3 py-2 text-xs font-bold transition"
            title="Excel ফাইল এক্সপোর্ট করুন"
          >
            <FileDown className="w-3.5 h-3.5" /> Export Excel
          </button>

          <button
            onClick={saveAll}
            disabled={saving}
            className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/50 bg-emerald-500 text-white hover:bg-emerald-600 px-3.5 py-2 text-xs font-bold shadow-md transition disabled:opacity-50"
          >
            {saving ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Save className="w-3.5 h-3.5" />
            )}
            Save Changes
          </button>
        </div>
      </div>

      {/* PO Visual Progress Steppers Overview Section */}
      {filteredRows.length > 0 && (
        <div className="mx-4 p-3 md:p-4 rounded-xl border border-border/80 bg-panel-2/30 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-foreground flex items-center gap-1.5">
                <Shirt className="w-4 h-4 text-rose-400" />
                PO Production Progress Stepper (Cutting &rarr; Input &rarr; Output &rarr; Wash
                &rarr; Pack)
              </span>
              <span className="text-[10px] text-muted-foreground font-mono bg-panel px-2 py-0.5 rounded border border-border">
                {filteredRows.length} active styles
              </span>
            </div>

            <button
              onClick={() => setStepperExpanded((v) => !v)}
              className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-300 hover:text-rose-200"
            >
              {stepperExpanded ? (
                <>
                  <ChevronUp className="w-3.5 h-3.5" /> Collapse Stepper
                </>
              ) : (
                <>
                  <ChevronDown className="w-3.5 h-3.5" /> Expand Stepper Cards
                </>
              )}
            </button>
          </div>

          {stepperExpanded && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 pt-1">
              {filteredRows.map((r, i) => (
                <ProductionProgressStepper
                  key={`stepper-card-${r.planId}-${r.rawLine}-${i}`}
                  row={r}
                  compact={false}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Filter and Summary Bar */}
      <div className="px-4 py-3 border-b border-border bg-panel/40 flex flex-wrap items-center gap-3">
        <FilterSelect
          label="Line"
          value={lineFilter}
          onChange={setLineFilter}
          options={lineOptions}
        />
        <FilterSelect
          label="Buyer"
          value={buyerFilter}
          onChange={setBuyerFilter}
          options={buyerOptions}
        />
        <FilterSelect
          label="Style"
          value={styleFilter}
          onChange={setStyleFilter}
          options={styleOptions}
        />

        {lineFilter.length || buyerFilter.length || styleFilter.length ? (
          <button
            onClick={() => {
              setLineFilter([]);
              setBuyerFilter([]);
              setStyleFilter([]);
            }}
            className="text-xs font-bold text-red-400 hover:text-red-300 underline"
          >
            Reset Filters
          </button>
        ) : null}

        <span className="text-[11px] text-muted-foreground font-mono">
          {filteredRows.length} / {rows.length} lines
        </span>

        {isBackdate ? (
          <span className="inline-flex items-center gap-1 rounded-md border border-orange-500/50 bg-orange-500/10 px-2 py-0.5 text-[11px] font-bold text-orange-300">
            &Delta; ব্যাক-ডেট মোড ({formatDate(date)})
          </span>
        ) : null}

        {correctionsCount > 0 ? (
          <span className="inline-flex items-center gap-1 rounded-md border border-red-500/60 bg-red-500/15 px-2 py-0.5 text-[11px] font-bold text-red-300">
            ✎ {correctionsCount} correction
          </span>
        ) : null}

        {/* View Mode Toggle: Freeze (Sticky) vs Normal (Full Page) */}
        <div className="flex items-center gap-1 bg-panel-2/90 border border-border rounded-lg p-0.5 shadow-sm">
          <button
            type="button"
            onClick={() => {
              setFreezeMode(true);
              try {
                localStorage.setItem("cg_prod_freeze_mode", "true");
              } catch {
                /* ignore */
              }
            }}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-bold transition-all ${
              freezeMode
                ? "bg-purple-600 text-white shadow-sm ring-1 ring-purple-400/50"
                : "text-muted-foreground hover:text-foreground hover:bg-panel/60"
            }`}
            title="হেডার ও Line, Buyer, Style কলাম ফ্রিজ করে ব্রাউজ করুন"
          >
            <Pin className={`w-3.5 h-3.5 ${freezeMode ? "rotate-45" : ""}`} />
            <span>ফ্রিজ মোড (Sticky)</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setFreezeMode(false);
              try {
                localStorage.setItem("cg_prod_freeze_mode", "false");
              } catch {
                /* ignore */
              }
            }}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-bold transition-all ${
              !freezeMode
                ? "bg-panel border border-border text-foreground shadow-sm ring-1 ring-border"
                : "text-muted-foreground hover:text-foreground hover:bg-panel/60"
            }`}
            title="স্বাভাবিকভাবে সম্পূর্ণ পেজ দেখতে ফুল পেজ মোড"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span>ফুল পেজ (Normal)</span>
          </button>
        </div>

        {/* Live metric chips */}
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {selectedRowKeys.size > 0 && (
            <button
              onClick={() => setBatchModalOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 px-3 py-1.5 text-xs font-bold text-white shadow-md hover:from-purple-500 hover:to-indigo-500 transition-all animate-pulse"
            >
              <Layers className="w-3.5 h-3.5" />
              Batch Update ({selectedRowKeys.size})
            </button>
          )}

          <div className="bg-panel-2/70 border border-border rounded-lg px-2.5 py-1 text-[11px] font-medium flex items-center gap-2">
            <span className="text-muted-foreground">Cutting:</span>
            <span className="font-mono font-bold text-cyan-300">
              {totals.dayCutting.toLocaleString()}
            </span>
            <span className="text-border">|</span>
            <span className="text-muted-foreground">Input:</span>
            <span className="font-mono font-bold text-blue-300">
              {totals.dayInput.toLocaleString()}
            </span>
            <span className="text-border">|</span>
            <span className="text-muted-foreground">Output:</span>
            <span className="font-mono font-bold text-emerald-400">
              {totals.dayOutput.toLocaleString()}
            </span>
            <span className="text-border">|</span>
            <span className="text-muted-foreground">Pack:</span>
            <span className="font-mono font-bold text-purple-300">
              {totals.dayPack.toLocaleString()}
            </span>
            <span className="text-border">|</span>
            <span className="text-muted-foreground">FRI:</span>
            <span className="font-mono font-bold text-amber-300">
              {totals.friDoneQty.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Floating Batch Action Banner when items are selected */}
      {selectedRowKeys.size > 0 && (
        <div className="mx-4 mb-3 p-3 bg-gradient-to-r from-purple-950/70 via-panel-2 to-indigo-950/60 border border-purple-500/40 rounded-xl shadow-lg flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <CheckSquare className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">
                  {selectedRowKeys.size}টি PO সারি নির্বাচিত
                </span>
                <span className="text-[10px] text-purple-300 bg-purple-500/20 px-2 py-0.5 rounded-full font-medium">
                  এক ক্লিকে একাধিক স্ট্যাটাস আপডেট
                </span>
              </div>
              <p className="text-[11px] text-muted-foreground">
                নিচের কুইক বাটনে ক্লিক করুন অথবা কাস্টম ব্যাচ মডাল ওপেন করুন।
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => applyBatchUpdate({ stage: "Poly", mode: "order_qty" })}
              title="নির্বাচিত সমস্ত PO-এর Day Poly ভ্যালু Order Qty দিয়ে পূর্ণ করুন"
              className="px-2.5 py-1.5 rounded-md bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/40 text-xs font-semibold text-purple-300 transition-colors flex items-center gap-1.5"
            >
              <PackageCheck className="w-3.5 h-3.5 text-purple-400" />
              Mark Poly (Order Qty)
            </button>

            <button
              onClick={() => applyBatchUpdate({ stage: "Pack", mode: "order_qty" })}
              title="নির্বাচিত সমস্ত PO-এর Day Pack ভ্যালু Order Qty দিয়ে পূর্ণ করুন"
              className="px-2.5 py-1.5 rounded-md bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-xs font-semibold text-indigo-300 transition-colors flex items-center gap-1.5"
            >
              <PackageCheck className="w-3.5 h-3.5 text-indigo-400" />
              Mark Pack (Order Qty)
            </button>

            <button
              onClick={() => applyBatchUpdate({ stage: "Pack", mode: "day_output" })}
              title="Day Output-এর সমান পরিমাণ Day Pack হিসেবে সেট করুন"
              className="px-2.5 py-1.5 rounded-md bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-xs font-semibold text-emerald-300 transition-colors flex items-center gap-1.5"
            >
              Pack = Output Qty
            </button>

            <button
              onClick={() => setBatchModalOpen(true)}
              className="px-3 py-1.5 rounded-md bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow flex items-center gap-1.5"
            >
              <Edit3 className="w-3.5 h-3.5" />
              Advanced Batch...
            </button>

            <button
              onClick={clearSelection}
              className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-panel border border-border/70 text-xs transition-colors"
              title="নির্বাচন বাতিল করুন"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Wide Detail Matrix Table */}
      {isLoading ? (
        <div className="p-16 flex flex-col items-center justify-center gap-2">
          <Loader2 className="w-8 h-8 animate-spin text-rose-400" />
          <p className="text-xs text-muted-foreground">প্রোডাকশন ডেটা লোড হচ্ছে...</p>
        </div>
      ) : filteredRows.length === 0 ? (
        <div className="p-16 text-center space-y-2">
          <p className="text-sm font-medium text-muted-foreground">
            এই তারিখে ({formatDate(date)}) কোনো লাইনে নির্ধারিত প্ল্যান বা প্রোডাকশন নেই।
          </p>
          <p className="text-xs text-muted-foreground/80">
            তারিখ পরিবর্তন করুন অথবা <strong className="text-purple-300">Data Import</strong> বাটনে
            ক্লিক করে পুরনো ব্যাক-ডেটা আপলোড করুন।
          </p>
        </div>
      ) : (
        <div
          className={`border-t border-border transition-all ${
            freezeMode
              ? "overflow-auto max-h-[calc(100vh-210px)] min-h-[460px] shadow-inner"
              : "overflow-x-auto"
          }`}
        >
          <table className="w-full text-left text-xs border-collapse min-w-[2100px]">
            <thead className="bg-panel-2 text-muted-foreground text-[11px] uppercase tracking-wider sticky top-0 z-30 shadow-sm border-b border-border">
              <tr>
                <th
                  className={`p-2.5 font-bold text-foreground bg-panel-2 border-b border-border ${
                    freezeMode
                      ? "sticky top-0 left-0 z-40 w-[110px] min-w-[110px] max-w-[110px] shadow-r"
                      : "sticky top-0 left-0 z-20"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={toggleSelectAllFiltered}
                      title={
                        selectedRowKeys.size === filteredRows.length && filteredRows.length > 0
                          ? "সব আনচেক করুন"
                          : "সব ফিল্টার করা সারি সিলেক্ট করুন"
                      }
                      className="text-muted-foreground hover:text-white transition-colors"
                    >
                      {selectedRowKeys.size === filteredRows.length && filteredRows.length > 0 ? (
                        <CheckSquare className="w-4 h-4 text-purple-400" />
                      ) : selectedRowKeys.size > 0 ? (
                        <div className="w-4 h-4 rounded border border-purple-400 bg-purple-500/30 flex items-center justify-center">
                          <div className="w-2 h-0.5 bg-purple-300" />
                        </div>
                      ) : (
                        <Square className="w-4 h-4 text-muted-foreground/60" />
                      )}
                    </button>
                    <span>Line</span>
                  </div>
                </th>
                <th
                  className={`p-2.5 font-bold bg-panel-2 border-b border-border ${
                    freezeMode
                      ? "sticky top-0 left-[110px] z-50 w-[125px] min-w-[125px] max-w-[125px] text-foreground shadow-sm"
                      : ""
                  }`}
                >
                  Buyer
                </th>
                <th
                  className={`p-2.5 font-bold bg-panel-2 border-b border-border ${
                    freezeMode
                      ? "sticky top-0 left-[235px] z-50 w-[140px] min-w-[140px] max-w-[140px] text-foreground border-r border-border shadow-[4px_0_10px_-2px_rgba(0,0,0,0.5)]"
                      : ""
                  }`}
                >
                  Style
                </th>
                <th
                  className={`p-2.5 font-bold ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Season
                </th>
                <th
                  className={`p-2.5 font-bold min-w-[120px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  PO
                </th>
                <th
                  className={`p-2.5 font-bold min-w-[175px] bg-rose-500/5 text-rose-300 ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Progress Stepper
                </th>
                <th
                  className={`p-2.5 font-bold min-w-[110px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Color
                </th>
                <th
                  className={`p-2.5 font-bold min-w-[90px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Size
                </th>
                <th
                  className={`p-2.5 font-bold min-w-[80px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Block
                </th>
                <th
                  className={`p-2.5 text-right font-bold min-w-[90px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Order Qty
                </th>
                <th
                  className={`p-2.5 font-bold min-w-[110px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  PO Ship Date
                </th>
                <th
                  className={`p-2.5 font-bold min-w-[110px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Proposed Date
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-cyan-300 bg-cyan-500/5 min-w-[85px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Day Cut
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-blue-300 bg-blue-500/5 min-w-[85px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Day Input
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-emerald-400 bg-emerald-500/10 min-w-[95px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Day Output
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-sky-300 bg-sky-500/5 min-w-[85px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Wash Sent
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-sky-400 bg-sky-500/5 min-w-[85px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Wash Rcvd
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-indigo-300 bg-indigo-500/5 min-w-[95px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Fin. Lot Pass
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-purple-300 bg-purple-500/5 min-w-[85px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Day Poly
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-purple-400 bg-purple-500/5 min-w-[85px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Day Pack
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-amber-300 bg-amber-500/5 min-w-[85px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  DFI Offer
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-amber-400 bg-amber-500/5 min-w-[85px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  DFI Pass
                </th>
                <th
                  className={`p-2.5 text-right font-bold text-rose-300 bg-rose-500/5 min-w-[90px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  FRI Done
                </th>
                <th
                  className={`p-2.5 font-bold min-w-[150px] ${freezeMode ? "sticky top-0 z-30 bg-panel-2 border-b border-border shadow-xs" : ""}`}
                >
                  Remarks
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {filteredRows.map((r, i) => {
                const rowKey = `${r.planId}::${r.rawLine}`;
                const isSelected = selectedRowKeys.has(rowKey);
                const isCorrection =
                  r.existingId !== null &&
                  (r.dayOutput !== (r.originalActualQty ?? 0) ||
                    r.remarks !== (parseTrackingDetails(r.originalRemarks).userRemarks ?? ""));

                const rowCls = isSelected
                  ? "bg-purple-950/30 ring-1 ring-inset ring-purple-500/60"
                  : isCorrection
                    ? "bg-red-500/10 ring-1 ring-inset ring-red-500/50"
                    : r.dirty
                      ? "bg-amber-500/5"
                      : "hover:bg-panel-2/40";

                const stickyCellBg = isSelected
                  ? "bg-[#201538]"
                  : isCorrection
                    ? "bg-[#2b1319]"
                    : r.dirty
                      ? "bg-[#251d13]"
                      : i % 2 === 0
                        ? "bg-[#141b2e]"
                        : "bg-[#101726]";

                return (
                  <tr
                    key={`${r.planId}-${r.rawLine}-${i}`}
                    className={`${rowCls} transition-colors`}
                  >
                    {/* Line Column (Sticky left) with Checkbox */}
                    <td
                      className={`p-2.5 font-bold text-emerald-300 border-b border-border/30 ${
                        freezeMode
                          ? `sticky left-0 z-20 w-[110px] min-w-[110px] max-w-[110px] shadow-r ${stickyCellBg}`
                          : `sticky left-0 z-10 shadow-r ${isSelected ? "bg-purple-950/70" : "bg-panel"}`
                      }`}
                    >
                      <div className="flex items-center gap-2 whitespace-nowrap">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleRowSelection(rowKey)}
                          className="w-3.5 h-3.5 rounded border-border text-purple-600 focus:ring-purple-500 cursor-pointer"
                        />
                        <span className="truncate max-w-[65px]" title={r.line}>
                          {r.line.startsWith("Line - ") ? r.line.replace("Line - ", "L-") : r.line}
                        </span>
                        {isCorrection ? (
                          <span
                            title={`Original Output: ${r.originalActualQty ?? 0}`}
                            className="rounded border border-red-500/60 bg-red-500/20 px-1 py-0.2 text-[9px] font-bold text-red-300 uppercase shrink-0"
                          >
                            Rev
                          </span>
                        ) : null}
                      </div>
                    </td>

                    {/* Buyer Column (Sticky in freezeMode) */}
                    <td
                      className={`p-2.5 font-medium text-foreground whitespace-nowrap truncate border-b border-border/30 ${
                        freezeMode
                          ? `sticky left-[110px] z-20 w-[125px] min-w-[125px] max-w-[125px] ${stickyCellBg}`
                          : ""
                      }`}
                      title={r.buyer}
                    >
                      <span className="truncate block">{r.buyer}</span>
                    </td>

                    {/* Style Column (Sticky in freezeMode with right border & shadow) */}
                    <td
                      className={`p-2.5 font-medium text-muted-foreground whitespace-nowrap truncate border-b border-border/30 ${
                        freezeMode
                          ? `sticky left-[235px] z-20 w-[140px] min-w-[140px] max-w-[140px] border-r border-border shadow-[4px_0_10px_-2px_rgba(0,0,0,0.5)] ${stickyCellBg}`
                          : ""
                      }`}
                      title={r.style}
                    >
                      <span className="truncate block font-semibold text-slate-200">{r.style}</span>
                    </td>

                    {/* Season */}
                    <td className="p-2.5 text-muted-foreground/80 whitespace-nowrap">
                      {r.season || "—"}
                    </td>

                    {/* PO */}
                    <td className="p-2">
                      <input
                        type="text"
                        value={r.po}
                        onChange={(e) => updateRow(i, { po: e.target.value })}
                        placeholder="PO #"
                        className="w-full rounded border border-border bg-input/70 px-2 py-1 text-xs focus:ring-1 focus:ring-rose-500"
                      />
                    </td>

                    {/* Visual Progress Stepper Column */}
                    <td className="p-2 bg-rose-500/5">
                      <ProductionProgressStepper row={r} compact={true} />
                    </td>

                    {/* Color */}
                    <td className="p-2">
                      <input
                        type="text"
                        value={r.color}
                        onChange={(e) => updateRow(i, { color: e.target.value })}
                        placeholder="Color"
                        className="w-full rounded border border-border bg-input/70 px-2 py-1 text-xs focus:ring-1 focus:ring-rose-500"
                      />
                    </td>

                    {/* Size */}
                    <td className="p-2">
                      <input
                        type="text"
                        value={r.size}
                        onChange={(e) => updateRow(i, { size: e.target.value })}
                        placeholder="Size"
                        className="w-full rounded border border-border bg-input/70 px-2 py-1 text-xs focus:ring-1 focus:ring-rose-500"
                      />
                    </td>

                    {/* Block */}
                    <td className="p-2">
                      <input
                        type="text"
                        value={r.block}
                        onChange={(e) => updateRow(i, { block: e.target.value })}
                        placeholder="Block"
                        className="w-full rounded border border-border bg-input/70 px-2 py-1 text-xs focus:ring-1 focus:ring-rose-500"
                      />
                    </td>

                    {/* Order Qty */}
                    <td className="p-2 text-right">
                      <input
                        type="number"
                        min={0}
                        value={r.orderQty || ""}
                        onChange={(e) => updateRow(i, { orderQty: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="w-20 text-right rounded border border-border bg-input/70 px-1.5 py-1 text-xs font-mono focus:ring-1 focus:ring-rose-500"
                      />
                    </td>

                    {/* PO Ship Date */}
                    <td className="p-2">
                      <input
                        type="date"
                        value={r.poShipDate}
                        onChange={(e) => updateRow(i, { poShipDate: e.target.value })}
                        className="w-28 rounded border border-border bg-input/70 px-1.5 py-1 text-[11px] font-mono focus:ring-1 focus:ring-rose-500"
                      />
                    </td>

                    {/* Proposed Date */}
                    <td className="p-2">
                      <input
                        type="date"
                        value={r.proposedDate}
                        onChange={(e) => updateRow(i, { proposedDate: e.target.value })}
                        className="w-28 rounded border border-border bg-input/70 px-1.5 py-1 text-[11px] font-mono focus:ring-1 focus:ring-rose-500"
                      />
                    </td>

                    {/* Day Cutting */}
                    <td className="p-2 text-right bg-cyan-500/5">
                      <input
                        type="number"
                        min={0}
                        value={r.dayCutting || ""}
                        onChange={(e) => updateRow(i, { dayCutting: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="w-20 text-right rounded border border-cyan-500/30 bg-input px-1.5 py-1 text-xs font-mono text-cyan-300 focus:ring-1 focus:ring-cyan-500"
                      />
                    </td>

                    {/* Day Input */}
                    <td className="p-2 text-right bg-blue-500/5">
                      <input
                        type="number"
                        min={0}
                        value={r.dayInput || ""}
                        onChange={(e) => updateRow(i, { dayInput: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="w-20 text-right rounded border border-blue-500/30 bg-input px-1.5 py-1 text-xs font-mono text-blue-300 focus:ring-1 focus:ring-blue-500"
                      />
                    </td>

                    {/* Day Output (Sewing) */}
                    <td className="p-2 text-right bg-emerald-500/10">
                      <input
                        type="number"
                        min={0}
                        value={r.dayOutput || ""}
                        onChange={(e) => updateRow(i, { dayOutput: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className={`w-20 text-right rounded border px-1.5 py-1 text-xs font-mono font-bold focus:ring-1 ${
                          isCorrection
                            ? "border-red-500 bg-red-500/10 text-red-300 focus:ring-red-500"
                            : "border-emerald-500/40 bg-input text-emerald-400 focus:ring-emerald-500"
                        }`}
                      />
                      {isCorrection && (
                        <div className="text-[10px] text-red-300/80 font-mono mt-0.5">
                          orig: {(r.originalActualQty ?? 0).toLocaleString()}
                        </div>
                      )}
                    </td>

                    {/* Day Wash Sent */}
                    <td className="p-2 text-right bg-sky-500/5">
                      <input
                        type="number"
                        min={0}
                        value={r.dayWashSent || ""}
                        onChange={(e) => updateRow(i, { dayWashSent: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="w-20 text-right rounded border border-sky-500/30 bg-input px-1.5 py-1 text-xs font-mono text-sky-300 focus:ring-1 focus:ring-sky-500"
                      />
                    </td>

                    {/* Day Wash Rcvd */}
                    <td className="p-2 text-right bg-sky-500/5">
                      <input
                        type="number"
                        min={0}
                        value={r.dayWashRcvd || ""}
                        onChange={(e) => updateRow(i, { dayWashRcvd: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="w-20 text-right rounded border border-sky-500/30 bg-input px-1.5 py-1 text-xs font-mono text-sky-400 focus:ring-1 focus:ring-sky-500"
                      />
                    </td>

                    {/* Day Finishing Lot Pass */}
                    <td className="p-2 text-right bg-indigo-500/5">
                      <input
                        type="number"
                        min={0}
                        value={r.dayFinishingLotPass || ""}
                        onChange={(e) =>
                          updateRow(i, { dayFinishingLotPass: Number(e.target.value) || 0 })
                        }
                        placeholder="0"
                        className="w-20 text-right rounded border border-indigo-500/30 bg-input px-1.5 py-1 text-xs font-mono text-indigo-300 focus:ring-1 focus:ring-indigo-500"
                      />
                    </td>

                    {/* Day Poly */}
                    <td className="p-2 text-right bg-purple-500/5">
                      <input
                        type="number"
                        min={0}
                        value={r.dayPoly || ""}
                        onChange={(e) => updateRow(i, { dayPoly: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="w-20 text-right rounded border border-purple-500/30 bg-input px-1.5 py-1 text-xs font-mono text-purple-300 focus:ring-1 focus:ring-purple-500"
                      />
                    </td>

                    {/* Day Pack */}
                    <td className="p-2 text-right bg-purple-500/5">
                      <input
                        type="number"
                        min={0}
                        value={r.dayPack || ""}
                        onChange={(e) => updateRow(i, { dayPack: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="w-20 text-right rounded border border-purple-500/30 bg-input px-1.5 py-1 text-xs font-mono text-purple-400 focus:ring-1 focus:ring-purple-500"
                      />
                    </td>

                    {/* Day DFI Offer */}
                    <td className="p-2 text-right bg-amber-500/5">
                      <input
                        type="number"
                        min={0}
                        value={r.dayDfiOffer || ""}
                        onChange={(e) => updateRow(i, { dayDfiOffer: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="w-20 text-right rounded border border-amber-500/30 bg-input px-1.5 py-1 text-xs font-mono text-amber-300 focus:ring-1 focus:ring-amber-500"
                      />
                    </td>

                    {/* Day DFI Pass */}
                    <td className="p-2 text-right bg-amber-500/5">
                      <input
                        type="number"
                        min={0}
                        value={r.dayDfiPass || ""}
                        onChange={(e) => updateRow(i, { dayDfiPass: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="w-20 text-right rounded border border-amber-500/30 bg-input px-1.5 py-1 text-xs font-mono text-amber-400 focus:ring-1 focus:ring-amber-500"
                      />
                    </td>

                    {/* FRI Done Qty */}
                    <td className="p-2 text-right bg-rose-500/5">
                      <input
                        type="number"
                        min={0}
                        value={r.friDoneQty || ""}
                        onChange={(e) => updateRow(i, { friDoneQty: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="w-20 text-right rounded border border-rose-500/30 bg-input px-1.5 py-1 text-xs font-mono font-bold text-rose-300 focus:ring-1 focus:ring-rose-500"
                      />
                    </td>

                    {/* Remarks */}
                    <td className="p-2">
                      <input
                        type="text"
                        value={r.remarks}
                        onChange={(e) => updateRow(i, { remarks: e.target.value })}
                        placeholder="মন্তব্য বা নোট..."
                        className="w-full rounded border border-border bg-input/70 px-2 py-1 text-xs focus:ring-1 focus:ring-sky-500"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>

            {/* Matrix Summary Footer */}
            <tfoot className="bg-panel-2 font-bold border-t-2 border-border text-[11px] sticky bottom-0 z-10 shadow-lg">
              <tr>
                <td className="p-3 text-sky-300 bg-panel-2 sticky left-0 z-20 shadow-r" colSpan={4}>
                  TOTAL ({filteredRows.length} Lines)
                </td>
                <td colSpan={8}></td>
                <td className="p-3 text-right font-mono text-cyan-300 bg-cyan-500/10">
                  {totals.dayCutting.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-blue-300 bg-blue-500/10">
                  {totals.dayInput.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-emerald-400 bg-emerald-500/20">
                  {totals.dayOutput.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-sky-300 bg-sky-500/10">
                  {totals.dayWashSent.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-sky-400 bg-sky-500/10">
                  {totals.dayWashRcvd.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-indigo-300 bg-indigo-500/10">
                  {totals.dayFinishingLotPass.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-purple-300 bg-purple-500/10">
                  {totals.dayPoly.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-purple-400 bg-purple-500/10">
                  {totals.dayPack.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-amber-300 bg-amber-500/10">
                  {totals.dayDfiOffer.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-amber-400 bg-amber-500/10">
                  {totals.dayDfiPass.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-rose-300 bg-rose-500/10">
                  {totals.friDoneQty.toLocaleString()}
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}

      {/* Excel Data Import Modal */}
      {importModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-150">
          <div className="bg-panel border border-border rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <div>
                <h3 className="text-base font-bold text-purple-300 flex items-center gap-2">
                  <FileUp className="w-5 h-5 text-purple-400" /> Excel Data Import (Daily &amp; Back
                  Data)
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Excel শিট থেকে দৈনন্দিন বা বিগত দিনের সমস্ত প্রোডাকশন ডেটা এক ক্লিকে বাল্ক ইমপোর্ট
                  করুন।
                </p>
              </div>
              <button
                onClick={() => setImportModalOpen(false)}
                className="text-muted-foreground hover:text-foreground text-sm font-bold p-1 rounded-md"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div className="bg-panel-2/60 rounded-xl p-4 border border-border/80 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-foreground">
                    ১. স্ট্যান্ডার্ড টেমপ্লেট ডাউনলোড করুন:
                  </span>
                  <button
                    onClick={downloadTemplate}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-sky-400 hover:text-sky-300 bg-sky-500/10 border border-sky-500/30 px-2.5 py-1 rounded-md transition"
                  >
                    <Download className="w-3.5 h-3.5" /> Sample Template (.xlsx)
                  </button>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  টেমপ্লেটে{" "}
                  <strong>
                    Line, Buyer, Style, Season, PO, Color, Size, Block, Order Qty, PO Ship Date,
                    Proposed Date, Day Cutting, Day Input, Day Output, Day Wash, Finishing, Poly,
                    Pack, DFI, FRI
                  </strong>{" "}
                  সহ সব কলামের ফরম্যাট দেওয়া আছে।
                </p>
              </div>

              <div className="bg-panel-2/60 rounded-xl p-4 border border-border/80 space-y-3">
                <span className="text-xs font-bold text-foreground block">
                  ২. প্রস্তুতকৃত Excel ফাইল নির্বাচন করুন:
                </span>

                <div className="flex flex-col items-center justify-center border-2 border-dashed border-border rounded-xl p-6 hover:border-purple-500/50 transition bg-input/30 text-center">
                  <FileUp className="w-8 h-8 text-purple-400 mb-2 opacity-80" />
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx, .xls, .csv"
                    onChange={handleFileUpload}
                    className="block w-full text-xs text-muted-foreground file:mr-4 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700 cursor-pointer"
                  />
                  <p className="text-[11px] text-muted-foreground mt-2">
                    সাপোর্টেড ফরম্যাট: .xlsx, .xls, .csv (তারিখ কলামে যে কোনো তারিখ থাকলে ব্যাক-ডেটা
                    হিসেবে সংরক্ষিত হবে)
                  </p>
                </div>
              </div>

              <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-3 flex items-start gap-2.5 text-amber-300 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                <div className="space-y-1">
                  <p className="font-bold">গুরুত্বপূর্ণ নির্দেশনা:</p>
                  <p className="text-[11px] text-amber-200/90 leading-tight">
                    • সিস্টেম স্বয়ংক্রিয়ভাবে Style ও Line নাম মিলিয়ে সংশ্লিষ্ট প্ল্যানের সাথে ডেটা
                    যুক্ত করবে।
                    <br />• Day Output সংখ্যাটি স্বয়ংক্রিয়ভাবে মূল Actual Production হিসেবে সংগৃহীত
                    হবে এবং Early/Delay ও Plan Board এ রিফ্লেক্ট করবে।
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-border">
              <button
                onClick={() => setImportModalOpen(false)}
                className="px-4 py-2 rounded-lg border border-border text-xs font-semibold hover:bg-panel-2 text-foreground"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Batch Processing Modal */}
      {batchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-150">
          <div className="bg-panel border border-border rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <div>
                <h3 className="text-base font-bold text-purple-300 flex items-center gap-2">
                  <Layers className="w-5 h-5 text-purple-400" /> Batch Status &amp; Stage Update
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  নির্বাচিত{" "}
                  <strong className="text-white font-mono">{selectedRowKeys.size}টি</strong> PO
                  সারিতে এক ক্লিকে প্রোডাকশন কোয়ান্টিটি ও স্ট্যাটাস আপডেট করুন।
                </p>
              </div>
              <button
                onClick={() => setBatchModalOpen(false)}
                className="text-muted-foreground hover:text-foreground text-sm font-bold p-1 rounded-md"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* Target Stage */}
              <div>
                <label className="block text-xs font-bold text-foreground mb-1.5">
                  কোন প্রোডাকশন স্টেজ আপডেট করতে চান?
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: "Poly", label: "Day Poly" },
                    { id: "Pack", label: "Day Pack" },
                    { id: "Output", label: "Day Output" },
                    { id: "WashSent", label: "Wash Sent" },
                    { id: "WashRcvd", label: "Wash Rcvd" },
                    { id: "Cut", label: "Day Cut" },
                    { id: "Input", label: "Day Input" },
                    { id: "FinPass", label: "Fin. Lot Pass" },
                    { id: "FriDone", label: "FRI Done" },
                  ].map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setBatchStage(s.id as any)}
                      className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-all text-center ${
                        batchStage === s.id
                          ? "bg-purple-600 border-purple-400 text-white shadow-sm ring-2 ring-purple-500/40"
                          : "bg-panel-2/60 border-border text-muted-foreground hover:text-foreground hover:bg-panel-2"
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity Value Mode */}
              <div>
                <label className="block text-xs font-bold text-foreground mb-1.5">
                  কোয়ান্টিটি (Quantity) ভ্যালু কীভাবে সেট করবেন?
                </label>
                <div className="space-y-2">
                  <label className="flex items-center gap-2.5 p-2 rounded-lg border border-border bg-input/40 cursor-pointer hover:bg-input/60">
                    <input
                      type="radio"
                      name="batchMode"
                      checked={batchMode === "order_qty"}
                      onChange={() => setBatchMode("order_qty")}
                      className="text-purple-600 focus:ring-purple-500"
                    />
                    <div className="text-xs">
                      <span className="font-bold text-foreground">প্রতিটি PO-এর Order Qty দিন</span>
                      <p className="text-[11px] text-muted-foreground">
                        প্রতিটি নির্বাচিত PO এর নির্দিষ্ট Order Quantity অনুযায়ী স্বয়ংক্রিয়ভাবে
                        পূর্ণ হবে (100% Complete)
                      </p>
                    </div>
                  </label>

                  <label className="flex items-center gap-2.5 p-2 rounded-lg border border-border bg-input/40 cursor-pointer hover:bg-input/60">
                    <input
                      type="radio"
                      name="batchMode"
                      checked={batchMode === "day_output"}
                      onChange={() => setBatchMode("day_output")}
                      className="text-purple-600 focus:ring-purple-500"
                    />
                    <div className="text-xs">
                      <span className="font-bold text-foreground">
                        Day Output-এর সমান কোয়ান্টিটি দিন
                      </span>
                      <p className="text-[11px] text-muted-foreground">
                        লাইনের আজকের সুইং আউটপুটের সমপরিমাণ সংখ্যা এই স্টেজে বসবে
                      </p>
                    </div>
                  </label>

                  <label className="flex items-center gap-2.5 p-2 rounded-lg border border-border bg-input/40 cursor-pointer hover:bg-input/60">
                    <input
                      type="radio"
                      name="batchMode"
                      checked={batchMode === "fixed_qty"}
                      onChange={() => setBatchMode("fixed_qty")}
                      className="text-purple-600 focus:ring-purple-500"
                    />
                    <div className="text-xs flex-1">
                      <span className="font-bold text-foreground">
                        নির্দিষ্ট সংখ্যা (Custom Fixed Qty)
                      </span>
                      {batchMode === "fixed_qty" && (
                        <input
                          type="number"
                          min={0}
                          value={batchCustomValue}
                          onChange={(e) => setBatchCustomValue(e.target.value)}
                          placeholder="উদা: 500"
                          className="mt-1.5 w-full rounded border border-purple-500/40 bg-input px-2 py-1 text-xs font-mono text-purple-300 focus:ring-1 focus:ring-purple-500"
                        />
                      )}
                    </div>
                  </label>

                  <label className="flex items-center gap-2.5 p-2 rounded-lg border border-border bg-input/40 cursor-pointer hover:bg-input/60">
                    <input
                      type="radio"
                      name="batchMode"
                      checked={batchMode === "clear"}
                      onChange={() => setBatchMode("clear")}
                      className="text-purple-600 focus:ring-purple-500"
                    />
                    <div className="text-xs">
                      <span className="font-bold text-foreground">
                        রিসেট বা শূন্য (Clear / 0) করুন
                      </span>
                      <p className="text-[11px] text-muted-foreground">
                        নির্বাচিত স্টেজের আজকের কোয়ান্টিটি মুছে ০ করা হবে
                      </p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Optional Proposed Date batch update */}
              <div>
                <label className="block text-xs font-bold text-foreground mb-1">
                  Proposed Date পরিবর্তন (ঐচ্ছিক):
                </label>
                <input
                  type="date"
                  value={batchProposedDate}
                  onChange={(e) => setBatchProposedDate(e.target.value)}
                  className="w-full rounded border border-border bg-input/70 px-2.5 py-1.5 text-xs font-mono focus:ring-1 focus:ring-purple-500"
                />
              </div>

              {/* Optional Remarks appending */}
              <div>
                <label className="block text-xs font-bold text-foreground mb-1">
                  নোট বা রিমার্কস যুক্ত করুন (ঐচ্ছিক):
                </label>
                <input
                  type="text"
                  value={batchAppendRemarks}
                  onChange={(e) => setBatchAppendRemarks(e.target.value)}
                  placeholder="উদা: Batch packed, Full shipment ready..."
                  className="w-full rounded border border-border bg-input/70 px-2.5 py-1.5 text-xs focus:ring-1 focus:ring-purple-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-border">
              <button
                type="button"
                onClick={() => {
                  clearSelection();
                  setBatchModalOpen(false);
                }}
                className="px-3 py-1.5 rounded-lg border border-border text-xs font-semibold hover:bg-panel-2 text-muted-foreground"
              >
                বাতিল করুন
              </button>

              <button
                type="button"
                onClick={() => {
                  applyBatchUpdate({
                    stage: batchStage,
                    mode: batchMode,
                    customValue: Number(batchCustomValue) || 0,
                    newProposedDate: batchProposedDate,
                    appendRemarks: batchAppendRemarks,
                  });
                  setBatchModalOpen(false);
                }}
                className="px-4 py-2 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md transition-all flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                {selectedRowKeys.size}টি সারিতে প্রয়োগ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
