import { useMemo, useState, useEffect, useRef } from "react";
import {
  X,
  Search,
  Layers,
  Factory,
  Calendar,
  CheckSquare,
  Square,
  ArrowRight,
  ArrowRightLeft,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  ChevronUp,
  ChevronDown,
  Loader2,
  RotateCcw,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/hooks/use-current-user";
import { logActivity } from "@/lib/audit-logger";
import {
  calculatePlan,
  nextWorkingDay,
  formatDate,
  type LineInput,
  type PlanResult,
  type TargetAdjustment,
} from "@/lib/plan-calc";
import { normLine, canonicalLineName, buildLinePresetLookup } from "./lineLookup";

export type BulkPlanItem = {
  id: string;
  buyer: string;
  style: string;
  season?: string | null;
  order_qty: number;
  excess_pct?: number;
  daily_target?: number;
  shipment_date?: string;
  config?: {
    status?: string;
    isUnplanned?: boolean;
    lines?: LineInput[];
    customHolidays?: string[];
    targetAdjustments?: TargetAdjustment[];
    targetAdjustmentsEnabled?: boolean;
    learningCurve?: number[];
    learningCurveEnabled?: boolean;
  };
  calc_result?: PlanResult;
};

export type BulkStyleAssignmentModalProps = {
  open: boolean;
  onClose: () => void;
  plans: BulkPlanItem[];
  initialSelectedPlanIds?: string[];
  linePresets: string[];
  globalHolidays: string[];
  onSuccess?: () => void;
};

type AssignmentStrategy = "sequential" | "keep_dates" | "same_start";

const EMPTY_INITIAL_IDS: string[] = [];

export function BulkStyleAssignmentModal({
  open,
  onClose,
  plans,
  initialSelectedPlanIds = EMPTY_INITIAL_IDS,
  linePresets,
  globalHolidays,
  onSuccess,
}: BulkStyleAssignmentModalProps) {
  const { data: user } = useCurrentUser();

  // Search & filter states for style picker
  const [search, setSearch] = useState("");
  const [filterBuyer, setFilterBuyer] = useState("all");
  const [filterLine, setFilterLine] = useState("all");

  // Selection state
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Target line selection
  const [targetLine, setTargetLine] = useState<string>("");

  // Scheduling strategy
  const [strategy, setStrategy] = useState<AssignmentStrategy>("sequential");

  // Start date for sequential or same_start mode (defaults to tomorrow)
  const [baseStartDate, setBaseStartDate] = useState<string>(
    new Date(Date.now() + 86400000).toISOString().slice(0, 10),
  );

  // Submitting state
  const [submitting, setSubmitting] = useState(false);

  // Track previous open state so we ONLY reset when modal transitions from closed to open
  const prevOpenKeyRef = useRef<string>("");
  const initialIdsKey = (initialSelectedPlanIds || []).join(",");

  useEffect(() => {
    if (open) {
      const openKey = `${open}:${initialIdsKey}`;
      if (prevOpenKeyRef.current !== openKey) {
        prevOpenKeyRef.current = openKey;
        if (initialSelectedPlanIds && initialSelectedPlanIds.length > 0) {
          // Keep order of initialSelectedPlanIds
          const validIds = initialSelectedPlanIds.filter((id) => plans.some((p) => p.id === id));
          setSelectedIds(validIds);
        } else {
          setSelectedIds([]);
        }
        setSearch("");
        setFilterBuyer("all");
        setFilterLine("all");
        setStrategy("sequential");
        setBaseStartDate(new Date(Date.now() + 86400000).toISOString().slice(0, 10));

        if (linePresets && linePresets.length > 0) {
          setTargetLine(linePresets[0]);
        }
      }
    } else {
      prevOpenKeyRef.current = "";
    }
  }, [open, initialIdsKey, plans, linePresets, initialSelectedPlanIds]);

  // Unique buyers
  const buyers = useMemo(() => {
    if (!open) return [];
    const set = new Set<string>();
    plans.forEach((p) => p.buyer && set.add(p.buyer));
    return Array.from(set).sort();
  }, [open, plans]);

  const presetLookup = useMemo(() => buildLinePresetLookup(linePresets || []), [linePresets]);

  // Unique current lines across plans
  const currentLines = useMemo(() => {
    if (!open) return [];
    const set = new Set<string>();
    plans.forEach((p) => {
      const isUnplanned =
        p.config?.isUnplanned ||
        p.config?.status === "unplanned" ||
        !p.calc_result?.lines ||
        p.calc_result.lines.length === 0;
      if (isUnplanned) {
        set.add("__unplanned__");
      } else {
        p.calc_result?.lines?.forEach(
          (l) => l.name && set.add(canonicalLineName(l.name, presetLookup)),
        );
      }
    });
    return Array.from(set).sort();
  }, [open, plans, presetLookup]);

  // Filtered available styles
  const filteredPlans = useMemo(() => {
    if (!open) return [];
    return plans.filter((p) => {
      // Buyer filter
      if (filterBuyer !== "all" && p.buyer !== filterBuyer) return false;

      // Line filter
      if (filterLine !== "all") {
        const isUnplanned =
          p.config?.isUnplanned ||
          p.config?.status === "unplanned" ||
          !p.calc_result?.lines ||
          p.calc_result.lines.length === 0;
        if (filterLine === "__unplanned__") {
          if (!isUnplanned) return false;
        } else {
          const hasLine = p.calc_result?.lines?.some(
            (l) => canonicalLineName(l.name, presetLookup) === filterLine,
          );
          if (!hasLine) return false;
        }
      }

      // Search query
      if (search.trim()) {
        const q = search.trim().toLowerCase();
        const styleMatch = p.style?.toLowerCase().includes(q);
        const buyerMatch = p.buyer?.toLowerCase().includes(q);
        const seasonMatch = p.season?.toLowerCase().includes(q);
        return styleMatch || buyerMatch || seasonMatch;
      }

      return true;
    });
  }, [open, plans, filterBuyer, filterLine, search, presetLookup]);

  // Selected plan objects preserving the order of selection
  const selectedPlans = useMemo(() => {
    if (!open) return [];
    const map = new Map(plans.map((p) => [p.id, p]));
    return selectedIds.map((id) => map.get(id)).filter((p): p is BulkPlanItem => Boolean(p));
  }, [open, selectedIds, plans]);

  // Toggle selection for an item
  const toggleItem = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  // Select all visible filtered items
  const selectAllFiltered = () => {
    const newIds = new Set(selectedIds);
    filteredPlans.forEach((p) => newIds.add(p.id));
    setSelectedIds(Array.from(newIds));
  };

  // Deselect all
  const deselectAll = () => {
    setSelectedIds([]);
  };

  // Reorder items in selected list (moves item up or down)
  const moveItemOrder = (index: number, direction: "up" | "down") => {
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= selectedIds.length) return;
    const nextIds = [...selectedIds];
    const [moved] = nextIds.splice(index, 1);
    nextIds.splice(targetIndex, 0, moved);
    setSelectedIds(nextIds);
  };

  // Inspect existing occupancy of target line
  const targetLineOccupancy = useMemo(() => {
    if (!open || !targetLine) return { count: 0, latestFinish: null as string | null };
    const norm = normLine(targetLine);
    let count = 0;
    let latestFinish: string | null = null;

    plans.forEach((p) => {
      // Exclude styles that are currently selected for moving to avoid counting themselves
      if (selectedIds.includes(p.id)) return;
      p.calc_result?.lines?.forEach((l) => {
        if (normLine(l.name) === norm && l.finishDateStr) {
          count++;
          if (!latestFinish || l.finishDateStr > latestFinish) {
            latestFinish = l.finishDateStr;
          }
        }
      });
    });

    return { count, latestFinish };
  }, [open, targetLine, plans, selectedIds]);

  // Auto-suggest starting date based on target line's latest finish
  const suggestedStartDate = useMemo(() => {
    if (targetLineOccupancy.latestFinish) {
      return nextWorkingDay(targetLineOccupancy.latestFinish, globalHolidays);
    }
    return new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  }, [targetLineOccupancy.latestFinish, globalHolidays]);

  // Live Projected Schedule Calculation for Selected Styles
  const projectedSchedules = useMemo(() => {
    if (!open || !targetLine || selectedPlans.length === 0) return [];

    const results: Array<{
      plan: BulkPlanItem;
      startDate: string;
      finishDate: string;
      workingDays: number;
      dailyTarget: number;
      delayed: boolean;
    }> = [];

    let currentStart = baseStartDate;

    for (const p of selectedPlans) {
      const orderQty = p.order_qty || 1000;
      const excessPct = p.excess_pct ?? 0;
      const dailyTarget = p.daily_target && p.daily_target > 0 ? p.daily_target : 500;
      const shipDate = p.shipment_date || "";

      let styleStartDate = currentStart;

      if (strategy === "keep_dates") {
        // Keep existing start date if present
        const existingStart = p.calc_result?.lines?.[0]?.startDateStr;
        styleStartDate = existingStart || baseStartDate;
      } else if (strategy === "same_start") {
        styleStartDate = baseStartDate;
      }

      const mergedHolidays = Array.from(
        new Set([...(globalHolidays || []), ...(p.config?.customHolidays || [])]),
      );

      const lineInput: LineInput = {
        id: 1,
        name: targetLine,
        startDateStr: styleStartDate,
        allocatedOrderQty: orderQty,
        applyLC: false,
        chainAuto: true,
        targetOverride: dailyTarget,
      };

      const simulated = calculatePlan({
        buyer: p.buyer,
        style: p.style,
        orderQty,
        excessPct,
        dailyTargetPerLine: dailyTarget,
        shipmentDate: shipDate,
        lines: [lineInput],
        customHolidays: mergedHolidays,
        targetAdjustments: p.config?.targetAdjustments || [],
        targetAdjustmentsEnabled: Boolean(p.config?.targetAdjustmentsEnabled),
        learningCurve: p.config?.learningCurve,
      });

      const resLine = simulated.lines?.[0];
      const finishDate = resLine?.finishDateStr || styleStartDate;
      const workingDays = resLine?.workingDays || 1;
      const isDelayed = shipDate ? finishDate > shipDate : false;

      results.push({
        plan: p,
        startDate: styleStartDate,
        finishDate,
        workingDays,
        dailyTarget,
        delayed: isDelayed,
      });

      if (strategy === "sequential") {
        // Next style starts the working day after current style finishes
        currentStart = nextWorkingDay(finishDate, mergedHolidays);
      }
    }

    return results;
  }, [targetLine, selectedPlans, strategy, baseStartDate, globalHolidays]);

  // Total quantity of selected plans
  const totalSelectedQty = useMemo(() => {
    return selectedPlans.reduce((sum, p) => sum + (p.order_qty || 0), 0);
  }, [selectedPlans]);

  // Execute Bulk Assignment
  const handleExecuteBulkAssignment = async () => {
    if (selectedPlans.length === 0) {
      toast.error("অনুগ্রহ করে অন্তত একটি স্টাইল নির্বাচন করুন।");
      return;
    }
    if (!targetLine) {
      toast.error("অনুগ্রহ করে একটি টার্গেট প্রোডাকশন লাইন নির্বাচন করুন।");
      return;
    }

    setSubmitting(true);
    try {
      const updates = [];

      for (const item of projectedSchedules) {
        const { plan: p, startDate } = item;
        const orderQty = p.order_qty || 1000;
        const excessPct = p.excess_pct ?? 0;
        const dailyTarget = p.daily_target && p.daily_target > 0 ? p.daily_target : 500;
        const shipDate = p.shipment_date || "";

        const mergedHolidays = Array.from(
          new Set([...(globalHolidays || []), ...(p.config?.customHolidays || [])]),
        );

        const newLine: LineInput = {
          id: 1,
          name: targetLine,
          startDateStr: startDate,
          allocatedOrderQty: orderQty,
          applyLC: false,
          chainAuto: true,
          targetOverride: dailyTarget,
        };

        const updatedCalc = calculatePlan({
          buyer: p.buyer,
          style: p.style,
          orderQty,
          excessPct,
          dailyTargetPerLine: dailyTarget,
          shipmentDate: shipDate,
          lines: [newLine],
          customHolidays: mergedHolidays,
          targetAdjustments: p.config?.targetAdjustments || [],
          targetAdjustmentsEnabled: Boolean(p.config?.targetAdjustmentsEnabled),
          learningCurve: p.config?.learningCurve,
        });

        const updatedConfig = {
          ...(p.config || {}),
          status: "planned",
          isUnplanned: false,
          lines: updatedCalc.lines,
          last_bulk_assigned_at: new Date().toISOString(),
          last_bulk_target_line: targetLine,
        };

        updates.push(
          supabase
            .from("plans")
            .update({
              num_lines: 1,
              config: updatedConfig as any,
              calc_result: updatedCalc as any,
            } as any)
            .eq("id", p.id),
        );
      }

      const results = await Promise.all(updates);
      const errors = results.filter((r) => r.error);
      if (errors.length > 0) {
        throw new Error(errors[0].error?.message || "কিছু স্টাইল আপডেট করতে ব্যর্থ হয়েছে।");
      }

      // Log activity
      logActivity({
        action: "BOARD_RESCHEDULE",
        details: `বাল্ক লাইন অ্যাসাইনমেন্ট: ${selectedPlans.length}টি স্টাইল (মোট ${totalSelectedQty.toLocaleString()} pcs) "${targetLine}"-এ স্থানান্তর ও শিডিউল করা হয়েছে (${strategy})`,
        targetName: targetLine,
        metadata: {
          targetLine,
          strategy,
          baseStartDate,
          styleCount: selectedPlans.length,
          styles: selectedPlans.map((p) => p.style),
          totalQty: totalSelectedQty,
        },
      });

      toast.success(
        `সফলভাবে ${selectedPlans.length}টি স্টাইল "${targetLine}"-এ স্থানান্তর করা হয়েছে!`,
        {
          description: `মোট ${totalSelectedQty.toLocaleString()} pcs একযোগে নতুন লাইনে শিডিউল হয়েছে।`,
        },
      );

      onSuccess?.();
      onClose();
    } catch (err: any) {
      console.error(err);
      toast.error("বাল্ক অ্যাসাইনমেন্ট সম্পন্ন করা যায়নি: " + (err?.message || "Error"));
    } finally {
      setSubmitting(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-2xl border border-purple-500/40 bg-panel shadow-2xl overflow-hidden animate-in fade-in-50 zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-border bg-gradient-to-r from-purple-950/50 via-panel to-panel flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-foreground">
                  বাল্ক লাইন অ্যাসাইনমেন্ট (Bulk Style Line Assignment)
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30 font-mono">
                  Multi-Style Move
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                একাধিক স্টাইল একসাথে নির্দিষ্ট প্রোডাকশন লাইনে স্থানান্তর করুন এবং দ্রুত শিডিউল
                সাজান
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-panel-2 text-muted-foreground hover:text-foreground transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto text-xs flex-1">
          {/* Top Config Row: Target Line & Strategy */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-3.5 rounded-xl border border-border bg-panel-2/60">
            {/* Target Line Picker */}
            <div className="space-y-1">
              <label className="text-[11px] font-black text-foreground flex items-center gap-1.5">
                <Factory className="w-3.5 h-3.5 text-purple-400" />
                <span>টার্গেট প্রোডাকশন লাইন:</span>
              </label>
              <select
                value={targetLine}
                onChange={(e) => setTargetLine(e.target.value)}
                className="w-full rounded-lg border border-purple-500/40 bg-input px-3 py-2 text-xs font-bold text-foreground focus:outline-none focus:ring-1 focus:ring-purple-500 cursor-pointer"
              >
                {linePresets.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
              {targetLineOccupancy.count > 0 ? (
                <div className="text-[10px] text-amber-300 flex items-center gap-1">
                  <span>⚠️</span>
                  <span>
                    এই লাইনে {targetLineOccupancy.count}টি স্টাইল শিডিউল্ড (চলবে:{" "}
                    {formatDate(targetLineOccupancy.latestFinish || "")} পর্যন্ত)
                  </span>
                </div>
              ) : (
                <div className="text-[10px] text-emerald-400 flex items-center gap-1">
                  <span>✓</span>
                  <span>এই লাইন সম্পূর্ণ খালি বা ফ্রি রয়েছে</span>
                </div>
              )}
            </div>

            {/* Strategy Selection */}
            <div className="space-y-1">
              <label className="text-[11px] font-black text-foreground flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                <span>শিডিউলিং পদ্ধতি:</span>
              </label>
              <select
                value={strategy}
                onChange={(e) => setStrategy(e.target.value as AssignmentStrategy)}
                className="w-full rounded-lg border border-border bg-input px-3 py-2 text-xs font-bold text-foreground focus:outline-none focus:ring-1 focus:ring-teal-500 cursor-pointer"
              >
                <option value="sequential">ধারাবাহিক শিডিউল (একটার পর একটা - No Overlap)</option>
                <option value="keep_dates">মূল তারিখ বজায় রাখুন (Keep Existing Dates)</option>
                <option value="same_start">একই তারিখে শুরু (Same Start Date)</option>
              </select>
              <span className="text-[10px] text-muted-foreground block">
                {strategy === "sequential"
                  ? "✓ প্রতিটি স্টাইল শেষ হওয়ার পরের কর্মদিবসে পরের স্টাইল শুরু হবে"
                  : strategy === "keep_dates"
                    ? "✓ স্টাইলগুলোর বিদ্যমান তারিখ অপরিবর্তিত থাকবে"
                    : "✓ সব স্টাইল একই শুরুর তারিখ থেকে শুরু হবে"}
              </span>
            </div>

            {/* Base Start Date */}
            <div className="space-y-1">
              <label className="text-[11px] font-black text-foreground flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                  <span>
                    {strategy === "sequential" ? "প্রথম স্টাইলের শুরুর তারিখ:" : "শুরুর তারিখ:"}
                  </span>
                </span>
                {targetLineOccupancy.latestFinish && (
                  <button
                    type="button"
                    onClick={() => setBaseStartDate(suggestedStartDate)}
                    className="text-[9.5px] text-teal-400 hover:underline cursor-pointer"
                    title="ফ্রি হওয়ার তারিখ সেট করুন"
                  >
                    ফ্রি ডেট ব্যবহার করুন
                  </button>
                )}
              </label>
              <input
                type="date"
                value={baseStartDate}
                onChange={(e) => setBaseStartDate(e.target.value)}
                disabled={strategy === "keep_dates"}
                className="w-full rounded-lg border border-border bg-input px-3 py-2 text-xs font-bold text-foreground focus:outline-none focus:ring-1 focus:ring-cyan-500 cursor-pointer disabled:opacity-40"
              />
              <span className="text-[10px] text-muted-foreground block">
                {strategy === "keep_dates"
                  ? "বর্তমান তারিখ বজায় থাকবে"
                  : `নির্বাচিত তারিখ: ${formatDate(baseStartDate)}`}
              </span>
            </div>
          </div>

          {/* Main 2-column layout: Left = Style Picker, Right = Projected Preview */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Left Column: Style Selection List (7 cols) */}
            <div className="lg:col-span-6 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-foreground text-xs flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-purple-400" />
                    স্টাইল নির্বাচন করুন:
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-mono font-bold text-[10px]">
                    {selectedIds.length} / {plans.length} নির্বাচিত
                  </span>
                </div>
                <div className="flex items-center gap-1 text-[11px]">
                  <button
                    type="button"
                    onClick={selectAllFiltered}
                    className="px-2 py-0.5 rounded hover:bg-panel-2 text-teal-300 font-semibold cursor-pointer"
                  >
                    ফিল্টারকৃত সব
                  </button>
                  <span className="text-border">|</span>
                  <button
                    type="button"
                    onClick={deselectAll}
                    className="px-2 py-0.5 rounded hover:bg-panel-2 text-muted-foreground hover:text-foreground cursor-pointer"
                  >
                    ক্লিয়ার
                  </button>
                </div>
              </div>

              {/* Filters & Search */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div className="sm:col-span-1 relative">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="স্টাইল / বায়ার খুঁজুন..."
                    className="w-full pl-8 pr-2.5 py-1.5 rounded-lg border border-border bg-input text-foreground text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <select
                    value={filterBuyer}
                    onChange={(e) => setFilterBuyer(e.target.value)}
                    className="w-full px-2 py-1.5 rounded-lg border border-border bg-input text-foreground text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-500 cursor-pointer"
                  >
                    <option value="all">সব বায়ার ({buyers.length})</option>
                    {buyers.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <select
                    value={filterLine}
                    onChange={(e) => setFilterLine(e.target.value)}
                    className="w-full px-2 py-1.5 rounded-lg border border-border bg-input text-foreground text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-500 cursor-pointer"
                  >
                    <option value="all">সব বর্তমান লাইন</option>
                    <option value="__unplanned__">📦 শুধু আনপ্ল্যান্ড পুল</option>
                    {currentLines
                      .filter((l) => l !== "__unplanned__")
                      .map((l) => (
                        <option key={l} value={l}>
                          {l}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              {/* Style List Box */}
              <div className="border border-border rounded-xl bg-panel-2/30 divide-y divide-border/60 max-h-[300px] sm:max-h-[340px] overflow-y-auto">
                {filteredPlans.length === 0 ? (
                  <div className="p-8 text-center text-muted-foreground space-y-1">
                    <p className="font-semibold">কোনো স্টাইল পাওয়া যায়নি</p>
                    <p className="text-[11px]">সার্চ বা ফিল্টার পরিবর্তন করে দেখুন।</p>
                  </div>
                ) : (
                  filteredPlans.map((p) => {
                    const isSelected = selectedIds.includes(p.id);
                    const selectedIdx = selectedIds.indexOf(p.id);
                    const isUnplanned =
                      p.config?.isUnplanned ||
                      p.config?.status === "unplanned" ||
                      !p.calc_result?.lines ||
                      p.calc_result.lines.length === 0;
                    const lineNames = isUnplanned
                      ? "📦 আনপ্ল্যান্ড"
                      : p.calc_result?.lines?.map((l) => l.name).join(", ") || "—";

                    return (
                      <div
                        key={p.id}
                        onClick={() => toggleItem(p.id)}
                        className={`p-2.5 flex items-center justify-between gap-2.5 transition cursor-pointer select-none ${
                          isSelected
                            ? "bg-purple-500/15 hover:bg-purple-500/20"
                            : "hover:bg-panel-2/60"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleItem(p.id);
                            }}
                            className="text-purple-400 hover:text-purple-300 transition"
                          >
                            {isSelected ? (
                              <CheckSquare className="w-4 h-4 fill-purple-600/30 text-purple-400" />
                            ) : (
                              <Square className="w-4 h-4 text-muted-foreground" />
                            )}
                          </button>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-bold text-foreground truncate">{p.style}</span>
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-panel border border-border text-muted-foreground">
                                {p.buyer}
                              </span>
                              {p.season && (
                                <span className="text-[10px] text-muted-foreground">
                                  ({p.season})
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-[10.5px] text-muted-foreground mt-0.5">
                              <span>
                                বর্তমান:{" "}
                                <b
                                  className={
                                    isUnplanned
                                      ? "text-amber-400 font-semibold"
                                      : "text-cyan-300 font-mono"
                                  }
                                >
                                  {lineNames}
                                </b>
                              </span>
                              <span>·</span>
                              <span className="font-mono text-emerald-400 font-semibold">
                                {(p.order_qty || 0).toLocaleString()} pcs
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Reorder controls for selected items */}
                        {isSelected && (
                          <div
                            className="flex items-center gap-1 shrink-0"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-black">
                              #{selectedIdx + 1}
                            </span>
                            <div className="flex flex-col">
                              <button
                                type="button"
                                disabled={selectedIdx === 0}
                                onClick={() => moveItemOrder(selectedIdx, "up")}
                                className="p-0.5 hover:bg-input rounded text-muted-foreground hover:text-foreground disabled:opacity-20 cursor-pointer"
                                title="উপরে সরান"
                              >
                                <ChevronUp className="w-3 h-3" />
                              </button>
                              <button
                                type="button"
                                disabled={selectedIdx === selectedIds.length - 1}
                                onClick={() => moveItemOrder(selectedIdx, "down")}
                                className="p-0.5 hover:bg-input rounded text-muted-foreground hover:text-foreground disabled:opacity-20 cursor-pointer"
                                title="নিচে সরান"
                              >
                                <ChevronDown className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Right Column: Projected Schedule Preview (5 cols) */}
            <div className="lg:col-span-6 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-foreground text-xs flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-teal-400" />
                  <span>নতুন শিডিউল প্রিভিউ ({targetLine}):</span>
                </span>
                <span className="text-[10.5px] font-bold text-muted-foreground">
                  মোট কোয়ান্টিটি:{" "}
                  <b className="text-emerald-300 font-mono">
                    {totalSelectedQty.toLocaleString()} pcs
                  </b>
                </span>
              </div>

              {/* Projected Table Box */}
              <div className="border border-border rounded-xl bg-panel-2/30 divide-y divide-border/60 max-h-[300px] sm:max-h-[340px] overflow-y-auto">
                {projectedSchedules.length === 0 ? (
                  <div className="p-8 text-center text-muted-foreground space-y-1.5">
                    <p className="font-semibold text-xs">কোনো স্টাইল নির্বাচিত নেই</p>
                    <p className="text-[11px]">
                      বাম পাশের তালিকা থেকে এক বা একাধিক স্টাইল নির্বাচন করুন।
                    </p>
                  </div>
                ) : (
                  projectedSchedules.map((item, idx) => {
                    return (
                      <div
                        key={item.plan.id}
                        className="p-2.5 flex items-center justify-between gap-2 hover:bg-panel-2/50 transition"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono text-[10px] px-1 py-0.2 rounded bg-purple-500/20 text-purple-300 font-black">
                              {idx + 1}
                            </span>
                            <span className="font-extrabold text-foreground truncate">
                              {item.plan.style}
                            </span>
                            <span className="text-[10px] text-muted-foreground font-mono">
                              ({(item.plan.order_qty || 0).toLocaleString()} pcs)
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-[10.5px] text-muted-foreground mt-0.5 font-mono">
                            <span className="text-cyan-200">
                              {item.startDate} → {item.finishDate}
                            </span>
                            <span>·</span>
                            <span>{item.workingDays} দিন</span>
                            <span>·</span>
                            <span>@{item.dailyTarget}/d</span>
                          </div>
                        </div>

                        {/* Status Badge */}
                        <div className="shrink-0 text-right">
                          {item.delayed ? (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-black bg-rose-500/20 text-rose-300 border border-rose-500/40">
                              <AlertTriangle className="w-2.5 h-2.5" />
                              <span>বিলম্ব ঝুঁকি</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                              <CheckCircle2 className="w-2.5 h-2.5" />
                              <span>সঠিক সময়</span>
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Summary note */}
              {projectedSchedules.length > 0 && (
                <div className="p-2.5 rounded-lg bg-teal-500/10 border border-teal-500/30 text-[11px] text-teal-200 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-teal-300 shrink-0" />
                    <span>
                      {selectedPlans.length}টি স্টাইল মোট{" "}
                      <b>
                        {projectedSchedules[0]?.startDate} থেকে{" "}
                        {projectedSchedules[projectedSchedules.length - 1]?.finishDate}
                      </b>{" "}
                      পর্যন্ত লাইনে বিন্যস্ত হবে।
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-border bg-panel-2/50 flex flex-wrap items-center justify-between gap-3">
          <div className="text-[11px] text-muted-foreground flex items-center gap-1.5">
            <span>💡</span>
            <span>
              "স্থানান্তর করুন" বাটনে চাপলে ডাটাবেজে স্বয়ংক্রিয়ভাবে সবগুলো স্টাইলের লাইন ও
              ক্যালকুলেশন আপডেট হয়ে যাবে।
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2 rounded-xl border border-border hover:bg-panel text-xs font-bold text-muted-foreground hover:text-foreground transition cursor-pointer"
            >
              বাতিল
            </button>

            <button
              type="button"
              onClick={handleExecuteBulkAssignment}
              disabled={submitting || selectedPlans.length === 0}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-teal-600 hover:from-purple-500 hover:to-teal-500 text-white font-black text-xs shadow-md flex items-center gap-2 transition disabled:opacity-50 cursor-pointer"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>স্থানান্তর হচ্ছে...</span>
                </>
              ) : (
                <>
                  <ArrowRight className="w-4 h-4" />
                  <span>
                    {selectedPlans.length > 0
                      ? `${selectedPlans.length}টি স্টাইল "${targetLine}"-এ স্থানান্তর করুন`
                      : `টার্গেট লাইনে স্থানান্তর করুন`}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
