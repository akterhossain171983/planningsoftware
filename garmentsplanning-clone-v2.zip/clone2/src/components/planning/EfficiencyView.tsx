import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { useLinePresets } from "@/hooks/use-line-presets";
import {
  buildLinePresetLookup,
  canonicalLineName,
  normLine,
  sortLineNamesByPreset,
} from "./lineLookup";

type LineEffSettings = { smv: number; manpower: number; hours: number; efficiency: number };
type SavedPlan = {
  id: string;
  buyer: string;
  style: string;
  config: {
    lines: Array<{ name: string }>;
    lineEfficiency?: Record<string, LineEffSettings>;
  };
  calc_result: {
    lines: Array<{
      name: string;
      dailyProduction: Array<{ date: string; qty: number }>;
    }>;
  };
};

function monthKey(dateStr: string) {
  return dateStr.slice(0, 7);
}

function monthLabel(mk: string) {
  const [y, m] = mk.split("-").map(Number);
  const names = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  return `${names[m - 1]} ${y}`;
}

type Draft = { smv: string; manpower: string; hours: string; efficiency: string };

export function EfficiencyView() {
  const qc = useQueryClient();
  const { presets: linePresets } = useLinePresets();
  const presetLookup = useMemo(() => buildLinePresetLookup(linePresets), [linePresets]);
  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "efficiency"],
    queryFn: async (): Promise<SavedPlan[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("id,buyer,style,config,calc_result")
        .is("completed_at", null);
      if (error) throw error;
      return (data ?? []) as unknown as SavedPlan[];
    },
  });

  const [fromMonth, setFromMonth] = useState<string>("");
  const [toMonth, setToMonth] = useState<string>("");
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [saving, setSaving] = useState<Record<string, boolean>>({});

  function getEff(p: SavedPlan, lineName: string): LineEffSettings | null {
    const le = p.config?.lineEfficiency ?? {};
    return le[lineName] ?? le.__default__ ?? null;
  }

  const { monthRows, missingCount, totalDaysAll, missingRows, suggestion } = useMemo(() => {
    const map: Record<string, Record<string, { days: number; effSum: number }>> = {};
    let missing = 0;
    let totalDays = 0;

    const allSettings: LineEffSettings[] = [];
    const perLineSettings: Record<string, LineEffSettings[]> = {};
    for (const p of plans) {
      const le = p.config?.lineEfficiency ?? {};
      for (const [name, s] of Object.entries(le)) {
        if (!s) continue;
        allSettings.push(s);
        if (name !== "__default__") {
          perLineSettings[name] ??= [];
          perLineSettings[name].push(s);
        }
      }
    }
    const avg = (arr: number[]) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0);
    const suggestion: LineEffSettings | null = allSettings.length
      ? {
          smv: +avg(allSettings.map((s) => s.smv)).toFixed(2),
          manpower: Math.round(avg(allSettings.map((s) => s.manpower))),
          hours: +avg(allSettings.map((s) => s.hours)).toFixed(1),
          efficiency: +avg(allSettings.map((s) => s.efficiency)).toFixed(1),
        }
      : null;
    const perLineSuggestion: Record<string, LineEffSettings> = {};
    for (const [name, arr] of Object.entries(perLineSettings)) {
      perLineSuggestion[name] = {
        smv: +avg(arr.map((s) => s.smv)).toFixed(2),
        manpower: Math.round(avg(arr.map((s) => s.manpower))),
        hours: +avg(arr.map((s) => s.hours)).toFixed(1),
        efficiency: +avg(arr.map((s) => s.efficiency)).toFixed(1),
      };
    }

    const missingRows: Array<{
      planId: string;
      buyer: string;
      style: string;
      line: string;
      rawLine: string;
      days: number;
      avgTarget: number;
      suggested: LineEffSettings | null;
      backCalcEff: number | null;
    }> = [];

    for (const p of plans) {
      const resultLines = p.calc_result?.lines ?? [];
      for (const rl of resultLines) {
        const eff = getEff(p, rl.name);
        const monthDays: Record<string, number> = {};
        let workingDays = 0;
        let qtySum = 0;
        for (const d of rl.dailyProduction ?? []) {
          if (d.qty > 0) {
            monthDays[monthKey(d.date)] = (monthDays[monthKey(d.date)] ?? 0) + 1;
            workingDays++;
            qtySum += d.qty;
          }
        }
        if (!eff && workingDays > 0) {
          const avgTarget = qtySum / workingDays;
          const displayLine = canonicalLineName(rl.name, presetLookup);
          const sug = perLineSuggestion[rl.name] ?? perLineSuggestion[displayLine] ?? suggestion;
          let backCalcEff: number | null = null;
          if (sug && sug.manpower && sug.hours && sug.smv) {
            backCalcEff = +((avgTarget * sug.smv * 100) / (sug.manpower * sug.hours * 60)).toFixed(
              1,
            );
          }
          missingRows.push({
            planId: p.id,
            buyer: p.buyer,
            style: p.style,
            line: displayLine,
            rawLine: rl.name,
            days: workingDays,
            avgTarget: Math.round(avgTarget),
            suggested: sug,
            backCalcEff,
          });
        }
        for (const [mk, days] of Object.entries(monthDays)) {
          totalDays += days;
          if (!eff) {
            missing += days;
            continue;
          }
          const displayLine = canonicalLineName(rl.name, presetLookup);
          map[mk] ??= {};
          map[mk][displayLine] ??= { days: 0, effSum: 0 };
          map[mk][displayLine].days += days;
          map[mk][displayLine].effSum += days * eff.efficiency;
        }
      }
    }

    const months = Object.keys(map).sort();
    const filtered = months.filter(
      (m) => (!fromMonth || m >= fromMonth) && (!toMonth || m <= toMonth),
    );

    const rows = filtered.map((m) => {
      const lineMap = map[m];
      const lines = Object.entries(lineMap)
        .map(([name, v]) => ({ name, days: v.days, eff: v.effSum / v.days }))
        .sort(
          (a, b) =>
            sortLineNamesByPreset([a.name, b.name], linePresets).indexOf(a.name) -
            sortLineNamesByPreset([a.name, b.name], linePresets).indexOf(b.name),
        );
      const totalDays = lines.reduce((s, l) => s + l.days, 0);
      const overall = totalDays > 0 ? lines.reduce((s, l) => s + l.days * l.eff, 0) / totalDays : 0;
      return { month: m, overall, totalDays, lines };
    });

    missingRows.sort(
      (a, b) =>
        sortLineNamesByPreset([a.line, b.line], linePresets).indexOf(a.line) -
          sortLineNamesByPreset([a.line, b.line], linePresets).indexOf(b.line) || b.days - a.days,
    );
    return {
      monthRows: rows,
      missingCount: missing,
      totalDaysAll: totalDays,
      missingRows,
      suggestion,
    };
  }, [plans, fromMonth, toMonth, presetLookup, linePresets]);

  const grand = useMemo(() => {
    let d = 0,
      s = 0;
    for (const r of monthRows) {
      d += r.totalDays;
      s += r.totalDays * r.overall;
    }
    return { days: d, eff: d ? s / d : 0 };
  }, [monthRows]);

  function rowKey(planId: string, line: string) {
    return `${planId}::${line}`;
  }

  function getDraft(
    planId: string,
    line: string,
    suggested: LineEffSettings | null,
    backCalcEff: number | null,
  ): Draft {
    const k = rowKey(planId, line);
    if (drafts[k]) return drafts[k];
    return {
      smv: suggested ? String(suggested.smv) : "",
      manpower: suggested ? String(suggested.manpower) : "",
      hours: suggested ? String(suggested.hours) : "",
      efficiency:
        backCalcEff !== null ? String(backCalcEff) : suggested ? String(suggested.efficiency) : "",
    };
  }

  function updateDraft(
    planId: string,
    line: string,
    field: keyof Draft,
    value: string,
    base: Draft,
  ) {
    const k = rowKey(planId, line);
    setDrafts((prev) => ({ ...prev, [k]: { ...(prev[k] ?? base), [field]: value } }));
  }

  async function saveRow(planId: string, line: string, d: Draft) {
    const smv = parseFloat(d.smv);
    const manpower = parseFloat(d.manpower);
    const hours = parseFloat(d.hours);
    const efficiency = parseFloat(d.efficiency);
    if (![smv, manpower, hours, efficiency].every((n) => Number.isFinite(n) && n > 0)) {
      toast.error("সব ফিল্ডে valid positive সংখ্যা দিন।");
      return;
    }
    const k = rowKey(planId, line);
    setSaving((p) => ({ ...p, [k]: true }));
    try {
      const plan = plans.find((p) => p.id === planId);
      if (!plan) throw new Error("Plan not found");
      const newConfig = {
        ...plan.config,
        lineEfficiency: {
          ...(plan.config?.lineEfficiency ?? {}),
          [line]: { smv, manpower, hours, efficiency },
        },
      };
      const { error } = await supabase
        .from("plans")
        .update({ config: newConfig as never })
        .eq("id", planId);
      if (error) throw error;
      toast.success(`${line}-এর efficiency setting সেভ হয়েছে`);
      setDrafts((prev) => {
        const c = { ...prev };
        delete c[k];
        return c;
      });
      await qc.invalidateQueries({ queryKey: ["plans"] });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      toast.error(`সেভ করতে সমস্যা: ${msg}`);
    } finally {
      setSaving((p) => ({ ...p, [k]: false }));
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20 text-muted-foreground">
        <Loader2 className="w-6 h-6 animate-spin mr-2" /> লোড হচ্ছে...
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3 items-end p-4 rounded-xl border border-purple-500/30 bg-purple-500/5">
        <div>
          <label className="block text-[10px] font-bold text-purple-300 mb-1">From Month</label>
          <input
            type="month"
            value={fromMonth}
            onChange={(e) => setFromMonth(e.target.value)}
            className="px-2 py-1.5 rounded-lg border border-purple-500/40 bg-panel-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-[10px] font-bold text-purple-300 mb-1">To Month</label>
          <input
            type="month"
            value={toMonth}
            onChange={(e) => setToMonth(e.target.value)}
            className="px-2 py-1.5 rounded-lg border border-purple-500/40 bg-panel-2 text-sm"
          />
        </div>
        <button
          type="button"
          onClick={() => {
            setFromMonth("");
            setToMonth("");
          }}
          className="px-3 py-1.5 rounded-lg border border-purple-500/40 bg-purple-500/10 text-purple-200 text-xs font-bold hover:bg-purple-500/20"
        >
          Reset
        </button>
        <div className="ml-auto flex flex-wrap gap-2 text-xs">
          <span className="px-3 py-1.5 rounded-lg bg-purple-500/20 border border-purple-500/40 text-purple-100 font-bold">
            Overall Avg: {grand.eff.toFixed(2)}% ({grand.days} days)
          </span>
          {missingCount > 0 && (
            <span className="px-3 py-1.5 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-100">
              ⚠ {missingCount} din er efficiency setting missing (out of {totalDaysAll})
            </span>
          )}
        </div>
      </div>

      {monthRows.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground text-sm">
          কোনো ডেটা নেই। প্ল্যান ইনপুট ফর্মে SMV ক্যালকুলেটর থেকে Efficiency সেট করে সেভ করুন।
        </div>
      ) : (
        <div className="overflow-auto rounded-xl border border-white/10">
          <table className="min-w-full text-sm">
            <thead className="bg-panel-2 sticky top-0">
              <tr>
                <th className="px-3 py-2 text-left text-xs font-bold text-purple-300">Month</th>
                <th className="px-3 py-2 text-right text-xs font-bold text-purple-300">
                  Working Days
                </th>
                <th className="px-3 py-2 text-right text-xs font-bold text-purple-300">
                  Weighted Avg Efficiency
                </th>
                <th className="px-3 py-2 text-left text-xs font-bold text-purple-300">
                  Per-Line Breakdown
                </th>
              </tr>
            </thead>
            <tbody>
              {monthRows.map((r) => (
                <tr key={r.month} className="border-t border-white/5 hover:bg-white/5">
                  <td className="px-3 py-2 font-bold text-purple-200">{monthLabel(r.month)}</td>
                  <td className="px-3 py-2 text-right">{r.totalDays}</td>
                  <td className="px-3 py-2 text-right font-extrabold text-purple-100">
                    {r.overall.toFixed(2)}%
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex flex-wrap gap-1">
                      {r.lines.map((l) => (
                        <span
                          key={l.name}
                          className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md border border-white/10 bg-panel-2"
                          title={`${l.days} days`}
                        >
                          <b className="text-purple-300">{l.name}</b>
                          <span>{l.eff.toFixed(1)}%</span>
                          <span className="text-muted-foreground">({l.days}d)</span>
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {missingRows.length > 0 && (
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/5">
          <div className="flex flex-wrap items-center gap-3 px-4 py-3 border-b border-amber-500/20">
            <div className="text-sm font-bold text-amber-200">
              ⚠ Missing Efficiency Settings — {missingRows.length} line(s)
            </div>
            {suggestion && (
              <div className="text-[11px] text-amber-100/80">
                Auto-fill default (avg of existing): SMV <b>{suggestion.smv}</b> · MP{" "}
                <b>{suggestion.manpower}</b> · Hrs <b>{suggestion.hours}</b> · Eff{" "}
                <b>{suggestion.efficiency}%</b>
              </div>
            )}
            <div className="ml-auto text-[11px] text-muted-foreground">
              Edit values inline and press Save — or open the plan's SMV Calculator.
            </div>
          </div>
          <div className="overflow-auto max-h-[520px]">
            <table className="min-w-full text-xs">
              <thead className="bg-panel-2 sticky top-0">
                <tr className="text-left text-[10px] font-bold text-amber-300">
                  <th className="px-3 py-2">Buyer / Style</th>
                  <th className="px-3 py-2">Line</th>
                  <th className="px-3 py-2 text-right">Days</th>
                  <th className="px-3 py-2 text-right">Avg Target</th>
                  <th className="px-3 py-2 text-right">SMV</th>
                  <th className="px-3 py-2 text-right">Manpower</th>
                  <th className="px-3 py-2 text-right">Hours</th>
                  <th
                    className="px-3 py-2 text-right"
                    title="Back-calc from avg target if left blank"
                  >
                    Efficiency %
                  </th>
                  <th className="px-3 py-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {missingRows.map((r, i) => {
                  const base = getDraft(r.planId, r.rawLine, r.suggested, r.backCalcEff);
                  const d = drafts[rowKey(r.planId, r.rawLine)] ?? base;
                  const isSaving = saving[rowKey(r.planId, r.rawLine)];
                  const inputCls =
                    "w-20 px-1.5 py-1 rounded border border-amber-500/30 bg-panel-2 text-right font-mono text-[11px] focus:outline-none focus:border-amber-400";
                  return (
                    <tr
                      key={`${r.planId}-${r.rawLine}-${i}`}
                      className="border-t border-white/5 hover:bg-white/5"
                    >
                      <td className="px-3 py-1.5">
                        <div className="font-bold text-purple-200">{r.buyer}</div>
                        <div className="text-muted-foreground text-[10px]">{r.style}</div>
                      </td>
                      <td className="px-3 py-1.5 font-bold text-purple-300">{r.line}</td>
                      <td className="px-3 py-1.5 text-right">{r.days}</td>
                      <td className="px-3 py-1.5 text-right">{r.avgTarget}</td>
                      <td className="px-3 py-1.5 text-right">
                        <input
                          type="number"
                          step="0.01"
                          value={d.smv}
                          onChange={(e) =>
                            updateDraft(r.planId, r.rawLine, "smv", e.target.value, base)
                          }
                          className={inputCls}
                          placeholder="—"
                        />
                      </td>
                      <td className="px-3 py-1.5 text-right">
                        <input
                          type="number"
                          value={d.manpower}
                          onChange={(e) =>
                            updateDraft(r.planId, r.rawLine, "manpower", e.target.value, base)
                          }
                          className={inputCls}
                          placeholder="—"
                        />
                      </td>
                      <td className="px-3 py-1.5 text-right">
                        <input
                          type="number"
                          step="0.1"
                          value={d.hours}
                          onChange={(e) =>
                            updateDraft(r.planId, r.rawLine, "hours", e.target.value, base)
                          }
                          className={inputCls}
                          placeholder="—"
                        />
                      </td>
                      <td className="px-3 py-1.5 text-right">
                        <input
                          type="number"
                          step="0.1"
                          value={d.efficiency}
                          onChange={(e) =>
                            updateDraft(r.planId, r.rawLine, "efficiency", e.target.value, base)
                          }
                          className={`${inputCls} text-emerald-200`}
                          placeholder={r.backCalcEff !== null ? String(r.backCalcEff) : "—"}
                        />
                      </td>
                      <td className="px-3 py-1.5 text-center">
                        <button
                          onClick={() => saveRow(r.planId, r.rawLine, d)}
                          disabled={isSaving}
                          className="inline-flex items-center gap-1 px-2 py-1 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-[10px] font-bold hover:bg-emerald-500/30 disabled:opacity-50"
                        >
                          {isSaving ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Save className="w-3 h-3" />
                          )}
                          Save
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
