import { Fragment, useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  FileSpreadsheet,
  Download,
  Search,
  X,
  Loader2,
  Layers,
  ArrowUpDown,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Scissors,
  ArrowRightLeft,
  CheckSquare,
  Square,
} from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import type { PlanResult } from "@/lib/plan-calc";
import { useLinePresets } from "@/hooks/use-line-presets";
import { buildLinePresetLookup, canonicalLineName, sortLineNamesByPreset } from "./lineLookup";
import { FilterSelect } from "./LineSummaryView";
import { SplitStylePlanModal } from "./SplitStylePlanModal";
import { BulkStyleAssignmentModal } from "./BulkStyleAssignmentModal";

type PlanRow = {
  id: string;
  buyer: string;
  style: string;
  season: string | null;
  order_qty: number;
  excess_pct?: number;
  daily_target?: number;
  shipment_date: string;
  config?: any;
  calc_result: PlanResult;
  created_at: string;
};

type StyleLineBreakdown = {
  line: string;
  startDate: string;
  finishDate: string;
  workingDays: number;
  orderQty: number;
  plannedQty: number;
  dailyTarget: number;
};

export type StyleSummaryItem = {
  id: string;
  buyer: string;
  season: string;
  style: string;
  sumOfPlanLines: number;
  mentionPlanLines: string;
  distinctLines: string[];
  totalOrderQty: number;
  totalPlannedQty: number;
  earliestStart: string;
  latestFinish: string;
  lineBreakdown: StyleLineBreakdown[];
};

type SortField =
  "buyer" | "season" | "style" | "sumOfPlanLines" | "totalPlannedQty" | "earliestStart";
type SortDirection = "asc" | "desc";

export function StyleLinesSummaryView() {
  const qc = useQueryClient();
  const { presets: linePresets } = useLinePresets();

  const [search, setSearch] = useState("");
  const [buyerFilter, setBuyerFilter] = useState<string[]>([]);
  const [seasonFilter, setSeasonFilter] = useState<string[]>([]);
  const [sortField, setSortField] = useState<SortField>("buyer");
  const [sortDir, setSortDir] = useState<SortDirection>("asc");
  const [expandedStyleKey, setExpandedStyleKey] = useState<string | null>(null);
  const [selectedStyleIds, setSelectedStyleIds] = useState<string[]>([]);
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [splitModalTarget, setSplitModalTarget] = useState<{
    planId: string;
    style: string;
    buyer: string;
    season: string | null;
    orderQty: number;
    plannedQty: number;
    lineQty?: number;
    currentLine?: string;
    dailyTarget?: number;
  } | null>(null);

  const { data: rawPlans = [], isLoading } = useQuery({
    queryKey: ["plans", "style-lines-summary"],
    queryFn: async (): Promise<PlanRow[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select(
          "id, buyer, style, season, order_qty, excess_pct, daily_target, shipment_date, calc_result, config, created_at",
        )
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as PlanRow[];
    },
  });

  // Realtime subscription to plans table
  useEffect(() => {
    const ch = supabase
      .channel("plans-style-lines-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () => {
        qc.invalidateQueries({ queryKey: ["plans"] });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  // Aggregate plans by Buyer + Season + Style
  const summaryItems = useMemo<StyleSummaryItem[]>(() => {
    const presetLookup = buildLinePresetLookup(linePresets);
    const groups = new Map<
      string,
      {
        id: string;
        buyer: string;
        season: string;
        style: string;
        distinctLinesSet: Set<string>;
        totalOrderQty: number;
        totalPlannedQty: number;
        starts: string[];
        finishes: string[];
        lineBreakdown: StyleLineBreakdown[];
      }
    >();

    for (const p of rawPlans) {
      const buyer = (p.buyer || "").trim() || "Unassigned Buyer";
      const season = (p.season && p.season.trim()) || "— (No Season)";
      const style = (p.style || "").trim() || "Unassigned Style";
      const key = `${buyer.toUpperCase()}|||${season.toUpperCase()}|||${style.toUpperCase()}`;

      if (!groups.has(key)) {
        groups.set(key, {
          id: p.id,
          buyer,
          season,
          style,
          distinctLinesSet: new Set<string>(),
          totalOrderQty: 0,
          totalPlannedQty: 0,
          starts: [],
          finishes: [],
          lineBreakdown: [],
        });
      }

      const g = groups.get(key)!;
      const lines = p.calc_result?.lines ?? [];
      const excessPct = p.calc_result?.excessPct ?? 0;
      const factor = 1 + excessPct / 100;

      for (const l of lines) {
        if (!l?.name) continue;
        const cLine = canonicalLineName(l.name, presetLookup);
        g.distinctLinesSet.add(cLine);

        const daily = l.dailyProduction ?? [];
        const firstOut = daily.length ? daily[0].date : (l.startDateStr ?? "");
        const lastOut = l.finishDateStr ?? (daily.length ? daily[daily.length - 1].date : "");

        let orderQty = l.allocatedOrderQty || 0;
        let planQty = l.plannedQty || 0;
        if (orderQty === 0 && planQty === 0 && daily.length > 0) {
          planQty = daily.reduce((sum, d) => sum + (d.qty || 0), 0);
          orderQty = factor > 0 ? Math.round(planQty / factor) : planQty;
        }

        if (firstOut) g.starts.push(firstOut);
        if (lastOut) g.finishes.push(lastOut);

        g.lineBreakdown.push({
          line: cLine,
          startDate: firstOut,
          finishDate: lastOut,
          workingDays: l.workingDays || daily.length,
          orderQty,
          plannedQty: planQty,
          dailyTarget: l.targetOverride ?? p.calc_result?.dailyTargetPerLine ?? 0,
        });
      }

      // If no lines were returned in calc_result, take top-level order_qty
      if (lines.length === 0) {
        g.totalOrderQty += p.order_qty || 0;
        g.totalPlannedQty += p.calc_result?.totalPlannedQty || p.order_qty || 0;
      }
    }

    const result: StyleSummaryItem[] = [];

    for (const [key, g] of groups.entries()) {
      const distinctLines = sortLineNamesByPreset(Array.from(g.distinctLinesSet), linePresets);

      // Sum quantities from lines if available
      let totalOrderQty = g.lineBreakdown.reduce((s, b) => s + b.orderQty, 0);
      let totalPlannedQty = g.lineBreakdown.reduce((s, b) => s + b.plannedQty, 0);
      if (totalOrderQty === 0 && g.totalOrderQty > 0) {
        totalOrderQty = g.totalOrderQty;
        totalPlannedQty = g.totalPlannedQty;
      }

      const validStarts = g.starts.filter(Boolean).sort();
      const validFinishes = g.finishes.filter(Boolean).sort();

      const earliestStart = validStarts.length ? validStarts[0] : "—";
      const latestFinish = validFinishes.length ? validFinishes[validFinishes.length - 1] : "—";

      // Sort breakdown lines according to linePresets
      const sortedBreakdown = [...g.lineBreakdown].sort((a, b) => {
        const [first] = sortLineNamesByPreset([a.line, b.line], linePresets);
        return first === a.line ? -1 : 1;
      });

      result.push({
        id: key,
        buyer: g.buyer,
        season: g.season,
        style: g.style,
        sumOfPlanLines: distinctLines.length,
        mentionPlanLines: distinctLines.length > 0 ? distinctLines.join(", ") : "— (No Lines)",
        distinctLines,
        totalOrderQty,
        totalPlannedQty,
        earliestStart,
        latestFinish,
        lineBreakdown: sortedBreakdown,
      });
    }

    return result;
  }, [rawPlans, linePresets]);

  // Unique filter dropdown options
  const buyerOptions = useMemo(
    () => Array.from(new Set(summaryItems.map((i) => i.buyer))).sort(),
    [summaryItems],
  );

  const seasonOptions = useMemo(
    () => Array.from(new Set(summaryItems.map((i) => i.season))).sort(),
    [summaryItems],
  );

  // Filter & Search
  const filteredItems = useMemo(() => {
    const q = search.trim().toLowerCase();
    return summaryItems.filter((item) => {
      const matchesBuyer = buyerFilter.length === 0 || buyerFilter.includes(item.buyer);
      const matchesSeason = seasonFilter.length === 0 || seasonFilter.includes(item.season);
      const matchesSearch =
        q === "" ||
        item.buyer.toLowerCase().includes(q) ||
        item.season.toLowerCase().includes(q) ||
        item.style.toLowerCase().includes(q) ||
        item.mentionPlanLines.toLowerCase().includes(q);

      return matchesBuyer && matchesSeason && matchesSearch;
    });
  }, [summaryItems, search, buyerFilter, seasonFilter]);

  // Sort
  const sortedItems = useMemo(() => {
    return [...filteredItems].sort((a, b) => {
      let cmp = 0;
      if (sortField === "buyer") cmp = a.buyer.localeCompare(b.buyer);
      else if (sortField === "season") cmp = a.season.localeCompare(b.season);
      else if (sortField === "style") cmp = a.style.localeCompare(b.style);
      else if (sortField === "sumOfPlanLines") cmp = a.sumOfPlanLines - b.sumOfPlanLines;
      else if (sortField === "totalPlannedQty") cmp = a.totalPlannedQty - b.totalPlannedQty;
      else if (sortField === "earliestStart") cmp = a.earliestStart.localeCompare(b.earliestStart);

      return sortDir === "asc" ? cmp : -cmp;
    });
  }, [filteredItems, sortField, sortDir]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  };

  // KPI Calculations
  const totalStylesCount = sortedItems.length;
  const allDistinctLines = useMemo(() => {
    const set = new Set<string>();
    sortedItems.forEach((i) => i.distinctLines.forEach((l) => set.add(l)));
    return set.size;
  }, [sortedItems]);

  const totalPlannedUnits = useMemo(() => {
    return sortedItems.reduce((acc, curr) => acc + curr.totalPlannedQty, 0);
  }, [sortedItems]);

  const totalOrderUnits = useMemo(() => {
    return sortedItems.reduce((acc, curr) => acc + curr.totalOrderQty, 0);
  }, [sortedItems]);

  // Export to Excel (.xlsx)
  const handleExportExcel = () => {
    try {
      if (sortedItems.length === 0) {
        toast.warning("এক্সপোর্ট করার মতো কোনো ডেটা নেই।");
        return;
      }

      const rows = sortedItems.map((item, index) => ({
        "SL No": index + 1,
        Buyer: item.buyer,
        Season: item.season,
        Style: item.style,
        "Sum of Plan Lines": item.sumOfPlanLines,
        "Mention Plan Lines": item.mentionPlanLines,
        "Order Qty (pcs)": item.totalOrderQty,
        "Planned Qty (pcs)": item.totalPlannedQty,
        "Start Date": item.earliestStart,
        "Finish Date": item.latestFinish,
      }));

      const ws = XLSX.utils.json_to_sheet(rows);

      // Auto width calculation
      const colWidths = [
        { wch: 8 }, // SL No
        { wch: 18 }, // Buyer
        { wch: 18 }, // Season
        { wch: 22 }, // Style
        { wch: 18 }, // Sum of Plan Lines
        { wch: 38 }, // Mention Plan Lines
        { wch: 16 }, // Order Qty
        { wch: 16 }, // Planned Qty
        { wch: 14 }, // Start Date
        { wch: 14 }, // Finish Date
      ];
      ws["!cols"] = colWidths;

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Style Lines Summary");

      const today = new Date().toISOString().slice(0, 10);
      XLSX.writeFile(wb, `Style_Lines_Summary_${today}.xlsx`);
      toast.success("Excel (.xlsx) ফাইল সফলভাবে ডাউনলোড হয়েছে!");
    } catch (err) {
      console.error(err);
      toast.error("Excel ফাইল তৈরিতে সমস্যা হয়েছে।");
    }
  };

  // Export to CSV
  const handleExportCSV = () => {
    try {
      if (sortedItems.length === 0) {
        toast.warning("এক্সপোর্ট করার মতো কোনো ডেটা নেই।");
        return;
      }

      const headers = [
        "SL No",
        "Buyer",
        "Season",
        "Style",
        "Sum of Plan Lines",
        "Mention Plan Lines",
        "Order Qty (pcs)",
        "Planned Qty (pcs)",
        "Start Date",
        "Finish Date",
      ];

      const escapeCSV = (val: unknown): string => {
        if (val === null || val === undefined) return "";
        const str = String(val);
        if (str.includes(",") || str.includes('"') || str.includes("\n")) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      };

      const csvLines = [headers.join(",")];

      sortedItems.forEach((item, index) => {
        const row = [
          index + 1,
          escapeCSV(item.buyer),
          escapeCSV(item.season),
          escapeCSV(item.style),
          item.sumOfPlanLines,
          escapeCSV(item.mentionPlanLines),
          item.totalOrderQty,
          item.totalPlannedQty,
          escapeCSV(item.earliestStart),
          escapeCSV(item.latestFinish),
        ];
        csvLines.push(row.join(","));
      });

      // Include UTF-8 BOM so Excel opens Bangla and special characters correctly
      const blob = new Blob(["\uFEFF" + csvLines.join("\r\n")], {
        type: "text/csv;charset=utf-8;",
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      const today = new Date().toISOString().slice(0, 10);
      link.setAttribute("href", url);
      link.setAttribute("download", `Style_Lines_Summary_${today}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success("CSV ফাইল সফলভাবে ডাউনলোড হয়েছে!");
    } catch (err) {
      console.error(err);
      toast.error("CSV ফাইল তৈরিতে সমস্যা হয়েছে।");
    }
  };

  return (
    <div className="space-y-4">
      {/* View Header with Title and Export Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border pb-3">
        <div>
          <h1 className="text-lg md:text-xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <Layers className="w-5 h-5 text-teal-400" />
            Style & Line Summary (স্টাইল লাইন সামারি)
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            বায়ার, সিজন, ও স্টাইল অনুযায়ী নির্ধারিত লাইনের মোট সংখ্যা এবং কমা দিয়ে উল্লেখিত লাইনের
            তালিকা।
          </p>
        </div>

        {/* Action Buttons: Bulk Line Assignment, Export to Excel & CSV */}
        <div className="flex items-center gap-2 shrink-0 flex-wrap">
          <button
            type="button"
            onClick={() => setShowBulkModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-purple-500/50 bg-purple-600/20 text-purple-200 hover:bg-purple-600/30 text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 shadow-sm"
            title="একাধিক স্টাইল একসাথে নির্দিষ্ট লাইনে স্থানান্তর করুন (Bulk Line Assignment)"
          >
            <ArrowRightLeft className="w-3.5 h-3.5 text-purple-400" />
            <span>
              বাল্ক লাইন অ্যাসাইন{" "}
              {selectedStyleIds.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-purple-600 text-white font-mono text-[10px]">
                  {selectedStyleIds.length}
                </span>
              )}
            </span>
          </button>

          <button
            type="button"
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 text-xs font-semibold transition cursor-pointer whitespace-nowrap shrink-0 shadow-sm"
            title="Download formatted Excel spreadsheet"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            Export Excel (.xlsx)
          </button>

          <button
            type="button"
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-panel-2 hover:bg-panel text-xs font-semibold text-foreground transition cursor-pointer whitespace-nowrap shrink-0 shadow-sm"
            title="Download CSV file"
          >
            <Download className="w-3.5 h-3.5 text-teal-400" />
            Export CSV
          </button>
        </div>
      </div>

      {/* KPI Overview Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="rounded-xl border border-border bg-panel-1 p-3 shadow-xs">
          <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider block">
            Total Styles (মোট স্টাইল)
          </span>
          <div className="text-xl font-bold text-foreground font-mono tabular-nums mt-1">
            {totalStylesCount.toLocaleString()}
          </div>
          <span className="text-[10px] text-muted-foreground">Active styled plans</span>
        </div>

        <div className="rounded-xl border border-border bg-panel-1 p-3 shadow-xs">
          <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider block">
            Distinct Lines (সক্রিয় লাইন)
          </span>
          <div className="text-xl font-bold text-teal-300 font-mono tabular-nums mt-1">
            {allDistinctLines}
          </div>
          <span className="text-[10px] text-muted-foreground">Lines engaged in schedule</span>
        </div>

        <div className="rounded-xl border border-border bg-panel-1 p-3 shadow-xs">
          <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider block">
            Planned Quantity (মোট প্ল্যান)
          </span>
          <div className="text-xl font-bold text-emerald-300 font-mono tabular-nums mt-1">
            {totalPlannedUnits.toLocaleString()}{" "}
            <span className="text-xs font-normal text-muted-foreground">pcs</span>
          </div>
          <span className="text-[10px] text-muted-foreground">
            Order: {totalOrderUnits.toLocaleString()} pcs
          </span>
        </div>

        <div className="rounded-xl border border-border bg-panel-1 p-3 shadow-xs">
          <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider block">
            Avg. Lines / Style (গড় লাইন)
          </span>
          <div className="text-xl font-bold text-amber-300 font-mono tabular-nums mt-1">
            {totalStylesCount > 0
              ? (sortedItems.reduce((s, i) => s + i.sumOfPlanLines, 0) / totalStylesCount).toFixed(
                  1,
                )
              : "0.0"}
          </div>
          <span className="text-[10px] text-muted-foreground">Average line allocations</span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center gap-2 rounded-xl border border-border bg-panel-1 p-2.5">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="w-3.5 h-3.5 text-muted-foreground absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search Buyer, Season, Style, or Line..."
            className="w-full rounded-md border border-border bg-input pl-8 pr-7 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-teal-500"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch("")}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Buyer Multi-Filter */}
        <FilterSelect
          label="Buyer"
          options={buyerOptions}
          value={buyerFilter}
          onChange={setBuyerFilter}
        />

        {/* Season Multi-Filter */}
        <FilterSelect
          label="Season"
          options={seasonOptions}
          value={seasonFilter}
          onChange={setSeasonFilter}
        />

        {(search || buyerFilter.length > 0 || seasonFilter.length > 0) && (
          <button
            type="button"
            onClick={() => {
              setSearch("");
              setBuyerFilter([]);
              setSeasonFilter([]);
            }}
            className="text-xs text-rose-300 hover:text-rose-200 px-2 py-1 rounded hover:bg-rose-500/10 transition cursor-pointer"
          >
            Reset Filters
          </button>
        )}

        <div className="ml-auto text-xs text-muted-foreground font-mono tabular-nums">
          Showing {sortedItems.length} of {summaryItems.length} styles
        </div>
      </div>

      {/* Table Container */}
      <div className="rounded-xl border border-border bg-panel-1 overflow-hidden shadow-sm">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center p-12 text-muted-foreground">
            <Loader2 className="w-6 h-6 animate-spin text-teal-400 mb-2" />
            <span className="text-xs font-medium">প্ল্যান ডেটা লোড হচ্ছে...</span>
          </div>
        ) : sortedItems.length === 0 ? (
          <div className="p-12 text-center text-muted-foreground space-y-2">
            <p className="text-sm font-semibold">কোনো ডেটা খুঁজে পাওয়া যায়নি</p>
            <p className="text-xs text-muted-foreground">
              {summaryItems.length === 0
                ? "বর্তমানে সক্রিয় কোনো প্ল্যান নেই।"
                : "আপনার ফিল্টারের সাথে মিলে এমন কোনো স্টাইল নেই।"}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-border bg-panel-2 text-muted-foreground font-semibold select-none">
                  <th className="py-2.5 px-3 w-10 text-center">
                    <button
                      type="button"
                      onClick={() => {
                        const visibleIds = sortedItems.map((i) => i.id);
                        const allSelected =
                          visibleIds.length > 0 &&
                          visibleIds.every((id) => selectedStyleIds.includes(id));
                        if (allSelected) {
                          setSelectedStyleIds((prev) =>
                            prev.filter((id) => !visibleIds.includes(id)),
                          );
                        } else {
                          const next = new Set(selectedStyleIds);
                          visibleIds.forEach((id) => next.add(id));
                          setSelectedStyleIds(Array.from(next));
                        }
                      }}
                      className="text-purple-400 hover:text-purple-300 transition cursor-pointer"
                      title="সবগুলো নির্বাচন / অনির্বাচন করুন"
                    >
                      {sortedItems.length > 0 &&
                      sortedItems.every((i) => selectedStyleIds.includes(i.id)) ? (
                        <CheckSquare className="w-4 h-4 fill-purple-600/30 text-purple-400" />
                      ) : (
                        <Square className="w-4 h-4 text-muted-foreground" />
                      )}
                    </button>
                  </th>
                  <th className="py-2.5 px-3 w-10 text-center">#</th>
                  <th
                    className="py-2.5 px-3 cursor-pointer hover:text-foreground transition"
                    onClick={() => handleSort("buyer")}
                  >
                    <div className="flex items-center gap-1">
                      <span>Buyer (বায়ার)</span>
                      <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </div>
                  </th>
                  <th
                    className="py-2.5 px-3 cursor-pointer hover:text-foreground transition"
                    onClick={() => handleSort("season")}
                  >
                    <div className="flex items-center gap-1">
                      <span>Season (সিজন)</span>
                      <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </div>
                  </th>
                  <th
                    className="py-2.5 px-3 cursor-pointer hover:text-foreground transition"
                    onClick={() => handleSort("style")}
                  >
                    <div className="flex items-center gap-1">
                      <span>Style (স্টাইল)</span>
                      <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </div>
                  </th>
                  <th
                    className="py-2.5 px-3 text-center cursor-pointer hover:text-foreground transition bg-teal-500/10 text-teal-300 font-bold border-x border-border"
                    onClick={() => handleSort("sumOfPlanLines")}
                  >
                    <div className="flex items-center justify-center gap-1">
                      <span>Sum of Plan Lines</span>
                      <ArrowUpDown className="w-3 h-3 opacity-70" />
                    </div>
                  </th>
                  <th className="py-2.5 px-3 min-w-[240px]">
                    Mention Plan Lines (নির্ধারিত লাইনসমূহ — কমা দিয়ে)
                  </th>
                  <th
                    className="py-2.5 px-3 text-right cursor-pointer hover:text-foreground transition"
                    onClick={() => handleSort("totalPlannedQty")}
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Planned Qty</span>
                      <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </div>
                  </th>
                  <th
                    className="py-2.5 px-3 cursor-pointer hover:text-foreground transition"
                    onClick={() => handleSort("earliestStart")}
                  >
                    <div className="flex items-center gap-1">
                      <span>Schedule (Start → End)</span>
                      <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </div>
                  </th>
                  <th className="py-2.5 px-3 text-center w-32">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {sortedItems.map((item, index) => {
                  const isExpanded = expandedStyleKey === item.id;
                  const isSelected = selectedStyleIds.includes(item.id);
                  return (
                    <Fragment key={item.id}>
                      <tr
                        className={`hover:bg-panel-2/70 transition-colors ${
                          isSelected
                            ? "bg-purple-500/10 hover:bg-purple-500/15"
                            : isExpanded
                              ? "bg-panel-2/50"
                              : ""
                        }`}
                      >
                        <td className="py-2.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedStyleIds((prev) =>
                                prev.includes(item.id)
                                  ? prev.filter((x) => x !== item.id)
                                  : [...prev, item.id],
                              );
                            }}
                            className="text-purple-400 hover:text-purple-300 transition cursor-pointer"
                          >
                            {isSelected ? (
                              <CheckSquare className="w-4 h-4 fill-purple-600/30 text-purple-400" />
                            ) : (
                              <Square className="w-4 h-4 text-muted-foreground" />
                            )}
                          </button>
                        </td>
                        <td className="py-2.5 px-3 text-center text-muted-foreground font-mono tabular-nums text-[11px]">
                          {index + 1}
                        </td>
                        <td className="py-2.5 px-3 font-medium text-foreground whitespace-nowrap">
                          {item.buyer}
                        </td>
                        <td className="py-2.5 px-3 text-muted-foreground whitespace-nowrap">
                          {item.season}
                        </td>
                        <td className="py-2.5 px-3 font-semibold text-foreground whitespace-nowrap">
                          {item.style}
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold font-mono tabular-nums bg-teal-500/5 border-x border-border">
                          <span
                            className={`inline-block px-2 py-0.5 rounded text-xs ${
                              item.sumOfPlanLines > 0
                                ? "bg-teal-500/20 text-teal-300 font-extrabold"
                                : "text-muted-foreground"
                            }`}
                          >
                            {item.sumOfPlanLines}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-foreground font-medium">
                          {item.sumOfPlanLines > 0 ? (
                            <span className="tracking-wide text-cyan-200">
                              {item.mentionPlanLines}
                            </span>
                          ) : (
                            <span className="text-muted-foreground italic">
                              কোনো লাইন নির্ধারিত নেই
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold text-emerald-300 whitespace-nowrap">
                          {item.totalPlannedQty.toLocaleString()}{" "}
                          <span className="text-[10px] text-muted-foreground font-normal">pcs</span>
                        </td>
                        <td className="py-2.5 px-3 text-muted-foreground font-mono tabular-nums text-[11px] whitespace-nowrap">
                          {item.earliestStart} → {item.latestFinish}
                        </td>
                        <td className="py-2.5 px-3 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setSplitModalTarget({
                                  planId: item.id,
                                  style: item.style,
                                  buyer: item.buyer,
                                  season: item.season === "— (No Season)" ? null : item.season,
                                  orderQty: item.totalOrderQty || item.totalPlannedQty,
                                  plannedQty: item.totalPlannedQty,
                                  lineQty: item.lineBreakdown?.[0]?.plannedQty,
                                  currentLine: item.distinctLines[0] || undefined,
                                  dailyTarget: item.lineBreakdown?.[0]?.dailyTarget,
                                });
                              }}
                              className="px-2 py-1 rounded bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 hover:text-white font-extrabold text-[10.5px] flex items-center gap-1 transition cursor-pointer shadow-xs"
                              title="Split Order: এই স্টাইলটি স্প্লিট করে নতুন লাইনে পাঠান"
                            >
                              <Scissors className="w-3 h-3 text-purple-400" />
                              <span>Split Order</span>
                            </button>
                            {item.lineBreakdown.length > 0 && (
                              <button
                                type="button"
                                onClick={() =>
                                  setExpandedStyleKey((curr) => (curr === item.id ? null : item.id))
                                }
                                className="p-1 rounded hover:bg-input text-muted-foreground hover:text-foreground transition cursor-pointer"
                                title={
                                  isExpanded ? "লাইন বিবরণ লুকান" : "প্রতিটি লাইনের বিবরণ দেখুন"
                                }
                              >
                                {isExpanded ? (
                                  <ChevronDown className="w-4 h-4 text-teal-400" />
                                ) : (
                                  <ChevronRight className="w-4 h-4" />
                                )}
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>

                      {/* Expandable Per-Line Breakdown Details */}
                      {isExpanded && item.lineBreakdown.length > 0 && (
                        <tr
                          key={`${item.id}-details`}
                          className="bg-panel-2/30 border-b border-border"
                        >
                          <td colSpan={10} className="p-3 pl-12 pr-6">
                            <div className="rounded-lg border border-border bg-panel-1 p-3 space-y-2">
                              <div className="flex items-center justify-between text-xs font-semibold text-muted-foreground">
                                <span className="flex items-center gap-1.5 text-teal-300 font-bold">
                                  <Sparkles className="w-3.5 h-3.5" />
                                  লাইন ভিত্তিক বিস্তারিত বরাদ্দ ({item.style})
                                </span>
                                <span>মোট {item.lineBreakdown.length} টি লাইনের তথ্য</span>
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 pt-1">
                                {item.lineBreakdown.map((lb, lidx) => (
                                  <div
                                    key={`${lb.line}-${lb.startDate}-${lidx}`}
                                    className="rounded border border-border bg-input/40 p-2 text-[11px] space-y-1"
                                  >
                                    <div className="flex items-center justify-between font-bold">
                                      <span className="text-foreground">{lb.line}</span>
                                      <div className="flex items-center gap-1.5">
                                        <span className="font-mono text-emerald-300">
                                          {lb.plannedQty.toLocaleString()} pcs
                                        </span>
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setSplitModalTarget({
                                              planId: item.id,
                                              style: item.style,
                                              buyer: item.buyer,
                                              season:
                                                item.season === "— (No Season)"
                                                  ? null
                                                  : item.season,
                                              orderQty: item.totalOrderQty || item.totalPlannedQty,
                                              plannedQty: item.totalPlannedQty,
                                              lineQty: lb.plannedQty,
                                              currentLine: lb.line,
                                              dailyTarget: lb.dailyTarget,
                                            });
                                          }}
                                          className="px-1.5 py-0.5 rounded bg-purple-500/20 hover:bg-purple-600 text-purple-300 hover:text-white border border-purple-400/40 text-[9.5px] font-bold transition flex items-center gap-1 cursor-pointer"
                                          title={`Split Order: ${lb.line} লাইন থেকে কোয়ান্টিটি স্প্লিট করুন`}
                                        >
                                          <Scissors className="w-2.5 h-2.5" />
                                          <span>Split</span>
                                        </button>
                                      </div>
                                    </div>
                                    <div className="flex items-center justify-between text-muted-foreground text-[10px]">
                                      <span>
                                        {lb.startDate} → {lb.finishDate}
                                      </span>
                                      <span className="font-mono">
                                        {lb.workingDays} days @ {lb.dailyTarget}/d
                                      </span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Floating Bottom Dock for Bulk Selection in Style Lines Summary */}
      {selectedStyleIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-panel/95 backdrop-blur-md border border-purple-500/60 shadow-2xl rounded-2xl px-4 py-3 flex items-center gap-3 animate-in slide-in-from-bottom-4 duration-200">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-purple-500/20 text-purple-300">
              <Layers className="w-4 h-4" />
            </span>
            <span className="font-extrabold text-xs text-foreground">
              <b className="text-purple-300 font-mono text-sm">{selectedStyleIds.length}</b>টি
              স্টাইল নির্বাচিত
            </span>
          </div>

          <div className="h-4 w-px bg-border" />

          <button
            type="button"
            onClick={() => setShowBulkModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
            <span>টার্গেট লাইনে স্থানান্তর করুন (Bulk Assign)</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedStyleIds([])}
            className="px-2.5 py-1.5 rounded-xl border border-border hover:bg-panel text-xs text-muted-foreground hover:text-foreground transition cursor-pointer"
          >
            ক্লিয়ার
          </button>
        </div>
      )}

      {/* Split Order Modal */}
      {splitModalTarget && (
        <SplitStylePlanModal
          open={!!splitModalTarget}
          onClose={() => setSplitModalTarget(null)}
          planId={splitModalTarget.planId}
          styleName={splitModalTarget.style}
          buyerName={splitModalTarget.buyer}
          season={splitModalTarget.season}
          orderQty={splitModalTarget.orderQty}
          plannedQty={splitModalTarget.plannedQty}
          lineQty={splitModalTarget.lineQty}
          currentLine={splitModalTarget.currentLine}
          dailyTarget={splitModalTarget.dailyTarget}
          linePresets={linePresets}
          globalHolidays={[]}
          onSuccess={() => {
            qc.invalidateQueries({ queryKey: ["plans"] });
            setSplitModalTarget(null);
          }}
        />
      )}

      {/* Bulk Style Line Assignment Modal */}
      {showBulkModal && (
        <BulkStyleAssignmentModal
          open={showBulkModal}
          onClose={() => setShowBulkModal(false)}
          plans={rawPlans as any}
          initialSelectedPlanIds={selectedStyleIds}
          linePresets={linePresets}
          globalHolidays={[]}
          onSuccess={() => {
            qc.invalidateQueries({ queryKey: ["plans"] });
            setSelectedStyleIds([]);
          }}
        />
      )}
    </div>
  );
}
