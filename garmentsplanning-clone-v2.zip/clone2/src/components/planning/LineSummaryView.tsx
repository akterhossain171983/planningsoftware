import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, FileDown } from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import { formatDate, type PlanResult } from "@/lib/plan-calc";
import { useLinePresets } from "@/hooks/use-line-presets";
import {
  buildLinePresetLookup,
  canonicalLineName,
  sortLineNamesByPreset,
  uniqueCanonicalLineNames,
} from "./lineLookup";

type Row = {
  id: string;
  buyer: string;
  style: string;
  order_qty: number;
  shipment_date: string;
  calc_result: PlanResult;
};

type SummaryRow = {
  line: string;
  buyer: string;
  style: string;
  orderQty: number;
  planQty: number;
  shipDate: string;
  firstOutput: string;
  lastOutput: string;
};

function buildRows(plans: Row[], linePresets: string[]): SummaryRow[] {
  const out: SummaryRow[] = [];
  const presetLookup = buildLinePresetLookup(linePresets);
  for (const p of plans) {
    const lines = p.calc_result?.lines ?? [];
    const excessPct = p.calc_result?.excessPct ?? 0;
    const factor = 1 + excessPct / 100;
    for (const l of lines) {
      if (!l?.name) continue;
      const daily = l.dailyProduction ?? [];
      const firstOutput = daily.length ? daily[0].date : (l.startDateStr ?? "");
      const lastOutput = l.finishDateStr ?? (daily.length ? daily[daily.length - 1].date : "");

      // Manual allocation: use as-is. Auto allocation: derive per-line qty from dailyProduction.
      let orderQty = l.allocatedOrderQty || 0;
      let planQty = l.plannedQty || 0;
      if (orderQty === 0 && planQty === 0 && daily.length > 0) {
        planQty = daily.reduce((s, d) => s + (d.qty || 0), 0);
        orderQty = factor > 0 ? Math.round(planQty / factor) : planQty;
      }

      out.push({
        line: canonicalLineName(l.name, presetLookup),
        buyer: p.buyer,
        style: p.style,
        orderQty,
        planQty,
        shipDate: p.shipment_date,
        firstOutput,
        lastOutput,
      });
    }
  }
  out.sort((a, b) => {
    const [first] = sortLineNamesByPreset([a.line, b.line], linePresets);
    const byLine = first === a.line ? (a.line === b.line ? 0 : -1) : 1;
    if (byLine !== 0) return byLine;
    return (a.firstOutput || "").localeCompare(b.firstOutput || "");
  });
  return out;
}

export function LineSummaryView() {
  const qc = useQueryClient();
  const { presets: linePresets } = useLinePresets();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "line-summary"],
    queryFn: async (): Promise<Row[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("id, buyer, style, order_qty, shipment_date, calc_result")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("plans-line-summary-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () =>
        qc.invalidateQueries({ queryKey: ["plans"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const allRows = useMemo(() => buildRows(plans, linePresets), [plans, linePresets]);

  const [lineFilter, setLineFilter] = useState<string[]>([]);
  const [buyerFilter, setBuyerFilter] = useState<string[]>([]);
  const [styleFilter, setStyleFilter] = useState<string[]>([]);

  const lineOptions = useMemo(
    () =>
      uniqueCanonicalLineNames(
        allRows.map((r) => r.line),
        linePresets,
      ),
    [allRows, linePresets],
  );
  const buyerOptions = useMemo(
    () => Array.from(new Set(allRows.map((r) => r.buyer))).sort(),
    [allRows],
  );
  const styleOptions = useMemo(
    () => Array.from(new Set(allRows.map((r) => r.style))).sort(),
    [allRows],
  );

  const rows = useMemo(
    () =>
      allRows.filter(
        (r) =>
          (lineFilter.length === 0 || lineFilter.includes(r.line)) &&
          (buyerFilter.length === 0 || buyerFilter.includes(r.buyer)) &&
          (styleFilter.length === 0 || styleFilter.includes(r.style)),
      ),
    [allRows, lineFilter, buyerFilter, styleFilter],
  );

  const totals = useMemo(
    () =>
      rows.reduce(
        (acc, r) => {
          acc.orderQty += r.orderQty || 0;
          acc.planQty += r.planQty || 0;
          return acc;
        },
        { orderQty: 0, planQty: 0 },
      ),
    [rows],
  );

  function exportExcel() {
    if (rows.length === 0) {
      toast.error("এক্সপোর্ট করার মতো কোনো ডেটা নেই।");
      return;
    }
    const aoa: (string | number)[][] = [
      ["Line", "Buyer", "Style", "Order Qty", "Plan Qty", "Ship Date", "1st Output", "Last Output"],
      ...rows.map((r) => [
        r.line,
        r.buyer,
        r.style,
        r.orderQty,
        r.planQty,
        r.shipDate,
        r.firstOutput,
        r.lastOutput,
      ]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [
      { wch: 12 },
      { wch: 18 },
      { wch: 18 },
      { wch: 12 },
      { wch: 12 },
      { wch: 12 },
      { wch: 12 },
      { wch: 12 },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Line Summary");
    const stamp = new Date().toISOString().slice(0, 10);
    XLSX.writeFile(wb, `line-summary-${stamp}.xlsx`);
    toast.success("Excel এক্সপোর্ট হয়েছে।");
  }

  if (isLoading) {
    return (
      <div className="p-12 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl">
      <div className="p-4 md:p-6 border-b border-border bg-panel-2/40 flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-base md:text-lg font-bold text-sky-400">📄 Line Summary</h2>
          <p className="text-xs text-muted-foreground mt-1">
            প্রতিটি লাইনের বায়ার, স্টাইল, কোয়ান্টিটি ও তারিখের সংক্ষিপ্ত ভিউ।
          </p>
        </div>
        <button
          onClick={exportExcel}
          className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/50 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 px-3 py-2 text-xs font-bold"
        >
          <FileDown className="w-3.5 h-3.5" /> Export to Excel
        </button>
      </div>
      <div className="p-3 md:p-4 border-b border-border bg-panel/40 flex flex-wrap items-center gap-2">
        <FilterSelect
          label="Line"
          value={lineFilter}
          onChange={setLineFilter}
          options={lineOptions}
        />
        <FilterSelect
          label="Buyer"
          value={buyerFilter}
          onChange={setBuyerFilter}
          options={buyerOptions}
        />
        <FilterSelect
          label="Style"
          value={styleFilter}
          onChange={setStyleFilter}
          options={styleOptions}
        />
        {lineFilter.length || buyerFilter.length || styleFilter.length ? (
          <button
            onClick={() => {
              setLineFilter([]);
              setBuyerFilter([]);
              setStyleFilter([]);
            }}
            className="ml-auto text-xs font-bold text-red-300 hover:text-red-200 underline"
          >
            Clear filters
          </button>
        ) : null}
        <span className="text-[11px] text-muted-foreground ml-2">
          {rows.length} / {allRows.length} rows
        </span>
        <div className="w-full flex flex-wrap items-center gap-2 mt-1">
          <span className="inline-flex items-center gap-1.5 rounded-md border border-yellow-500/40 bg-yellow-500/10 px-2 py-1 text-[11px] font-bold text-yellow-300">
            Σ Order Qty: <span className="font-mono">{totals.orderQty.toLocaleString()}</span>
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-md border border-emerald-500/40 bg-emerald-500/10 px-2 py-1 text-[11px] font-bold text-emerald-300">
            Σ Plan Qty: <span className="font-mono">{totals.planQty.toLocaleString()}</span>
          </span>
        </div>
      </div>
      {rows.length === 0 ? (
        <p className="p-12 text-center text-sm text-muted-foreground">কোনো প্ল্যান সেভ হয়নি।</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-panel-2 text-muted-foreground text-xs uppercase tracking-wider">
              <tr>
                <th className="p-3">Line</th>
                <th className="p-3">Buyer</th>
                <th className="p-3">Style</th>
                <th className="p-3 text-right">Order Qty</th>
                <th className="p-3 text-right">Plan Qty</th>
                <th className="p-3">Ship Date</th>
                <th className="p-3">1st Output</th>
                <th className="p-3">Last Output</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {rows.map((r, i) => (
                <tr key={i} className="hover:bg-panel-2/40">
                  <td className="p-3 font-bold text-emerald-300">
                    {r.line.startsWith("Line - ") ? r.line.replace("Line - ", "") : r.line}
                  </td>
                  <td className="p-3 text-foreground">{r.buyer}</td>
                  <td className="p-3 text-muted-foreground">{r.style}</td>
                  <td className="p-3 text-right font-mono text-yellow-300">
                    {r.orderQty ? r.orderQty.toLocaleString() : "-"}
                  </td>
                  <td className="p-3 text-right font-mono text-emerald-400 font-bold">
                    {r.planQty ? r.planQty.toLocaleString() : "-"}
                  </td>
                  <td className="p-3 font-mono text-xs text-red-300">{formatDate(r.shipDate)}</td>
                  <td className="p-3 font-mono text-xs text-blue-300">
                    {formatDate(r.firstOutput)}
                  </td>
                  <td className="p-3 font-mono text-xs text-amber-300">
                    {formatDate(r.lastOutput)}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-panel-2/60 border-t-2 border-border">
              <tr className="font-bold">
                <td className="p-3 text-sky-300" colSpan={3}>
                  Subtotal ({rows.length} rows)
                </td>
                <td className="p-3 text-right font-mono text-yellow-300">
                  {totals.orderQty.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono text-emerald-400">
                  {totals.planQty.toLocaleString()}
                </td>
                <td className="p-3" colSpan={3}></td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </div>
  );
}

export function FilterSelect({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string[];
  onChange: (v: string[]) => void;
  options: string[];
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const toggle = (opt: string) => {
    if (value.includes(opt)) onChange(value.filter((v) => v !== opt));
    else onChange([...value, opt]);
  };
  const filteredOptions = useMemo(
    () =>
      search.trim() === ""
        ? options
        : options.filter((o) => o.toLowerCase().includes(search.trim().toLowerCase())),
    [options, search],
  );
  const summary =
    value.length === 0 ? "All" : value.length <= 2 ? value.join(", ") : `${value.length} selected`;
  return (
    <div className="relative inline-block text-xs">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="inline-flex items-center gap-1.5 rounded-md border border-border bg-input px-2 py-1.5 text-xs text-foreground min-w-[10rem]"
      >
        <span className="text-muted-foreground font-bold">{label}:</span>
        <span className="truncate max-w-[10rem]">{summary}</span>
        <span className="ml-auto opacity-60">▾</span>
      </button>
      {open && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => {
              setOpen(false);
              setSearch("");
            }}
          />
          <div className="absolute z-50 mt-1 w-64 max-h-80 overflow-hidden rounded-md border border-border bg-panel shadow-xl flex flex-col">
            <div className="p-2 border-b border-border">
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={`Search ${label.toLowerCase()}...`}
                autoFocus
                className="w-full rounded border border-border bg-input px-2 py-1 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-sky-500"
              />
              <div className="flex items-center justify-between mt-2">
                <button
                  type="button"
                  onClick={() => onChange(Array.from(new Set([...value, ...filteredOptions])))}
                  className="text-[11px] text-sky-300 hover:underline"
                >
                  Select {search ? "matches" : "all"}
                </button>
                <button
                  type="button"
                  onClick={() => onChange([])}
                  className="text-[11px] text-red-300 hover:underline"
                >
                  Clear
                </button>
              </div>
            </div>
            <div className="overflow-auto p-2 flex-1">
              {filteredOptions.length === 0 && (
                <p className="text-[11px] text-muted-foreground px-1 py-2">No matches</p>
              )}
              {filteredOptions.map((o) => (
                <label
                  key={o}
                  className="flex items-center gap-2 px-1.5 py-1 rounded hover:bg-panel-2 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={value.includes(o)}
                    onChange={() => toggle(o)}
                    className="accent-sky-500"
                  />
                  <span className="text-foreground text-xs truncate">{o}</span>
                </label>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
