import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Loader2,
  PackageOpen,
  Package,
  RotateCcw,
  Zap,
  Plus,
  X,
  Search,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Pencil,
  ArrowRight,
  Maximize2,
  Minimize2,
  ArrowUpDown,
  ChevronUp,
  ChevronDown,
  Eye,
  AlignJustify,
  Save,
  Scale,
  TrendingUp,
  TrendingDown,
  SlidersHorizontal,
  RefreshCw,
  Trash2,
  ListOrdered,
  Scissors,
  ArrowRightLeft,
  CheckSquare,
  Square,
} from "lucide-react";
import { toast } from "sonner";
import { formatDate, calculatePlan, type PlanResult } from "@/lib/plan-calc";
import { FilterSelect } from "./LineSummaryView";
import { useLinePresets } from "@/hooks/use-line-presets";
import {
  buildLinePresetLookup,
  canonicalLineName,
  uniqueCanonicalLineNames,
  normLine,
} from "./lineLookup";
import { useGlobalHolidays } from "./HolidayCalendar";
import { buildPlanSnapshot } from "@/lib/plan-snapshot";
import { simulateDrop, shiftDateStr, type PlanRow, type LineChange } from "./planBoardSim";
import { logActivity } from "@/lib/audit-logger";
import { StylePlanVarianceModal, type StyleVarianceItem } from "./StylePlanVarianceModal";
import { SplitStylePlanModal } from "./SplitStylePlanModal";
import { BulkStyleAssignmentModal } from "./BulkStyleAssignmentModal";
import { PlanBoardToolbar } from "./PlanBoardToolbar";
import {
  detectLineConflicts,
  getBarConflictMap,
  groupConflictsByLine,
  checkDragCollision,
  type LineConflict,
} from "./lineConflict";
import { LineConflictDrawer } from "./LineConflictDrawer";

type Bar = {
  planId: string;
  line: string; // canonical (preset)
  rawLine: string; // stored name in config
  buyer: string;
  style: string;
  qty: number;
  start: string;
  end: string;
  fabricEta?: string | null;
  orderQty?: number;
  plannedQty?: number;
  diffQty?: number;
  diffPct?: number;
  status?: "over" | "under" | "exact";
  dailyTarget?: number;
};

type Zoom = "day" | "week" | "month";
const ZOOM_PX: Record<Zoom, number> = { day: 28, week: 12, month: 6 };

function hueFor(key: string): number {
  let h = 0;
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
  return h % 360;
}
function colorFor(style: string) {
  const hue = hueFor(style);
  return {
    bg: `hsl(${hue} 70% 45% / 0.85)`,
    border: `hsl(${hue} 80% 65%)`,
    text: `hsl(${hue} 90% 96%)`,
  };
}
function daysBetween(a: Date, b: Date): number {
  return Math.round((b.getTime() - a.getTime()) / 86_400_000);
}

function buildBars(
  plans: PlanRow[],
  producedMap: Map<string, number>,
  linePresets: string[],
): Bar[] {
  const out: Bar[] = [];
  const presetLookup = buildLinePresetLookup(linePresets);
  for (const p of plans) {
    const isUnplanned =
      (p.config as any)?.status === "unplanned" ||
      (p.config as any)?.isUnplanned === true ||
      p.num_lines === 0;
    if (isUnplanned) continue;

    const lines = p.calc_result?.lines ?? [];
    const excessPct = p.calc_result?.excessPct ?? 0;
    const factor = 1 + excessPct / 100;
    const fabricEta =
      (p.config as any)?.fabricEta ||
      (p.config as any)?.fabric_eta ||
      (p as any)?.fabric_eta ||
      (p as any)?.fabricEta ||
      (p.calc_result as any)?.fabricEta ||
      (p.calc_result as any)?.fabric_eta ||
      null;

    const planOrderQty = Number(p.order_qty) || 0;
    let planTotalPlanned = Number(p.calc_result?.totalPlannedQty) || 0;
    if (planTotalPlanned === 0 && lines.length) {
      planTotalPlanned = lines.reduce(
        (sum, l) => sum + (Number(l.plannedQty || l.allocatedOrderQty) || 0),
        0,
      );
    }
    if (planTotalPlanned === 0 && p.config?.lines?.length) {
      planTotalPlanned = p.config.lines.reduce(
        (sum, l) => sum + (Number(l.allocatedOrderQty) || 0),
        0,
      );
    }
    const diffQty = planTotalPlanned - planOrderQty;
    const diffPct = planOrderQty > 0 ? (diffQty / planOrderQty) * 100 : 0;
    const status: "over" | "under" | "exact" =
      diffQty > 0 ? "over" : diffQty < 0 ? "under" : "exact";

    for (const l of lines) {
      if (!l?.name) continue;
      const daily = l.dailyProduction ?? [];
      const start = daily.length ? daily[0].date : l.startDateStr;
      const end = l.finishDateStr || (daily.length ? daily[daily.length - 1].date : start);
      if (!start || !end) continue;
      let qty = l.plannedQty || 0;
      if (qty === 0 && l.allocatedOrderQty) qty = Math.round(l.allocatedOrderQty * factor);
      if (qty === 0 && daily.length) qty = daily.reduce((s, d) => s + (d.qty || 0), 0);
      const produced = producedMap.get(`${p.id}::${l.name}`) ?? 0;
      const remaining = Math.max(0, qty - produced);
      if (qty > 0 && remaining <= 0) continue;
      const lineDailyTarget =
        Number(l.targetOverride) ||
        Number(p.calc_result?.dailyTargetPerLine) ||
        Number((p as any).daily_target) ||
        Number((p.config as any)?.dailyTargetPerLine) ||
        (l.workingDays ? Math.round(qty / l.workingDays) : 0);
      out.push({
        planId: p.id,
        line: canonicalLineName(l.name, presetLookup),
        rawLine: l.name,
        buyer: p.buyer,
        style: p.style,
        qty: remaining || qty,
        start,
        end,
        fabricEta,
        orderQty: planOrderQty,
        plannedQty: planTotalPlanned,
        diffQty,
        diffPct,
        status,
        dailyTarget: lineDailyTarget,
      });
    }
  }
  return out;
}

type DragState = {
  planId: string;
  rawLine: string;
  origLineCanonical: string;
  pointerStartX: number;
  pointerStartY: number;
  dx: number;
  dy: number;
  origRowIdx: number;
  targetRowIdx: number;
  rowTops: number[]; // clientY tops of each visible line row
  deltaDays: number;
  moved: boolean;
};

type ConfirmState = {
  planId: string;
  rawLine: string;
  origLine: string;
  newLine: string;
  deltaDays: number;
  changes: LineChange[];
  dirtyIds: string[];
  after: PlanRow[];
};

type PlanFields = { config: unknown; calc_result: unknown; previous_snapshot: unknown };
type HistoryEntry = {
  label: string;
  prev: Array<{ id: string } & PlanFields>;
  next: Array<{ id: string } & PlanFields>;
};

export function PlanBoardView() {
  const qc = useQueryClient();
  const { presets: linePresets } = useLinePresets();
  const { data: globalHolidays = [] } = useGlobalHolidays();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "board"],
    queryFn: async (): Promise<PlanRow[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("*")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as PlanRow[];
    },
  });

  const { data: produced = [] } = useQuery({
    queryKey: ["production_updates", "board"],
    queryFn: async (): Promise<
      Array<{ plan_id: string; line_name: string; actual_qty: number }>
    > => {
      const { data, error } = await supabase
        .from("production_updates")
        .select("plan_id, line_name, actual_qty");
      if (error) throw error;
      return data ?? [];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("plans-board-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () =>
        qc.invalidateQueries({ queryKey: ["plans"] }),
      )
      .on("postgres_changes", { event: "*", schema: "public", table: "production_updates" }, () =>
        qc.invalidateQueries({ queryKey: ["production_updates"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const producedMap = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of produced) {
      const k = `${r.plan_id}::${r.line_name}`;
      m.set(k, (m.get(k) ?? 0) + (r.actual_qty || 0));
    }
    return m;
  }, [produced]);

  const allBars = useMemo(
    () => buildBars(plans, producedMap, linePresets),
    [plans, producedMap, linePresets],
  );

  const lineOptions = useMemo(
    () =>
      uniqueCanonicalLineNames(
        allBars.map((b) => b.line),
        linePresets,
      ),
    [allBars, linePresets],
  );
  const buyerOptions = useMemo(
    () => Array.from(new Set(allBars.map((b) => b.buyer))).sort(),
    [allBars],
  );
  const styleOptions = useMemo(
    () => Array.from(new Set(allBars.map((b) => b.style))).sort(),
    [allBars],
  );

  const styleVariances = useMemo<StyleVarianceItem[]>(() => {
    const map = new Map<string, StyleVarianceItem>();
    const presetLookup = buildLinePresetLookup(linePresets);

    for (const p of plans) {
      const isUnplanned =
        (p.config as any)?.status === "unplanned" ||
        (p.config as any)?.isUnplanned === true ||
        p.num_lines === 0;
      if (isUnplanned) continue;

      const key = `${p.buyer}:::${p.style}`;
      const orderQty = Math.max(0, Number(p.order_qty) || 0);
      const excessPct = Number(p.excess_pct) || Number(p.calc_result?.excessPct) || 0;
      const factor = 1 + excessPct / 100;
      const lines = p.calc_result?.lines ?? [];

      let planTotalPlanned = Number(p.calc_result?.totalPlannedQty) || 0;
      if (planTotalPlanned === 0 && lines.length) {
        planTotalPlanned = lines.reduce(
          (sum, l) => sum + (Number(l.plannedQty || l.allocatedOrderQty) || 0),
          0,
        );
      }
      if (planTotalPlanned === 0 && p.config?.lines?.length) {
        planTotalPlanned = p.config.lines.reduce(
          (sum, l) => sum + (Number(l.allocatedOrderQty) || 0),
          0,
        );
      }

      const planLines: Array<{
        planId: string;
        lineName: string;
        rawLine: string;
        qty: number;
        start: string;
        end: string;
        dailyTarget?: number;
      }> = [];

      for (const l of lines) {
        if (!l?.name) continue;
        const daily = l.dailyProduction ?? [];
        const start = daily.length ? daily[0].date : l.startDateStr;
        const end = l.finishDateStr || (daily.length ? daily[daily.length - 1].date : start);
        let qty = l.plannedQty || 0;
        if (qty === 0 && l.allocatedOrderQty) qty = Math.round(l.allocatedOrderQty * factor);
        if (qty === 0 && daily.length) qty = daily.reduce((s, d) => s + (d.qty || 0), 0);
        const lineDailyTarget =
          Number(l.targetOverride) ||
          Number(p.calc_result?.dailyTargetPerLine) ||
          Number((p as any).daily_target) ||
          Number((p.config as any)?.dailyTargetPerLine) ||
          (l.workingDays ? Math.round(qty / l.workingDays) : 0);
        planLines.push({
          planId: p.id,
          lineName: canonicalLineName(l.name, presetLookup),
          rawLine: l.name,
          qty,
          start,
          end,
          dailyTarget: lineDailyTarget,
        });
      }

      if (!map.has(key)) {
        map.set(key, {
          styleKey: key,
          style: p.style,
          buyer: p.buyer,
          orderQty,
          plannedQty: planTotalPlanned,
          diffQty: 0,
          diffPct: 0,
          status: "exact",
          excessPct,
          planIds: [p.id],
          lines: planLines,
        });
      } else {
        const existing = map.get(key)!;
        existing.orderQty += orderQty;
        existing.plannedQty += planTotalPlanned;
        if (!existing.planIds.includes(p.id)) {
          existing.planIds.push(p.id);
        }
        existing.lines.push(...planLines);
      }
    }

    const items = Array.from(map.values()).map((v) => {
      const diffQty = v.plannedQty - v.orderQty;
      const diffPct = v.orderQty > 0 ? (diffQty / v.orderQty) * 100 : 0;
      const status: "over" | "under" | "exact" =
        Math.abs(diffPct) < 0.1 ? "exact" : diffQty > 0 ? "over" : "under";
      return {
        ...v,
        diffQty,
        diffPct,
        status,
      };
    });

    return items.sort((a, b) => {
      if (a.status !== "exact" && b.status === "exact") return -1;
      if (a.status === "exact" && b.status !== "exact") return 1;
      return Math.abs(b.diffPct) - Math.abs(a.diffPct);
    });
  }, [plans, linePresets]);

  const varianceIssuesCount = useMemo(() => {
    return styleVariances.filter((s) => s.status !== "exact").length;
  }, [styleVariances]);

  const [lineFilter, setLineFilter] = useState<string[]>([]);
  const [buyerFilter, setBuyerFilter] = useState<string[]>([]);
  const [styleFilter, setStyleFilter] = useState<string[]>([]);
  const [zoom, setZoom] = useState<Zoom>("day");
  const [pastMonthFilter, setPastMonthFilter] = useState<string[]>([]);

  const [showConflictDrawer, setShowConflictDrawer] = useState(false);
  const [filterConflictingOnly, setFilterConflictingOnly] = useState(false);

  const dayPx = ZOOM_PX[zoom];

  const yesterdayStart = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - 1);
    return d;
  }, []);

  const pastMonthOptions = useMemo(() => {
    const set = new Set<string>();
    for (const b of allBars) {
      const s = new Date(b.start);
      const e = new Date(b.end);
      const cur = new Date(s.getFullYear(), s.getMonth(), 1);
      const stop = new Date(e.getFullYear(), e.getMonth(), 1);
      while (cur <= stop) {
        if (cur < yesterdayStart) {
          set.add(cur.toLocaleString("en-US", { month: "short", year: "numeric" }));
        }
        cur.setMonth(cur.getMonth() + 1);
      }
    }
    return Array.from(set).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
  }, [allBars, yesterdayStart]);

  const bars = useMemo(
    () =>
      allBars.filter(
        (b) =>
          (lineFilter.length === 0 || lineFilter.includes(b.line)) &&
          (buyerFilter.length === 0 || buyerFilter.includes(b.buyer)) &&
          (styleFilter.length === 0 || styleFilter.includes(b.style)),
      ),
    [allBars, lineFilter, buyerFilter, styleFilter],
  );

  const cutoff = useMemo(() => {
    if (pastMonthFilter.length === 0) return yesterdayStart;
    const earliestTs = Math.min(...pastMonthFilter.map((m) => new Date(m).getTime()));
    const d = new Date(earliestTs);
    return new Date(d.getFullYear(), d.getMonth(), 1);
  }, [pastMonthFilter, yesterdayStart]);

  const visibleBars = useMemo(() => bars.filter((b) => new Date(b.end) >= cutoff), [bars, cutoff]);

  // Line assignment conflict warning system: flags when same line is assigned to multiple styles at same time
  const conflicts = useMemo(() => detectLineConflicts(allBars), [allBars]);
  const barConflictMap = useMemo(() => getBarConflictMap(conflicts), [conflicts]);
  const lineConflictGroupMap = useMemo(() => groupConflictsByLine(conflicts), [conflicts]);

  const visibleLines = useMemo(() => {
    const lines = lineFilter.length ? lineFilter : lineOptions;
    const withBars = new Set(visibleBars.map((b) => b.line));
    let filtered = lines.filter((l) => withBars.has(l));
    if (filterConflictingOnly) {
      filtered = filtered.filter((l) => lineConflictGroupMap.has(l));
    }
    return filtered;
  }, [lineFilter, lineOptions, visibleBars, filterConflictingOnly, lineConflictGroupMap]);

  const range = useMemo(() => {
    if (visibleBars.length === 0) return null;
    let minStr = visibleBars[0].start;
    let maxStr = visibleBars[0].end;
    for (const b of visibleBars) {
      if (b.start < minStr) minStr = b.start;
      if (b.end > maxStr) maxStr = b.end;
    }
    let s = new Date(minStr);
    if (s < cutoff) s = new Date(cutoff);
    s.setDate(s.getDate() - 2);
    const e = new Date(maxStr);
    e.setDate(e.getDate() + 2);
    return { start: s, end: e, days: daysBetween(s, e) + 1 };
  }, [visibleBars, cutoff]);

  const barsByLine = useMemo(() => {
    const m = new Map<string, Bar[]>();
    for (const b of visibleBars) {
      if (!m.has(b.line)) m.set(b.line, []);
      m.get(b.line)!.push(b);
    }
    return m;
  }, [visibleBars]);

  // ─── Vertical Size & Fullscreen State ────────────────────────
  type VHeightMode = "standard" | "large" | "max";
  const [vHeight, setVHeight] = useState<VHeightMode>(() => {
    try {
      return (localStorage.getItem("cg:planboard-vheight") as VHeightMode) || "large";
    } catch {
      return "large";
    }
  });
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [compactHeader, setCompactHeader] = useState(() => {
    try {
      return localStorage.getItem("cg:planboard-compact-header") === "true";
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("cg:planboard-vheight", vHeight);
    } catch {
      /* noop */
    }
  }, [vHeight]);

  useEffect(() => {
    try {
      localStorage.setItem("cg:planboard-compact-header", String(compactHeader));
    } catch {
      /* noop */
    }
  }, [compactHeader]);

  // ─── Toolbar Rows Option (2-Row Compact vs 1-Row) ─────────────
  const [twoRowToolbar, setTwoRowToolbar] = useState<boolean>(() => {
    try {
      return localStorage.getItem("cg:planboard-2row-toolbar") !== "false";
    } catch {
      return true;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("cg:planboard-2row-toolbar", String(twoRowToolbar));
    } catch {
      /* noop */
    }
  }, [twoRowToolbar]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isFullscreen) {
        setIsFullscreen(false);
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [isFullscreen]);

  // ─── Row Density & Width (Compact / At a Glance) ────────────
  type RowDensity = "normal" | "compact" | "glance" | "ultra";
  const [rowDensity, setRowDensity] = useState<RowDensity>(() => {
    try {
      return (localStorage.getItem("cg:planboard-row-density") as RowDensity) || "glance";
    } catch {
      return "glance";
    }
  });

  const [customColWidth, setCustomColWidth] = useState<number | null>(() => {
    try {
      const v = localStorage.getItem("cg:planboard-col-width");
      return v ? parseInt(v, 10) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("cg:planboard-row-density", rowDensity);
    } catch {
      /* noop */
    }
  }, [rowDensity]);

  useEffect(() => {
    try {
      if (customColWidth) {
        localStorage.setItem("cg:planboard-col-width", String(customColWidth));
      } else {
        localStorage.removeItem("cg:planboard-col-width");
      }
    } catch {
      /* noop */
    }
  }, [customColWidth]);

  const rowHeight =
    rowDensity === "ultra" ? 22 : rowDensity === "glance" ? 26 : rowDensity === "compact" ? 34 : 44;

  const defaultColWidth =
    rowDensity === "ultra" ? 52 : rowDensity === "glance" ? 58 : rowDensity === "compact" ? 74 : 94;

  const lineColWidth = customColWidth ?? defaultColWidth;

  const barHeight = rowHeight <= 22 ? 16 : rowHeight <= 26 ? 20 : rowHeight <= 34 ? 26 : 34;

  const barTop = Math.max(2, Math.floor((rowHeight - barHeight) / 2));

  function formatLineLabel(line: string, colWidth: number) {
    const clean = line.replace(/^Line\s*[-–—]?\s*/i, "").trim();
    if (colWidth <= 60) {
      if (/^\d+$/.test(clean)) return `L-${clean.padStart(2, "0")}`;
      if (clean.length > 5) return clean.slice(0, 4);
      return clean;
    }
    if (colWidth <= 78) {
      if (/^\d+$/.test(clean)) return `Line ${clean}`;
      return clean;
    }
    return line.startsWith("Line - ") ? line.replace("Line - ", "Line ") : line;
  }

  function toggleAtAGlance() {
    if (rowDensity === "glance" || rowDensity === "ultra") {
      setRowDensity("compact");
      setCompactHeader(false);
      setVHeight("large");
      setCustomColWidth(null);
    } else {
      setRowDensity("glance");
      setCompactHeader(true);
      setVHeight("max");
      setCustomColWidth(58);
    }
  }

  const [showFabricEta, setShowFabricEta] = useState(() => {
    try {
      const stored = localStorage.getItem("cg:planboard-show-fabric-eta");
      return stored === null ? true : stored === "true";
    } catch {
      return true;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("cg:planboard-show-fabric-eta", String(showFabricEta));
    } catch {
      /* noop */
    }
  }, [showFabricEta]);

  const [showVarianceBadges, setShowVarianceBadges] = useState(() => {
    try {
      const stored = localStorage.getItem("cg:planboard-show-variance-badges");
      return stored === null ? true : stored === "true";
    } catch {
      return true;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("cg:planboard-show-variance-badges", String(showVarianceBadges));
    } catch {
      /* noop */
    }
  }, [showVarianceBadges]);

  const [showDailyTarget, setShowDailyTarget] = useState(() => {
    try {
      const stored = localStorage.getItem("cg:planboard-show-daily-target");
      return stored === null ? true : stored === "true";
    } catch {
      return true;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("cg:planboard-show-daily-target", String(showDailyTarget));
    } catch {
      /* noop */
    }
  }, [showDailyTarget]);

  const [showVarianceModal, setShowVarianceModal] = useState(false);
  const [fixingPlanId, setFixingPlanId] = useState<string | null>(null);

  function editPlan(planId: string) {
    window.dispatchEvent(new CustomEvent("cg:edit-plan", { detail: planId }));
  }

  // ─── Unplanned Orders Integration ──────────────────────────
  const [selectedBar, setSelectedBar] = useState<Bar | null>(null);
  const [editingEta, setEditingEta] = useState("");
  const [savingEta, setSavingEta] = useState(false);

  useEffect(() => {
    if (selectedBar) {
      setEditingEta(selectedBar.fabricEta ?? "");
    }
  }, [selectedBar]);

  async function handleSaveQuickEta(planId: string, newEta: string) {
    setSavingEta(true);
    try {
      const plan = plans.find((p) => p.id === planId);
      if (!plan) throw new Error("প্ল্যান খুঁজে পাওয়া যায়নি");
      const currentConfig = (plan.config || {}) as Record<string, unknown>;
      const trimmed = newEta.trim() || null;
      const updatedConfig = {
        ...currentConfig,
        fabricEta: trimmed,
        fabric_eta: trimmed,
      };

      const { error } = await supabase
        .from("plans")
        // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
        .update({ config: updatedConfig as any })
        .eq("id", planId);

      if (error) throw error;

      setSelectedBar((prev) => (prev ? { ...prev, fabricEta: trimmed } : null));

      logActivity({
        action: "PLAN_EDIT",
        details: `ফ্যাব্রিক ETA আপডেট: "${selectedBar?.style}" (বায়ার: ${selectedBar?.buyer}, ETA: ${trimmed ? formatDate(trimmed) : "মুছে ফেলা হয়েছে"})`,
        targetId: planId,
        targetName: selectedBar?.style,
      });

      await qc.invalidateQueries({ queryKey: ["plans"] });

      toast.success(
        trimmed
          ? `ফ্যাব্রিক ETA (${formatDate(trimmed)}) সফলভাবে সেভ হয়েছে!`
          : "ফ্যাব্রিক ETA মুছে ফেলা হয়েছে!",
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "ফ্যাব্রিক ETA সেভ করা যায়নি।");
    } finally {
      setSavingEta(false);
    }
  }

  const [unplanModalTarget, setUnplanModalTarget] = useState<{
    planId: string;
    style: string;
    buyer: string;
  } | null>(null);
  const [splitModalTarget, setSplitModalTarget] = useState<{
    planId: string;
    style: string;
    buyer: string;
    season?: string | null;
    orderQty: number;
    plannedQty: number;
    lineQty?: number;
    currentLine?: string;
    dailyTarget?: number;
    shipmentDate?: string;
  } | null>(null);
  const [unplanningId, setUnplanningId] = useState<string | null>(null);
  const [showUnplannedDrawer, setShowUnplannedDrawer] = useState(false);
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; bar: Bar } | null>(null);
  const [unplannedTab, setUnplannedTab] = useState<"unplanned" | "scheduled">("unplanned");
  const [unplannedSearch, setUnplannedSearch] = useState("");

  // Bulk Assignment States
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [bulkSelectedPlanIds, setBulkSelectedPlanIds] = useState<Set<string>>(new Set());
  const [isBulkSelectMode, setIsBulkSelectMode] = useState(false);

  useEffect(() => {
    const handleOpenBulk = (e: any) => {
      if (e.detail?.planIds && Array.isArray(e.detail.planIds)) {
        setBulkSelectedPlanIds(new Set(e.detail.planIds));
      }
      setShowBulkModal(true);
    };
    window.addEventListener("cg:bulk-assign" as any, handleOpenBulk);
    return () => window.removeEventListener("cg:bulk-assign" as any, handleOpenBulk);
  }, []);

  const unplannedOrders = useMemo(() => {
    return plans.filter((p) => {
      return (
        (p.config as any)?.status === "unplanned" ||
        (p.config as any)?.isUnplanned === true ||
        p.num_lines === 0 ||
        !p.calc_result?.lines ||
        (p.calc_result.lines as unknown[]).length === 0
      );
    });
  }, [plans]);
  const unplannedCount = unplannedOrders.length;

  useEffect(() => {
    const handleCloseMenu = () => setContextMenu(null);
    window.addEventListener("click", handleCloseMenu);
    return () => window.removeEventListener("click", handleCloseMenu);
  }, []);

  async function handleUnplanOrder(planId: string) {
    const p = plans.find((x) => x.id === planId);
    if (!p) return;
    setUnplanningId(planId);
    try {
      const prevLines = (p.config as any)?.lines ?? [];
      const { error } = await supabase
        .from("plans")
        .update({
          num_lines: 0,
          config: {
            ...(p.config || {}),
            status: "unplanned",
            isUnplanned: true,
            previous_lines: prevLines,
            lines: [],
          },
          calc_result: {
            ...(p.calc_result || {}),
            lines: [],
            orderQty: p.order_qty,
            excessPct: p.excess_pct,
          },
        } as any)
        .eq("id", planId);

      if (error) throw error;
      logActivity({
        action: "BOARD_UNPLAN",
        details: `বোর্ড থেকে সরানো হয়েছে: স্টাইল "${p.style}" (বায়ার: ${p.buyer})`,
        targetId: planId,
        targetName: p.style,
      });
      toast.success(
        `"${p.style}" (${p.buyer}) অর্ডারটি লাইন শিডিউল থেকে সরিয়ে আনপ্ল্যান্ড পুলে পাঠানো হয়েছে।`,
      );
      qc.invalidateQueries({ queryKey: ["plans"] });
      setSelectedBar(null);
      setUnplanModalTarget(null);
    } catch (err: any) {
      toast.error("আনপ্ল্যান্ড করা যায়নি: " + (err?.message || "Error"));
    } finally {
      setUnplanningId(null);
    }
  }

  async function handleAutoFixPlan(planId: string) {
    const p = plans.find((x) => x.id === planId);
    if (!p) {
      toast.error("প্ল্যান খুঁজে পাওয়া যায়নি।");
      return;
    }
    setFixingPlanId(planId);
    try {
      const orderQty = Math.max(0, Number(p.order_qty) || 0);
      const excessPct = Number(p.excess_pct) || Number(p.calc_result?.excessPct) || 0;
      const factor = 1 + excessPct / 100;
      const targetPlanned = Math.round(orderQty * factor);

      const prevConfigLines = (p.config?.lines || p.calc_result?.lines || []) as any[];
      if (prevConfigLines.length === 0) {
        toast.error("এই প্ল্যানে কোনো লাইন পাওয়া যায়নি।");
        return;
      }

      const currentTotalAlloc = prevConfigLines.reduce(
        (sum, l) => sum + (Number(l.allocatedOrderQty || l.plannedQty) || 0),
        0,
      );

      let updatedLines: any[];
      if (currentTotalAlloc > 0) {
        let allocatedSoFar = 0;
        updatedLines = prevConfigLines.map((l, idx) => {
          const isLast = idx === prevConfigLines.length - 1;
          const currentVal = Number(l.allocatedOrderQty || l.plannedQty) || 0;
          const newAlloc = isLast
            ? Math.max(0, targetPlanned - allocatedSoFar)
            : Math.round((currentVal / currentTotalAlloc) * targetPlanned);
          allocatedSoFar += newAlloc;
          return {
            ...l,
            allocatedOrderQty: newAlloc,
          };
        });
      } else {
        const perLine = Math.floor(targetPlanned / prevConfigLines.length);
        let allocatedSoFar = 0;
        updatedLines = prevConfigLines.map((l, idx) => {
          const isLast = idx === prevConfigLines.length - 1;
          const newAlloc = isLast ? Math.max(0, targetPlanned - allocatedSoFar) : perLine;
          allocatedSoFar += newAlloc;
          return {
            ...l,
            allocatedOrderQty: newAlloc,
          };
        });
      }

      const planInput = {
        buyer: p.buyer,
        style: p.style,
        orderQty,
        excessPct,
        dailyTargetPerLine: Number(
          p.calc_result?.dailyTargetPerLine || p.config?.dailyTargetPerLine || 1000,
        ),
        shipmentDate: p.shipment_date,
        lines: updatedLines,
        customHolidays: (p.calc_result?.customHolidays ||
          p.config?.customHolidays ||
          []) as string[],
        targetAdjustments: (p.calc_result?.targetAdjustments ||
          p.config?.targetAdjustments ||
          []) as any[],
        targetAdjustmentsEnabled: Boolean(p.config?.targetAdjustmentsEnabled),
        learningCurve: p.config?.learningCurve,
      };

      const newCalcResult = calculatePlan(planInput);

      const updatedConfig = {
        ...(p.config || {}),
        lines: updatedLines,
      };

      const { error } = await supabase
        .from("plans")
        .update({
          config: updatedConfig as any,
          calc_result: newCalcResult as any,
        } as any)
        .eq("id", planId);

      if (error) throw error;

      logActivity({
        action: "PLAN_EDIT",
        details: `স্টাইল কোয়ান্টিটি অটো-ফিক্স: "${p.style}" (বায়ার: ${p.buyer}) ১০০% অর্ডারের (${orderQty.toLocaleString()} pcs) সাথে ম্যাচ করা হয়েছে`,
        targetId: planId,
        targetName: p.style,
      });

      await qc.invalidateQueries({ queryKey: ["plans"] });
      toast.success(
        `"${p.style}" সফলভাবে ১০০% সঠিক কোয়ান্টিটিতে (${orderQty.toLocaleString()} pcs) ফিক্স করা হয়েছে!`,
      );
    } catch (err: any) {
      toast.error("অটো-ফিক্স ব্যর্থ হয়েছে: " + (err?.message || "Error"));
    } finally {
      setFixingPlanId(null);
    }
  }

  async function handleDeletePlan(planId: string, style: string) {
    if (
      !window.confirm(
        `আপনি কি নিশ্চিত যে "${style}" প্ল্যানটি ডাটাবেস থেকে স্থায়ীভাবে ডিলিট করতে চান?`,
      )
    ) {
      return;
    }
    try {
      const { error } = await supabase.from("plans").delete().eq("id", planId);
      if (error) throw error;
      toast.success(`"${style}" সফলভাবে ডিলিট করা হয়েছে!`);
      await qc.invalidateQueries({ queryKey: ["plans"] });
    } catch (err: any) {
      toast.error("ডিলিট করা যায়নি: " + (err?.message || "Error"));
    }
  }

  // ─── Drag & Drop ──────────────────────────────────────────────
  const rowRefs = useRef<Map<number, HTMLDivElement | null>>(new Map());
  const boardScrollRef = useRef<HTMLDivElement | null>(null);
  const justDraggedRef = useRef(false);
  const [drag, setDrag] = useState<DragState | null>(null);
  const [confirm, setConfirm] = useState<ConfirmState | null>(null);
  const [applying, setApplying] = useState(false);
  const [undoStack, setUndoStack] = useState<HistoryEntry[]>([]);
  const [redoStack, setRedoStack] = useState<HistoryEntry[]>([]);
  const [busyHistory, setBusyHistory] = useState<"undo" | "redo" | null>(null);
  const [autoSaveOnDrop, setAutoSaveOnDrop] = useState(() => {
    try {
      return localStorage.getItem("cg:planboard-autosave-drop") !== "false";
    } catch {
      return true;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("cg:planboard-autosave-drop", String(autoSaveOnDrop));
    } catch {
      /* noop */
    }
  }, [autoSaveOnDrop]);

  function onBarPointerDown(e: React.PointerEvent<HTMLButtonElement>, b: Bar) {
    if (e.button !== 0) return;
    const origRowIdx = visibleLines.indexOf(b.line);
    if (origRowIdx < 0) return;
    const rowTops = visibleLines.map((_, i) => {
      const el = rowRefs.current.get(i);
      return el ? el.getBoundingClientRect().top : 0;
    });
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      /* ignore if pointer capture fails */
    }
    setDrag({
      planId: b.planId,
      rawLine: b.rawLine,
      origLineCanonical: b.line,
      pointerStartX: e.clientX,
      pointerStartY: e.clientY,
      dx: 0,
      dy: 0,
      origRowIdx,
      targetRowIdx: origRowIdx,
      rowTops,
      deltaDays: 0,
      moved: false,
    });
  }

  function onBarPointerMove(e: React.PointerEvent<HTMLButtonElement>) {
    if (!drag) return;
    const dx = e.clientX - drag.pointerStartX;
    const dy = e.clientY - drag.pointerStartY;
    const deltaDays = Math.round(dx / dayPx);

    // Auto-scroll horizontally if dragging near viewport edges
    const container = boardScrollRef.current;
    if (container) {
      const rect = container.getBoundingClientRect();
      const edgeThreshold = 70;
      if (e.clientX < rect.left + edgeThreshold + lineColWidth) {
        container.scrollLeft -= 12;
      } else if (e.clientX > rect.right - edgeThreshold) {
        container.scrollLeft += 12;
      }
    }

    // Find hovered row with boundary clamping and robust row fallback
    let targetRowIdx = drag.origRowIdx;
    if (drag.rowTops && drag.rowTops.length > 0) {
      if (e.clientY < drag.rowTops[0]) {
        targetRowIdx = 0;
      } else if (e.clientY >= drag.rowTops[drag.rowTops.length - 1] + rowHeight) {
        targetRowIdx = drag.rowTops.length - 1;
      } else {
        for (let i = 0; i < drag.rowTops.length; i++) {
          const top = drag.rowTops[i];
          if (e.clientY >= top && e.clientY < top + rowHeight) {
            targetRowIdx = i;
            break;
          }
        }
      }
    } else {
      targetRowIdx = Math.max(
        0,
        Math.min(visibleLines.length - 1, drag.origRowIdx + Math.round(dy / rowHeight)),
      );
    }
    const moved = drag.moved || Math.abs(dx) > 8 || Math.abs(dy) > 8;
    setDrag({ ...drag, dx, dy, deltaDays, targetRowIdx, moved });
  }

  const dragCollision = useMemo(() => {
    if (!drag || !drag.moved) return null;
    const targetLine = visibleLines[drag.targetRowIdx];
    if (!targetLine) return null;
    const draggedBar = visibleBars.find(
      (b) => b.planId === drag.planId && b.rawLine === drag.rawLine,
    );
    if (!draggedBar) return null;
    const newStart = shiftDateStr(draggedBar.start, drag.deltaDays);
    const newEnd = shiftDateStr(draggedBar.end, drag.deltaDays);
    return checkDragCollision(drag.planId, draggedBar.style, targetLine, newStart, newEnd, allBars);
  }, [drag, visibleLines, visibleBars, allBars]);

  async function applyChanges(
    afterPlans: PlanRow[],
    dirtyIds: string[],
    changes: LineChange[],
    newLine: string,
    deltaDays: number,
  ) {
    if (dirtyIds.length === 0) return;
    setApplying(true);
    try {
      const origById = new Map(plans.map((p) => [p.id, p]));
      const prevEntries: HistoryEntry["prev"] = [];
      const nextEntries: HistoryEntry["next"] = [];
      const updates = [];

      for (const id of dirtyIds) {
        const next = afterPlans.find((p) => p.id === id);
        const orig = origById.get(id);
        if (!next || !orig) continue;
        const snap = buildPlanSnapshot(orig.calc_result);
        prevEntries.push({
          id,
          config: orig.config,
          calc_result: orig.calc_result,
          // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
          previous_snapshot: (orig as any).previous_snapshot ?? null,
        });
        nextEntries.push({
          id,
          config: next.config,
          calc_result: next.calc_result,
          previous_snapshot: snap,
        });
        updates.push(
          supabase
            .from("plans")
            // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
            .update({
              config: next.config,
              calc_result: next.calc_result as any,
              previous_snapshot: snap as any,
            } as any)
            .eq("id", id),
        );
      }

      await Promise.all(updates);

      const movedChange = changes.find((c) => c.reason === "moved");
      const cleanNewLine = newLine.startsWith("Line - ") ? newLine.replace("Line - ", "") : newLine;
      const label = movedChange
        ? `${movedChange.style} → ${cleanNewLine}${deltaDays !== 0 ? ` (${deltaDays > 0 ? "+" : ""}${deltaDays}d)` : ""}`
        : "Plan Board change";

      logActivity({
        action: "BOARD_RESCHEDULE",
        details: `প্ল্যান বোর্ড ড্র্যাগ ও রিসিডিউল: ${label}`,
        targetName: movedChange?.style,
        metadata: {
          style: movedChange?.style,
          cleanNewLine,
          deltaDays,
          dirtyCount: dirtyIds.length,
        },
      });

      const historyItem = { label, prev: prevEntries, next: nextEntries };
      setUndoStack((s) => [...s, historyItem]);
      setRedoStack([]);

      toast.success(`Rescheduled: ${label} (Database updated)`, {
        action: {
          label: "Undo",
          onClick: () => {
            applyHistorySide(prevEntries).then(() => {
              setUndoStack((s) => s.slice(0, -1));
              setRedoStack((s) => [...s, historyItem]);
              toast.success(`Undone: ${label}`);
              qc.invalidateQueries({ queryKey: ["plans"] });
            });
          },
        },
      });

      setConfirm(null);
      qc.invalidateQueries({ queryKey: ["plans"] });
      qc.invalidateQueries({ queryKey: ["production_updates"] });
    } catch (err) {
      console.error(err);
      toast.error(err instanceof Error ? err.message : "Failed to update database");
    } finally {
      setApplying(false);
    }
  }

  function onBarPointerUp(e: React.PointerEvent<HTMLButtonElement>, b: Bar) {
    if (!drag) return;
    const d = drag;
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
    setDrag(null);
    const newLine = visibleLines[d.targetRowIdx] ?? d.origLineCanonical;
    const isSamePosition = d.deltaDays === 0 && normLine(newLine) === normLine(d.origLineCanonical);

    if (!d.moved || isSamePosition) {
      editPlan(b.planId);
      return;
    }

    justDraggedRef.current = true;
    setTimeout(() => {
      justDraggedRef.current = false;
    }, 150);

    // Simulation logic handles name matching via normLine helper inside simulateDrop.
    const { after, changes } = simulateDrop({
      plans,
      editPlanId: b.planId,
      origLineName: b.rawLine,
      newLineName: newLine,
      deltaDays: d.deltaDays,
      globalHolidays,
    });

    const origById = new Map(plans.map((p) => [p.id, p]));
    const dirtyIds = after
      .filter((p) => {
        const o = origById.get(p.id);
        if (!o) return false;
        return (
          JSON.stringify(o.config) !== JSON.stringify(p.config) ||
          JSON.stringify(o.calc_result) !== JSON.stringify(p.calc_result)
        );
      })
      .map((p) => p.id);

    if (dirtyIds.length === 0) return;

    if (autoSaveOnDrop) {
      applyChanges(after, dirtyIds, changes, newLine, d.deltaDays);
    } else {
      setConfirm({
        planId: b.planId,
        rawLine: b.rawLine,
        origLine: d.origLineCanonical,
        newLine,
        deltaDays: d.deltaDays,
        changes,
        dirtyIds,
        after,
      });
    }
  }

  function applyConfirm() {
    if (!confirm) return;
    applyChanges(
      confirm.after,
      confirm.dirtyIds,
      confirm.changes,
      confirm.newLine,
      confirm.deltaDays,
    );
  }

  async function applyHistorySide(entries: Array<{ id: string } & PlanFields>) {
    const updates = [];
    for (const e of entries) {
      updates.push(
        supabase
          .from("plans")
          // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
          .update({
            config: e.config as any,
            calc_result: e.calc_result as any,
            previous_snapshot: e.previous_snapshot as any,
          } as any)
          .eq("id", e.id),
      );
    }
    await Promise.all(updates);
  }

  async function undo() {
    const entry = undoStack[undoStack.length - 1];
    if (!entry || busyHistory) return;
    setBusyHistory("undo");
    try {
      await applyHistorySide(entry.prev);
      setUndoStack((s) => s.slice(0, -1));
      setRedoStack((s) => [...s, entry]);
      toast.success(`Undone: ${entry.label}`);
      qc.invalidateQueries({ queryKey: ["plans"] });
    } catch (err) {
      console.error(err);
      toast.error("Undo failed");
    } finally {
      setBusyHistory(null);
    }
  }

  async function redo() {
    const entry = redoStack[redoStack.length - 1];
    if (!entry || busyHistory) return;
    setBusyHistory("redo");
    try {
      await applyHistorySide(entry.next);
      setRedoStack((s) => s.slice(0, -1));
      setUndoStack((s) => [...s, entry]);
      toast.success(`Redone: ${entry.label}`);
      qc.invalidateQueries({ queryKey: ["plans"] });
    } catch (err) {
      console.error(err);
      toast.error("Redo failed");
    } finally {
      setBusyHistory(null);
    }
  }

  if (isLoading) {
    return (
      <div className="p-12 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const totalWidth = range ? range.days * dayPx : 0;

  const monthHeaders: Array<{ label: string; days: number }> = [];
  if (range) {
    const cur = new Date(range.start);
    for (let i = 0; i < range.days; i++) {
      const label = cur.toLocaleString("en-US", { month: "short", year: "numeric" });
      const last = monthHeaders[monthHeaders.length - 1];
      if (last && last.label === label) last.days += 1;
      else monthHeaders.push({ label, days: 1 });
      cur.setDate(cur.getDate() + 1);
    }
  }

  // Grid ticks for week/month zoom (day zoom draws its own per-day grid)
  const gridTicks: Array<{ offset: number; span: number; label: string; major: boolean }> = [];
  if (range && zoom !== "day") {
    if (zoom === "week") {
      let i = 0;
      while (i < range.days) {
        const d = new Date(range.start);
        d.setDate(d.getDate() + i);
        // week boundary: Saturday start
        const step = i === 0 ? Math.max(1, 7 - ((d.getDay() + 1) % 7)) : 7;
        const span = Math.min(step, range.days - i);
        gridTicks.push({
          offset: i,
          span,
          label: `${d.getDate()}`,
          major: d.getDate() <= 7,
        });
        i += span;
      }
    } else {
      let acc = 0;
      for (const m of monthHeaders) {
        gridTicks.push({ offset: acc, span: m.days, label: m.label.split(" ")[0], major: true });
        acc += m.days;
      }
    }
  }

  // Today marker
  const todayDate = new Date();
  todayDate.setHours(0, 0, 0, 0);
  const todayOffset = range ? daysBetween(range.start, todayDate) : -1;
  const todayVisible = range ? todayOffset >= 0 && todayOffset < range.days : false;
  const todayLeft = todayOffset * dayPx;

  return (
    <div
      className={
        isFullscreen
          ? "fixed inset-0 z-50 bg-background overflow-hidden p-1.5 md:p-2 flex flex-col shadow-2xl"
          : "rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl flex flex-col transition-all duration-200"
      }
    >
      {!compactHeader ? (
        <div className="px-3 py-1.5 border-b border-border bg-panel-2/40 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-fuchsia-400 flex items-center gap-1.5">
              <span>📊</span> Plan Board
            </h2>
            <span className="hidden md:inline text-[11px] text-muted-foreground">
              — Gantt বোর্ড (এক নজরে সব লাইন দেখার মোড ও আনপ্ল্যান্ড পুল সহ)
            </span>
          </div>
          <button
            type="button"
            onClick={() => setCompactHeader(true)}
            className="p-1 px-2 rounded-lg border border-border/80 hover:bg-panel text-muted-foreground hover:text-foreground text-[11px] font-bold flex items-center gap-1 transition cursor-pointer"
            title="ভার্টিক্যাল স্পেস বাড়াতে হেডার লুকান"
          >
            <ChevronUp className="w-3 h-3" />
            <span className="hidden sm:inline">হেডার লুকান</span>
          </button>
        </div>
      ) : null}

      <PlanBoardToolbar
        compactHeader={compactHeader}
        onToggleCompactHeader={() => setCompactHeader(false)}
        lineFilter={lineFilter}
        onLineFilterChange={setLineFilter}
        lineOptions={lineOptions}
        buyerFilter={buyerFilter}
        onBuyerFilterChange={setBuyerFilter}
        buyerOptions={buyerOptions}
        styleFilter={styleFilter}
        onStyleFilterChange={setStyleFilter}
        styleOptions={styleOptions}
        pastMonthFilter={pastMonthFilter}
        onPastMonthFilterChange={setPastMonthFilter}
        pastMonthOptions={pastMonthOptions}
        onClearFilters={() => {
          setLineFilter([]);
          setBuyerFilter([]);
          setStyleFilter([]);
          setPastMonthFilter([]);
        }}
        visibleLinesCount={visibleLines.length}
        visibleBarsCount={visibleBars.length}
        twoRowToolbar={twoRowToolbar}
        onToggleTwoRowToolbar={() => setTwoRowToolbar((v) => !v)}
        undo={undo}
        redo={redo}
        undoStackLength={undoStack.length}
        redoStackLength={redoStack.length}
        undoLabel={undoStack.length ? undoStack[undoStack.length - 1].label : undefined}
        redoLabel={redoStack.length ? redoStack[redoStack.length - 1].label : undefined}
        busyHistory={busyHistory}
        zoom={zoom}
        onZoomChange={setZoom}
        rowDensity={rowDensity}
        onSetRowDensity={setRowDensity}
        onSetCustomColWidth={setCustomColWidth}
        lineColWidth={lineColWidth}
        vHeight={vHeight}
        onSetVHeight={setVHeight}
        isFullscreen={isFullscreen}
        onToggleFullscreen={() => setIsFullscreen((prev) => !prev)}
        toggleAtAGlance={toggleAtAGlance}
        autoSaveOnDrop={autoSaveOnDrop}
        onSetAutoSaveOnDrop={setAutoSaveOnDrop}
        applying={applying}
        showFabricEta={showFabricEta}
        onSetShowFabricEta={setShowFabricEta}
        fabricEtaBarsCount={visibleBars.filter((b) => !!b.fabricEta).length}
        totalBarsCount={visibleBars.length}
        varianceIssuesCount={varianceIssuesCount}
        onOpenVarianceModal={() => setShowVarianceModal(true)}
        showVarianceBadges={showVarianceBadges}
        onSetShowVarianceBadges={setShowVarianceBadges}
        showDailyTarget={showDailyTarget}
        onSetShowDailyTarget={setShowDailyTarget}
        unplannedCount={unplannedCount}
        onOpenUnplannedDrawer={() => setShowUnplannedDrawer(true)}
        onSwitchToStyleLines={() =>
          window.dispatchEvent(new CustomEvent("cg:switch-tab", { detail: "stylelines" }))
        }
        bulkSelectedCount={bulkSelectedPlanIds.size}
        onOpenBulkModal={() => setShowBulkModal(true)}
        isBulkSelectMode={isBulkSelectMode}
        onToggleBulkSelectMode={() => {
          setIsBulkSelectMode((v) => !v);
          if (isBulkSelectMode) setBulkSelectedPlanIds(new Set());
        }}
        conflictsCount={conflicts.length}
        conflictLinesCount={lineConflictGroupMap.size}
        onOpenConflictDrawer={() => setShowConflictDrawer(true)}
        filterConflictingOnly={filterConflictingOnly}
        onToggleFilterConflictingOnly={() => setFilterConflictingOnly((v) => !v)}
      />

      {!range || visibleLines.length === 0 ? (
        <p className="p-12 text-center text-sm text-muted-foreground">কোনো প্ল্যান নেই।</p>
      ) : (
        <div
          ref={boardScrollRef}
          className={
            isFullscreen
              ? "flex-1 overflow-auto w-full"
              : vHeight === "standard"
                ? "overflow-auto h-[65vh] max-h-[65vh]"
                : vHeight === "max"
                  ? compactHeader
                    ? twoRowToolbar
                      ? "overflow-auto h-[calc(100vh-149px)] max-h-[calc(100vh-149px)]"
                      : "overflow-auto h-[calc(100vh-125px)] max-h-[calc(100vh-125px)]"
                    : twoRowToolbar
                      ? "overflow-auto h-[calc(100vh-179px)] max-h-[calc(100vh-179px)]"
                      : "overflow-auto h-[calc(100vh-155px)] max-h-[calc(100vh-155px)]"
                  : compactHeader
                    ? twoRowToolbar
                      ? "overflow-auto h-[calc(100vh-189px)] max-h-[calc(100vh-189px)]"
                      : "overflow-auto h-[calc(100vh-165px)] max-h-[calc(100vh-165px)]"
                    : twoRowToolbar
                      ? "overflow-auto h-[calc(100vh-219px)] max-h-[calc(100vh-219px)]"
                      : "overflow-auto h-[calc(100vh-195px)] max-h-[calc(100vh-195px)]"
          }
        >
          <div style={{ width: lineColWidth + totalWidth }} className="relative">
            {todayVisible && (
              <div
                style={{ left: lineColWidth + todayLeft + dayPx / 2 - 1 }}
                className="absolute top-[38px] bottom-0 w-[2px] bg-amber-400/80 z-[25] pointer-events-none"
              />
            )}

            {/* UNIFIED FIXED/STICKY HEADER FOR MONTH & DATE (Never scrolls away) */}
            <div className="sticky top-0 z-30 bg-panel shadow-md border-b-2 border-border/80 select-none">
              {/* Row 1: Month Headers */}
              <div className="flex bg-panel-2 border-b border-border/60">
                <div
                  style={{ width: lineColWidth }}
                  className="shrink-0 sticky left-0 z-40 bg-panel-2 border-r border-border px-1 py-1 text-[11px] font-extrabold text-muted-foreground uppercase tracking-wider text-center"
                >
                  Line
                </div>
                <div className="flex">
                  {monthHeaders.map((m, i) => (
                    <div
                      key={i}
                      style={{ width: m.days * dayPx }}
                      className="shrink-0 border-r border-border/60 px-1 py-1 text-[10.5px] font-bold text-sky-300 text-center overflow-hidden whitespace-nowrap"
                    >
                      {m.days * dayPx >= 35 ? m.label : ""}
                    </div>
                  ))}
                </div>
              </div>

              {/* Row 2: Date Numbers / Grid Ticks */}
              {zoom === "day" ? (
                <div className="flex bg-panel">
                  <div
                    style={{ width: lineColWidth }}
                    className="shrink-0 sticky left-0 z-40 bg-panel border-r border-border px-1 py-0.5 text-[9px] text-muted-foreground text-center font-mono font-bold"
                  >
                    {visibleLines.length}L
                  </div>
                  <div className="flex">
                    {Array.from({ length: range.days }).map((_, i) => {
                      const d = new Date(range.start);
                      d.setDate(d.getDate() + i);
                      const isFri = d.getDay() === 5;
                      const isToday = i === todayOffset;
                      return (
                        <div
                          key={i}
                          style={{ width: dayPx }}
                          className={`shrink-0 border-r border-border/40 text-[9.5px] font-mono text-center py-0.5 ${
                            isToday
                              ? "bg-amber-400 text-black font-extrabold ring-1 ring-amber-500"
                              : isFri
                                ? "bg-red-500/10 text-red-300 font-semibold"
                                : "text-muted-foreground"
                          }`}
                        >
                          {d.getDate()}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="flex bg-panel">
                  <div
                    style={{ width: lineColWidth }}
                    className="shrink-0 sticky left-0 z-40 bg-panel border-r border-border px-1 py-0.5 text-[9px] text-muted-foreground text-center font-mono font-bold"
                  >
                    {visibleLines.length}L
                  </div>
                  <div className="flex">
                    {gridTicks.map((t, i) => (
                      <div
                        key={i}
                        style={{ width: t.span * dayPx }}
                        className={`shrink-0 text-[9.5px] font-mono text-center py-0.5 overflow-hidden whitespace-nowrap border-r ${
                          t.major
                            ? "border-border text-sky-300 font-bold"
                            : "border-border/50 text-muted-foreground"
                        }`}
                      >
                        {t.span * dayPx >= 18 ? t.label : ""}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {visibleLines.map((line, rowIdx) => {
              const rowBars = barsByLine.get(line) ?? [];
              const isDragTarget = drag && drag.moved && drag.targetRowIdx === rowIdx;
              return (
                <div
                  key={line}
                  ref={(el) => {
                    rowRefs.current.set(rowIdx, el);
                  }}
                  className={`flex border-b relative transition-colors ${
                    isDragTarget
                      ? "bg-fuchsia-500/20 ring-2 ring-inset ring-fuchsia-400 border-fuchsia-400 z-10"
                      : "border-border/40 hover:bg-panel-2/20"
                  }`}
                  style={{ height: rowHeight }}
                >
                  <div
                    style={{ width: lineColWidth }}
                    className={`shrink-0 sticky left-0 z-10 border-r flex items-center justify-center px-1 font-bold transition-colors select-none ${
                      rowHeight <= 26 ? "text-xs" : "text-sm"
                    } ${
                      isDragTarget
                        ? "bg-fuchsia-900 text-white border-fuchsia-400 shadow-md"
                        : "bg-panel border-border text-emerald-300"
                    }`}
                    title={line}
                  >
                    <span className="truncate text-center">
                      {formatLineLabel(line, lineColWidth)}
                    </span>
                    {lineConflictGroupMap.has(line) && (
                      <span
                        onClick={(ev) => {
                          ev.stopPropagation();
                          setShowConflictDrawer(true);
                        }}
                        className="ml-1 px-1 py-0.2 rounded bg-rose-600 hover:bg-rose-500 text-white font-mono text-[8.5px] font-black flex items-center gap-0.5 cursor-pointer shadow-xs animate-pulse shrink-0"
                        title={`⚠️ লাইন কনফ্লিক্ট: এই লাইনে ${lineConflictGroupMap.get(line)!.conflicts.length}টি সংঘর্ষ রয়েছে! ক্লিক করে সমাধান প্যানেল দেখুন`}
                      >
                        <span>⚠️</span>
                        {lineColWidth >= 70 && (
                          <span>{lineConflictGroupMap.get(line)!.conflicts.length}</span>
                        )}
                      </span>
                    )}
                    {isDragTarget && lineColWidth >= 70 && (
                      <span className="ml-1 text-[8px] px-1 py-0.2 rounded bg-fuchsia-500 text-white font-mono uppercase tracking-wider animate-pulse">
                        Target
                      </span>
                    )}
                  </div>
                  <div className="relative" style={{ width: totalWidth, height: rowHeight }}>
                    {zoom === "day" &&
                      Array.from({ length: range.days }).map((_, i) => {
                        const d = new Date(range.start);
                        d.setDate(d.getDate() + i);
                        const isFri = d.getDay() === 5;
                        const isToday = i === todayOffset;
                        return (
                          <div
                            key={i}
                            style={{ left: i * dayPx, width: dayPx }}
                            className={`absolute top-0 bottom-0 border-r border-border/20 ${isToday ? "bg-amber-400/15" : isFri ? "bg-red-500/5" : ""}`}
                          />
                        );
                      })}

                    {zoom !== "day" &&
                      gridTicks.map((t, i) => (
                        <div
                          key={i}
                          style={{ left: t.offset * dayPx, width: t.span * dayPx }}
                          className={`absolute top-0 bottom-0 border-r ${
                            t.major ? "border-border/50" : "border-border/25"
                          }`}
                        />
                      ))}

                    {rowBars.map((b, idx) => {
                      const s = new Date(b.start);
                      const e = new Date(b.end);
                      const rawOffset = daysBetween(range.start, s);
                      const spanDays = daysBetween(s, e) + 1;
                      const clippedOffset = Math.max(rawOffset, 0);
                      const clippedSpan = spanDays + Math.min(rawOffset, 0);
                      const c = colorFor(b.style);
                      const width = Math.max(clippedSpan * dayPx - 2, 16);
                      const offset = clippedOffset;
                      const isThisDrag =
                        drag && drag.planId === b.planId && drag.rawLine === b.rawLine;
                      const tx = isThisDrag ? drag!.deltaDays * dayPx : 0;
                      const ty = isThisDrag
                        ? (drag!.targetRowIdx - drag!.origRowIdx) * rowHeight
                        : 0;
                      return (
                        <div key={idx} className="contents">
                          {isThisDrag && drag!.moved && (
                            <div
                              style={{
                                left: Math.max(0, offset * dayPx + tx),
                                top: 4 + ty - 32,
                                zIndex: 60,
                              }}
                              className={`absolute pointer-events-none text-white border px-2.5 py-1 rounded-md shadow-2xl text-[10px] font-bold flex items-center gap-2 whitespace-nowrap transition-colors ${
                                dragCollision
                                  ? "bg-rose-950/95 border-rose-400 ring-2 ring-rose-500/80 animate-pulse"
                                  : "bg-slate-900/95 backdrop-blur border-fuchsia-400 ring-2 ring-fuchsia-500/40"
                              }`}
                            >
                              <span className="text-emerald-400 flex items-center gap-1">
                                <span>📍</span>
                                <span>
                                  {visibleLines[drag!.targetRowIdx]?.replace("Line - ", "Line ") ||
                                    visibleLines[drag!.targetRowIdx]}
                                </span>
                              </span>
                              <span className="text-white/40">|</span>
                              <span className="font-mono text-amber-300 flex items-center gap-1">
                                <span>📅</span>
                                <span>{shiftDateStr(b.start, drag!.deltaDays)}</span>
                              </span>
                              {drag!.deltaDays !== 0 && (
                                <span
                                  className={`text-[9px] px-1 py-0.5 rounded ${
                                    drag!.deltaDays > 0
                                      ? "bg-amber-500/20 text-amber-300"
                                      : "bg-sky-500/20 text-sky-300"
                                  }`}
                                >
                                  {drag!.deltaDays > 0
                                    ? `+${drag!.deltaDays}d`
                                    : `${drag!.deltaDays}d`}
                                </span>
                              )}
                              {dragCollision ? (
                                <span className="text-[9.5px] text-rose-200 bg-rose-600/70 border border-rose-400 px-1.5 py-0.5 rounded font-black flex items-center gap-1">
                                  <span>🚨 সংঘর্ষ:</span>
                                  <span>
                                    {dragCollision.conflictingBar.style} (
                                    {dragCollision.overlapDays}d)
                                  </span>
                                </span>
                              ) : (
                                <span className="text-[9px] text-fuchsia-300 bg-fuchsia-500/20 px-1 py-0.5 rounded font-mono">
                                  {autoSaveOnDrop ? "Drop to Auto-Save" : "Drop to Review"}
                                </span>
                              )}
                            </div>
                          )}
                          {(() => {
                            const bConflicts =
                              barConflictMap.get(`${b.planId}::${b.rawLine}`) ||
                              barConflictMap.get(b.planId) ||
                              [];
                            const hasConflict = bConflicts.length > 0;
                            return (
                              <button
                                type="button"
                                onPointerDown={(ev) => onBarPointerDown(ev, b)}
                                onPointerMove={onBarPointerMove}
                                onPointerUp={(ev) => onBarPointerUp(ev, b)}
                                onPointerCancel={() => setDrag(null)}
                                onClick={(ev) => {
                                  ev.stopPropagation();
                                  if (isBulkSelectMode) {
                                    setBulkSelectedPlanIds((prev) => {
                                      const next = new Set(prev);
                                      if (next.has(b.planId)) {
                                        next.delete(b.planId);
                                      } else {
                                        next.add(b.planId);
                                      }
                                      return next;
                                    });
                                    return;
                                  }
                                  if (!justDraggedRef.current) {
                                    setSelectedBar(b);
                                  }
                                }}
                                onContextMenu={(ev) => {
                                  ev.preventDefault();
                                  ev.stopPropagation();
                                  setContextMenu({ x: ev.clientX, y: ev.clientY, bar: b });
                                }}
                                title={`স্টাইল: ${b.style} · বায়ার: ${b.buyer}\nলাইন: ${b.line} (${b.rawLine})\n${
                                  hasConflict
                                    ? `🚨 লাইন কনফ্লিক্ট সতর্কবার্তা: এই লাইনে একই সময়ে "${bConflicts
                                        .map((c) =>
                                          c.barA.planId === b.planId ? c.barB.style : c.barA.style,
                                        )
                                        .join(
                                          '", ',
                                        )}" নির্ধারিত রয়েছে (${bConflicts[0].overlapStart} → ${bConflicts[0].overlapEnd})!\n`
                                    : ""
                                }কোয়ান্টিটি: ${b.qty.toLocaleString()} pcs\n🎯 Target/Day/Line: ${
                                  b.dailyTarget && b.dailyTarget > 0
                                    ? `${b.dailyTarget.toLocaleString()} pcs/day`
                                    : "নির্ধারিত নেই"
                                }\nঅর্ডার: ${(b.orderQty ?? 0).toLocaleString()} pcs · মোট প্ল্যান: ${(b.plannedQty ?? 0).toLocaleString()} pcs (${b.diffPct !== undefined && b.diffPct >= 0 ? "+" : ""}${(b.diffPct ?? 0).toFixed(1)}%)\n${
                                  b.status === "over"
                                    ? `⚠️ বেশি প্ল্যান করা হয়েছে: +${(b.diffQty ?? 0).toLocaleString()} pcs (+${(b.diffPct ?? 0).toFixed(1)}%)\n`
                                    : b.status === "under"
                                      ? `⚠️ কম প্ল্যান করা হয়েছে: ${(b.diffQty ?? 0).toLocaleString()} pcs (${(b.diffPct ?? 0).toFixed(1)}%)\n`
                                      : "✅ কোয়ান্টিটি ১০০% সঠিক ম্যাচ\n"
                                }সময়: ${formatDate(b.start)} → ${formatDate(b.end)}${
                                  b.fabricEta
                                    ? `\n🧵 ফ্যাব্রিক ETA: ${formatDate(b.fabricEta)}${
                                        b.fabricEta > b.start
                                          ? " ⚠️ (লাইন শুরুর পরে - সুইং ঝুঁকি!)"
                                          : " ✅ (লাইন শুরুর আগে)"
                                      }`
                                    : "\n🧵 ফ্যাব্রিক ETA: নির্ধারিত নেই (ক্লিক করে সেট করুন)"
                                }\n\n💡 ক্লিক: কোয়ান্টিটি ভ্যারিয়েন্স অডিট, ফ্যাব্রিক ETA ও অ্যাকশন\n💡 ড্র্যাগ: শিডিউল পরিবর্তন`}
                                style={{
                                  left: offset * dayPx + 1,
                                  width,
                                  top: barTop,
                                  height: barHeight,
                                  background: c.bg,
                                  borderColor: c.border,
                                  color: c.text,
                                  transform: `translate(${tx}px, ${ty}px)`,
                                  opacity: isThisDrag && drag!.moved ? 0.85 : 1,
                                  zIndex: isThisDrag ? 40 : undefined,
                                  cursor: isThisDrag && drag!.moved ? "grabbing" : "grab",
                                  touchAction: "none",
                                }}
                                className={`group/bar absolute rounded border shadow-sm px-1.5 flex items-center justify-between overflow-hidden font-bold whitespace-nowrap hover:brightness-125 hover:z-20 transition-[filter,opacity] ${
                                  bulkSelectedPlanIds.has(b.planId)
                                    ? "ring-2 ring-purple-400 bg-purple-800/40 shadow-lg shadow-purple-500/50 border-purple-300"
                                    : hasConflict
                                      ? "ring-2 ring-rose-500 shadow-md shadow-rose-500/50 border-rose-400"
                                      : ""
                                } ${
                                  rowHeight <= 22
                                    ? "text-[9px] leading-none"
                                    : rowHeight <= 26
                                      ? "text-[10px] leading-tight"
                                      : rowHeight <= 34
                                        ? "text-[11px]"
                                        : "text-xs"
                                }`}
                              >
                                <span className="truncate flex items-center gap-1 min-w-0 pr-1">
                                  {isBulkSelectMode && (
                                    <span className="shrink-0 mr-0.5">
                                      {bulkSelectedPlanIds.has(b.planId) ? (
                                        <CheckSquare className="w-3 h-3 text-purple-200 fill-purple-600" />
                                      ) : (
                                        <Square className="w-3 h-3 text-white/70" />
                                      )}
                                    </span>
                                  )}
                                  <span className="truncate">
                                    {b.style} · {b.qty.toLocaleString()}
                                  </span>
                                  {hasConflict && (
                                    <span
                                      onClick={(ev) => {
                                        ev.stopPropagation();
                                        setShowConflictDrawer(true);
                                      }}
                                      onPointerDown={(e) => e.stopPropagation()}
                                      className="inline-flex items-center gap-0.5 px-1 py-0.2 rounded font-black text-[9px] shrink-0 border select-none bg-rose-600 text-white border-rose-300 hover:bg-rose-500 transition cursor-pointer shadow-xs animate-pulse"
                                      title={`⚠️ লাইন কনফ্লিক্ট: এই লাইনে ${bConflicts.length}টি সংঘর্ষ রয়েছে! ক্লিক করে অডিট দেখুন`}
                                    >
                                      <AlertTriangle className="w-2.5 h-2.5" />
                                      <span>কনফ্লিক্ট</span>
                                    </span>
                                  )}
                                  {showDailyTarget && b.dailyTarget && b.dailyTarget > 0 && (
                                    <span
                                      className="inline-flex items-center gap-0.5 px-1 py-0.2 rounded font-extrabold text-[9px] shrink-0 border select-none bg-cyan-950/90 text-cyan-200 border-cyan-500/80 shadow-xs"
                                      title={`🎯 Target/Day/Line: ${b.dailyTarget.toLocaleString()} pcs/day`}
                                    >
                                      <span>🎯</span>
                                      <span className="font-mono">
                                        {b.dailyTarget.toLocaleString()}/d
                                      </span>
                                    </span>
                                  )}
                                  {showFabricEta && b.fabricEta && (
                                    <span
                                      className={`inline-flex items-center gap-0.5 px-1 py-0.2 rounded font-extrabold text-[9px] shrink-0 border select-none ${
                                        b.fabricEta > b.start
                                          ? "bg-rose-950/90 text-rose-200 border-rose-500/80 shadow-xs"
                                          : "bg-teal-950/90 text-teal-200 border-teal-400/80 shadow-xs"
                                      }`}
                                      title={
                                        b.fabricEta > b.start
                                          ? `⚠️ সতর্কতা: ফ্যাব্রিক ETA (${formatDate(b.fabricEta)}) লাইন শুরুর (${formatDate(b.start)}) পরে আসবে!`
                                          : `🧵 ফ্যাব্রিক ETA: ${formatDate(b.fabricEta)}`
                                      }
                                    >
                                      <span>🧵</span>
                                      <span className="font-mono">{formatDate(b.fabricEta)}</span>
                                      {b.fabricEta > b.start && (
                                        <span className="animate-pulse">⚠️</span>
                                      )}
                                    </span>
                                  )}
                                  {showVarianceBadges &&
                                    b.diffPct !== undefined &&
                                    Math.abs(b.diffPct) >= 0.1 && (
                                      <span
                                        className={`inline-flex items-center gap-0.5 px-1 py-0.2 rounded font-black text-[9px] shrink-0 border select-none cursor-pointer ${
                                          b.status === "over"
                                            ? "bg-amber-950/95 text-amber-200 border-amber-500/90 shadow-xs"
                                            : "bg-rose-950/95 text-rose-200 border-rose-500/90 shadow-xs"
                                        }`}
                                        title={
                                          b.status === "over"
                                            ? `⚠️ অতিরিক্ত প্ল্যান: +${b.diffPct.toFixed(1)}% (+${b.diffQty?.toLocaleString()} pcs) — ক্লিক করে ফিক্স/রি-প্ল্যান করুন`
                                            : `⚠️ কম প্ল্যান: ${b.diffPct.toFixed(1)}% (${b.diffQty?.toLocaleString()} pcs ঘাটতি) — ক্লিক করে ফিক্স/রি-প্ল্যান করুন`
                                        }
                                        onClick={(ev) => {
                                          ev.stopPropagation();
                                          setShowVarianceModal(true);
                                        }}
                                      >
                                        <span>
                                          {b.status === "over" ? "🔺+" : "🔻"}
                                          {Math.abs(b.diffPct).toFixed(0)}%
                                        </span>
                                      </span>
                                    )}
                                  {b.status === "under" && width >= 80 && (
                                    <span
                                      onClick={(ev) => {
                                        ev.stopPropagation();
                                        const p = plans.find((x) => x.id === b.planId);
                                        setSplitModalTarget({
                                          planId: b.planId,
                                          style: b.style,
                                          buyer: b.buyer,
                                          season: p?.season ?? null,
                                          orderQty: b.orderQty ?? p?.order_qty ?? b.qty,
                                          plannedQty: b.plannedQty ?? b.qty,
                                          lineQty: b.qty,
                                          currentLine: b.line,
                                          dailyTarget: b.dailyTarget ?? p?.daily_target ?? 500,
                                          shipmentDate: p?.shipment_date ?? "",
                                        });
                                      }}
                                      onPointerDown={(e) => e.stopPropagation()}
                                      className="inline-flex items-center gap-0.5 px-1 py-0.2 rounded font-extrabold text-[9px] shrink-0 border select-none bg-purple-950/95 text-purple-200 border-purple-500/80 hover:bg-purple-600 hover:text-white transition cursor-pointer shadow-xs"
                                      title={`Split Order: ${Math.abs(b.diffQty ?? 0).toLocaleString()} pcs বাকি আছে — ক্লিক করে নতুন লাইনে স্প্লিট করুন`}
                                    >
                                      <Scissors className="w-2.5 h-2.5" />
                                      <span>Split</span>
                                    </span>
                                  )}
                                </span>
                                {/* Split Order Button on Bar Hover */}
                                {rowHeight >= 22 && (
                                  <span
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const p = plans.find((x) => x.id === b.planId);
                                      setSplitModalTarget({
                                        planId: b.planId,
                                        style: b.style,
                                        buyer: b.buyer,
                                        season: p?.season ?? null,
                                        orderQty: b.orderQty ?? p?.order_qty ?? b.qty,
                                        plannedQty: b.plannedQty ?? b.qty,
                                        lineQty: b.qty,
                                        currentLine: b.line,
                                        dailyTarget: b.dailyTarget ?? p?.daily_target ?? 500,
                                        shipmentDate: p?.shipment_date ?? "",
                                      });
                                    }}
                                    onPointerDown={(e) => e.stopPropagation()}
                                    className="hidden group-hover/bar:inline-flex items-center gap-1 ml-1 px-1.5 py-0.5 rounded bg-purple-950/95 hover:bg-purple-600 text-purple-100 hover:text-white border border-purple-400/60 shadow-xs text-[9.5px] font-black cursor-pointer transition shrink-0 z-30"
                                    title="Split Order: এই স্টাইলটি স্প্লিট করে বাকি কোয়ান্টিটি নতুন লাইনে শিডিউল করুন"
                                  >
                                    <Scissors className="w-2.5 h-2.5 text-purple-200" />
                                    <span className="hidden sm:inline">Split Order</span>
                                  </span>
                                )}
                                {rowHeight >= 26 && (
                                  <span
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setUnplanModalTarget({
                                        planId: b.planId,
                                        style: b.style,
                                        buyer: b.buyer,
                                      });
                                    }}
                                    onPointerDown={(e) => e.stopPropagation()}
                                    className="hidden group-hover/bar:inline-flex items-center ml-1 p-0.5 rounded bg-black/40 hover:bg-amber-600/90 text-amber-200 hover:text-white transition shrink-0"
                                    title="আনপ্ল্যান্ড পুলে পাঠান"
                                  >
                                    <RotateCcw className="w-2.5 h-2.5" />
                                  </span>
                                )}
                              </button>
                            );
                          })()}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Selected Bar Details & Action Dialog */}
      {selectedBar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-border bg-panel shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-border bg-panel-2/60 flex items-center justify-between">
              <div>
                <h3 className="text-base font-extrabold text-foreground flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: colorFor(selectedBar.style).border }}
                  />
                  {selectedBar.style}
                </h3>
                <p className="text-xs text-muted-foreground">
                  বায়ার: <b className="text-foreground">{selectedBar.buyer}</b>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedBar(null)}
                className="p-1 rounded-lg hover:bg-panel-2 text-muted-foreground hover:text-foreground cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-panel-2/40 p-3 rounded-xl border border-border/60">
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold">
                    লাইন
                  </span>
                  <span className="font-bold text-foreground text-sm flex items-center gap-1 mt-0.5">
                    🏭 {selectedBar.line}
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold">
                    কোয়ান্টিটি
                  </span>
                  <span className="font-bold text-emerald-400 font-mono text-sm mt-0.5 block">
                    {selectedBar.qty.toLocaleString()} pcs
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold">
                    সময়সীমা
                  </span>
                  <span className="font-bold text-foreground mt-0.5 block">
                    {formatDate(selectedBar.start)} → {formatDate(selectedBar.end)}
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold">
                    Target/Day/Line
                  </span>
                  <span className="font-bold text-cyan-300 font-mono text-sm mt-0.5 flex items-center gap-1">
                    🎯{" "}
                    {selectedBar.dailyTarget && selectedBar.dailyTarget > 0
                      ? `${selectedBar.dailyTarget.toLocaleString()} pcs/day`
                      : "নির্ধারিত নেই"}
                  </span>
                </div>
                <div className="col-span-2">
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold">
                    ফ্যাব্রিক ETA
                  </span>
                  <span className="font-bold text-teal-300 mt-0.5 flex items-center gap-1.5 flex-wrap">
                    {selectedBar.fabricEta ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-teal-500/20 text-teal-200 border border-teal-500/40 text-xs font-mono font-bold">
                        🧵 {formatDate(selectedBar.fabricEta)}
                        {selectedBar.fabricEta > selectedBar.start && (
                          <span
                            className="text-rose-300 font-extrabold"
                            title="সুইং শুরুর পরে ফ্যাব্রিক আসবে!"
                          >
                            ⚠️
                          </span>
                        )}
                      </span>
                    ) : (
                      <span className="text-muted-foreground italic text-xs">নির্ধারিত নেই</span>
                    )}
                  </span>
                </div>
              </div>

              {/* Line Assignment Conflict Warning Card */}
              {(() => {
                const sConflicts =
                  barConflictMap.get(`${selectedBar.planId}::${selectedBar.rawLine}`) ||
                  barConflictMap.get(selectedBar.planId) ||
                  [];
                if (sConflicts.length === 0) return null;
                return (
                  <div className="p-3.5 rounded-xl border border-rose-500/80 bg-rose-950/30 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 font-black text-xs text-rose-300">
                        <AlertTriangle className="w-4 h-4 text-rose-400 animate-pulse" />
                        <span>🚨 লাইন অ্যাসাইনমেন্ট কনফ্লিক্ট শনাক্ত হয়েছে!</span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-600 text-white font-bold font-mono">
                        {sConflicts.length}টি সংঘর্ষ
                      </span>
                    </div>
                    <p className="text-[11px] text-muted-foreground leading-snug">
                      এই লাইন ({selectedBar.line})-এ একই সাথে অন্য স্টাইলের শিডিউল বিদ্যমান রয়েছে।
                    </p>
                    <div className="space-y-1.5 pt-0.5">
                      {sConflicts.map((sc, i) => {
                        const other = sc.barA.planId === selectedBar.planId ? sc.barB : sc.barA;
                        return (
                          <div
                            key={i}
                            className="p-2.5 rounded-lg bg-panel border border-rose-500/30 flex items-center justify-between gap-2 text-xs"
                          >
                            <div>
                              <span className="font-extrabold text-foreground block">
                                {other.style} ({other.buyer})
                              </span>
                              <span className="text-[11px] text-muted-foreground block">
                                ওভারল্যাপ:{" "}
                                <b className="text-amber-300 font-mono">
                                  {sc.overlapStart} → {sc.overlapEnd}
                                </b>{" "}
                                ({sc.overlapDays} দিন)
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                setShowConflictDrawer(true);
                                setSelectedBar(null);
                              }}
                              className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-[10.5px] font-bold cursor-pointer shrink-0 transition"
                            >
                              সমাধান করুন
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}

              {/* Style Plan Quantity Variance Audit Card */}
              <div
                className={`p-3.5 rounded-xl border space-y-2.5 ${
                  selectedBar.status === "over"
                    ? "bg-amber-950/25 border-amber-500/50"
                    : selectedBar.status === "under"
                      ? "bg-rose-950/25 border-rose-500/50"
                      : "bg-emerald-950/20 border-emerald-500/40"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-black text-xs">
                    <Scale className="w-4 h-4 text-purple-300" />
                    <span className="text-foreground">প্ল্যান কোয়ান্টিটি ভ্যারিয়েন্স:</span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-md text-[11px] font-black border ${
                      selectedBar.status === "over"
                        ? "bg-amber-500/20 text-amber-300 border-amber-500/50"
                        : selectedBar.status === "under"
                          ? "bg-rose-500/20 text-rose-300 border-rose-500/50"
                          : "bg-emerald-500/20 text-emerald-300 border-emerald-500/50"
                    }`}
                  >
                    {selectedBar.status === "over"
                      ? `🔺 +${(selectedBar.diffPct ?? 0).toFixed(1)}% বেশি প্ল্যান`
                      : selectedBar.status === "under"
                        ? `🔻 ${(selectedBar.diffPct ?? 0).toFixed(1)}% কম প্ল্যান`
                        : "✅ ১০০% সঠিক (Exact Match)"}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="bg-panel/70 p-2 rounded-lg border border-border">
                    <span className="text-[10px] text-muted-foreground block font-bold">
                      অর্ডার কোয়ান্টিটি
                    </span>
                    <span className="font-mono font-black text-foreground">
                      {(selectedBar.orderQty ?? 0).toLocaleString()} pcs
                    </span>
                  </div>
                  <div className="bg-panel/70 p-2 rounded-lg border border-border">
                    <span className="text-[10px] text-muted-foreground block font-bold">
                      মোট প্ল্যান
                    </span>
                    <span className="font-mono font-black text-foreground">
                      {(selectedBar.plannedQty ?? 0).toLocaleString()} pcs
                    </span>
                  </div>
                  <div className="bg-panel/70 p-2 rounded-lg border border-border">
                    <span className="text-[10px] text-muted-foreground block font-bold">
                      পার্থক্য (+/-)
                    </span>
                    <span
                      className={`font-mono font-black ${
                        selectedBar.status === "over"
                          ? "text-amber-400"
                          : selectedBar.status === "under"
                            ? "text-rose-400"
                            : "text-emerald-400"
                      }`}
                    >
                      {selectedBar.diffQty !== undefined && selectedBar.diffQty > 0 ? "+" : ""}
                      {(selectedBar.diffQty ?? 0).toLocaleString()} pcs
                    </span>
                  </div>
                </div>

                {selectedBar.status !== "exact" && (
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-border/40">
                    <p className="text-[11px] text-muted-foreground flex-1">
                      {selectedBar.status === "over"
                        ? "অর্ডারের চেয়ে বেশি প্ল্যান করা হয়েছে। আপনি এক ক্লিকে ১০০% অর্ডারের সাথে অটো-ম্যাচ করতে পারেন অথবা রিপ্ল্যান করতে পারেন।"
                        : "অর্ডারের চেয়ে কম প্ল্যান করা হয়েছে। প্ল্যান ১০০% সম্পন্ন করতে অটো-ম্যাচ বা রিপ্ল্যান করুন।"}
                    </p>
                    <button
                      type="button"
                      disabled={fixingPlanId === selectedBar.planId}
                      onClick={async () => {
                        await handleAutoFixPlan(selectedBar.planId);
                        setSelectedBar(null);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center gap-1.5 shadow-sm transition disabled:opacity-50 cursor-pointer shrink-0"
                      title="লাইন কোয়ান্টিটি আনুপাতিক হারে অ্যাডজাস্ট করে ১০০% অর্ডারের সমান করুন"
                    >
                      {fixingPlanId === selectedBar.planId ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Zap className="w-3.5 h-3.5 text-amber-300" />
                      )}
                      <span>অটো-ম্যাচ (Fix)</span>
                    </button>
                    {selectedBar.status === "under" && (
                      <button
                        type="button"
                        onClick={() => {
                          const p = plans.find((x) => x.id === selectedBar.planId);
                          setSplitModalTarget({
                            planId: selectedBar.planId,
                            style: selectedBar.style,
                            buyer: selectedBar.buyer,
                            season: p?.season ?? null,
                            orderQty: selectedBar.orderQty ?? p?.order_qty ?? selectedBar.qty,
                            plannedQty: selectedBar.plannedQty ?? selectedBar.qty,
                            lineQty: selectedBar.qty,
                            currentLine: selectedBar.line,
                            dailyTarget: selectedBar.dailyTarget ?? p?.daily_target ?? 500,
                            shipmentDate: p?.shipment_date ?? "",
                          });
                          setSelectedBar(null);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs flex items-center gap-1.5 shadow-sm transition cursor-pointer shrink-0"
                        title="ঘাটতি কোয়ান্টিটি আলাদা করে নতুন আনপ্ল্যান্ড অর্ডার হিসেবে বা অন্য লাইনে শিডিউল করুন"
                      >
                        <Scissors className="w-3.5 h-3.5 text-white" />
                        <span>
                          Split Order (বাকি {Math.abs(selectedBar.diffQty ?? 0).toLocaleString()}{" "}
                          pcs)
                        </span>
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* Quick Fabric ETA Update & Management */}
              <div className="p-3.5 rounded-xl border border-teal-500/40 bg-teal-950/25 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-base">🧵</span>
                    <label className="text-xs font-extrabold text-teal-200">
                      ফ্যাব্রিক ETA যোগ / পরিবর্তন করুন:
                    </label>
                  </div>
                  {selectedBar.fabricEta && (
                    <span className="text-[10px] text-teal-400 font-mono">
                      বর্তমান: {formatDate(selectedBar.fabricEta)}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="date"
                    value={editingEta}
                    onChange={(e) => setEditingEta(e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded-lg border border-border bg-input text-foreground text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-teal-500 cursor-pointer"
                  />
                  <button
                    type="button"
                    disabled={savingEta}
                    onClick={() => handleSaveQuickEta(selectedBar.planId, editingEta)}
                    className="px-3.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50 transition shrink-0"
                  >
                    {savingEta ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Save className="w-3.5 h-3.5" />
                    )}
                    <span>সেভ ETA</span>
                  </button>
                  {editingEta && (
                    <button
                      type="button"
                      disabled={savingEta}
                      onClick={() => setEditingEta("")}
                      className="px-2 py-1.5 rounded-lg border border-border hover:bg-panel-2 text-[10px] text-muted-foreground hover:text-foreground cursor-pointer shrink-0"
                      title="ইনপুট ক্লিয়ার করুন"
                    >
                      ক্লিয়ার
                    </button>
                  )}
                </div>

                {/* Date comparison safety check */}
                {editingEta ? (
                  editingEta > selectedBar.start ? (
                    <div className="p-2 rounded-lg bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-1.5 font-bold animate-pulse">
                      <span>⚠️</span>
                      <span>
                        সতর্কতা: ফ্যাব্রিক লাইন শুরুর তারিখের ({formatDate(selectedBar.start)}) পরে
                        পৌঁছাবে! সুইং বিলম্বের ঝুঁকি রয়েছে।
                      </span>
                    </div>
                  ) : (
                    <div className="p-2 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-1.5 font-bold">
                      <span>✅</span>
                      <span>
                        লাইন শুরুর তারিখের ({formatDate(selectedBar.start)}) আগেই ফ্যাব্রিক প্রস্তুত
                        থাকবে।
                      </span>
                    </div>
                  )
                ) : (
                  <div className="text-[11px] text-muted-foreground flex items-center gap-1">
                    <span>💡</span>
                    <span>
                      তারিখ বেছে "সেভ ETA" বাটনে চাপলে প্ল্যান বোর্ডে সাথে সাথে ফ্যাব্রিক আসার তারিখ
                      সেট হয়ে যাবে।
                    </span>
                  </div>
                )}
              </div>

              <p className="text-[11px] text-muted-foreground">
                আপনি এই অর্ডারটি প্ল্যান ইনপুটে এডিট করতে পারেন অথবা বোর্ড থেকে সরিয়ে আনপ্ল্যান্ড
                পুলে ফেরত পাঠাতে পারেন।
              </p>
            </div>

            <div className="p-4 border-t border-border bg-panel-2/40 flex flex-wrap items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedBar(null)}
                className="px-3 py-2 rounded-xl border border-border hover:bg-panel-2 text-xs font-bold text-muted-foreground cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={() => {
                  setUnplanModalTarget({
                    planId: selectedBar.planId,
                    style: selectedBar.style,
                    buyer: selectedBar.buyer,
                  });
                  setSelectedBar(null);
                }}
                className="px-4 py-2 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/40 text-amber-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                📦 আনপ্ল্যান্ড করুন
              </button>
              <button
                type="button"
                onClick={() => {
                  setSelectedBar(null);
                  setShowVarianceModal(true);
                }}
                className="px-3.5 py-2 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition"
                title="সকল স্টাইলের ভ্যারিয়েন্স অডিট তালিকা দেখুন"
              >
                <Scale className="w-3.5 h-3.5" />
                ⚖️ ভ্যারিয়েন্স অডিট
              </button>
              <button
                type="button"
                onClick={() => {
                  const p = plans.find((x) => x.id === selectedBar.planId);
                  setSplitModalTarget({
                    planId: selectedBar.planId,
                    style: selectedBar.style,
                    buyer: selectedBar.buyer,
                    season: p?.season ?? null,
                    orderQty: selectedBar.orderQty ?? p?.order_qty ?? selectedBar.qty,
                    plannedQty: selectedBar.plannedQty ?? selectedBar.qty,
                    lineQty: selectedBar.qty,
                    currentLine: selectedBar.line,
                    dailyTarget: selectedBar.dailyTarget ?? p?.daily_target ?? 500,
                    shipmentDate: p?.shipment_date ?? "",
                  });
                  setSelectedBar(null);
                }}
                className="px-3.5 py-2 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 font-extrabold text-xs flex items-center gap-1.5 cursor-pointer transition shadow-xs"
                title="এই স্টাইলটি স্প্লিট করে বাকি কোয়ান্টিটি অন্য লাইনে বা আনপ্ল্যান্ড পুলে পাঠান"
              >
                <Scissors className="w-3.5 h-3.5 text-purple-400" />
                <span>✂️ Split Order (স্টাইল স্প্লিট ও বাকি প্ল্যান)</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  editPlan(selectedBar.planId);
                  setSelectedBar(null);
                }}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:opacity-90 text-white font-extrabold text-xs shadow-md flex items-center gap-1.5 cursor-pointer"
              >
                <Pencil className="w-3.5 h-3.5" />
                ✏️ প্ল্যান এডিট / রি-প্ল্যান
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Unplan Confirmation Modal */}
      {unplanModalTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-amber-500/50 bg-panel shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-border bg-panel-2/60">
              <h3 className="text-base font-black text-amber-400 flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-amber-400" />
                অর্ডারটি কি আনপ্ল্যান্ড পুলে পাঠাতে চান?
              </h3>
            </div>

            <div className="p-5 text-xs text-muted-foreground space-y-3">
              <p>
                স্টাইল: <b className="text-foreground">{unplanModalTarget.style}</b> (বায়ার:{" "}
                <b className="text-foreground">{unplanModalTarget.buyer}</b>)
              </p>
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 space-y-1 text-[11px]">
                <p className="font-bold flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  এর ফলে কী ঘটবে:
                </p>
                <ul className="list-disc list-inside space-y-0.5 text-amber-200/90 ml-1">
                  <li>এই স্টাইলটি বর্তমান লাইন শিডিউল থেকে মুছে যাবে।</li>
                  <li>লাইনের ওই দিনগুলোতে অন্য স্টাইল শিডিউল করার স্লট খালি হবে।</li>
                  <li>অর্ডারের সমস্ত ডেটা "আনপ্ল্যান্ড পুল"-এ সংরক্ষিত থাকবে।</li>
                  <li>পরবর্তীতে যেকোনো সময় আপনি এটি পুনরায় লাইনে প্ল্যান করতে পারবেন।</li>
                </ul>
              </div>
            </div>

            <div className="p-4 border-t border-border bg-panel-2/40 flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={!!unplanningId}
                onClick={() => setUnplanModalTarget(null)}
                className="px-4 py-2 rounded-xl border border-border hover:bg-panel-2 text-xs font-bold text-muted-foreground cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={!!unplanningId}
                onClick={() => handleUnplanOrder(unplanModalTarget.planId)}
                className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-black text-xs shadow-md transition disabled:opacity-50 cursor-pointer flex items-center gap-2"
              >
                {unplanningId ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    আনপ্ল্যান্ড হচ্ছে...
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-3.5 h-3.5" />
                    হ্যাঁ, আনপ্ল্যান্ড করুন
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Unplanned Orders Drawer / Slide-Over Modal */}
      {showUnplannedDrawer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-4xl max-h-[90vh] rounded-2xl border border-border bg-panel shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="p-4 md:p-5 border-b border-border bg-panel-2/60 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <PackageOpen className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-base md:text-lg font-black text-foreground">
                    আনপ্ল্যান্ড অর্ডার ও ব্যাকলগ ম্যানেজমেন্ট
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    অর্ডার লাইন শিডিউল করুন অথবা যেকোনো শিডিউল্ড অর্ডারকে আনপ্ল্যান্ড পুলে পাঠান
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 p-1 rounded-xl bg-input border border-border text-xs">
                  <button
                    type="button"
                    onClick={() => setUnplannedTab("unplanned")}
                    className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                      unplannedTab === "unplanned"
                        ? "bg-amber-600 text-white shadow-sm"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    📦 আনপ্ল্যান্ড পুল ({unplannedCount})
                  </button>
                  <button
                    type="button"
                    onClick={() => setUnplannedTab("scheduled")}
                    className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                      unplannedTab === "scheduled"
                        ? "bg-emerald-600 text-white shadow-sm"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    🏭 শিডিউল্ড অর্ডার ({plans.length - unplannedCount})
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setShowUnplannedDrawer(false)}
                  className="p-1.5 rounded-lg hover:bg-panel-2 text-muted-foreground hover:text-foreground cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Filter toolbar inside drawer */}
            <div className="p-3 border-b border-border bg-panel flex items-center justify-between gap-3">
              <div className="relative flex-1 max-w-sm">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={unplannedSearch}
                  onChange={(e) => setUnplannedSearch(e.target.value)}
                  placeholder="স্টাইল বা বায়ার খুঁজুন..."
                  className="w-full bg-input border border-border rounded-xl pl-8 pr-3 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none"
                />
              </div>

              <div className="text-xs text-muted-foreground">
                {unplannedTab === "unplanned"
                  ? `${unplannedOrders.length} টি অর্ডার লাইনে বরাদ্দের অপেক্ষায়`
                  : `${plans.length - unplannedCount} টি অর্ডার বর্তমানে লাইনে চলছে`}
              </div>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
              {unplannedTab === "unplanned" ? (
                unplannedOrders.length === 0 ? (
                  <div className="py-16 text-center text-muted-foreground space-y-2">
                    <PackageOpen className="w-10 h-10 mx-auto text-muted-foreground/30" />
                    <p className="text-sm font-bold text-foreground">
                      আনপ্ল্যান্ড পুলে কোনো অর্ডার নেই!
                    </p>
                    <p className="text-xs">সবগুলো অর্ডার লাইনে প্ল্যান করা আছে।</p>
                  </div>
                ) : (
                  unplannedOrders
                    .filter((p) => {
                      if (!unplannedSearch) return true;
                      const q = unplannedSearch.toLowerCase();
                      return p.style.toLowerCase().includes(q) || p.buyer.toLowerCase().includes(q);
                    })
                    .map((p) => (
                      <div
                        key={p.id}
                        className="p-3.5 rounded-xl border border-border bg-panel-2/50 hover:bg-panel-2 transition flex items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-foreground text-sm">
                              {p.buyer}
                            </span>
                            <span className="font-bold text-foreground/80 text-xs">
                              ({p.style})
                            </span>
                            {p.season && (
                              <span className="text-[10px] text-purple-300 bg-purple-500/10 border border-purple-500/20 px-1.5 py-0.5 rounded">
                                {p.season}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <span>
                              কোয়ান্টিটি:{" "}
                              <b className="text-emerald-400 font-mono">
                                {p.order_qty.toLocaleString()} pcs
                              </b>
                            </span>
                            <span>
                              দৈনিক টার্গেট:{" "}
                              <b className="text-yellow-300 font-mono">
                                {p.daily_target ? `${p.daily_target}/দিন` : "সেট নেই"}
                              </b>
                            </span>
                            <span>
                              শিপমেন্ট: <b className="text-foreground">{p.shipment_date}</b>
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              editPlan(p.id);
                              setShowUnplannedDrawer(false);
                            }}
                            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-90 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                          >
                            <Zap className="w-3.5 h-3.5" />
                            লাইনে প্ল্যান করুন
                          </button>
                        </div>
                      </div>
                    ))
                )
              ) : (
                plans
                  .filter((p) => {
                    const isUnplanned =
                      (p.config as any)?.status === "unplanned" ||
                      (p.config as any)?.isUnplanned === true ||
                      p.num_lines === 0;
                    if (isUnplanned) return false;
                    if (!unplannedSearch) return true;
                    const q = unplannedSearch.toLowerCase();
                    return p.style.toLowerCase().includes(q) || p.buyer.toLowerCase().includes(q);
                  })
                  .map((p) => {
                    const lines = (p.config as any)?.lines ?? [];
                    return (
                      <div
                        key={p.id}
                        className="p-3.5 rounded-xl border border-border bg-panel-2/50 hover:bg-panel-2 transition flex items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-foreground text-sm">
                              {p.buyer}
                            </span>
                            <span className="font-bold text-foreground/80 text-xs">
                              ({p.style})
                            </span>
                            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded font-bold">
                              ✓ {p.num_lines} লাইনে চলছে
                            </span>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                            <span>
                              কোয়ান্টিটি:{" "}
                              <b className="text-emerald-400 font-mono">
                                {p.order_qty.toLocaleString()} pcs
                              </b>
                            </span>
                            <span>
                              লাইন:{" "}
                              <b className="text-foreground">
                                {lines.map((l: any) => l.name).join(", ")}
                              </b>
                            </span>
                            <span>
                              শিপমেন্ট: <b className="text-foreground">{p.shipment_date}</b>
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              setUnplanModalTarget({
                                planId: p.id,
                                style: p.style,
                                buyer: p.buyer,
                              });
                              setShowUnplannedDrawer(false);
                            }}
                            className="px-3 py-1.5 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/40 text-amber-300 font-extrabold text-xs flex items-center gap-1.5 cursor-pointer transition"
                            title="বোর্ড থেকে সরিয়ে আনপ্ল্যান্ড পুলে পাঠান"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            আনপ্ল্যান্ড করুন
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              editPlan(p.id);
                              setShowUnplannedDrawer(false);
                            }}
                            className="p-1.5 rounded-lg border border-border bg-input hover:bg-panel-2 text-foreground cursor-pointer"
                            title="প্ল্যান এডিট করুন"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
              )}
            </div>
          </div>
        </div>
      )}

      {/* Context Menu on Right Click */}
      {contextMenu && (
        <div
          style={{ left: contextMenu.x, top: contextMenu.y }}
          className="fixed z-50 min-w-[180px] rounded-xl border border-border bg-panel shadow-2xl p-1 text-xs space-y-0.5 animate-in fade-in zoom-in-95 duration-100"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="px-2.5 py-1 text-[10px] font-bold text-muted-foreground border-b border-border mb-1">
            <span className="font-extrabold text-foreground block">{contextMenu.bar.style}</span>
            <span className="text-[10px] text-muted-foreground block">
              {contextMenu.bar.buyer} · {contextMenu.bar.qty.toLocaleString()} pcs
            </span>
            {contextMenu.bar.dailyTarget && contextMenu.bar.dailyTarget > 0 ? (
              <span className="text-[10px] text-cyan-300 font-mono block">
                🎯 Target: {contextMenu.bar.dailyTarget.toLocaleString()} pcs/day
              </span>
            ) : null}
            {contextMenu.bar.status !== "exact" && (
              <span
                className={`inline-block mt-0.5 px-1.5 py-0.2 rounded text-[10px] font-black ${
                  contextMenu.bar.status === "over"
                    ? "bg-amber-500/20 text-amber-300"
                    : "bg-rose-500/20 text-rose-300"
                }`}
              >
                {contextMenu.bar.status === "over" ? "🔺 +" : "🔻 "}
                {(contextMenu.bar.diffPct ?? 0).toFixed(1)}% ভ্যারিয়েন্স
              </span>
            )}
          </div>
          {contextMenu.bar.status !== "exact" && (
            <button
              type="button"
              onClick={() => {
                handleAutoFixPlan(contextMenu.bar.planId);
                setContextMenu(null);
              }}
              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-emerald-600/20 text-emerald-300 font-bold flex items-center gap-2 cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-amber-300" />
              অটো-ম্যাচ (১০০% ফিক্স)
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              setShowVarianceModal(true);
              setContextMenu(null);
            }}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-purple-600/20 text-purple-300 font-bold flex items-center gap-2 cursor-pointer"
          >
            <Scale className="w-3.5 h-3.5 text-purple-400" />
            ভ্যারিয়েন্স অডিট (+/- %)
          </button>
          <button
            type="button"
            onClick={() => {
              setSelectedBar(contextMenu.bar);
              setContextMenu(null);
            }}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-teal-600/20 text-teal-300 font-bold flex items-center gap-2 cursor-pointer"
          >
            <span className="text-sm">🧵</span>
            ফ্যাব্রিক ETA পরিবর্তন / যোগ করুন
          </button>
          <button
            type="button"
            onClick={() => {
              editPlan(contextMenu.bar.planId);
              setContextMenu(null);
            }}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-panel-2 text-foreground font-bold flex items-center gap-2 cursor-pointer"
          >
            <Pencil className="w-3.5 h-3.5 text-blue-400" />
            প্ল্যান এডিট / রি-প্ল্যান
          </button>
          <button
            type="button"
            onClick={() => {
              const b = contextMenu.bar;
              const p = plans.find((x) => x.id === b.planId);
              setSplitModalTarget({
                planId: b.planId,
                style: b.style,
                buyer: b.buyer,
                season: p?.season ?? null,
                orderQty: b.orderQty ?? p?.order_qty ?? b.qty,
                plannedQty: b.plannedQty ?? b.qty,
                lineQty: b.qty,
                currentLine: b.line,
                dailyTarget: b.dailyTarget ?? p?.daily_target ?? 500,
                shipmentDate: p?.shipment_date ?? "",
              });
              setContextMenu(null);
            }}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-purple-600/20 text-purple-300 font-bold flex items-center gap-2 cursor-pointer"
          >
            <Scissors className="w-3.5 h-3.5 text-purple-400" />
            Split Order (স্টাইল স্প্লিট ও নতুন লাইন এন্ট্রি)
          </button>
          <button
            type="button"
            onClick={() => {
              setUnplanModalTarget({
                planId: contextMenu.bar.planId,
                style: contextMenu.bar.style,
                buyer: contextMenu.bar.buyer,
              });
              setContextMenu(null);
            }}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-amber-600/20 text-amber-300 font-bold flex items-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            আনপ্ল্যান্ড পুলে পাঠান
          </button>
        </div>
      )}

      {confirm && (
        <ConfirmDialog
          state={confirm}
          applying={applying}
          onCancel={() => setConfirm(null)}
          onApply={applyConfirm}
        />
      )}

      {/* Style Plan Variance Audit Modal */}
      <StylePlanVarianceModal
        open={showVarianceModal}
        onClose={() => setShowVarianceModal(false)}
        variances={styleVariances}
        onEditPlan={(planId) => {
          editPlan(planId);
        }}
        onAutoFixPlan={handleAutoFixPlan}
        onUnplan={(planId, style, buyer) => {
          setUnplanModalTarget({ planId, style, buyer });
          setShowVarianceModal(false);
        }}
        onDeletePlan={handleDeletePlan}
        onSplitPlan={(planId, style, buyer, orderQty, plannedQty, currentLine) => {
          const p = plans.find((x) => x.id === planId);
          const normCurrent = currentLine
            ? currentLine.toLowerCase().replace(/[^a-z0-9]/g, "")
            : "";
          const matchedLine = normCurrent
            ? p?.calc_result?.lines?.find(
                (l: any) => (l.name || "").toLowerCase().replace(/[^a-z0-9]/g, "") === normCurrent,
              )
            : null;
          const lineAlloc = matchedLine
            ? Number(matchedLine.plannedQty) || Number(matchedLine.allocatedOrderQty)
            : undefined;

          setSplitModalTarget({
            planId,
            style,
            buyer,
            season: p?.season ?? null,
            orderQty,
            plannedQty,
            lineQty: lineAlloc,
            currentLine,
            dailyTarget: p?.daily_target ?? 500,
            shipmentDate: p?.shipment_date ?? "",
          });
          setShowVarianceModal(false);
        }}
        fixingPlanId={fixingPlanId}
      />

      {/* Split Style Plan Modal */}
      {splitModalTarget && (
        <SplitStylePlanModal
          open={!!splitModalTarget}
          onClose={() => setSplitModalTarget(null)}
          planId={splitModalTarget.planId}
          styleName={splitModalTarget.style}
          buyerName={splitModalTarget.buyer}
          season={splitModalTarget.season}
          orderQty={splitModalTarget.orderQty}
          plannedQty={splitModalTarget.plannedQty}
          lineQty={splitModalTarget.lineQty}
          currentLine={splitModalTarget.currentLine}
          dailyTarget={splitModalTarget.dailyTarget}
          shipmentDate={splitModalTarget.shipmentDate}
          linePresets={linePresets}
          globalHolidays={globalHolidays}
          onSuccess={() => {
            qc.invalidateQueries({ queryKey: ["plans"] });
          }}
          onOpenPlanInput={(id) => {
            editPlan(id);
          }}
        />
      )}

      {/* Line Conflict Warning Drawer */}
      <LineConflictDrawer
        open={showConflictDrawer}
        onClose={() => setShowConflictDrawer(false)}
        conflicts={conflicts}
        onOpenSplitModal={(target) => {
          setSplitModalTarget(target);
        }}
        onEditPlan={(id) => {
          editPlan(id);
        }}
        onUnplan={(planId, style, buyer) => {
          setUnplanModalTarget({ planId, style, buyer });
        }}
        onFocusLine={(targetLine) => {
          const rowIdx = visibleLines.indexOf(targetLine);
          if (rowIdx >= 0) {
            const el = rowRefs.current.get(rowIdx);
            el?.scrollIntoView({ behavior: "smooth", block: "center" });
          }
        }}
      />

      {/* Bulk Style Line Assignment Modal */}
      {showBulkModal && (
        <BulkStyleAssignmentModal
          open={showBulkModal}
          onClose={() => setShowBulkModal(false)}
          plans={plans as any}
          initialSelectedPlanIds={Array.from(bulkSelectedPlanIds)}
          linePresets={linePresets}
          globalHolidays={globalHolidays}
          onSuccess={() => {
            qc.invalidateQueries({ queryKey: ["plans"] });
            setBulkSelectedPlanIds(new Set());
            setIsBulkSelectMode(false);
          }}
        />
      )}

      {/* Floating Bottom Dock for Bulk Selection on Plan Board */}
      {bulkSelectedPlanIds.size > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-panel/95 backdrop-blur-md border border-purple-500/60 shadow-2xl rounded-2xl px-4 py-3 flex items-center gap-3 animate-in slide-in-from-bottom-4 duration-200">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-purple-500/20 text-purple-300">
              <Layers className="w-4 h-4" />
            </span>
            <span className="font-extrabold text-xs text-foreground">
              <b className="text-purple-300 font-mono text-sm">{bulkSelectedPlanIds.size}</b>টি
              স্টাইল নির্বাচিত
            </span>
          </div>

          <div className="h-4 w-px bg-border" />

          <button
            type="button"
            onClick={() => setShowBulkModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
            <span>টার্গেট লাইনে স্থানান্তর করুন (Bulk Assign)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setBulkSelectedPlanIds(new Set());
              setIsBulkSelectMode(false);
            }}
            className="px-2.5 py-1.5 rounded-xl border border-border hover:bg-panel text-xs text-muted-foreground hover:text-foreground transition cursor-pointer"
          >
            ক্লিয়ার
          </button>
        </div>
      )}
    </div>
  );
}

function ConfirmDialog({
  state,
  applying,
  onCancel,
  onApply,
}: {
  state: ConfirmState;
  applying: boolean;
  onCancel: () => void;
  onApply: () => void;
}) {
  const lineMoved = state.origLine !== state.newLine;
  const dateShift = state.deltaDays;
  const cascadeCount = state.changes.filter((c) => c.reason === "cascade").length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-2xl max-h-[85vh] rounded-2xl border border-border bg-panel shadow-2xl overflow-hidden flex flex-col">
        <div className="p-4 border-b border-border bg-panel-2/60">
          <h3 className="text-base font-bold text-fuchsia-300">নিশ্চিত করুন — পরিবর্তন সংক্ষেপ</h3>
          <p className="text-xs text-muted-foreground mt-1">
            {lineMoved && (
              <>
                Line: <b className="text-emerald-300">{state.origLine}</b> →{" "}
                <b className="text-emerald-300">{state.newLine}</b>.{" "}
              </>
            )}
            {dateShift !== 0 && (
              <>
                Date shift:{" "}
                <b className={dateShift > 0 ? "text-amber-300" : "text-sky-300"}>
                  {dateShift > 0 ? `+${dateShift}` : dateShift} দিন
                </b>
                .{" "}
              </>
            )}
            {cascadeCount > 0 && (
              <>
                Cascade: <b className="text-amber-300">{cascadeCount}</b> style push back হবে।
              </>
            )}
          </p>
        </div>

        <div className="flex-1 overflow-auto p-4 space-y-2">
          {state.changes.length === 0 ? (
            <p className="text-sm text-muted-foreground p-6 text-center">
              কোনো effective পরিবর্তন হচ্ছে না।
            </p>
          ) : (
            state.changes.map((c, i) => (
              <div
                key={i}
                className={`rounded-lg border p-3 text-xs ${
                  c.reason === "moved"
                    ? "border-fuchsia-500/50 bg-fuchsia-500/5"
                    : "border-amber-500/40 bg-amber-500/5"
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-emerald-300">
                    {c.oldLineName && c.oldLineName !== c.lineName ? (
                      <>
                        {c.oldLineName} → {c.lineName}
                      </>
                    ) : (
                      c.lineName
                    )}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      c.reason === "moved"
                        ? "bg-fuchsia-600/30 text-fuchsia-200"
                        : "bg-amber-600/30 text-amber-200"
                    }`}
                  >
                    {c.reason === "moved" ? "MOVED" : "CASCADE"}
                  </span>
                </div>
                <div className="text-muted-foreground mb-1">
                  <span className="font-semibold text-foreground">{c.buyer}</span> · {c.style}
                </div>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <DiffRow label="Start" oldVal={c.oldStart} newVal={c.newStart} />
                  <DiffRow label="1st Output" oldVal={c.oldFirstOutput} newVal={c.newFirstOutput} />
                  <DiffRow label="Last Output" oldVal={c.oldLastOutput} newVal={c.newLastOutput} />
                </div>
              </div>
            ))
          )}

          <div className="mt-4 rounded-lg border border-sky-500/30 bg-sky-500/5 p-3 text-[11px] text-sky-200">
            <b>যেসব tab-এ প্রভাব পড়বে:</b> Plan Input · Matrix · Line Summary · Line Open Days ·
            Free Slots · FRI Plan · Efficiency · Shift Tracker · Early/Delay · Revision History
          </div>
        </div>

        <div className="p-4 border-t border-border bg-panel-2/40 flex items-center justify-end gap-2">
          <button
            onClick={onCancel}
            disabled={applying}
            className="px-4 py-2 rounded-md text-xs font-bold border border-border bg-panel hover:bg-panel-2 disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={onApply}
            disabled={applying || state.changes.length === 0}
            className="px-4 py-2 rounded-md text-xs font-bold bg-fuchsia-600 hover:bg-fuchsia-500 text-white disabled:opacity-50 flex items-center gap-2"
          >
            {applying && <Loader2 className="w-3 h-3 animate-spin" />}
            Apply Changes
          </button>
        </div>
      </div>
    </div>
  );
}

function DiffRow({ label, oldVal, newVal }: { label: string; oldVal: string; newVal: string }) {
  const same = oldVal === newVal;
  return (
    <div className="flex flex-col">
      <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
      {same ? (
        <span className="font-mono text-foreground">{oldVal ? formatDate(oldVal) : "—"}</span>
      ) : (
        <span className="font-mono">
          <span className="text-muted-foreground line-through">
            {oldVal ? formatDate(oldVal) : "—"}
          </span>
          <span className="mx-1">→</span>
          <span className="text-emerald-300 font-bold">{newVal ? formatDate(newVal) : "—"}</span>
        </span>
      )}
    </div>
  );
}
