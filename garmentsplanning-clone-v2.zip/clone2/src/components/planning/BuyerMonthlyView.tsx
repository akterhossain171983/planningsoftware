import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Loader2,
  Search,
  X,
  Calendar,
  CheckCircle2,
  Layers,
  ChevronDown,
  ChevronRight,
  FileSpreadsheet,
  Check,
  Clock,
  Sparkles,
  PackageCheck,
  Filter,
} from "lucide-react";
import type { PlanResult } from "@/lib/plan-calc";
import { FilterSelect } from "./LineSummaryView";
import * as XLSX from "xlsx";

type Row = {
  id: string;
  buyer: string;
  style: string;
  season: string | null;
  order_qty: number;
  excess_pct: number;
  num_lines: number;
  shipment_date?: string | null;
  config: Record<string, unknown> | null;
  calc_result: PlanResult | null;
  completed_at: string | null;
  created_at?: string;
};

type StyleItem = {
  id: string;
  style: string;
  season: string;
  isCompleted: boolean;
  isUnplanned: boolean;
  totalOrderQty: number;
  totalDays: number;
  lines: string[];
  dateRange: string;
  months: Record<string, { qty: number; days: number }>;
};

type Group = {
  buyer: string;
  season: string;
  months: Record<string, { qty: number; days: number }>;
  totalQty: number;
  totalDays: number;
  styles: StyleItem[];
  completedCount: number;
  activeCount: number;
};

// Determine if a plan is marked as unplanned (i.e. not yet planned on board)
function checkIsUnplanned(p: Row): boolean {
  return (
    (p.config as Record<string, unknown>)?.status === "unplanned" ||
    (p.config as Record<string, unknown>)?.isUnplanned === true ||
    p.num_lines === 0 ||
    !p.calc_result?.lines ||
    p.calc_result.lines.length === 0
  );
}

// Get planned calendar days for a specific month for a style
function getPlanMonthDays(p: Row, monthStr: string): number {
  const distinctDates = new Set<string>();
  if (p.calc_result?.lines && Array.isArray(p.calc_result.lines)) {
    for (const l of p.calc_result.lines) {
      for (const dp of l.dailyProduction ?? []) {
        if (!dp?.date || (dp.qty ?? 0) <= 0) continue;
        const d = new Date(dp.date);
        if (isNaN(d.getTime())) continue;
        const mKey = d.toLocaleString("en-US", { month: "short", year: "numeric" });
        if (mKey === monthStr) {
          distinctDates.add(dp.date);
        }
      }
    }
  }
  if (distinctDates.size > 0) return distinctDates.size;

  const mb = p.calc_result?.monthlyBreakdown?.[monthStr];
  if (typeof mb === "object" && typeof mb?.days === "number" && mb.days > 0) {
    return mb.days;
  }
  return 0;
}

// Get total planned working days across all lines/months for a style
function getPlanTotalDays(p: Row): number {
  const distinctDates = new Set<string>();
  if (p.calc_result?.lines && Array.isArray(p.calc_result.lines)) {
    for (const l of p.calc_result.lines) {
      for (const dp of l.dailyProduction ?? []) {
        if (!dp?.date || (dp.qty ?? 0) <= 0) continue;
        distinctDates.add(dp.date);
      }
    }
  }
  if (distinctDates.size > 0) return distinctDates.size;

  if (p.calc_result?.totalLineDaysSum && p.calc_result.totalLineDaysSum > 0) {
    return p.calc_result.totalLineDaysSum;
  }

  let sum = 0;
  for (const m in p.calc_result?.monthlyBreakdown ?? {}) {
    const mb = p.calc_result.monthlyBreakdown[m];
    if (typeof mb === "object" && typeof mb?.days === "number") {
      sum += mb.days || 0;
    }
  }
  return sum;
}

export function BuyerMonthlyView() {
  const qc = useQueryClient();
  const [buyerFilter, setBuyerFilter] = useState<string[]>([]);
  const [seasonFilter, setSeasonFilter] = useState<string[]>([]);
  const [search, setSearch] = useState("");

  // Plan scope option: "board_planned" (planned on board + complete, excludes unplanned) vs "all"
  const [planScope, setPlanScope] = useState<"board_planned" | "all">("board_planned");
  // Include completed orders toggle (default true as requested)
  const [includeCompleted, setIncludeCompleted] = useState<boolean>(true);
  // Option to show days in brackets
  const [showDaysInBracket, setShowDaysInBracket] = useState<boolean>(true);
  // Expandable style rows
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());

  // Fetch all plans including completed orders so we can filter and present accurately
  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "buyer-monthly-all"],
    queryFn: async (): Promise<Row[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select(
          "id, buyer, style, season, order_qty, excess_pct, num_lines, shipment_date, config, calc_result, completed_at, created_at",
        )
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("plans-buyer-monthly-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () =>
        qc.invalidateQueries({ queryKey: ["plans"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const buyerOptions = useMemo(
    () => Array.from(new Set(plans.map((p) => p.buyer))).sort(),
    [plans],
  );

  const seasonOptions = useMemo(
    () =>
      Array.from(
        new Set(plans.map((p) => (p.season && p.season.trim()) || "— (No Season)")),
      ).sort(),
    [plans],
  );

  // Filter plans based on search, dropdown filters, scope (board_planned vs all), and includeCompleted
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return plans.filter((p) => {
      const isCompleted = p.completed_at !== null;
      const isUnplanned = checkIsUnplanned(p);

      // 1. If completed and user opted out of completed orders:
      if (isCompleted && !includeCompleted) {
        return false;
      }

      // 2. Plan board scope filter:
      // When "board_planned": only bring styles planned on the board and completed styles; EXCLUDE unplanned styles
      if (planScope === "board_planned") {
        if (isUnplanned && !isCompleted) {
          return false;
        }
      }

      // 3. Dropdown filters
      const seasonKey = (p.season && p.season.trim()) || "— (No Season)";
      const matchesBuyer = buyerFilter.length === 0 || buyerFilter.includes(p.buyer);
      const matchesSeason = seasonFilter.length === 0 || seasonFilter.includes(seasonKey);

      // 4. Search query
      const matchesSearch =
        q === "" ||
        p.buyer.toLowerCase().includes(q) ||
        p.style.toLowerCase().includes(q) ||
        (p.season ?? "").toLowerCase().includes(q);

      return matchesBuyer && matchesSeason && matchesSearch;
    });
  }, [plans, buyerFilter, seasonFilter, search, planScope, includeCompleted]);

  // Collect all distinct months
  const sortedMonths = useMemo(() => {
    const monthSet = new Set<string>();
    filtered.forEach((p) => {
      for (const m in p.calc_result?.monthlyBreakdown ?? {}) {
        monthSet.add(m);
      }
    });
    return Array.from(monthSet).sort(
      (a, b) => new Date("1 " + a).getTime() - new Date("1 " + b).getTime(),
    );
  }, [filtered]);

  // Aggregate by Buyer + Season, and collect style-level breakdowns
  const groups = useMemo(() => {
    const groupsMap = new Map<string, Group>();

    filtered.forEach((p) => {
      const seasonKey = (p.season && p.season.trim()) || "";
      const groupKey = `${p.buyer}||${seasonKey}`;
      let g = groupsMap.get(groupKey);
      if (!g) {
        g = {
          buyer: p.buyer,
          season: seasonKey,
          months: {},
          totalQty: 0,
          totalDays: 0,
          styles: [],
          completedCount: 0,
          activeCount: 0,
        };
        groupsMap.set(groupKey, g);
      }

      const isCompleted = p.completed_at !== null;
      const isUnplanned = checkIsUnplanned(p);

      if (isCompleted) {
        g.completedCount += 1;
      } else {
        g.activeCount += 1;
      }

      const divisor = 1 + (Number(p.excess_pct) || 0) / 100;
      const styleMonths: Record<string, { qty: number; days: number }> = {};
      let styleTotalQty = 0;

      // Extract line names and date range for style details
      const lineNames: string[] = [];
      let minStart = "";
      let maxFinish = "";

      if (p.calc_result?.lines && Array.isArray(p.calc_result.lines)) {
        p.calc_result.lines.forEach((l) => {
          if (l.name && !lineNames.includes(l.name)) lineNames.push(l.name);
          if (l.startDateStr && (!minStart || l.startDateStr < minStart)) minStart = l.startDateStr;
          if (l.finishDateStr && (!maxFinish || l.finishDateStr > maxFinish))
            maxFinish = l.finishDateStr;
        });
      }

      for (const m in p.calc_result?.monthlyBreakdown ?? {}) {
        const plannedQty = p.calc_result.monthlyBreakdown[m]?.qty ?? 0;
        const orderQty = divisor > 0 ? Math.round(plannedQty / divisor) : plannedQty;
        const monthDays = getPlanMonthDays(p, m);

        styleMonths[m] = { qty: orderQty, days: monthDays };
        styleTotalQty += orderQty;

        if (!g.months[m]) {
          g.months[m] = { qty: 0, days: 0 };
        }
        g.months[m].qty += orderQty;
        g.months[m].days += monthDays;
      }

      // If no monthlyBreakdown exists (e.g. initial unplanned), fallback to top-level order_qty
      if (Object.keys(styleMonths).length === 0 && p.order_qty) {
        styleTotalQty = p.order_qty;
      }

      const styleDays = getPlanTotalDays(p);
      g.totalQty += styleTotalQty;
      g.totalDays += styleDays;

      const dateRangeStr =
        minStart && maxFinish
          ? `${minStart} ~ ${maxFinish}`
          : p.shipment_date
            ? `Ship: ${p.shipment_date}`
            : "—";

      g.styles.push({
        id: p.id,
        style: p.style,
        season: seasonKey,
        isCompleted,
        isUnplanned,
        totalOrderQty: styleTotalQty,
        totalDays: styleDays,
        lines: lineNames,
        dateRange: dateRangeStr,
        months: styleMonths,
      });
    });

    return Array.from(groupsMap.values()).sort((a, b) => {
      if (a.buyer !== b.buyer) return a.buyer.localeCompare(b.buyer);
      return a.season.localeCompare(b.season);
    });
  }, [filtered]);

  // Grand totals
  const grandTotal = useMemo(() => {
    let qty = 0;
    let days = 0;
    const monthTotals: Record<string, { qty: number; days: number }> = {};
    sortedMonths.forEach((m) => (monthTotals[m] = { qty: 0, days: 0 }));

    groups.forEach((g) => {
      qty += g.totalQty;
      days += g.totalDays;
      sortedMonths.forEach((m) => {
        const item = g.months[m];
        if (item) {
          monthTotals[m].qty += item.qty;
          monthTotals[m].days += item.days;
        }
      });
    });

    return { totalQty: qty, totalDays: days, months: monthTotals };
  }, [groups, sortedMonths]);

  // Toggle single group expand
  const toggleGroup = (key: string) => {
    setExpandedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  // Toggle all groups expand
  const toggleAllGroups = () => {
    if (expandedGroups.size === groups.length) {
      setExpandedGroups(new Set());
    } else {
      setExpandedGroups(new Set(groups.map((g) => `${g.buyer}||${g.season}`)));
    }
  };

  // Export to Excel with Quantity + Days in brackets
  const handleExportExcel = () => {
    if (groups.length === 0) return;

    const dataRows: (string | number)[][] = [];

    // Header row
    const headers = ["Buyer", "Season", "Status", "Total Order Qty (Days)"];
    sortedMonths.forEach((m) => headers.push(`${m} Qty (Days)`));
    dataRows.push(headers);

    // Group rows + individual style sub-rows
    groups.forEach((g) => {
      const groupRow: (string | number)[] = [
        g.buyer,
        g.season || "No Season",
        `Styles: ${g.styles.length} (${g.activeCount} Active, ${g.completedCount} Complete)`,
        showDaysInBracket
          ? `${g.totalQty.toLocaleString()} (${g.totalDays} দিন)`
          : g.totalQty.toLocaleString(),
      ];

      sortedMonths.forEach((m) => {
        const item = g.months[m];
        if (item && item.qty > 0) {
          groupRow.push(
            showDaysInBracket
              ? `${item.qty.toLocaleString()} (${item.days} দিন)`
              : item.qty.toLocaleString(),
          );
        } else {
          groupRow.push("-");
        }
      });
      dataRows.push(groupRow);

      // Style sub-rows
      g.styles.forEach((s) => {
        const sRow: (string | number)[] = [
          `  └ ${g.buyer}`,
          s.style,
          s.isCompleted ? "Complete" : s.isUnplanned ? "Unplanned" : "Planned",
          showDaysInBracket
            ? `${s.totalOrderQty.toLocaleString()} (${s.totalDays} দিন)`
            : s.totalOrderQty.toLocaleString(),
        ];
        sortedMonths.forEach((m) => {
          const item = s.months[m];
          if (item && item.qty > 0) {
            sRow.push(
              showDaysInBracket
                ? `${item.qty.toLocaleString()} (${item.days} দিন)`
                : item.qty.toLocaleString(),
            );
          } else {
            sRow.push("-");
          }
        });
        dataRows.push(sRow);
      });
    });

    // Grand total row
    const totalRow: (string | number)[] = [
      "GRAND TOTAL",
      "—",
      "—",
      showDaysInBracket
        ? `${grandTotal.totalQty.toLocaleString()} (${grandTotal.totalDays} দিন)`
        : grandTotal.totalQty.toLocaleString(),
    ];
    sortedMonths.forEach((m) => {
      const item = grandTotal.months[m];
      if (item && item.qty > 0) {
        totalRow.push(
          showDaysInBracket
            ? `${item.qty.toLocaleString()} (${item.days} দিন)`
            : item.qty.toLocaleString(),
        );
      } else {
        totalRow.push("-");
      }
    });
    dataRows.push(totalRow);

    const ws = XLSX.utils.aoa_to_sheet(dataRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Buyer x Season");
    XLSX.writeFile(wb, `Buyer_Season_Plan_Board_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const hasFilter =
    buyerFilter.length > 0 ||
    seasonFilter.length > 0 ||
    search.trim() !== "" ||
    planScope !== "board_planned" ||
    !includeCompleted;

  if (isLoading) {
    return (
      <div className="p-12 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const allExpanded = groups.length > 0 && expandedGroups.size === groups.length;

  return (
    <div className="rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl">
      {/* Top Header */}
      <div className="p-4 md:p-6 border-b border-border bg-panel-2/40 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base md:text-lg font-bold text-cyan-400 flex items-center gap-2">
              <Layers className="w-5 h-5 text-cyan-400" />
              Buyer × Season — Month-wise Plan Board Quantity
            </h2>
            <p className="text-xs text-muted-foreground mt-1">
              প্ল্যান বোর্ডে শিডিউলকৃত স্টাইল ও সম্পন্ন (Complete) অর্ডারসমূহের মাসভিত্তিক
              কোয়ান্টিটি এবং ব্র্যাকেটে প্ল্যানড কার্যদিবস{" "}
              <b className="text-cyan-300 font-semibold">(দিন)</b>।
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportExcel}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-emerald-700/30 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600 hover:text-white transition cursor-pointer shadow-sm"
              title="এক্সেল ফাইল ডাউনলোড করুন"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Excel Export
            </button>
            <button
              onClick={toggleAllGroups}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-panel border border-border text-foreground hover:bg-panel-2 transition cursor-pointer"
            >
              {allExpanded ? (
                <>
                  <ChevronDown className="w-3.5 h-3.5" /> সবগুলো সঙ্কুচিত করুন
                </>
              ) : (
                <>
                  <ChevronRight className="w-3.5 h-3.5" /> স্টাইল বিস্তারিত দেখুন
                </>
              )}
            </button>
          </div>
        </div>

        {/* Option Bar: Mode Toggle, Completed Toggle, Days in Bracket Toggle */}
        <div className="p-3 rounded-xl border border-cyan-500/20 bg-cyan-950/20 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-bold text-muted-foreground uppercase text-[11px] flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-cyan-400" /> ফিল্টার অপশন:
            </span>

            {/* Scope Toggle: Board Planned vs All */}
            <div className="inline-flex rounded-lg border border-border bg-panel p-0.5">
              <button
                type="button"
                onClick={() => setPlanScope("board_planned")}
                className={`px-3 py-1 text-xs font-bold rounded-md transition flex items-center gap-1.5 cursor-pointer ${
                  planScope === "board_planned"
                    ? "bg-cyan-600 text-white shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
                title="শুধুমাত্র প্ল্যান বোর্ডে যুক্ত ও সম্পন্ন স্টাইল আনবে (আনপ্ল্যান্ড বাদ)"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                প্ল্যানড ও কমপ্লিট (অনবোর্ড)
              </button>
              <button
                type="button"
                onClick={() => setPlanScope("all")}
                className={`px-3 py-1 text-xs font-bold rounded-md transition cursor-pointer ${
                  planScope === "all"
                    ? "bg-cyan-600 text-white shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
                title="সকল অর্ডার আনবে (আনপ্ল্যান্ড সহ)"
              >
                সকল অর্ডার (আনপ্ল্যান্ড সহ)
              </button>
            </div>

            {/* Include Completed Orders Toggle */}
            <button
              type="button"
              onClick={() => setIncludeCompleted((v) => !v)}
              className={`px-3 py-1 text-xs font-bold rounded-lg border transition flex items-center gap-1.5 cursor-pointer ${
                includeCompleted
                  ? "bg-emerald-600/20 border-emerald-500/40 text-emerald-300"
                  : "bg-panel border-border text-muted-foreground hover:text-foreground"
              }`}
              title="কমপ্লিট হয়ে যাওয়া অর্ডারগুলো অন্তর্ভুক্ত রাখুন"
            >
              <PackageCheck className="w-3.5 h-3.5 text-emerald-400" />
              কমপ্লিট অর্ডার সহ: {includeCompleted ? "চালু" : "বন্ধ"}
            </button>

            {/* Show Days in Bracket Toggle */}
            <button
              type="button"
              onClick={() => setShowDaysInBracket((v) => !v)}
              className={`px-3 py-1 text-xs font-bold rounded-lg border transition flex items-center gap-1.5 cursor-pointer ${
                showDaysInBracket
                  ? "bg-amber-600/20 border-amber-500/40 text-amber-300"
                  : "bg-panel border-border text-muted-foreground hover:text-foreground"
              }`}
              title="কোয়ান্টিটির সাথে ব্র্যাকেটে প্ল্যানড দিনের সংখ্যা দেখান"
            >
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              দিন সংখ্যা [দিন]: {showDaysInBracket ? "চালু" : "বন্ধ"}
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-cyan-300/80 bg-cyan-900/40 px-2 py-0.5 rounded border border-cyan-500/30">
              মোট স্টাইল:{" "}
              <b>
                {groups.reduce(
                  (sum, g) =>
                    sum +
                    (planScope === "board_planned"
                      ? g.styles.filter((s) => !s.isUnplanned || s.isCompleted).length
                      : g.styles.length),
                  0,
                )}
              </b>
            </span>
            <span className="text-[11px] font-mono text-amber-300/80 bg-amber-900/40 px-2 py-0.5 rounded border border-amber-500/30">
              মোট দিন: <b>{grandTotal.totalDays}</b>
            </span>
          </div>
        </div>

        {/* Filter Inputs Bar */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buyer / Season / Style সার্চ..."
              className="pl-8 pr-8 py-1.5 text-xs rounded-lg bg-panel border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-cyan-500/60 w-60"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <FilterSelect
            label="Buyer"
            value={buyerFilter}
            onChange={setBuyerFilter}
            options={buyerOptions}
          />

          <FilterSelect
            label="Season"
            value={seasonFilter}
            onChange={setSeasonFilter}
            options={seasonOptions}
          />

          {hasFilter && (
            <button
              onClick={() => {
                setBuyerFilter([]);
                setSeasonFilter([]);
                setSearch("");
                setPlanScope("board_planned");
                setIncludeCompleted(true);
              }}
              className="text-xs font-bold text-red-300 hover:text-red-200 underline ml-1 cursor-pointer"
            >
              ফিল্টার রিসেট
            </button>
          )}

          <span className="text-xs bg-cyan-950 text-cyan-400 border border-cyan-500/50 px-3 py-1 rounded-lg font-bold ml-auto">
            {groups.length} Groups
          </span>
        </div>
      </div>

      {groups.length === 0 ? (
        <div className="p-12 text-center text-sm text-muted-foreground space-y-2">
          <p className="font-semibold text-foreground">কোনো ডাটা খুঁজে পাওয়া যায়নি।</p>
          <p className="text-xs">
            {planScope === "board_planned"
              ? "বর্তমানে ফিল্টারে কোনো প্ল্যানড বা সম্পন্ন স্টাইল নেই। ফিল্টার পরিবর্তন করে দেখতে পারেন।"
              : "কোনো অর্ডার পাওয়া যায়নি।"}
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead className="bg-panel-2 text-muted-foreground text-xs uppercase tracking-wider">
              <tr>
                <th className="p-3.5 border-r border-border bg-panel-2 sticky left-0 z-20 w-60">
                  Buyer & Season
                </th>
                <th className="p-3.5 border-r border-border bg-panel-2 w-32 text-center">
                  স্ট্যাটাস
                </th>
                <th className="p-3.5 border-r border-border text-center text-yellow-400 bg-panel-2 min-w-[150px]">
                  Total Order Qty{" "}
                  {showDaysInBracket && <span className="text-cyan-300">(দিন)</span>}
                </th>
                {sortedMonths.map((m) => (
                  <th
                    key={m}
                    className="p-3.5 text-center border-r border-border/60 bg-panel-2/90 min-w-[140px]"
                  >
                    <span>{m}</span>
                    {showDaysInBracket && (
                      <span className="block text-[10px] font-normal text-cyan-300/80 lowercase">
                        qty (দিন)
                      </span>
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {groups.map((g) => {
                const groupKey = `${g.buyer}||${g.season}`;
                const isExpanded = expandedGroups.has(groupKey);

                return (
                  <GroupRows
                    key={groupKey}
                    group={g}
                    groupKey={groupKey}
                    isExpanded={isExpanded}
                    onToggle={() => toggleGroup(groupKey)}
                    sortedMonths={sortedMonths}
                    showDaysInBracket={showDaysInBracket}
                  />
                );
              })}
            </tbody>
            <tfoot className="bg-panel-2/95 font-bold border-t-2 border-border">
              <tr>
                <td
                  colSpan={2}
                  className="p-4 border-r border-border bg-panel-2 sticky left-0 z-10 text-right uppercase text-xs text-muted-foreground"
                >
                  Grand Total ➔
                </td>
                <td className="p-3.5 border-r border-border text-center bg-panel-2">
                  <div className="flex flex-col items-center justify-center">
                    <span className="font-bold text-yellow-400 text-base">
                      {grandTotal.totalQty.toLocaleString()} Pcs
                    </span>
                    {showDaysInBracket && grandTotal.totalDays > 0 && (
                      <span className="text-xs text-cyan-300 font-semibold mt-0.5">
                        ({grandTotal.totalDays} দিন)
                      </span>
                    )}
                  </div>
                </td>
                {sortedMonths.map((m) => {
                  const mData = grandTotal.months[m];
                  return (
                    <td
                      key={m}
                      className="p-3.5 text-center border-r border-border/60 bg-cyan-950/60"
                    >
                      <div className="flex flex-col items-center justify-center">
                        <span className="font-bold text-base text-cyan-400">
                          {mData.qty > 0 ? `${mData.qty.toLocaleString()} Pcs` : "—"}
                        </span>
                        {showDaysInBracket && mData.days > 0 && (
                          <span className="text-xs text-amber-300 font-semibold mt-0.5">
                            ({mData.days} দিন)
                          </span>
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </div>
  );
}

// Subcomponent for each Buyer × Season row and its expandable style details
function GroupRows({
  group,
  groupKey,
  isExpanded,
  onToggle,
  sortedMonths,
  showDaysInBracket,
}: {
  group: Group;
  groupKey: string;
  isExpanded: boolean;
  onToggle: () => void;
  sortedMonths: string[];
  showDaysInBracket: boolean;
}) {
  return (
    <>
      <tr className="hover:bg-panel-2/50 transition group cursor-pointer" onClick={onToggle}>
        <td className="p-3.5 border-r border-border bg-panel font-bold text-foreground sticky left-0 z-10">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded hover:bg-panel-2 text-cyan-400 transition">
              {isExpanded ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-cyan-400" />
              )}
            </span>
            <div className="min-w-0">
              <span className="text-sm font-bold text-foreground block truncate">
                {group.buyer}
              </span>
              <span className="text-xs text-amber-400 font-medium block truncate">
                {group.season ? (
                  group.season
                ) : (
                  <span className="italic text-muted-foreground">— (No Season)</span>
                )}
              </span>
            </div>
          </div>
        </td>

        <td className="p-3 border-r border-border bg-panel/60 text-center">
          <div className="flex flex-col items-center gap-0.5">
            <span className="text-[11px] font-bold text-muted-foreground">
              {group.styles.length} টি স্টাইল
            </span>
            <div className="flex items-center gap-1 text-[10px]">
              {group.completedCount > 0 && (
                <span
                  className="text-emerald-400 font-semibold flex items-center gap-0.5"
                  title="সম্পন্ন"
                >
                  <CheckCircle2 className="w-3 h-3 inline" /> {group.completedCount}
                </span>
              )}
              {group.activeCount > 0 && (
                <span
                  className="text-cyan-400 font-semibold flex items-center gap-0.5"
                  title="প্ল্যানড"
                >
                  <Clock className="w-3 h-3 inline" /> {group.activeCount}
                </span>
              )}
            </div>
          </div>
        </td>

        <td className="p-3 border-r border-border text-center bg-panel/60">
          <div className="flex flex-col items-center justify-center">
            <span className="font-bold text-cyan-300 text-sm">
              {group.totalQty.toLocaleString()} Pcs
            </span>
            {showDaysInBracket && group.totalDays > 0 && (
              <span className="text-xs text-amber-300 font-medium mt-0.5">
                ({group.totalDays} দিন)
              </span>
            )}
          </div>
        </td>

        {sortedMonths.map((m) => {
          const item = group.months[m];
          if (!item || item.qty <= 0) {
            return (
              <td
                key={m}
                className="p-3.5 text-center border-r border-border/60 text-muted-foreground/60 text-xs"
              >
                -
              </td>
            );
          }

          return (
            <td key={m} className="p-3 text-center border-r border-border/60 bg-panel-2/30">
              <div className="flex flex-col items-center justify-center">
                <span className="text-xs font-bold text-teal-300">
                  {item.qty.toLocaleString()}{" "}
                  <small className="text-[9px] font-normal text-muted-foreground">Pcs</small>
                </span>
                {showDaysInBracket && item.days > 0 && (
                  <span className="text-[11px] font-semibold text-amber-300/90 mt-0.5">
                    ({item.days} দিন)
                  </span>
                )}
              </div>
            </td>
          );
        })}
      </tr>

      {/* Expanded Style Sub-rows */}
      {isExpanded &&
        group.styles.map((style) => (
          <tr
            key={style.id}
            className="bg-panel-2/20 hover:bg-panel-2/50 text-xs transition border-b border-border/40"
          >
            <td className="p-2.5 pl-9 border-r border-border bg-panel-2/30 sticky left-0 z-10">
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground text-[11px]">└</span>
                <div>
                  <span className="font-bold text-blue-400 hover:underline">{style.style}</span>
                  {style.lines.length > 0 && (
                    <span className="block text-[10px] text-muted-foreground">
                      {style.lines.join(", ")}
                    </span>
                  )}
                </div>
              </div>
            </td>

            <td className="p-2 border-r border-border text-center">
              {style.isCompleted ? (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-600/20 text-emerald-300 border border-emerald-500/30">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  কমপ্লিট
                </span>
              ) : style.isUnplanned ? (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-600/20 text-amber-300 border border-amber-500/30">
                  আনপ্ল্যান্ড
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-cyan-600/20 text-cyan-300 border border-cyan-500/30">
                  <Clock className="w-3 h-3 text-cyan-400" />
                  প্ল্যানড
                </span>
              )}
            </td>

            <td className="p-2 border-r border-border text-center">
              <div className="flex flex-col items-center">
                <span className="font-bold text-foreground">
                  {style.totalOrderQty.toLocaleString()} Pcs
                </span>
                {showDaysInBracket && style.totalDays > 0 && (
                  <span className="text-[10px] text-amber-300/90 font-medium">
                    ({style.totalDays} দিন)
                  </span>
                )}
              </div>
            </td>

            {sortedMonths.map((m) => {
              const item = style.months[m];
              if (!item || item.qty <= 0) {
                return (
                  <td
                    key={m}
                    className="p-2 text-center border-r border-border/40 text-muted-foreground/40 text-[11px]"
                  >
                    -
                  </td>
                );
              }
              return (
                <td key={m} className="p-2 text-center border-r border-border/40 bg-panel/30">
                  <div className="flex flex-col items-center">
                    <span className="font-medium text-foreground text-[11px]">
                      {item.qty.toLocaleString()}
                    </span>
                    {showDaysInBracket && item.days > 0 && (
                      <span className="text-[10px] text-amber-300 font-semibold">
                        ({item.days} দিন)
                      </span>
                    )}
                  </div>
                </td>
              );
            })}
          </tr>
        ))}
    </>
  );
}
