import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, RotateCcw, Download } from "lucide-react";
import * as XLSX from "xlsx";
import type { PlanResult } from "@/lib/plan-calc";
import { getLocalDateStr, formatDate } from "@/lib/plan-calc";
import { useGlobalHolidays } from "./HolidayCalendar";
import { useLinePresets } from "@/hooks/use-line-presets";
import { buildLinePresetLookup, canonicalLineName, sortLineNamesByPreset } from "./lineLookup";

type FriPlan = {
  id: string;
  buyer: string;
  style: string;
  calc_result: PlanResult;
};

type SrcItem = { line: string; sewDate: string; qty: number };
type FriRow = {
  date: string;
  dc: number;
  cCut: number;
  ds: number;
  cSew: number;
  df: number;
  cFin: number;
  dp: number;
  cPack: number;
  sewByLine: Record<string, number>;
  srcCut: SrcItem[];
  srcSew: SrcItem[];
  srcFin: SrcItem[];
  srcPack: SrcItem[];
};

function exportFriPlan(
  buyer: string,
  style: string,
  rows: FriRow[],
  meta: { total: number; dailyCap: number; numLines: number; lineNames: string[] },
) {
  const aoa: (string | number)[][] = [];
  aoa.push([`Buyer: ${buyer}`, `Style: ${style}`]);
  aoa.push([
    `Total Qty: ${meta.total}`,
    `Lines: ${meta.numLines}`,
    `Daily Cap (all lines): ${meta.dailyCap}`,
  ]);
  aoa.push([]);
  const header: (string | number)[] = [
    "Date",
    "Day",
    "Day Cutting",
    "Cum Cutting",
    ...meta.lineNames.map((ln) => `Sew ${ln}`),
    "Total Sewing",
    "Cum Sewing",
    "Day Finishing",
    "Cum Finishing",
    "Day Packing",
    "Cum Packing",
  ];
  aoa.push(header);
  rows.forEach((r) => {
    const d = new Date(r.date);
    const dayName = d.toLocaleDateString("en-US", { weekday: "short" });
    aoa.push([
      formatDate(r.date),
      dayName,
      r.dc || "",
      r.cCut || "",
      ...meta.lineNames.map((ln) => r.sewByLine[ln] || ""),
      r.ds || "",
      r.cSew || "",
      r.df || "",
      r.cFin || "",
      r.dp || "",
      r.cPack || "",
    ]);
  });

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  // Autofit column widths based on max content length per column
  const colCount = aoa.reduce((m, r) => Math.max(m, r.length), 0);
  const cols: { wch: number }[] = [];
  for (let c = 0; c < colCount; c++) {
    let max = 8;
    for (const row of aoa) {
      const v = row[c];
      if (v === undefined || v === null) continue;
      const len = String(v).length;
      if (len > max) max = len;
    }
    cols.push({ wch: Math.min(max + 2, 40) });
  }
  ws["!cols"] = cols;
  // Freeze the header row (row 4) so it stays visible on scroll
  (ws as unknown as { "!views"?: unknown[] })["!views"] = [
    { state: "frozen", xSplit: 0, ySplit: 4, topLeftCell: "A5", activePane: "bottomLeft" },
  ];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "FRI Plan");
  const safe = (s: string) => s.replace(/[^\w-]+/g, "_").slice(0, 40);
  XLSX.writeFile(wb, `FRIPlan_${safe(buyer)}_${safe(style)}.xlsx`);
}

function shiftWorkingDays(startStr: string, days: number, holidays: Set<string>): string {
  const d = new Date(startStr);
  const step = days >= 0 ? 1 : -1;
  let remaining = Math.abs(days);
  while (remaining > 0) {
    d.setDate(d.getDate() + step);
    const s = getLocalDateStr(d);
    if (d.getDay() === 5 || holidays.has(s)) continue;
    remaining--;
  }
  return getLocalDateStr(d);
}

function nextWorking(dateStr: string, holidays: Set<string>): string {
  const d = new Date(dateStr);
  while (d.getDay() === 5 || holidays.has(getLocalDateStr(d))) {
    d.setDate(d.getDate() + 1);
  }
  return getLocalDateStr(d);
}

function buildStage(
  startStr: string,
  bases: Array<{ date: string; qty: number }>,
  factors: number[],
  holidays: Set<string>,
): { out: Map<string, number>; sources: Map<string, Array<{ sewDate: string; qty: number }>> } {
  const out = new Map<string, number>();
  const sources = new Map<string, Array<{ sewDate: string; qty: number }>>();
  if (bases.length === 0 || factors.length === 0) return { out, sources };

  const total = bases.reduce((a, b) => a + b.qty, 0);

  // Step 1: apply LC ramp-up factors day-by-day (first days scaled down).
  const planned = bases.map((b, i) => {
    const f = factors[Math.min(i, factors.length - 1)];
    return Math.round(b.qty * f);
  });

  // Step 2: redistribute LC shortfall into the tail (post-rampup) days so the
  // stage completes within the SAME number of working days as sewing — never
  // spilling past sewing's last day. Distribution is proportional to base qty.
  const plannedSum = planned.reduce((a, b) => a + b, 0);
  const deficit = total - plannedSum;
  if (deficit !== 0) {
    const tailStart = Math.max(0, factors.length - 1);
    const tailIdx: number[] = [];
    for (let i = tailStart; i < bases.length; i++) tailIdx.push(i);
    // If no post-ramp days exist (very short plan), fall back to last day.
    if (tailIdx.length === 0) tailIdx.push(bases.length - 1);
    const tailBaseSum = tailIdx.reduce((s, i) => s + (bases[i]?.qty || 0), 0) || tailIdx.length;
    tailIdx.forEach((i) => {
      const share = bases[i]?.qty || 1;
      planned[i] += Math.round((deficit * share) / tailBaseSum);
    });
    // Fix any rounding drift on the very last tail day.
    const drift = total - planned.reduce((a, b) => a + b, 0);
    if (drift !== 0) planned[tailIdx[tailIdx.length - 1]] += drift;
  }

  // Step 3: walk working days from startStr and assign planned[i] to each,
  // keeping source pointer = sewing day i for traceability.
  let cursor = nextWorking(startStr, holidays);
  for (let i = 0; i < bases.length; i++) {
    const qty = Math.max(0, planned[i]);
    if (qty > 0) {
      out.set(cursor, (out.get(cursor) ?? 0) + qty);
      const arr = sources.get(cursor) ?? [];
      arr.push({ sewDate: bases[i].date, qty });
      sources.set(cursor, arr);
    }
    if (i < bases.length - 1) {
      const d = new Date(cursor);
      d.setDate(d.getDate() + 1);
      while (d.getDay() === 5 || holidays.has(getLocalDateStr(d))) {
        d.setDate(d.getDate() + 1);
      }
      cursor = getLocalDateStr(d);
    }
  }
  return { out, sources };
}

const DEFAULTS = {
  cutOffset: 3,
  finOffset: 4,
  packOffset: 6,
  cutLC: "30,60,80,100",
  finLC: "40,70,100",
  packLC: "40,70,100",
};

const STORAGE_KEY = "fri-plan-settings-v1";

function parseLC(s: string): number[] {
  return s
    .split(/[,\s]+/)
    .map((x) => parseFloat(x))
    .filter((n) => !isNaN(n) && n > 0)
    .map((n) => n / 100);
}

export function FriPlanView() {
  const qc = useQueryClient();
  const { data: holidayList = [] } = useGlobalHolidays();
  const { presets: linePresets } = useLinePresets();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "fri"],
    queryFn: async (): Promise<FriPlan[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("id, buyer, style, calc_result")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as FriPlan[];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("plans-fri-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () =>
        qc.invalidateQueries({ queryKey: ["plans"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const [selectedId, setSelectedId] = useState<string>("");
  useEffect(() => {
    if (plans.length && !selectedId) setSelectedId(plans[0].id);
  }, [plans, selectedId]);

  const [settings, setSettings] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return { ...DEFAULTS, ...JSON.parse(raw) };
    } catch {
      /* noop */
    }
    return DEFAULTS;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch {
      /* noop */
    }
  }, [settings]);

  const holidays = useMemo(() => new Set(holidayList), [holidayList]);
  const presetLookup = useMemo(() => buildLinePresetLookup(linePresets), [linePresets]);
  const plan = plans.find((p) => p.id === selectedId);

  const computed = useMemo(() => {
    if (!plan) return null;
    const calc = plan.calc_result;
    const numLines = calc.lines?.length ?? 0;
    const dailyCap = (calc.dailyTargetPerLine ?? 0) * numLines;
    const total = calc.totalPlannedQty ?? 0;

    const lineNames: string[] = sortLineNamesByPreset(
      (calc.lines ?? []).map((l) => canonicalLineName(l.name, presetLookup)),
      linePresets,
    );
    const sewMap = new Map<string, number>();
    const sewSrc = new Map<string, SrcItem[]>();
    const sewByLine = new Map<string, Map<string, number>>(); // date -> line -> qty
    (calc.lines ?? []).forEach((l) =>
      (l.dailyProduction ?? []).forEach((d) => {
        sewMap.set(d.date, (sewMap.get(d.date) ?? 0) + d.qty);
        const arr = sewSrc.get(d.date) ?? [];
        const lineName = canonicalLineName(l.name, presetLookup);
        arr.push({ line: lineName, sewDate: d.date, qty: d.qty });
        sewSrc.set(d.date, arr);
        const inner = sewByLine.get(d.date) ?? new Map<string, number>();
        inner.set(lineName, (inner.get(lineName) ?? 0) + d.qty);
        sewByLine.set(d.date, inner);
      }),
    );
    if (sewMap.size === 0) return null;

    const cutLC = parseLC(settings.cutLC);
    const finLC = parseLC(settings.finLC);
    const packLC = parseLC(settings.packLC);
    const cutOff = Number(settings.cutOffset) || 0;
    const finOff = Number(settings.finOffset) || 0;
    const packOff = Number(settings.packOffset) || 0;

    // Build cutting/finishing/packing PER LINE — each follows that line's
    // own daily sewing loading and its own 1st-output date — then merge.
    const cutMap = new Map<string, number>();
    const finMap = new Map<string, number>();
    const packMap = new Map<string, number>();
    const cutSrc = new Map<string, SrcItem[]>();
    const finSrc = new Map<string, SrcItem[]>();
    const packSrc = new Map<string, SrcItem[]>();

    const mergeStage = (
      target: Map<string, number>,
      targetSrc: Map<string, SrcItem[]>,
      res: {
        out: Map<string, number>;
        sources: Map<string, Array<{ sewDate: string; qty: number }>>;
      },
      lineName: string,
    ) => {
      res.out.forEach((v, k) => target.set(k, (target.get(k) ?? 0) + v));
      res.sources.forEach((items, k) => {
        const arr = targetSrc.get(k) ?? [];
        items.forEach((it) => arr.push({ line: lineName, sewDate: it.sewDate, qty: it.qty }));
        targetSrc.set(k, arr);
      });
    };

    (calc.lines ?? []).forEach((l) => {
      const dp = (l.dailyProduction ?? [])
        .slice()
        .sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
      if (dp.length === 0) return;
      const bases = dp.map((d) => ({ date: d.date, qty: d.qty }));
      const lineFirst = dp[0].date;

      const cutStart = shiftWorkingDays(lineFirst, -Math.abs(cutOff), holidays);
      const lineName = canonicalLineName(l.name, presetLookup);
      mergeStage(cutMap, cutSrc, buildStage(cutStart, bases, cutLC, holidays), lineName);

      const finStart = shiftWorkingDays(lineFirst, Math.abs(finOff), holidays);
      mergeStage(finMap, finSrc, buildStage(finStart, bases, finLC, holidays), lineName);

      const packStart = shiftWorkingDays(lineFirst, Math.abs(packOff), holidays);
      mergeStage(packMap, packSrc, buildStage(packStart, bases, packLC, holidays), lineName);
    });

    const all = new Set<string>();
    [cutMap, sewMap, finMap, packMap].forEach((m) => m.forEach((_v, k) => all.add(k)));
    const dates = Array.from(all).sort();

    let cCut = 0,
      cSew = 0,
      cFin = 0,
      cPack = 0;
    const rows: FriRow[] = dates.map((date) => {
      const dc = cutMap.get(date) ?? 0;
      const ds = sewMap.get(date) ?? 0;
      const df = finMap.get(date) ?? 0;
      const dp = packMap.get(date) ?? 0;
      cCut += dc;
      cSew += ds;
      cFin += df;
      cPack += dp;
      const byLine: Record<string, number> = {};
      const inner = sewByLine.get(date);
      if (inner) inner.forEach((v, k) => (byLine[k] = v));
      return {
        date,
        dc,
        cCut,
        ds,
        cSew,
        df,
        cFin,
        dp,
        cPack,
        sewByLine: byLine,
        srcCut: cutSrc.get(date) ?? [],
        srcSew: sewSrc.get(date) ?? [],
        srcFin: finSrc.get(date) ?? [],
        srcPack: packSrc.get(date) ?? [],
      };
    });

    return { rows, total, dailyCap, numLines, lineNames };
  }, [plan, holidays, settings, presetLookup, linePresets]);

  if (isLoading) {
    return (
      <div className="p-12 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (plans.length === 0) {
    return (
      <div className="p-12 text-center">
        <p className="text-sm text-muted-foreground">কোনো প্ল্যান নেই।</p>
      </div>
    );
  }

  const setField = (k: keyof typeof DEFAULTS, v: string | number) =>
    setSettings((s: typeof DEFAULTS) => ({ ...s, [k]: v }));

  return (
    <div className="rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl">
      <div className="p-4 md:p-6 border-b border-border bg-panel-2/40 flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-[220px]">
          <h2 className="text-base md:text-lg font-bold text-cyan-300">
            🧵 FRI Plan — Cutting / Sewing / Finishing / Packing
          </h2>
          <p className="text-xs text-muted-foreground mt-1">
            নিচের সেটিংস থেকে দিন-অফসেট ও LC% কাস্টমাইজ করা যাবে।
          </p>
        </div>
        <PlanPicker plans={plans} value={selectedId} onChange={setSelectedId} />
        <button
          onClick={() =>
            plan && computed && exportFriPlan(plan.buyer, plan.style, computed.rows, computed)
          }
          disabled={!plan || !computed}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-emerald-600/50 bg-emerald-950/60 hover:bg-emerald-900/60 text-xs font-semibold text-emerald-200 disabled:opacity-40"
          title="Export to Excel"
        >
          <Download className="w-3.5 h-3.5" /> Export
        </button>
      </div>

      {/* Settings Panel */}
      <div className="p-4 md:p-6 border-b border-border bg-panel-2/20">
        <div className="flex flex-wrap items-end gap-3">
          <SettingNum
            label="Cutting Offset (days before sewing)"
            value={settings.cutOffset}
            onChange={(v) => setField("cutOffset", v)}
            tone="orange"
          />
          <SettingText
            label="Cutting LC % (comma-sep)"
            value={settings.cutLC}
            onChange={(v) => setField("cutLC", v)}
            tone="orange"
            placeholder="30,60,80,100"
          />
          <SettingNum
            label="Finishing Offset (days after sewing)"
            value={settings.finOffset}
            onChange={(v) => setField("finOffset", v)}
            tone="sky"
          />
          <SettingText
            label="Finishing LC %"
            value={settings.finLC}
            onChange={(v) => setField("finLC", v)}
            tone="sky"
            placeholder="40,70,100"
          />
          <SettingNum
            label="Packing Offset (days after sewing)"
            value={settings.packOffset}
            onChange={(v) => setField("packOffset", v)}
            tone="fuchsia"
          />
          <SettingText
            label="Packing LC %"
            value={settings.packLC}
            onChange={(v) => setField("packLC", v)}
            tone="fuchsia"
            placeholder="40,70,100"
          />
          <button
            onClick={() => setSettings(DEFAULTS)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-border bg-panel hover:bg-panel-2 text-xs font-semibold text-muted-foreground"
            title="Reset to defaults"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset
          </button>
        </div>
      </div>

      {plan && computed && (
        <div className="p-4 md:p-6">
          <div className="mb-4 flex flex-wrap gap-2 text-xs">
            <Badge label="Total Qty" value={computed.total.toLocaleString()} tone="emerald" />
            <Badge label="Lines" value={String(computed.numLines)} tone="blue" />
            <Badge
              label="Daily Cap (all lines)"
              value={computed.dailyCap.toLocaleString()}
              tone="amber"
            />
          </div>
          <div className="overflow-auto max-h-[75vh]">
            <table className="w-full text-sm border-collapse">
              <thead className="bg-panel-2 text-muted-foreground text-xs uppercase tracking-wider">
                <tr>
                  <th className="p-2.5 border border-border text-left sticky left-0 top-0 bg-panel-2 z-30">
                    Date
                  </th>
                  <th className="p-2.5 border border-border text-center sticky left-[92px] top-0 bg-panel-2 z-30">
                    Day
                  </th>
                  <th className="p-2.5 border border-border text-center text-orange-300 sticky top-0 bg-panel-2 z-20">
                    Day Cutting
                  </th>
                  <th className="p-2.5 border border-border text-center text-orange-300 sticky top-0 bg-panel-2 z-20">
                    Cum Cutting
                  </th>
                  {computed.lineNames.map((ln) => (
                    <th
                      key={`h-${ln}`}
                      className="p-2.5 border border-border text-center text-emerald-300 whitespace-nowrap sticky top-0 bg-panel-2 z-20"
                    >
                      {ln}
                    </th>
                  ))}
                  <th className="p-2.5 border border-border text-center text-emerald-300 sticky top-0 bg-panel-2 z-20">
                    Total Sewing
                  </th>
                  <th className="p-2.5 border border-border text-center text-emerald-300 sticky top-0 bg-panel-2 z-20">
                    Cum Sewing
                  </th>
                  <th className="p-2.5 border border-border text-center text-sky-300 sticky top-0 bg-panel-2 z-20">
                    Day Finishing
                  </th>
                  <th className="p-2.5 border border-border text-center text-sky-300 sticky top-0 bg-panel-2 z-20">
                    Cum Finishing
                  </th>
                  <th className="p-2.5 border border-border text-center text-fuchsia-300 sticky top-0 bg-panel-2 z-20">
                    Day Packing
                  </th>
                  <th className="p-2.5 border border-border text-center text-fuchsia-300 sticky top-0 bg-panel-2 z-20">
                    Cum Packing
                  </th>
                </tr>
              </thead>
              <tbody>
                {computed.rows.map((r) => {
                  const d = new Date(r.date);
                  const dayName = d.toLocaleDateString("en-US", { weekday: "short" });
                  const isFri = d.getDay() === 5;
                  const rowBg = isFri ? "bg-red-950/60" : "bg-panel";
                  return (
                    <tr key={r.date} className={isFri ? "bg-red-950/30" : "hover:bg-panel-2/30"}>
                      <td
                        className={`p-2 border border-border font-bold sticky left-0 z-10 ${rowBg}`}
                      >
                        {formatDate(r.date)}
                      </td>
                      <td
                        className={`p-2 border border-border text-center text-muted-foreground sticky left-[92px] z-10 ${rowBg}`}
                      >
                        {dayName}
                      </td>
                      <Cell v={r.dc} tone="orange" sources={r.srcCut} />
                      <Cell v={r.cCut} tone="orange" cum />
                      {computed.lineNames.map((ln) => (
                        <Cell key={`${r.date}-${ln}`} v={r.sewByLine[ln] ?? 0} tone="emerald" />
                      ))}
                      <Cell v={r.ds} tone="emerald" cum />
                      <Cell v={r.cSew} tone="emerald" cum />
                      <Cell v={r.df} tone="sky" sources={r.srcFin} />
                      <Cell v={r.cFin} tone="sky" cum />
                      <Cell v={r.dp} tone="fuchsia" sources={r.srcPack} />
                      <Cell v={r.cPack} tone="fuchsia" cum />
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function PlanPicker({
  plans,
  value,
  onChange,
}: {
  plans: FriPlan[];
  value: string;
  onChange: (id: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const selected = plans.find((p) => p.id === value);
  const filtered = plans.filter((p) =>
    `${p.buyer} ${p.style}`.toLowerCase().includes(q.trim().toLowerCase()),
  );
  return (
    <div className="relative min-w-[240px]">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full text-left rounded-lg border border-border bg-input px-3 py-2 text-sm font-bold text-foreground"
      >
        {selected ? `${selected.buyer} — ${selected.style}` : "Select plan"}
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute z-50 mt-1 w-full rounded-lg border border-border bg-panel shadow-xl">
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search buyer / style..."
              className="w-full rounded-t-lg border-b border-border bg-input px-3 py-2 text-sm text-foreground"
            />
            <div className="max-h-64 overflow-auto">
              {filtered.length === 0 && (
                <div className="px-3 py-2 text-xs text-muted-foreground">No match</div>
              )}
              {filtered.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    onChange(p.id);
                    setOpen(false);
                    setQ("");
                  }}
                  className={`block w-full text-left px-3 py-2 text-sm hover:bg-panel-2 ${
                    p.id === value ? "text-cyan-300 font-bold" : "text-foreground"
                  }`}
                >
                  {p.buyer} — {p.style}
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function SettingNum({
  label,
  value,
  onChange,
  tone,
}: {
  label: string;
  value: number | string;
  onChange: (v: number) => void;
  tone: "orange" | "sky" | "fuchsia";
}) {
  const border: Record<string, string> = {
    orange: "border-orange-600/40",
    sky: "border-sky-600/40",
    fuchsia: "border-fuchsia-600/40",
  };
  return (
    <label className="flex flex-col gap-1">
      <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <input
        type="number"
        min={0}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className={`w-20 rounded-md border ${border[tone]} bg-input px-2 py-1.5 text-sm font-bold text-foreground`}
      />
    </label>
  );
}

function SettingText({
  label,
  value,
  onChange,
  tone,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  tone: "orange" | "sky" | "fuchsia";
  placeholder?: string;
}) {
  const border: Record<string, string> = {
    orange: "border-orange-600/40",
    sky: "border-sky-600/40",
    fuchsia: "border-fuchsia-600/40",
  };
  return (
    <label className="flex flex-col gap-1">
      <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <input
        type="text"
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className={`w-36 rounded-md border ${border[tone]} bg-input px-2 py-1.5 text-sm font-mono text-foreground`}
      />
    </label>
  );
}

function Badge({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "emerald" | "blue" | "amber";
}) {
  const map: Record<string, string> = {
    emerald: "bg-emerald-950/60 border-emerald-600/50 text-emerald-300",
    blue: "bg-blue-950/60 border-blue-600/50 text-blue-300",
    amber: "bg-amber-950/60 border-amber-600/50 text-amber-300",
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border font-semibold ${map[tone]}`}
    >
      <span className="opacity-70">{label}:</span> {value}
    </span>
  );
}

function Cell({
  v,
  tone,
  cum,
}: {
  v: number;
  tone: "orange" | "emerald" | "sky" | "fuchsia";
  cum?: boolean;
  sources?: SrcItem[];
}) {
  const map: Record<string, string> = {
    orange: "text-orange-200",
    emerald: "text-emerald-200",
    sky: "text-sky-200",
    fuchsia: "text-fuchsia-200",
  };
  if (!v) {
    return <td className="p-2 border border-border text-center text-muted-foreground/40">-</td>;
  }
  return (
    <td
      className={`p-2 border border-border text-center ${cum ? "font-bold bg-panel-2/40" : "font-semibold"} ${map[tone]}`}
    >
      <div>{v.toLocaleString()}</div>
    </td>
  );
}
