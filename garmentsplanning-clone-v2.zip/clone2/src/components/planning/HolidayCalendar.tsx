import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/hooks/use-current-user";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { X, ChevronLeft, ChevronRight, Loader2, CalendarDays } from "lucide-react";

type HolidayRow = { date: string; label: string | null };

function pad(n: number) {
  return String(n).padStart(2, "0");
}
function toDateStr(y: number, m: number, d: number) {
  return `${y}-${pad(m + 1)}-${pad(d)}`;
}

export function useGlobalHolidays() {
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: ["global_holidays"],
    queryFn: async (): Promise<string[]> => {
      const { data, error } = await supabase.from("global_holidays").select("date").order("date");
      if (error) throw error;
      return (data ?? []).map((r) => r.date as string);
    },
    staleTime: 60_000,
  });

  useEffect(() => {
    const ch = supabase
      .channel("global_holidays-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "global_holidays" }, () =>
        qc.invalidateQueries({ queryKey: ["global_holidays"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  return query;
}

export function HolidayCalendarDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { data: user } = useCurrentUser();
  const isAdmin = user?.role === "admin";
  const qc = useQueryClient();

  const now = new Date();
  const [cursor, setCursor] = useState({ y: now.getFullYear(), m: now.getMonth() });

  const { data: holidayRows = [], isLoading } = useQuery({
    queryKey: ["global_holidays_full"],
    queryFn: async (): Promise<HolidayRow[]> => {
      const { data, error } = await supabase
        .from("global_holidays")
        .select("date,label")
        .order("date");
      if (error) throw error;
      return (data ?? []) as HolidayRow[];
    },
    enabled: open,
  });

  const holidaySet = useMemo(() => new Set(holidayRows.map((r) => r.date)), [holidayRows]);

  async function toggleDate(dateStr: string) {
    if (!isAdmin) {
      toast.error("শুধুমাত্র অ্যাডমিন ছুটি যোগ/মুছতে পারবেন।");
      return;
    }
    try {
      if (holidaySet.has(dateStr)) {
        const { error } = await supabase.from("global_holidays").delete().eq("date", dateStr);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("global_holidays")
          // biome-ignore lint/suspicious/noExplicitAny: insert payload
          .insert({ date: dateStr, created_by: user?.id } as any);
        if (error) throw error;
      }
      qc.invalidateQueries({ queryKey: ["global_holidays"] });
      qc.invalidateQueries({ queryKey: ["global_holidays_full"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "সেভ করা যায়নি।");
    }
  }

  if (!open) return null;

  // Render 2 months side by side per row, total 24 months from current month
  const months: Array<{ y: number; m: number }> = [];
  for (let i = 0; i < 24; i++) {
    const d = new Date(cursor.y, cursor.m + i, 1);
    months.push({ y: d.getFullYear(), m: d.getMonth() });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="bg-panel border border-border rounded-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h2 className="text-base md:text-lg font-extrabold bn-gradient-text flex items-center gap-2">
            <CalendarDays className="w-5 h-5" /> কাস্টম ছুটির ক্যালেন্ডার (২ বছর)
          </h2>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const d = new Date(cursor.y, cursor.m - 2, 1);
                setCursor({ y: d.getFullYear(), m: d.getMonth() });
              }}
              className="p-1.5 rounded border border-border hover:bg-panel-2"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                const d = new Date(cursor.y, cursor.m + 2, 1);
                setCursor({ y: d.getFullYear(), m: d.getMonth() });
              }}
              className="p-1.5 rounded border border-border hover:bg-panel-2"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded border border-border hover:bg-red-500/20 hover:text-red-400"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {!isAdmin && (
          <div className="px-4 py-2 text-[11px] text-yellow-300 bg-yellow-500/10 border-b border-yellow-500/30">
            ⚠️ শুধুমাত্র অ্যাডমিন ছুটি যোগ/মুছতে পারবেন। এই ছুটিগুলো সমস্ত প্ল্যানে অটোমেটিক
            প্রযোজ্য হবে।
          </div>
        )}

        <div className="p-4 overflow-y-auto flex-1">
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-5 h-5 animate-spin" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {months.map(({ y, m }) => (
                <MonthGrid
                  key={`${y}-${m}`}
                  year={y}
                  month={m}
                  holidaySet={holidaySet}
                  onToggle={toggleDate}
                  interactive={isAdmin}
                />
              ))}
            </div>
          )}
        </div>

        <div className="p-3 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="inline-block w-3 h-3 rounded bg-red-500/70" /> ছুটি
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block w-3 h-3 rounded bg-amber-500/60" /> শুক্রবার (সাপ্তাহিক)
            </span>
          </div>
          <span>মোট ছুটি: {holidayRows.length}</span>
        </div>
      </div>
    </div>
  );
}

function MonthGrid({
  year,
  month,
  holidaySet,
  onToggle,
  interactive,
}: {
  year: number;
  month: number;
  holidaySet: Set<string>;
  onToggle: (d: string) => void;
  interactive: boolean;
}) {
  const first = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const startDay = first.getDay(); // 0=Sun
  const cells: Array<{ day: number; dateStr: string } | null> = [];
  for (let i = 0; i < startDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push({ day: d, dateStr: toDateStr(year, month, d) });

  const monthName = first.toLocaleString("en-US", { month: "long", year: "numeric" });
  const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  return (
    <div className="border border-border rounded-xl bg-panel-2/50 p-3">
      <div className="text-sm font-bold text-foreground mb-2">{monthName}</div>
      <div className="grid grid-cols-7 gap-1 text-[10px] text-muted-foreground mb-1">
        {weekdays.map((w) => (
          <div key={w} className="text-center">
            {w}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {cells.map((c, i) => {
          if (!c) return <div key={i} />;
          const isFriday = new Date(year, month, c.day).getDay() === 5;
          const isHoliday = holidaySet.has(c.dateStr);
          return (
            <button
              key={i}
              type="button"
              disabled={!interactive}
              onClick={() => onToggle(c.dateStr)}
              className={`aspect-square rounded text-xs font-mono border transition ${
                isHoliday
                  ? "bg-red-500/70 border-red-400 text-white font-bold"
                  : isFriday
                    ? "bg-amber-500/30 border-amber-500/40 text-amber-200"
                    : "bg-input border-border hover:bg-panel"
              } ${interactive ? "cursor-pointer" : "cursor-not-allowed opacity-90"}`}
              title={c.dateStr}
            >
              {c.day}
            </button>
          );
        })}
      </div>
    </div>
  );
}
