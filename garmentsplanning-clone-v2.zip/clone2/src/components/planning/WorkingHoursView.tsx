import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Clock, Loader2, Play, Save, AlertTriangle, ArrowRight } from "lucide-react";
import {
  calculatePlan,
  formatDate,
  nextWorkingDay,
  type LineInput,
  type PlanResult,
  type TargetAdjustment,
} from "@/lib/plan-calc";
import { useGlobalHolidays } from "./HolidayCalendar";
import { useLinePresets } from "@/hooks/use-line-presets";
import {
  buildLinePresetLookup,
  canonicalLineName,
  normLine,
  sortLineNamesByPreset,
  uniqueCanonicalLineNames,
} from "./lineLookup";

type SavedPlan = {
  id: string;
  buyer: string;
  style: string;
  order_qty: number;
  excess_pct: number;
  daily_target: number;
  num_lines: number;
  shipment_date: string;
  config: {
    lines: LineInput[];
    customHolidays: string[];
    targetAdjustments: TargetAdjustment[];
    targetAdjustmentsEnabled: boolean;
  };
  calc_result: PlanResult;
  created_by: string;
};

// Line presets now come from `public.line_presets` via useLinePresets.

type PlanChange = {
  id: string;
  buyer: string;
  style: string;
  lineName: string;
  oldFirst: string;
  newFirst: string;
  deltaDays: number; // negative = advance, positive = pushback
  cascade?: boolean;
};

type SimResult = {
  changes: PlanChange[];
  dirty: Record<string, SavedPlan>;
};

function firstOutputByLine(plan: SavedPlan, lineName: string): string {
  const l = plan.calc_result?.lines?.find((x) => x.name === lineName);
  const dp = l?.dailyProduction ?? [];
  return dp[0]?.date ?? l?.startDateStr ?? "";
}

function daysBetween(a: string, b: string): number {
  if (!a || !b) return 0;
  return Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400000);
}

function recomputePlan(p: SavedPlan, mergedGlobalHolidays: string[]): PlanResult {
  const merged = Array.from(
    new Set([...(mergedGlobalHolidays ?? []), ...(p.config?.customHolidays ?? [])]),
  );
  return calculatePlan({
    buyer: p.buyer,
    style: p.style,
    orderQty: p.order_qty,
    excessPct: Number(p.excess_pct),
    dailyTargetPerLine: p.daily_target,
    shipmentDate: p.shipment_date,
    lines: p.config.lines,
    customHolidays: merged,
    targetAdjustments: p.config.targetAdjustments ?? [],
    targetAdjustmentsEnabled: !!p.config.targetAdjustmentsEnabled,
  });
}

export function WorkingHoursView() {
  const qc = useQueryClient();
  const { data: globalHolidays = [] } = useGlobalHolidays();

  const [selectedLines, setSelectedLines] = useState<string[]>([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [oldHours, setOldHours] = useState<number | "">(10);
  const [newHours, setNewHours] = useState<number | "">(9);
  const [preview, setPreview] = useState<SimResult | null>(null);
  const [applying, setApplying] = useState(false);
  const { presets: linePresets } = useLinePresets();
  const presetLookup = useMemo(() => buildLinePresetLookup(linePresets), [linePresets]);
  const selectedLineKeys = useMemo(
    () => new Set(selectedLines.map((name) => normLine(name))),
    [selectedLines],
  );

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "full"],
    queryFn: async (): Promise<SavedPlan[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("*")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as SavedPlan[];
    },
  });

  // Merge preset names with names actually used in plans
  const availableLines = useMemo(() => {
    const rawNames = [...linePresets];
    for (const p of plans) for (const l of p.config?.lines ?? []) rawNames.push(l.name);
    return uniqueCanonicalLineNames(rawNames, linePresets);
  }, [plans, linePresets]);

  const scale = useMemo(() => {
    const o = Number(oldHours),
      n = Number(newHours);
    if (!o || !n) return 0;
    return n / o;
  }, [oldHours, newHours]);

  function toggleLine(name: string) {
    setSelectedLines((prev) =>
      prev.includes(name) ? prev.filter((x) => x !== name) : [...prev, name],
    );
    setPreview(null);
  }

  function selectAll() {
    setSelectedLines(availableLines);
    setPreview(null);
  }
  function clearAll() {
    setSelectedLines([]);
    setPreview(null);
  }

  function simulate(): SimResult {
    if (selectedLines.length === 0 || !fromDate || !toDate || !scale) {
      return { changes: [], dirty: {} };
    }
    // Deep-clone all plans so we can mutate freely
    const workspace: SavedPlan[] = JSON.parse(JSON.stringify(plans));
    const byId: Record<string, SavedPlan> = Object.fromEntries(workspace.map((p) => [p.id, p]));
    const originalFirst: Record<string, Record<string, string>> = {};
    for (const p of plans) {
      originalFirst[p.id] = {};
      for (const l of p.config?.lines ?? []) {
        originalFirst[p.id][l.name] = firstOutputByLine(p, l.name);
      }
    }

    const dirty: Record<string, SavedPlan> = {};
    const changes: PlanChange[] = [];

    // Step 1: Apply proportional target adjustment to every plan/line that
    // has production in the selected date range.
    for (const p of workspace) {
      let touched = false;
      for (const l of p.config?.lines ?? []) {
        if (!selectedLineKeys.has(normLine(l.name))) continue;
        // Check if this line has any production day inside [fromDate, toDate]
        const rline = p.calc_result?.lines?.find((x) => x.name === l.name);
        const overlaps = (rline?.dailyProduction ?? []).some(
          (d) => d.date >= fromDate && d.date <= toDate,
        );
        if (!overlaps) continue;

        // Determine current effective target for this line (mid-range).
        const midDate = fromDate; // pick the first day inside range
        const existingAdj = (p.config.targetAdjustments ?? []).find(
          (a) => a.lineName === l.name && midDate >= a.fromDate && midDate <= a.toDate,
        );
        const currentTarget =
          !!p.config.targetAdjustmentsEnabled && existingAdj
            ? existingAdj.newTarget
            : p.daily_target;
        const newTarget = Math.max(1, Math.round(currentTarget * scale));

        const newAdj: TargetAdjustment = {
          id: Date.now() + Math.floor(Math.random() * 1e6),
          lineName: canonicalLineName(l.name, presetLookup),
          fromDate,
          toDate,
          newTarget,
        };
        // Prepend so this takes precedence over any older overlapping adjustment
        p.config.targetAdjustments = [newAdj, ...(p.config.targetAdjustments ?? [])];
        p.config.targetAdjustmentsEnabled = true;
        touched = true;
      }
      if (touched) {
        p.calc_result = recomputePlan(p, globalHolidays ?? []);
        dirty[p.id] = p;
      }
    }

    // Step 2: Force cascade — for every line, sort plans on that line by their
    // ORIGINAL start date and chain them: each subsequent plan's start = next
    // working day after previous plan's finish. Ignores chainAuto, and pulls
    // BACK when advancing (both directions).
    const lineNames = new Set<string>();
    for (const p of workspace) for (const l of p.config?.lines ?? []) lineNames.add(l.name);

    // Preserve original ordering by pre-computing original startDateStr per plan+line
    const origStart: Record<string, Record<string, string>> = {};
    for (const p of plans) {
      origStart[p.id] = {};
      for (const l of p.config?.lines ?? []) origStart[p.id][l.name] = l.startDateStr;
    }

    for (const lineName of lineNames) {
      const chain = workspace
        .filter((p) => (p.config?.lines ?? []).some((l) => l.name === lineName))
        .sort((a, b) =>
          (origStart[a.id]?.[lineName] ?? "").localeCompare(origStart[b.id]?.[lineName] ?? ""),
        );
      if (chain.length < 2) continue;

      for (let i = 1; i < chain.length; i++) {
        const prev = byId[chain[i - 1].id];
        const cur = byId[chain[i].id];
        const prevLine = prev.calc_result?.lines?.find((l) => l.name === lineName);
        if (!prevLine?.finishDateStr) continue;
        const idx = cur.config.lines.findIndex((l) => l.name === lineName);
        if (idx < 0) continue;

        const merged = Array.from(
          new Set([...(globalHolidays ?? []), ...(cur.config.customHolidays ?? [])]),
        );
        const desired = nextWorkingDay(prevLine.finishDateStr, merged);
        if (desired === cur.config.lines[idx].startDateStr) continue;

        cur.config.lines[idx] = { ...cur.config.lines[idx], startDateStr: desired };
        cur.calc_result = recomputePlan(cur, globalHolidays ?? []);
        dirty[cur.id] = cur;
      }
    }

    // Step 3: Build change report — compare each affected line's 1st output.
    for (const id of Object.keys(dirty)) {
      const p = byId[id];
      for (const l of p.config?.lines ?? []) {
        const oldF = originalFirst[id]?.[l.name];
        const newF = firstOutputByLine(p, l.name);
        if (!oldF || !newF || oldF === newF) continue;
        const delta = daysBetween(oldF, newF);
        changes.push({
          id,
          buyer: p.buyer,
          style: p.style,
          lineName: l.name,
          oldFirst: oldF,
          newFirst: newF,
          deltaDays: delta,
          cascade:
            !selectedLineKeys.has(normLine(l.name)) || newF < fromDate || newF > toDate
              ? true
              : false,
        });
      }
    }
    const lineOrder = new Map(
      sortLineNamesByPreset(
        changes.map((c) => c.lineName),
        linePresets,
      ).map((line, index) => [line, index]),
    );
    changes.sort(
      (a, b) =>
        (lineOrder.get(a.lineName) ?? 0) - (lineOrder.get(b.lineName) ?? 0) ||
        a.newFirst.localeCompare(b.newFirst),
    );
    return { changes, dirty };
  }

  function handlePreview() {
    if (selectedLines.length === 0) return toast.error("অন্তত একটি লাইন সিলেক্ট করুন।");
    if (!fromDate || !toDate) return toast.error("Date range দিন।");
    if (fromDate > toDate) return toast.error("From date, To date এর পরে হতে পারবে না।");
    if (!oldHours || !newHours) return toast.error("Old ও New working hours দিন।");
    const sim = simulate();
    setPreview(sim);
    if (sim.changes.length === 0) toast.info("এই সিলেকশনে কোন style এর 1st output বদলাচ্ছে না।");
  }

  async function handleApply() {
    if (!preview || Object.keys(preview.dirty).length === 0) {
      toast.error("আগে Preview চালান।");
      return;
    }
    const ok = window.confirm(
      `${Object.keys(preview.dirty).length} টি প্ল্যানের target/schedule আপডেট হবে। এগোবেন?`,
    );
    if (!ok) return;
    setApplying(true);
    try {
      for (const id of Object.keys(preview.dirty)) {
        const p = preview.dirty[id];
        // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
        const { error } = await supabase
          .from("plans")
          .update({ config: p.config, calc_result: p.calc_result as any } as any)
          .eq("id", id);
        if (error) throw error;
      }
      toast.success(`✅ ${Object.keys(preview.dirty).length} টি প্ল্যান আপডেট হয়েছে।`);
      qc.invalidateQueries({ queryKey: ["plans"] });
      setPreview(null);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "আপডেট করা যায়নি।");
    } finally {
      setApplying(false);
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-10">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  const advances = preview?.changes.filter((c) => c.deltaDays < 0) ?? [];
  const pushbacks = preview?.changes.filter((c) => c.deltaDays > 0) ?? [];

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-panel/70 p-5 md:p-6">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="w-5 h-5 text-cyan-400" />
          <h2 className="text-base md:text-lg font-extrabold bn-gradient-text">
            ⏱️ Working Hours পরিবর্তন
          </h2>
        </div>
        <p className="text-xs text-muted-foreground mb-5 leading-relaxed">
          একাধিক লাইন সিলেক্ট করে date range দিন, তারপর পুরনো ও নতুন working hours দিন। Target
          proportional scale হবে (new_target = old_target × new_hours / old_hours) এবং সব downstream
          style এর start date force-shift হবে (advance বা pushback)।
        </p>

        {/* Line selection */}
        <div className="mb-5">
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-bold text-muted-foreground">লাইন সিলেক্ট করুন</label>
            <div className="flex gap-2">
              <button
                onClick={selectAll}
                className="text-[11px] px-2 py-1 rounded bg-input hover:bg-panel-2 border border-border"
              >
                All
              </button>
              <button
                onClick={clearAll}
                className="text-[11px] px-2 py-1 rounded bg-input hover:bg-panel-2 border border-border"
              >
                None
              </button>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {availableLines.map((name) => {
              const on = selectedLines.includes(name);
              return (
                <button
                  key={name}
                  onClick={() => toggleLine(name)}
                  className={`text-xs px-3 py-1.5 rounded-lg border font-semibold transition ${
                    on
                      ? "bg-cyan-600 text-white border-cyan-500"
                      : "bg-input text-muted-foreground border-border hover:bg-panel-2"
                  }`}
                >
                  {name}
                </button>
              );
            })}
          </div>
          <div className="text-[11px] text-muted-foreground mt-2">
            সিলেক্টেড: {selectedLines.length} / {availableLines.length}
          </div>
        </div>

        {/* Range + hours */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
          <div>
            <label className="text-[11px] font-bold text-muted-foreground">From</label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => {
                setFromDate(e.target.value);
                setPreview(null);
              }}
              className="mt-1 w-full rounded-lg border border-border bg-input px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="text-[11px] font-bold text-muted-foreground">To</label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => {
                setToDate(e.target.value);
                setPreview(null);
              }}
              className="mt-1 w-full rounded-lg border border-border bg-input px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="text-[11px] font-bold text-muted-foreground">Old hours</label>
            <input
              type="number"
              min={1}
              step="0.5"
              value={oldHours}
              onChange={(e) => {
                setOldHours(e.target.value === "" ? "" : Number(e.target.value));
                setPreview(null);
              }}
              className="mt-1 w-full rounded-lg border border-border bg-input px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="text-[11px] font-bold text-muted-foreground">New hours</label>
            <input
              type="number"
              min={1}
              step="0.5"
              value={newHours}
              onChange={(e) => {
                setNewHours(e.target.value === "" ? "" : Number(e.target.value));
                setPreview(null);
              }}
              className="mt-1 w-full rounded-lg border border-border bg-input px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="text-[11px] font-bold text-muted-foreground">Scale</label>
            <div className="mt-1 rounded-lg border border-border bg-input px-3 py-2 text-sm font-mono">
              {scale ? `× ${scale.toFixed(3)}` : "—"}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={handlePreview}
            className="inline-flex items-center gap-2 rounded-xl bg-cyan-600 px-4 py-2 text-sm font-bold text-white hover:bg-cyan-500 transition"
          >
            <Play className="w-4 h-4" /> Preview
          </button>
          <button
            onClick={handleApply}
            disabled={!preview || Object.keys(preview.dirty).length === 0 || applying}
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-bold text-white hover:bg-emerald-500 transition disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {applying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Apply
          </button>
        </div>
      </div>

      {/* Preview report */}
      {preview && (
        <div className="rounded-2xl border border-border bg-panel/70 p-5 md:p-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-extrabold">Preview — 1st Output Shift</h3>
            <span className="ml-auto text-[11px] text-muted-foreground">
              {preview.changes.length} shifts · {Object.keys(preview.dirty).length} plans
            </span>
          </div>

          {preview.changes.length === 0 ? (
            <div className="text-xs text-muted-foreground py-6 text-center">
              কোনো style এর 1st output পরিবর্তন হচ্ছে না।
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3">
                  <div className="text-[11px] text-emerald-300 font-bold mb-1">
                    ⏩ Advanced ({advances.length})
                  </div>
                  <div className="text-xs text-muted-foreground">
                    যেসব style এর 1st output এগিয়ে এসেছে
                  </div>
                </div>
                <div className="rounded-lg border border-rose-500/30 bg-rose-500/5 p-3">
                  <div className="text-[11px] text-rose-300 font-bold mb-1">
                    ⏪ Pushed back ({pushbacks.length})
                  </div>
                  <div className="text-xs text-muted-foreground">
                    যেসব style এর 1st output পিছিয়ে গেছে
                  </div>
                </div>
              </div>

              <div className="overflow-auto max-h-[60vh] rounded-lg border border-border">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-panel-2 z-10">
                    <tr className="text-left">
                      <th className="px-3 py-2 font-bold">Line</th>
                      <th className="px-3 py-2 font-bold">Buyer / Style</th>
                      <th className="px-3 py-2 font-bold">Old 1st Output</th>
                      <th className="px-3 py-2 font-bold"></th>
                      <th className="px-3 py-2 font-bold">New 1st Output</th>
                      <th className="px-3 py-2 font-bold text-right">Δ Days</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.changes.map((c, i) => (
                      <tr key={i} className="border-t border-border">
                        <td className="px-3 py-2 font-semibold">
                          {c.lineName.startsWith("Line - ")
                            ? c.lineName.replace("Line - ", "")
                            : c.lineName}
                        </td>
                        <td className="px-3 py-2">
                          {c.buyer} <span className="text-muted-foreground">/ {c.style}</span>
                        </td>
                        <td className="px-3 py-2 font-mono text-muted-foreground">
                          {formatDate(c.oldFirst)}
                        </td>
                        <td className="px-3 py-2 text-muted-foreground">
                          <ArrowRight className="w-3 h-3" />
                        </td>
                        <td
                          className={`px-3 py-2 font-mono font-bold ${c.deltaDays < 0 ? "text-emerald-300" : "text-rose-300"}`}
                        >
                          {formatDate(c.newFirst)}
                        </td>
                        <td
                          className={`px-3 py-2 text-right font-mono font-bold ${c.deltaDays < 0 ? "text-emerald-300" : "text-rose-300"}`}
                        >
                          {c.deltaDays < 0
                            ? `${Math.abs(c.deltaDays)} দিন এগিয়ে`
                            : `${c.deltaDays} দিন পিছিয়ে`}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
