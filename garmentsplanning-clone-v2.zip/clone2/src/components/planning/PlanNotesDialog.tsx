import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { StickyNote, Trash2, X, Plus } from "lucide-react";

type Note = {
  id: string;
  plan_id: string;
  note_date: string;
  note: string;
  created_by: string;
  created_at: string;
};

type Props = {
  open: boolean;
  onClose: () => void;
  planId: string | null;
  planLabel?: string;
};

export function PlanNotesDialog({ open, onClose, planId, planLabel }: Props) {
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(false);
  const [noteDate, setNoteDate] = useState(new Date().toISOString().slice(0, 10));
  const [noteText, setNoteText] = useState("");
  const [saving, setSaving] = useState(false);
  const [userMap, setUserMap] = useState<Record<string, string>>({});
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  useEffect(() => {
    if (!open || !planId) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data: udata } = await supabase.auth.getUser();
      if (!cancelled) setCurrentUser(udata.user?.id ?? null);
      const { data, error } = await supabase
        .from("plan_notes")
        .select("*")
        .eq("plan_id", planId)
        .order("note_date", { ascending: false })
        .order("created_at", { ascending: false });
      if (cancelled) return;
      if (error) {
        toast.error("নোট লোড ব্যর্থ: " + error.message);
        setNotes([]);
      } else {
        setNotes((data ?? []) as Note[]);
        const ids = Array.from(new Set((data ?? []).map((n) => n.created_by)));
        if (ids.length) {
          const { data: profs } = await supabase
            .from("profiles")
            .select("id,username")
            .in("id", ids);
          const map: Record<string, string> = {};
          (profs ?? []).forEach((p) => (map[p.id] = p.username || ""));
          if (!cancelled) setUserMap(map);
        }
      }
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [open, planId]);

  const addNote = async () => {
    if (!planId || !noteText.trim()) {
      toast.error("নোট লিখুন");
      return;
    }
    const { data: udata } = await supabase.auth.getUser();
    if (!udata.user) return;
    setSaving(true);
    const { data, error } = await supabase
      .from("plan_notes")
      .insert({
        plan_id: planId,
        note_date: noteDate,
        note: noteText.trim(),
        created_by: udata.user.id,
      })
      .select()
      .single();
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setNotes((n) => [data as Note, ...n]);
    setNoteText("");
    toast.success("নোট যোগ হয়েছে");
  };

  const deleteNote = async (id: string) => {
    if (!confirm("এই নোট ডিলিট করবেন?")) return;
    const { error } = await supabase.from("plan_notes").delete().eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    setNotes((n) => n.filter((x) => x.id !== id));
  };

  if (!open) return null;

  const grouped: Record<string, Note[]> = {};
  for (const n of notes) {
    (grouped[n.note_date] ||= []).push(n);
  }
  const dates = Object.keys(grouped).sort((a, b) => (a < b ? 1 : -1));

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[90vh] bg-background border border-border rounded-2xl shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <StickyNote className="w-5 h-5 text-yellow-400" />
            <div>
              <div className="font-bold text-sm">স্টাইল নোটস (তারিখ ভিত্তিক)</div>
              {planLabel && <div className="text-[11px] text-muted-foreground">{planLabel}</div>}
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded hover:bg-panel-2">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 border-b border-border bg-panel-2/30">
          <div className="flex gap-2 items-end flex-wrap">
            <div>
              <label className="block text-[10px] text-muted-foreground mb-1">তারিখ</label>
              <input
                type="date"
                value={noteDate}
                onChange={(e) => setNoteDate(e.target.value)}
                className="bg-input border border-border rounded p-2 text-xs"
              />
            </div>
            <div className="flex-1 min-w-[200px]">
              <label className="block text-[10px] text-muted-foreground mb-1">নোট</label>
              <textarea
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                placeholder="এই স্টাইলে আজকের ইস্যু / আপডেট / রিমার্ক..."
                rows={2}
                className="w-full bg-input border border-border rounded p-2 text-xs outline-none focus:border-primary resize-y"
              />
            </div>
            <button
              onClick={addNote}
              disabled={saving}
              className="px-3 py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 disabled:opacity-50"
            >
              <Plus className="w-3.5 h-3.5" /> যোগ করুন
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-4 space-y-4">
          {loading ? (
            <div className="text-center text-muted-foreground text-xs py-8">লোড হচ্ছে...</div>
          ) : dates.length === 0 ? (
            <div className="text-center text-muted-foreground text-xs py-8">
              এখনো কোনো নোট নেই। উপরে থেকে যোগ করুন।
            </div>
          ) : (
            dates.map((d) => (
              <div key={d}>
                <div className="text-[11px] font-bold text-blue-400 mb-2 sticky top-0 bg-background py-1">
                  📅{" "}
                  {new Date(d).toLocaleDateString("en-GB", {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                  })}
                </div>
                <div className="space-y-2">
                  {grouped[d].map((n) => (
                    <div
                      key={n.id}
                      className="p-3 rounded-lg bg-panel-2/50 border border-border flex gap-2 items-start"
                    >
                      <div className="flex-1 text-xs whitespace-pre-wrap">{n.note}</div>
                      <div className="flex flex-col items-end gap-1">
                        <div className="text-[10px] text-muted-foreground">
                          {userMap[n.created_by] || "user"}
                        </div>
                        {n.created_by === currentUser && (
                          <button
                            onClick={() => deleteNote(n.id)}
                            className="p-1 rounded bg-red-600/20 border border-red-600/40 text-red-400 hover:bg-red-600/40"
                            title="ডিলিট"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
