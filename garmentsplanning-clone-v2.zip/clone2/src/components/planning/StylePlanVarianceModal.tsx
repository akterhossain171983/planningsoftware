import { useMemo, useState } from "react";
import {
  X,
  Search,
  Scale,
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Pencil,
  RotateCcw,
  Trash2,
  Loader2,
  SlidersHorizontal,
  Scissors,
} from "lucide-react";
import { formatDate } from "@/lib/plan-calc";

export type StyleVarianceItem = {
  styleKey: string;
  style: string;
  buyer: string;
  orderQty: number;
  plannedQty: number;
  diffQty: number;
  diffPct: number;
  status: "over" | "under" | "exact";
  excessPct: number;
  planIds: string[];
  lines: Array<{
    planId: string;
    lineName: string;
    rawLine: string;
    qty: number;
    start: string;
    end: string;
    dailyTarget?: number;
  }>;
};

type StylePlanVarianceModalProps = {
  open: boolean;
  onClose: () => void;
  variances: StyleVarianceItem[];
  onEditPlan: (planId: string) => void;
  onAutoFixPlan: (planId: string) => Promise<void>;
  onUnplan: (planId: string, style: string, buyer: string) => void;
  onDeletePlan?: (planId: string, style: string) => void;
  onSplitPlan?: (
    planId: string,
    style: string,
    buyer: string,
    orderQty: number,
    plannedQty: number,
    currentLine?: string,
  ) => void;
  fixingPlanId: string | null;
};

export function StylePlanVarianceModal({
  open,
  onClose,
  variances,
  onEditPlan,
  onAutoFixPlan,
  onUnplan,
  onDeletePlan,
  onSplitPlan,
  fixingPlanId,
}: StylePlanVarianceModalProps) {
  const [tab, setTab] = useState<"all" | "over" | "under" | "exact">("all");
  const [search, setSearch] = useState("");

  const summary = useMemo(() => {
    let overCount = 0;
    let underCount = 0;
    let exactCount = 0;
    let totalOverQty = 0;
    let totalUnderQty = 0;

    for (const v of variances) {
      if (v.status === "over") {
        overCount++;
        totalOverQty += v.diffQty;
      } else if (v.status === "under") {
        underCount++;
        totalUnderQty += Math.abs(v.diffQty);
      } else {
        exactCount++;
      }
    }

    return {
      total: variances.length,
      overCount,
      underCount,
      exactCount,
      totalOverQty,
      totalUnderQty,
    };
  }, [variances]);

  const filtered = useMemo(() => {
    return variances.filter((v) => {
      if (tab === "over" && v.status !== "over") return false;
      if (tab === "under" && v.status !== "under") return false;
      if (tab === "exact" && v.status !== "exact") return false;

      if (search.trim()) {
        const q = search.toLowerCase();
        return v.style.toLowerCase().includes(q) || v.buyer.toLowerCase().includes(q);
      }
      return true;
    });
  }, [variances, tab, search]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-md animate-in fade-in duration-150">
      <div className="w-full max-w-4xl max-h-[90vh] rounded-2xl border border-border bg-panel shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-border bg-panel-2/70 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300 shadow-inner">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-foreground tracking-tight">
                  স্টাইল প্ল্যান ভ্যারিয়েন্স ও কোয়ান্টিটি অডিট
                </h2>
                {summary.overCount + summary.underCount > 0 ? (
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-black bg-rose-500/20 text-rose-300 border border-rose-500/40">
                    {summary.overCount + summary.underCount}টি স্টাইলে অমিল
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    সব স্টাইল ১০০% সঠিক
                  </span>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                অর্ডারের চেয়ে কত পার্সেন্ট (+% / -%) কম বা বেশি প্ল্যান হয়েছে তা দেখুন এবং
                রি-প্ল্যান বা ফিক্স করুন।
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-panel-2 text-muted-foreground hover:text-foreground cursor-pointer transition border border-transparent hover:border-border"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-4 border-b border-border bg-panel-2/30">
          <div className="p-3 rounded-xl border border-border bg-panel/60">
            <span className="text-[11px] font-bold text-muted-foreground block">মোট স্টাইল</span>
            <div className="flex items-baseline gap-1.5 mt-1">
              <span className="text-xl font-black text-foreground font-mono">{summary.total}</span>
              <span className="text-[10px] text-muted-foreground">styles</span>
            </div>
          </div>

          <div
            onClick={() => setTab("over")}
            className={`p-3 rounded-xl border transition cursor-pointer ${
              tab === "over"
                ? "border-amber-500 bg-amber-950/40 shadow-sm ring-1 ring-amber-500/50"
                : "border-amber-500/30 bg-amber-950/15 hover:bg-amber-950/30"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-amber-300 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" /> বেশি প্ল্যান (Over)
              </span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-200 font-mono font-bold">
                {summary.overCount}
              </span>
            </div>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-base font-black text-amber-400 font-mono">
                +{summary.totalOverQty.toLocaleString()}
              </span>
              <span className="text-[10px] text-amber-300/80">pcs extra</span>
            </div>
          </div>

          <div
            onClick={() => setTab("under")}
            className={`p-3 rounded-xl border transition cursor-pointer ${
              tab === "under"
                ? "border-rose-500 bg-rose-950/40 shadow-sm ring-1 ring-rose-500/50"
                : "border-rose-500/30 bg-rose-950/15 hover:bg-rose-950/30"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-rose-300 flex items-center gap-1">
                <TrendingDown className="w-3.5 h-3.5" /> কম প্ল্যান (Under)
              </span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-200 font-mono font-bold">
                {summary.underCount}
              </span>
            </div>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-base font-black text-rose-400 font-mono">
                -{summary.totalUnderQty.toLocaleString()}
              </span>
              <span className="text-[10px] text-rose-300/80">pcs short</span>
            </div>
          </div>

          <div
            onClick={() => setTab("exact")}
            className={`p-3 rounded-xl border transition cursor-pointer ${
              tab === "exact"
                ? "border-emerald-500 bg-emerald-950/40 shadow-sm ring-1 ring-emerald-500/50"
                : "border-emerald-500/30 bg-emerald-950/15 hover:bg-emerald-950/30"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-emerald-300 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> সঠিক (100% Match)
              </span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-200 font-mono font-bold">
                {summary.exactCount}
              </span>
            </div>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-base font-black text-emerald-400 font-mono">
                {summary.total > 0 ? Math.round((summary.exactCount / summary.total) * 100) : 100}%
              </span>
              <span className="text-[10px] text-emerald-300/80">accuracy</span>
            </div>
          </div>
        </div>

        {/* Filter Tabs & Search Bar */}
        <div className="p-3 border-b border-border bg-panel/50 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-1 bg-panel-2/80 p-0.5 rounded-lg border border-border">
            <button
              type="button"
              onClick={() => setTab("all")}
              className={`px-3 py-1 rounded-md text-xs font-bold transition ${
                tab === "all"
                  ? "bg-purple-600 text-white shadow-xs"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              সব ({summary.total})
            </button>
            <button
              type="button"
              onClick={() => setTab("over")}
              className={`px-3 py-1 rounded-md text-xs font-bold transition ${
                tab === "over"
                  ? "bg-amber-600 text-white shadow-xs"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              🔺 বেশি প্ল্যান ({summary.overCount})
            </button>
            <button
              type="button"
              onClick={() => setTab("under")}
              className={`px-3 py-1 rounded-md text-xs font-bold transition ${
                tab === "under"
                  ? "bg-rose-600 text-white shadow-xs"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              🔻 কম প্ল্যান ({summary.underCount})
            </button>
            <button
              type="button"
              onClick={() => setTab("exact")}
              className={`px-3 py-1 rounded-md text-xs font-bold transition ${
                tab === "exact"
                  ? "bg-emerald-600 text-white shadow-xs"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              ✅ সঠিক ({summary.exactCount})
            </button>
          </div>

          <div className="relative flex-1 sm:max-w-xs">
            <Search className="w-3.5 h-3.5 text-muted-foreground absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="স্টাইল বা বায়ার খুঁজুন..."
              className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-border bg-input/80 text-foreground text-xs focus:outline-none focus:ring-1 focus:ring-purple-500"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* List of Styles */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filtered.length === 0 ? (
            <div className="p-12 text-center space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
              <p className="text-sm font-bold text-foreground">
                {tab === "over"
                  ? "কোনো স্টাইলে অতিরিক্ত (বেশি) প্ল্যান নেই।"
                  : tab === "under"
                    ? "কোনো স্টাইলে ঘাটতি (কম) প্ল্যান নেই।"
                    : "কোনো স্টাইল পাওয়া যায়নি।"}
              </p>
              <p className="text-xs text-muted-foreground">
                সব স্টাইলের প্ল্যানিং কোয়ান্টিটি অর্ডার সংখ্যার সাথে সুবিন্যস্ত আছে।
              </p>
            </div>
          ) : (
            filtered.map((item) => {
              const mainPlanId = item.planIds[0];
              const isOver = item.status === "over";
              const isUnder = item.status === "under";
              const isExact = item.status === "exact";

              return (
                <div
                  key={item.styleKey}
                  className={`p-3.5 sm:p-4 rounded-xl border transition-all ${
                    isOver
                      ? "bg-amber-950/20 border-amber-500/40 hover:border-amber-500/70"
                      : isUnder
                        ? "bg-rose-950/20 border-rose-500/40 hover:border-rose-500/70"
                        : "bg-panel-2/40 border-border hover:border-border/90"
                  }`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-2.5">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm sm:text-base font-extrabold text-foreground">
                          {item.style}
                        </h3>
                        <span className="text-xs text-muted-foreground font-semibold">
                          ({item.buyer})
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-black border ${
                            isOver
                              ? "bg-amber-500/20 text-amber-300 border-amber-500/50"
                              : isUnder
                                ? "bg-rose-500/20 text-rose-300 border-rose-500/50"
                                : "bg-emerald-500/20 text-emerald-300 border-emerald-500/50"
                          }`}
                        >
                          {isOver ? (
                            <>
                              <TrendingUp className="w-3 h-3" />
                              <span>
                                +{item.diffPct.toFixed(1)}% বেশি প্ল্যান (+
                                {item.diffQty.toLocaleString()} pcs)
                              </span>
                            </>
                          ) : isUnder ? (
                            <>
                              <TrendingDown className="w-3 h-3" />
                              <span>
                                {item.diffPct.toFixed(1)}% কম প্ল্যান (
                                {item.diffQty.toLocaleString()} pcs)
                              </span>
                            </>
                          ) : (
                            <>
                              <CheckCircle2 className="w-3 h-3" />
                              <span>১০০% সঠিক ম্যাচ (Exact Match)</span>
                            </>
                          )}
                        </span>
                        {item.excessPct > 0 && (
                          <span className="text-[10px] text-muted-foreground bg-panel px-1.5 py-0.5 rounded border border-border">
                            Excess Allowance: +{item.excessPct}%
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-2 shrink-0">
                      {!isExact && (
                        <button
                          type="button"
                          disabled={fixingPlanId === mainPlanId}
                          onClick={() => onAutoFixPlan(mainPlanId)}
                          className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center gap-1.5 shadow-sm transition disabled:opacity-50 cursor-pointer"
                          title="লাইন এলোকেশন আনুপাতিক হারে অ্যাডজাস্ট করে মোট প্ল্যান কোয়ান্টিটি ১০০% অর্ডারের সমান করুন"
                        >
                          {fixingPlanId === mainPlanId ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Zap className="w-3 h-3 text-amber-300" />
                          )}
                          <span>অটো-ম্যাচ (Fix)</span>
                        </button>
                      )}

                      {isUnder && onSplitPlan && (
                        <button
                          type="button"
                          onClick={() => {
                            onSplitPlan(
                              mainPlanId,
                              item.style,
                              item.buyer,
                              item.orderQty,
                              item.plannedQty,
                              item.lines[0]?.lineName,
                            );
                            onClose();
                          }}
                          className="px-3 py-1.5 rounded-lg bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 hover:text-white font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs"
                          title="বাকি কোয়ান্টিটি আলাদা করে নতুন আনপ্ল্যান্ড অর্ডার হিসেবে বা অন্য লাইনে প্ল্যান করুন"
                        >
                          <Scissors className="w-3.5 h-3.5 text-purple-400" />
                          <span>বাকি {Math.abs(item.diffQty).toLocaleString()} pcs স্প্লিট</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          onEditPlan(mainPlanId);
                          onClose();
                        }}
                        className="px-3 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 hover:text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                        title="প্ল্যান ইনপুট ফর্মে এই স্টাইলটি ওপেন করে তারিখ বা কোয়ান্টিটি রি-প্ল্যান করুন"
                      >
                        <Pencil className="w-3 h-3" />
                        <span>রি-প্ল্যান (Edit)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onUnplan(mainPlanId, item.style, item.buyer);
                          onClose();
                        }}
                        className="p-1.5 rounded-lg bg-panel hover:bg-amber-600/20 border border-border hover:border-amber-500/40 text-muted-foreground hover:text-amber-300 transition cursor-pointer"
                        title="বোর্ড থেকে সরিয়ে আনপ্ল্যান্ড পুলে পাঠান"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>

                      {onDeletePlan && (
                        <button
                          type="button"
                          onClick={() => onDeletePlan(mainPlanId, item.style)}
                          className="p-1.5 rounded-lg bg-panel hover:bg-red-600/20 border border-border hover:border-red-500/40 text-muted-foreground hover:text-red-300 transition cursor-pointer"
                          title="ভুল এন্ট্রি হলে এই প্ল্যানটি মুছে ফেলুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Quantity Breakdown Bar */}
                  <div className="grid grid-cols-3 gap-2 mt-3 p-2.5 rounded-lg bg-panel/70 border border-border/70 text-xs">
                    <div>
                      <span className="text-muted-foreground block text-[10px] font-bold uppercase">
                        বায়ার অর্ডার সংখ্যা
                      </span>
                      <span className="font-extrabold font-mono text-foreground text-sm mt-0.5 block">
                        {item.orderQty.toLocaleString()} pcs
                      </span>
                    </div>

                    <div>
                      <span className="text-muted-foreground block text-[10px] font-bold uppercase">
                        মোট প্ল্যান করা সংখ্যা
                      </span>
                      <span
                        className={`font-extrabold font-mono text-sm mt-0.5 block ${
                          isOver ? "text-amber-400" : isUnder ? "text-rose-400" : "text-emerald-400"
                        }`}
                      >
                        {item.plannedQty.toLocaleString()} pcs
                      </span>
                    </div>

                    <div>
                      <span className="text-muted-foreground block text-[10px] font-bold uppercase">
                        পার্থক্য (Variance)
                      </span>
                      <span
                        className={`font-black font-mono text-sm mt-0.5 block ${
                          isOver ? "text-amber-400" : isUnder ? "text-rose-400" : "text-emerald-400"
                        }`}
                      >
                        {item.diffQty > 0
                          ? `+${item.diffQty.toLocaleString()}`
                          : item.diffQty.toLocaleString()}{" "}
                        pcs (
                        {item.diffPct > 0
                          ? `+${item.diffPct.toFixed(1)}%`
                          : `${item.diffPct.toFixed(1)}%`}
                        )
                      </span>
                    </div>
                  </div>

                  {/* Allocated Lines List */}
                  {item.lines.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-border/50 flex flex-wrap items-center gap-2">
                      <span className="text-[10px] font-bold text-muted-foreground flex items-center gap-1">
                        <span>🏭</span>
                        <span>নির্ধারিত লাইন:</span>
                      </span>
                      {item.lines.map((l, lIdx) => (
                        <span
                          key={`${l.planId}-${l.rawLine}-${lIdx}`}
                          className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-panel-2 border border-border text-[11px] font-medium"
                        >
                          <b className="text-emerald-300 font-bold">{l.lineName}</b>
                          <span className="text-muted-foreground">|</span>
                          <span className="font-mono text-foreground font-bold">
                            {l.qty.toLocaleString()} pcs
                          </span>
                          {l.dailyTarget && l.dailyTarget > 0 ? (
                            <>
                              <span className="text-muted-foreground">|</span>
                              <span className="text-[10px] text-cyan-300 font-mono font-bold">
                                🎯 {l.dailyTarget.toLocaleString()}/d
                              </span>
                            </>
                          ) : null}
                          {l.start && l.end && (
                            <>
                              <span className="text-muted-foreground">|</span>
                              <span className="text-[10px] text-muted-foreground font-mono">
                                {formatDate(l.start)} → {formatDate(l.end)}
                              </span>
                            </>
                          )}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-border bg-panel-2/60 flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <span>💡</span>
            <span>
              <strong>টিপস:</strong> "অটো-ম্যাচ" চাপলে লাইনের অনুপাত ঠিক রেখে কোয়ান্টিটি ১০০%
              অর্ডারের সমান হয়ে যাবে।
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-panel hover:bg-panel-2 border border-border text-foreground font-bold cursor-pointer transition"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
}
