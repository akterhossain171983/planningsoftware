import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/hooks/use-current-user";
import { toast } from "sonner";
import {
  Package,
  PackagePlus,
  PackageOpen,
  Calendar,
  Layers,
  Zap,
  Trash2,
  Pencil,
  Search,
  Filter,
  ArrowRight,
  Clock,
  AlertTriangle,
  CheckCircle2,
  X,
  Plus,
  Factory,
  RotateCcw,
  Sparkles,
  ArrowRightLeft,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { AutocompleteInput } from "./AutocompleteInput";
import { useLinePresets } from "@/hooks/use-line-presets";
import { BulkStyleAssignmentModal } from "./BulkStyleAssignmentModal";

type PlanRow = {
  id: string;
  buyer: string;
  style: string;
  season: string | null;
  order_qty: number;
  excess_pct: number;
  daily_target: number;
  num_lines: number;
  shipment_date: string;
  config: Record<string, unknown> | null;
  calc_result: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
};

interface UnplannedOrdersViewProps {
  onPlanOrder?: (id: string) => void;
}

export function UnplannedOrdersView({ onPlanOrder }: UnplannedOrdersViewProps) {
  const { data: user } = useCurrentUser();
  const qc = useQueryClient();

  const [activeSubTab, setActiveSubTab] = useState<"unplanned" | "scheduled">("unplanned");
  const [search, setSearch] = useState("");
  const [selectedBuyer, setSelectedBuyer] = useState("");
  const [selectedSeason, setSelectedSeason] = useState("");
  const [sortBy, setSortBy] = useState<"date_asc" | "date_desc" | "qty_desc">("date_asc");

  // New quick unplanned order modal state
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [newBuyer, setNewBuyer] = useState("");
  const [newStyle, setNewStyle] = useState("");
  const [newSeason, setNewSeason] = useState("");
  const [newOrderQty, setNewOrderQty] = useState("");
  const [newExcessPct, setNewExcessPct] = useState("0");
  const [newDailyTarget, setNewDailyTarget] = useState("");
  const [newShipmentDate, setNewShipmentDate] = useState("");
  const [newSmv, setNewSmv] = useState("");
  const [newFabricEta, setNewFabricEta] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Bulk assignment modal state
  const { presets: linePresets } = useLinePresets();
  const [showBulkModal, setShowBulkModal] = useState(false);

  // Unplan confirmation modal state
  const [unplanTarget, setUnplanTarget] = useState<PlanRow | null>(null);
  const [isUnplanning, setIsUnplanning] = useState(false);

  // Delete confirmation modal state
  const [deleteTarget, setDeleteTarget] = useState<PlanRow | null>(null);

  // Fetch all active plans
  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "unplanned_view"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("plans")
        .select("*")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as PlanRow[];
    },
  });

  // Separate unplanned and scheduled plans
  const { unplannedOrders, scheduledOrders } = useMemo(() => {
    const un: PlanRow[] = [];
    const sc: PlanRow[] = [];

    for (const p of plans) {
      const isUnplanned =
        (p.config as any)?.status === "unplanned" ||
        (p.config as any)?.isUnplanned === true ||
        p.num_lines === 0 ||
        !p.calc_result?.lines ||
        (p.calc_result.lines as unknown[]).length === 0;

      if (isUnplanned) {
        un.push(p);
      } else {
        sc.push(p);
      }
    }
    return { unplannedOrders: un, scheduledOrders: sc };
  }, [plans]);

  // Unique filters
  const buyers = useMemo(() => {
    const set = new Set<string>();
    plans.forEach((p) => p.buyer && set.add(p.buyer));
    return Array.from(set).sort();
  }, [plans]);

  const seasons = useMemo(() => {
    const set = new Set<string>();
    plans.forEach((p) => p.season && set.add(p.season));
    return Array.from(set).sort();
  }, [plans]);

  const styleSuggestions = useMemo(() => {
    const normBuyer = newBuyer.trim().toLowerCase();
    const buyerStyles: string[] = [];
    const otherStyles: string[] = [];
    for (const p of plans) {
      if (!p.style) continue;
      if (normBuyer && p.buyer?.trim().toLowerCase() === normBuyer) {
        buyerStyles.push(p.style);
      } else {
        otherStyles.push(p.style);
      }
    }
    return Array.from(new Set([...buyerStyles, ...otherStyles]));
  }, [plans, newBuyer]);

  // Filter & sort
  const displayedList = useMemo(() => {
    const source = activeSubTab === "unplanned" ? unplannedOrders : scheduledOrders;
    return source
      .filter((p) => {
        if (selectedBuyer && p.buyer !== selectedBuyer) return false;
        if (selectedSeason && p.season !== selectedSeason) return false;
        if (search) {
          const q = search.toLowerCase();
          return (
            p.style.toLowerCase().includes(q) ||
            p.buyer.toLowerCase().includes(q) ||
            (p.season && p.season.toLowerCase().includes(q))
          );
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === "date_asc") {
          return new Date(a.shipment_date).getTime() - new Date(b.shipment_date).getTime();
        }
        if (sortBy === "date_desc") {
          return new Date(b.shipment_date).getTime() - new Date(a.shipment_date).getTime();
        }
        if (sortBy === "qty_desc") {
          return b.order_qty - a.order_qty;
        }
        return 0;
      });
  }, [
    activeSubTab,
    unplannedOrders,
    scheduledOrders,
    selectedBuyer,
    selectedSeason,
    search,
    sortBy,
  ]);

  // Total metrics
  const totalUnplannedQty = useMemo(
    () => unplannedOrders.reduce((sum, p) => sum + (p.order_qty || 0), 0),
    [unplannedOrders],
  );

  const totalScheduledQty = useMemo(
    () => scheduledOrders.reduce((sum, p) => sum + (p.order_qty || 0), 0),
    [scheduledOrders],
  );

  // Quick Unplan Mutation
  async function handleConfirmUnplan() {
    if (!unplanTarget) return;
    setIsUnplanning(true);
    try {
      const prevLines = (unplanTarget.config as any)?.lines ?? [];
      const { error } = await supabase
        .from("plans")
        .update({
          num_lines: 0,
          config: {
            ...(unplanTarget.config || {}),
            status: "unplanned",
            isUnplanned: true,
            previous_lines: prevLines,
            lines: [],
          },
          calc_result: {
            ...(unplanTarget.calc_result || {}),
            lines: [],
            orderQty: unplanTarget.order_qty,
            excessPct: unplanTarget.excess_pct,
          },
        } as any)
        .eq("id", unplanTarget.id);

      if (error) throw error;
      toast.success(
        `"${unplanTarget.style}" (${unplanTarget.buyer}) অর্ডারটি আনপ্ল্যান্ড পুলে স্থানান্তর করা হয়েছে।`,
      );
      qc.invalidateQueries({ queryKey: ["plans"] });
      setUnplanTarget(null);
    } catch (err: any) {
      toast.error("আনপ্ল্যান্ড করা যায়নি: " + (err?.message || "Error"));
    } finally {
      setIsUnplanning(false);
    }
  }

  // Quick Delete Mutation
  async function handleConfirmDelete() {
    if (!deleteTarget) return;
    try {
      const { error } = await supabase.from("plans").delete().eq("id", deleteTarget.id);
      if (error) throw error;
      toast.success("অর্ডারটি মুছে ফেলা হয়েছে।");
      qc.invalidateQueries({ queryKey: ["plans"] });
      setDeleteTarget(null);
    } catch (err: any) {
      toast.error("মুছে ফেলা সম্ভব হয়নি: " + (err?.message || "Error"));
    }
  }

  // Create Quick Unplanned Order
  async function handleCreateUnplannedOrder(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (!newBuyer.trim() || !newStyle.trim() || !newOrderQty || !newShipmentDate) {
      toast.error("অনুগ্রহ করে বায়ার, স্টাইল, কোয়ান্টিটি ও শিপমেন্ট তারিখ পূরণ করুন!");
      return;
    }

    setIsSubmitting(true);
    try {
      const qty = Math.max(0, parseInt(newOrderQty) || 0);
      const excess = Math.max(0, parseFloat(newExcessPct) || 0);
      const target = Math.max(0, parseInt(newDailyTarget) || 0);
      const plannedTotal = Math.round(qty * (1 + excess / 100));

      const payload = {
        buyer: newBuyer.trim(),
        style: newStyle.trim(),
        season: newSeason.trim() || null,
        order_qty: qty,
        excess_pct: excess,
        daily_target: target,
        num_lines: 0,
        shipment_date: newShipmentDate,
        config: {
          status: "unplanned",
          isUnplanned: true,
          lines: [],
          smv: newSmv ? parseFloat(newSmv) : null,
          fabricEta: newFabricEta.trim() || null,
        },
        calc_result: {
          buyer: newBuyer.trim(),
          style: newStyle.trim(),
          orderQty: qty,
          excessPct: excess,
          totalPlannedQty: plannedTotal,
          dailyTargetPerLine: target,
          lines: [],
          finishDate: "",
          shipmentDate: newShipmentDate,
        },
        created_by: user.id,
      };

      const { error } = await supabase.from("plans").insert(payload as any);
      if (error) throw error;

      toast.success(`"${newStyle}" অর্ডারটি আনপ্ল্যান্ড পুলে সংরক্ষিত হয়েছে!`);
      qc.invalidateQueries({ queryKey: ["plans"] });

      // Reset form
      setNewBuyer("");
      setNewStyle("");
      setNewSeason("");
      setNewOrderQty("");
      setNewExcessPct("0");
      setNewDailyTarget("");
      setNewShipmentDate("");
      setNewSmv("");
      setNewFabricEta("");
      setCreateModalOpen(false);
    } catch (err: any) {
      toast.error("সংরক্ষণ করা যায়নি: " + (err?.message || "Error"));
    } finally {
      setIsSubmitting(false);
    }
  }

  function handleTriggerPlan(id: string) {
    if (onPlanOrder) {
      onPlanOrder(id);
    } else {
      window.dispatchEvent(new CustomEvent("cg:edit-plan", { detail: id }));
    }
  }

  // Days left calculation
  function getShipmentStatus(dateStr: string) {
    if (!dateStr) return { text: "N/A", color: "text-muted-foreground bg-muted/40" };
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const ship = new Date(dateStr);
    ship.setHours(0, 0, 0, 0);
    const diffDays = Math.round((ship.getTime() - today.getTime()) / 86400000);

    if (diffDays < 0) {
      return {
        text: `বিলম্বিত (${Math.abs(diffDays)} দিন পার)`,
        color: "text-red-300 bg-red-500/20 border-red-500/40",
      };
    }
    if (diffDays <= 7) {
      return {
        text: `${diffDays} দিন বাকি (জরুরি)`,
        color: "text-amber-300 bg-amber-500/20 border-amber-500/40",
      };
    }
    if (diffDays <= 30) {
      return {
        text: `${diffDays} দিন বাকি`,
        color: "text-sky-300 bg-sky-500/10 border-sky-500/30",
      };
    }
    return {
      text: `${diffDays} দিন বাকি`,
      color: "text-emerald-300 bg-emerald-500/10 border-emerald-500/30",
    };
  }

  return (
    <div className="space-y-6">
      {/* Top Banner & Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-amber-950/40 via-panel to-panel p-5 rounded-2xl border border-amber-500/30 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <PackageOpen className="w-5 h-5" />
            </span>
            <h2 className="text-xl md:text-2xl font-black text-foreground">
              📦 আনপ্ল্যান্ড অর্ডার পুল (Backlog / Pool)
            </h2>
          </div>
          <p className="text-xs md:text-sm text-muted-foreground mt-1 max-w-2xl">
            যেসব অর্ডার এন্ট্রি করা হয়েছে কিন্তু এখনো লাইনে শিডিউল করা হয়নি, সেগুলোর কেন্দ্রীয়
            তালিকা। প্রয়োজনমতো যেকোনো মুহূর্তে এখান থেকে সরাসরি লাইনে প্ল্যান করতে পারবেন।
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            type="button"
            onClick={() => setShowBulkModal(true)}
            className="px-4 py-2.5 rounded-xl bg-purple-600/25 hover:bg-purple-600/35 border border-purple-500/50 text-purple-200 font-extrabold text-xs shadow-md flex items-center gap-2 transition cursor-pointer"
            title="একাধিক অর্ডার একসাথে নির্দিষ্ট প্রোডাকশন লাইনে অ্যাসাইন করুন"
          >
            <ArrowRightLeft className="w-4 h-4 text-purple-300" />
            বাল্ক লাইন অ্যাসাইন (Bulk Move)
          </button>

          <button
            type="button"
            onClick={() => setCreateModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-extrabold text-xs shadow-md flex items-center gap-2 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            নতুন আনপ্ল্যান্ড অর্ডার এন্ট্রি
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-950/10 backdrop-blur">
          <div className="flex items-center justify-between text-xs text-amber-300 font-bold">
            <span>অপেক্ষমাণ আনপ্ল্যান্ড</span>
            <Package className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl md:text-3xl font-black text-amber-400 mt-2">
            {unplannedOrders.length}{" "}
            <span className="text-xs font-normal text-muted-foreground">অর্ডার</span>
          </div>
          <div className="text-[11px] text-muted-foreground mt-1">
            মোট কোয়ান্টিটি: {totalUnplannedQty.toLocaleString()} pcs
          </div>
        </div>

        <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-950/10 backdrop-blur">
          <div className="flex items-center justify-between text-xs text-emerald-300 font-bold">
            <span>লাইনে শিডিউল্ড</span>
            <Factory className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl md:text-3xl font-black text-emerald-400 mt-2">
            {scheduledOrders.length}{" "}
            <span className="text-xs font-normal text-muted-foreground">অর্ডার</span>
          </div>
          <div className="text-[11px] text-muted-foreground mt-1">
            বোর্ডে মোট: {totalScheduledQty.toLocaleString()} pcs
          </div>
        </div>

        <div className="p-4 rounded-xl border border-sky-500/30 bg-sky-950/10 backdrop-blur">
          <div className="flex items-center justify-between text-xs text-sky-300 font-bold">
            <span>বায়ার সংখ্যা</span>
            <Layers className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl md:text-3xl font-black text-sky-400 mt-2">{buyers.length}</div>
          <div className="text-[11px] text-muted-foreground mt-1">
            {seasons.length > 0 ? `${seasons.length} টি সিজন যুক্ত` : "বিভিন্ন ব্র্যান্ড"}
          </div>
        </div>

        <div className="p-4 rounded-xl border border-purple-500/30 bg-purple-950/10 backdrop-blur">
          <div className="flex items-center justify-between text-xs text-purple-300 font-bold">
            <span>শিপমেন্ট রেঞ্জ</span>
            <Clock className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-sm md:text-base font-extrabold text-purple-300 mt-2 truncate">
            {unplannedOrders.length > 0
              ? `${unplannedOrders[0]?.shipment_date || "চলমান"}`
              : "অর্ডার শূন্য"}
          </div>
          <div className="text-[11px] text-muted-foreground mt-1">
            {unplannedOrders.length > 0 ? "আসন্ন ডেলিভারি অগ্রাধিকার দিন" : "সব অর্ডার শিডিউল্ড"}
          </div>
        </div>
      </div>

      {/* Main Container with Tabs */}
      <div className="rounded-2xl border border-border bg-panel shadow-sm overflow-hidden">
        {/* Sub-Tabs & Filter Toolbar */}
        <div className="p-4 border-b border-border flex flex-col md:flex-row md:items-center justify-between gap-3 bg-panel-2/40">
          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-panel border border-border text-xs w-fit">
            <button
              type="button"
              onClick={() => setActiveSubTab("unplanned")}
              className={`px-3.5 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-2 ${
                activeSubTab === "unplanned"
                  ? "bg-amber-600 text-white shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <PackageOpen className="w-3.5 h-3.5" />
              আনপ্ল্যান্ড অর্ডারসমূহ ({unplannedOrders.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveSubTab("scheduled")}
              className={`px-3.5 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-2 ${
                activeSubTab === "scheduled"
                  ? "bg-emerald-600 text-white shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Factory className="w-3.5 h-3.5" />
              শিডিউল্ড অর্ডার ({scheduledOrders.length}) — আনপ্ল্যান্ড করুন
            </button>
          </div>

          {/* Search & Select Filters */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative min-w-[160px] md:min-w-[200px]">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="স্টাইল বা বায়ার খুঁজুন..."
                className="w-full bg-input border border-border rounded-xl pl-8 pr-3 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            {buyers.length > 0 && (
              <select
                value={selectedBuyer}
                onChange={(e) => setSelectedBuyer(e.target.value)}
                className="bg-input border border-border rounded-xl px-2.5 py-1.5 text-xs text-foreground focus:outline-none"
              >
                <option value="">সকল বায়ার ({buyers.length})</option>
                {buyers.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            )}

            {seasons.length > 0 && (
              <select
                value={selectedSeason}
                onChange={(e) => setSelectedSeason(e.target.value)}
                className="bg-input border border-border rounded-xl px-2.5 py-1.5 text-xs text-foreground focus:outline-none"
              >
                <option value="">সকল সিজন</option>
                {seasons.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            )}

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-input border border-border rounded-xl px-2.5 py-1.5 text-xs text-foreground focus:outline-none"
            >
              <option value="date_asc">শিপমেন্ট: আগে থেকে পরে</option>
              <option value="date_desc">শিপমেন্ট: পরে থেকে আগে</option>
              <option value="qty_desc">কোয়ান্টিটি: সর্বোচ্চ</option>
            </select>
          </div>
        </div>

        {/* Table Content */}
        {isLoading ? (
          <div className="py-16 text-center text-muted-foreground">
            <div className="inline-block w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p className="text-xs">অর্ডার লোড হচ্ছে...</p>
          </div>
        ) : displayedList.length === 0 ? (
          <div className="py-16 text-center text-muted-foreground space-y-3">
            <PackageOpen className="w-12 h-12 mx-auto text-muted-foreground/40" />
            <div className="text-sm font-bold text-foreground">
              {activeSubTab === "unplanned"
                ? "কোনো আনপ্ল্যান্ড অর্ডার পাওয়া যায়নি!"
                : "কোনো শিডিউল্ড অর্ডার পাওয়া যায়নি!"}
            </div>
            <p className="text-xs max-w-sm mx-auto">
              {activeSubTab === "unplanned"
                ? "আপনি 'নতুন আনপ্ল্যান্ড অর্ডার এন্ট্রি' বোতাম দিয়ে অর্ডার ব্যাকলগে যোগ করতে পারেন অথবা প্ল্যান ইনপুট ফর্মে 'আনপ্ল্যান্ড হিসেবে সেভ করুন' ক্লিক করতে পারেন।"
                : "বোর্ডে বর্তমানে কোনো অ্যাক্টিভ প্ল্যান নেই।"}
            </p>
            {activeSubTab === "unplanned" && (
              <button
                type="button"
                onClick={() => setCreateModalOpen(true)}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs inline-flex items-center gap-2 cursor-pointer shadow-md"
              >
                <Plus className="w-3.5 h-3.5" />
                অর্ডার এন্ট্রি করুন
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-panel-2/80 text-[11px] font-bold text-muted-foreground uppercase tracking-wider border-b border-border">
                <tr>
                  <th className="p-3.5">বায়ার ও স্টাইল</th>
                  <th className="p-3.5">অর্ডার কোয়ান্টিটি</th>
                  <th className="p-3.5">টার্গেট ও স্পেসিফিকেশন</th>
                  <th className="p-3.5">বর্তমান স্ট্যাটাস</th>
                  <th className="p-3.5">শিপমেন্ট ডেট</th>
                  <th className="p-3.5 text-right">কার্যক্রম (Action)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {displayedList.map((p) => {
                  const isUnplanned =
                    (p.config as any)?.status === "unplanned" ||
                    (p.config as any)?.isUnplanned === true ||
                    p.num_lines === 0;
                  const shipStatus = getShipmentStatus(p.shipment_date);
                  const smv = (p.config as any)?.smv;
                  const fabricEta = (p.config as any)?.fabricEta;

                  return (
                    <tr key={p.id} className="hover:bg-panel-2/40 transition-colors group">
                      {/* Buyer & Style */}
                      <td className="p-3.5">
                        <div className="font-extrabold text-foreground text-sm">{p.buyer}</div>
                        <div className="text-xs text-foreground/80 font-medium">{p.style}</div>
                        {p.season && (
                          <div className="inline-block mt-1 text-[10px] font-semibold text-purple-300 bg-purple-500/10 border border-purple-500/20 px-1.5 py-0.5 rounded">
                            {p.season}
                          </div>
                        )}
                      </td>

                      {/* Order Quantity */}
                      <td className="p-3.5">
                        <div className="font-mono text-emerald-400 font-bold text-sm">
                          {p.order_qty.toLocaleString()}{" "}
                          <span className="text-[10px] text-muted-foreground">pcs</span>
                        </div>
                        {p.excess_pct > 0 && (
                          <div className="text-[10px] text-muted-foreground">
                            +{p.excess_pct}% excess ={" "}
                            {Math.round(p.order_qty * (1 + p.excess_pct / 100)).toLocaleString()}{" "}
                            pcs
                          </div>
                        )}
                      </td>

                      {/* Specs: Daily Target, SMV, Fabric ETA */}
                      <td className="p-3.5 space-y-1">
                        {p.daily_target > 0 ? (
                          <div className="text-[11px] font-mono text-yellow-300 font-bold">
                            🎯 {p.daily_target.toLocaleString()} pcs / দিন
                          </div>
                        ) : (
                          <div className="text-[11px] text-muted-foreground italic">
                            টার্গেট সেট করা নেই
                          </div>
                        )}

                        <div className="flex flex-wrap items-center gap-1 text-[10px]">
                          {smv && (
                            <span className="text-sky-300 bg-sky-500/10 border border-sky-500/20 px-1 py-0.5 rounded">
                              SMV: {smv}
                            </span>
                          )}
                          {fabricEta && (
                            <span className="text-teal-300 bg-teal-500/10 border border-teal-500/20 px-1 py-0.5 rounded">
                              ETA: {fabricEta}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="p-3.5">
                        {isUnplanned ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-extrabold text-amber-300 bg-amber-500/15 border border-amber-500/30">
                            <Package className="w-3 h-3 text-amber-400" />
                            আনপ্ল্যান্ড পুল
                          </span>
                        ) : (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold text-emerald-300 bg-emerald-500/15 border border-emerald-500/30">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                              {p.num_lines} লাইনে শিডিউল্ড
                            </span>
                            {(p.config as any)?.lines?.length > 0 && (
                              <div className="text-[10px] text-muted-foreground truncate max-w-[150px]">
                                {(p.config as any).lines.map((l: any) => l.name).join(", ")}
                              </div>
                            )}
                          </div>
                        )}
                      </td>

                      {/* Shipment Date */}
                      <td className="p-3.5">
                        <div className="font-mono text-foreground font-bold">{p.shipment_date}</div>
                        <div
                          className={`inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded border ${shipStatus.color}`}
                        >
                          {shipStatus.text}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {isUnplanned ? (
                            <>
                              <button
                                type="button"
                                onClick={() => handleTriggerPlan(p.id)}
                                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-90 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                                title="এই অর্ডারটির জন্য লাইন বরাদ্দ করুন"
                              >
                                <Zap className="w-3.5 h-3.5" />
                                লাইনে প্ল্যান করুন
                              </button>
                              <button
                                type="button"
                                onClick={() => handleTriggerPlan(p.id)}
                                className="p-1.5 rounded-lg border border-border bg-input hover:bg-panel-2 text-foreground cursor-pointer"
                                title="এডিট করুন"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                type="button"
                                onClick={() => setUnplanTarget(p)}
                                className="px-3 py-1.5 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/40 text-amber-300 font-extrabold text-xs flex items-center gap-1.5 cursor-pointer transition"
                                title="লাইন থেকে তুলে আনপ্ল্যান্ড পুলে পাঠান"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                আনপ্ল্যান্ড করুন
                              </button>
                              <button
                                type="button"
                                onClick={() => handleTriggerPlan(p.id)}
                                className="p-1.5 rounded-lg border border-border bg-input hover:bg-panel-2 text-foreground cursor-pointer"
                                title="প্ল্যান ইনপুটে এডিট করুন"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}

                          <button
                            type="button"
                            onClick={() => setDeleteTarget(p)}
                            className="p-1.5 rounded-lg border border-red-500/30 bg-red-500/10 hover:bg-red-500/20 text-red-300 cursor-pointer"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Quick Create Unplanned Order Modal */}
      <Dialog open={createModalOpen} onOpenChange={setCreateModalOpen}>
        <DialogContent className="max-w-lg bg-panel border-border text-foreground shadow-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-400 font-black text-lg">
              <PackagePlus className="w-5 h-5 text-amber-400" />
              নতুন আনপ্ল্যান্ড অর্ডার এন্ট্রি
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              অর্ডারের বেসিক তথ্য লিখে সংরক্ষণ করুন। কোনো লাইন সিলেক্ট করার প্রয়োজন নেই। পরবর্তীতে
              সুবিধামতো লাইনে এলোকেট করতে পারবেন।
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreateUnplannedOrder} className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-muted-foreground uppercase mb-1">
                  বায়ার (Buyer) *
                </label>
                <AutocompleteInput
                  required
                  value={newBuyer}
                  onChange={setNewBuyer}
                  suggestions={buyers}
                  placeholder="e.g. H&M, Zara, PVH"
                  className="w-full bg-input border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:ring-1 focus:ring-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-muted-foreground uppercase mb-1">
                  স্টাইল (Style No) *
                </label>
                <AutocompleteInput
                  required
                  value={newStyle}
                  onChange={setNewStyle}
                  suggestions={styleSuggestions}
                  placeholder="e.g. POLO-2026, JK-99"
                  className="w-full bg-input border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:ring-1 focus:ring-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-muted-foreground uppercase mb-1">
                  অর্ডার কোয়ান্টিটি *
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={newOrderQty}
                  onChange={(e) => setNewOrderQty(e.target.value)}
                  placeholder="e.g. 25000"
                  className="w-full bg-input border border-border rounded-xl px-3 py-2 text-xs font-mono text-emerald-400 font-bold focus:ring-1 focus:ring-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-muted-foreground uppercase mb-1">
                  এক্সেস % (Excess)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.5"
                  value={newExcessPct}
                  onChange={(e) => setNewExcessPct(e.target.value)}
                  placeholder="0"
                  className="w-full bg-input border border-border rounded-xl px-3 py-2 text-xs font-mono text-foreground focus:ring-1 focus:ring-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-muted-foreground uppercase mb-1">
                  দৈনিক টার্গেট
                </label>
                <input
                  type="number"
                  min="0"
                  value={newDailyTarget}
                  onChange={(e) => setNewDailyTarget(e.target.value)}
                  placeholder="e.g. 1200"
                  className="w-full bg-input border border-border rounded-xl px-3 py-2 text-xs font-mono text-yellow-300 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-muted-foreground uppercase mb-1">
                  শিপমেন্ট তারিখ *
                </label>
                <input
                  type="date"
                  required
                  value={newShipmentDate}
                  onChange={(e) => setNewShipmentDate(e.target.value)}
                  className="w-full bg-input border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:ring-1 focus:ring-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-muted-foreground uppercase mb-1">
                  সিজন (Season)
                </label>
                <AutocompleteInput
                  value={newSeason}
                  onChange={setNewSeason}
                  suggestions={seasons}
                  placeholder="e.g. Summer 2026"
                  className="w-full bg-input border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:ring-1 focus:ring-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-muted-foreground uppercase mb-1">
                  SMV (Standard Min)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={newSmv}
                  onChange={(e) => setNewSmv(e.target.value)}
                  placeholder="e.g. 14.5"
                  className="w-full bg-input border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:ring-1 focus:ring-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-muted-foreground uppercase mb-1">
                  ফ্যাব্রিক ETA (যদি থাকে)
                </label>
                <input
                  type="date"
                  value={newFabricEta}
                  onChange={(e) => setNewFabricEta(e.target.value)}
                  className="w-full bg-input border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:ring-1 focus:ring-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <DialogFooter className="mt-5 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setCreateModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-border hover:bg-panel-2 text-xs font-bold text-muted-foreground cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-black text-xs shadow-md transition disabled:opacity-50 cursor-pointer flex items-center gap-2"
              >
                {isSubmitting ? "সংরক্ষণ হচ্ছে..." : "📦 আনপ্ল্যান্ড পুলে সেভ করুন"}
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Unplan Confirmation Dialog */}
      <Dialog open={!!unplanTarget} onOpenChange={(open) => !open && setUnplanTarget(null)}>
        <DialogContent className="max-w-md bg-panel border-amber-500/50 text-foreground shadow-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-400 font-black text-base">
              <RotateCcw className="w-5 h-5 text-amber-400" />
              অর্ডারটি আনপ্ল্যান্ড পুলে পাঠাবেন?
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground text-left mt-2">
              স্টাইল: <b className="text-foreground">{unplanTarget?.style}</b> (বায়ার:{" "}
              <b className="text-foreground">{unplanTarget?.buyer}</b>)
              <br />
              <br />
              এটি নিশ্চিত করলে এই অর্ডারের সমস্ত লাইন এলোকেশন সাময়িকভাবে মুছে যাবে এবং লাইনের
              টাইমলাইনে স্লট ফাঁকা হবে। অর্ডারটি নিরাপদে আনপ্ল্যান্ড পুলে সংরক্ষিত থাকবে এবং
              পরবর্তীতে পুনরায় লাইনে প্ল্যান করা যাবে।
            </DialogDescription>
          </DialogHeader>

          <DialogFooter className="mt-4 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setUnplanTarget(null)}
              className="px-4 py-2 rounded-xl border border-border hover:bg-panel-2 text-xs font-bold text-muted-foreground cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="button"
              disabled={isUnplanning}
              onClick={handleConfirmUnplan}
              className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-extrabold text-xs shadow-md transition disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
            >
              {isUnplanning ? "আনপ্ল্যান্ড হচ্ছে..." : "হ্যাঁ, আনপ্ল্যান্ড করুন"}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <DialogContent className="max-w-md bg-panel border-red-500/50 text-foreground shadow-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-400 font-black text-base">
              <Trash2 className="w-5 h-5 text-red-400" />
              অর্ডার মুছে ফেলা নিশ্চিতকরণ
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground text-left mt-2">
              আপনি কি নিশ্চিত যে <b className="text-foreground">{deleteTarget?.style}</b> (
              {deleteTarget?.buyer}) অর্ডারটি স্থায়ীভাবে মুছে ফেলতে চান? এটি পুনরুদ্ধার করা যাবে
              না।
            </DialogDescription>
          </DialogHeader>

          <DialogFooter className="mt-4 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setDeleteTarget(null)}
              className="px-4 py-2 rounded-xl border border-border hover:bg-panel-2 text-xs font-bold text-muted-foreground cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="button"
              onClick={handleConfirmDelete}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-extrabold text-xs shadow-md transition cursor-pointer"
            >
              হ্যাঁ, মুছে ফেলুন
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Style Line Assignment Modal */}
      {showBulkModal && (
        <BulkStyleAssignmentModal
          open={showBulkModal}
          onClose={() => setShowBulkModal(false)}
          plans={plans as any}
          linePresets={linePresets}
          globalHolidays={[]}
          onSuccess={() => {
            qc.invalidateQueries({ queryKey: ["plans"] });
          }}
        />
      )}
    </div>
  );
}
