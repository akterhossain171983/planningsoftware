import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, History, ChevronDown, ChevronRight, Search, X } from "lucide-react";
import { formatDate } from "@/lib/plan-calc";
import type { PlanLineSnapshot } from "@/lib/plan-snapshot";

type Revision = {
  id: string;
  plan_id: string;
  revision_no: number;
  buyer: string | null;
  style: string | null;
  finish_date: string | null;
  lines: PlanLineSnapshot[];
  created_at: string;
};

type PlanRow = {
  id: string;
  buyer: string;
  style: string;
  order_qty: number;
  completed_at: string | null;
};

export function RevisionHistoryView() {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [search, setSearch] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const { data: plans, isLoading: plansLoading } = useQuery({
    queryKey: ["plans", "active-for-revisions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("plans")
        .select("id, buyer, style, order_qty, completed_at")
        .is("completed_at", null);
      if (error) throw error;
      return (data ?? []) as PlanRow[];
    },
  });

  const { data: revisions, isLoading: revsLoading } = useQuery({
    queryKey: ["plan_revisions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("plan_revisions" as never)
        .select("*")
        .order("revision_no", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as Revision[];
    },
  });

  const grouped = useMemo(() => {
    const q = search.trim().toLowerCase();
    const fromT = fromDate ? new Date(fromDate).getTime() : null;
    const toT = toDate ? new Date(toDate).getTime() + 86400000 - 1 : null;

    const byPlan = new Map<string, Revision[]>();
    for (const r of revisions ?? []) {
      if (fromT !== null || toT !== null) {
        const t = new Date(r.created_at).getTime();
        if (fromT !== null && t < fromT) continue;
        if (toT !== null && t > toT) continue;
      }
      const arr = byPlan.get(r.plan_id) ?? [];
      arr.push(r);
      byPlan.set(r.plan_id, arr);
    }
    return (plans ?? [])
      .filter((p) => {
        if (!q) return true;
        return p.buyer.toLowerCase().includes(q) || p.style.toLowerCase().includes(q);
      })
      .map((p) => ({ plan: p, revs: byPlan.get(p.id) ?? [] }))
      .filter((g) => g.revs.length > 0)
      .sort((a, b) => (a.plan.buyer + a.plan.style).localeCompare(b.plan.buyer + b.plan.style));
  }, [plans, revisions, search, fromDate, toDate]);

  const hasFilter = search || fromDate || toDate;

  if (plansLoading || revsLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-border bg-panel/60 p-4 md:p-6">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-extrabold bn-gradient-text">রিভিশন হিস্ট্রি</h2>
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          প্রতিটি অসমাপ্ত স্টাইলের সব রিভিশন — লাইন, ১ম আউটপুট ও সর্বশেষ আউটপুট।
        </p>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-[1fr_auto_auto_auto] gap-2 items-end">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buyer বা Style সার্চ করুন..."
              className="w-full pl-9 pr-3 py-2 rounded-lg bg-panel-2 border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <div className="flex flex-col">
            <label className="text-[11px] text-muted-foreground mb-1">From</label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="px-3 py-2 rounded-lg bg-panel-2 border border-border text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <div className="flex flex-col">
            <label className="text-[11px] text-muted-foreground mb-1">To</label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="px-3 py-2 rounded-lg bg-panel-2 border border-border text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          {hasFilter && (
            <button
              onClick={() => {
                setSearch("");
                setFromDate("");
                setToDate("");
              }}
              className="px-3 py-2 rounded-lg bg-panel-2 border border-border text-sm text-foreground hover:bg-panel flex items-center gap-1"
            >
              <X className="w-4 h-4" /> ক্লিয়ার
            </button>
          )}
        </div>
      </div>

      {grouped.length === 0 ? (
        <div className="rounded-2xl border border-border bg-panel/60 p-8 text-center text-sm text-muted-foreground">
          {hasFilter ? "ফিল্টারে কোনো রিভিশন পাওয়া যায়নি।" : "এখনও কোনো রিভিশন রেকর্ড হয়নি।"}
        </div>
      ) : (
        <div className="space-y-3">
          {grouped.map(({ plan, revs }) => {
            const isOpen = expanded[plan.id] ?? true;
            return (
              <div
                key={plan.id}
                className="rounded-2xl border border-border bg-panel/60 overflow-hidden"
              >
                <button
                  onClick={() => setExpanded((s) => ({ ...s, [plan.id]: !isOpen }))}
                  className="w-full flex items-center gap-2 px-4 py-3 hover:bg-panel-2 transition text-left"
                >
                  {isOpen ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                  <div className="flex-1">
                    <div className="text-sm font-bold text-foreground">
                      {plan.buyer} — {plan.style}
                    </div>
                    <div className="text-[11px] text-muted-foreground">
                      Order Qty: {plan.order_qty.toLocaleString()} • মোট রিভিশন: {revs.length}
                    </div>
                  </div>
                </button>

                {isOpen && (
                  <div className="border-t border-border overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead className="bg-panel-2 text-muted-foreground">
                        <tr>
                          <th className="text-left px-3 py-2 font-semibold">রিভিশন</th>
                          <th className="text-left px-3 py-2 font-semibold">লাইন</th>
                          <th className="text-left px-3 py-2 font-semibold">১ম আউটপুট</th>
                          <th className="text-left px-3 py-2 font-semibold">সর্বশেষ আউটপুট</th>
                          <th className="text-left px-3 py-2 font-semibold">সেভ হয়েছে</th>
                        </tr>
                      </thead>
                      <tbody>
                        {revs.map((r) => {
                          const lines = Array.isArray(r.lines) ? r.lines : [];
                          const rowCount = Math.max(1, lines.length);
                          return lines.length === 0 ? (
                            <tr key={r.id} className="border-t border-border">
                              <td className="px-3 py-2 font-bold text-primary">#{r.revision_no}</td>
                              <td className="px-3 py-2 text-muted-foreground" colSpan={3}>
                                কোনো লাইন ডেটা নেই
                              </td>
                              <td className="px-3 py-2 text-muted-foreground">
                                {formatDate(r.created_at.slice(0, 10))}
                              </td>
                            </tr>
                          ) : (
                            lines.map((ln, idx) => (
                              <tr
                                key={r.id + "-" + idx}
                                className={idx === 0 ? "border-t border-border" : ""}
                              >
                                {idx === 0 && (
                                  <td
                                    rowSpan={rowCount}
                                    className="px-3 py-2 align-top font-bold text-primary"
                                  >
                                    #{r.revision_no}
                                  </td>
                                )}
                                <td className="px-3 py-2 font-medium text-foreground">{ln.name}</td>
                                <td className="px-3 py-2 text-foreground">
                                  {formatDate(ln.firstOutput)}
                                </td>
                                <td className="px-3 py-2 text-foreground">
                                  {formatDate(ln.lastOutput)}
                                </td>
                                {idx === 0 && (
                                  <td
                                    rowSpan={rowCount}
                                    className="px-3 py-2 align-top text-muted-foreground"
                                  >
                                    {formatDate(r.created_at.slice(0, 10))}
                                  </td>
                                )}
                              </tr>
                            ))
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
