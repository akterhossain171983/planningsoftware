import { describe, it, expect } from "vitest";
import { normLine, buildLineLastOutput, lookupLastOutput, canonicalLineName } from "./lineLookup";

describe("normLine", () => {
  it("strips whitespace and punctuation", () => {
    expect(normLine("Line - R")).toBe("r");
    expect(normLine("Line-R")).toBe("r");
    expect(normLine("  Line  -  R  ")).toBe("r");
  });

  it("lowercases", () => {
    expect(normLine("LINE-R")).toBe(normLine("line-r"));
    expect(normLine("Line - 15")).toBe(normLine("line-15"));
  });

  it("handles empty/undefined input", () => {
    expect(normLine("")).toBe("");
    // @ts-expect-error runtime safety
    expect(normLine(undefined)).toBe("");
  });

  it("treats different spacing/case variants as equal", () => {
    const variants = ["Line - R", "Line-R", "line - r", "LINE  -  R", "  line-r "];
    const first = normLine(variants[0]);
    for (const v of variants) expect(normLine(v)).toBe(first);
  });
});

describe("buildLineLastOutput", () => {
  it("collapses spacing/case variants to a single key with the latest finish", () => {
    const plans = [
      {
        id: "a",
        calc_result: {
          lines: [
            { name: "Line - R", finishDateStr: "2026-06-20" },
            { name: "Line - 15", finishDateStr: "2026-07-01" },
          ],
        },
      },
      {
        id: "b",
        calc_result: {
          lines: [
            { name: "Line-R", finishDateStr: "2026-08-15" }, // later, different spelling
            { name: "line - 15", finishDateStr: "2026-06-10" }, // earlier, different case
          ],
        },
      },
    ];
    const map = buildLineLastOutput(plans);
    expect(map[normLine("Line - R")]).toBe("2026-08-15");
    expect(map[normLine("line-r")]).toBe("2026-08-15");
    expect(map[normLine("LINE-15")]).toBe("2026-07-01");
  });

  it("excludes the plan currently being edited", () => {
    const plans = [
      {
        id: "editing",
        calc_result: { lines: [{ name: "Line - R", finishDateStr: "2027-01-01" }] },
      },
      { id: "other", calc_result: { lines: [{ name: "Line-R", finishDateStr: "2026-08-15" }] } },
    ];
    const map = buildLineLastOutput(plans, "editing");
    expect(map[normLine("Line - R")]).toBe("2026-08-15");
  });

  it("ignores lines with missing name or finish date", () => {
    const plans = [
      {
        id: "a",
        calc_result: {
          lines: [
            { name: "", finishDateStr: "2026-08-15" },
            { name: "Line - R", finishDateStr: "" },
            { name: "Line - R", finishDateStr: "2026-08-15" },
          ],
        },
      },
    ];
    const map = buildLineLastOutput(plans);
    expect(Object.keys(map)).toEqual([normLine("Line - R")]);
    expect(map[normLine("Line-R")]).toBe("2026-08-15");
  });

  it("returns empty map when no plans provided", () => {
    expect(buildLineLastOutput([])).toEqual({});
  });
});

describe("lookupLastOutput", () => {
  const map = {
    [normLine("Line - R")]: "2026-08-15",
    [normLine("Line - 15")]: "2026-07-01",
  };

  it("finds a booking regardless of the query's spacing/case", () => {
    expect(lookupLastOutput(map, "Line - R")).toBe("2026-08-15");
    expect(lookupLastOutput(map, "Line-R")).toBe("2026-08-15");
    expect(lookupLastOutput(map, "  line-r  ")).toBe("2026-08-15");
    expect(lookupLastOutput(map, "LINE - 15")).toBe("2026-07-01");
  });

  it("returns undefined for an unknown line", () => {
    expect(lookupLastOutput(map, "Line - Z")).toBeUndefined();
  });
});

describe("Line - X naming synchronization constraints", () => {
  it("normLine('Line - 15') and normLine('15') should be identical", () => {
    expect(normLine("Line - 15")).toBe(normLine("15"));
    expect(normLine("Line - 15")).toBe("15");
  });

  it("normLine('Line - A') and normLine('A') should be identical", () => {
    expect(normLine("Line - A")).toBe(normLine("A"));
    expect(normLine("Line - A")).toBe("a");
  });

  it("canonicalLineName should restore the preset name from a raw number", () => {
    const presets = ["Line - 15", "Line - A"];
    expect(canonicalLineName("15", presets)).toBe("Line - 15");
    expect(canonicalLineName("A", presets)).toBe("Line - A");
  });

  it("canonicalLineName should handle different spacings of the same name", () => {
    const presets = ["Line - 15"];
    expect(canonicalLineName("Line-15", presets)).toBe("Line - 15");
    expect(canonicalLineName("line 15", presets)).toBe("Line - 15");
  });

  it("canonicalLineName should safely handle undefined, null, or missing presets without throwing", () => {
    expect(canonicalLineName("Line - 21")).toBe("Line - 21");
    expect(canonicalLineName("Line - 21", undefined)).toBe("Line - 21");
    expect(canonicalLineName("Line - 21", null)).toBe("Line - 21");
    expect(canonicalLineName("Line - 21", [])).toBe("Line - 21");
    expect(canonicalLineName("", undefined)).toBe("");
  });
});
