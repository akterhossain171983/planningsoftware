import { useMemo, useState } from "react";
import {
  AlertTriangle,
  X,
  Scissors,
  Pencil,
  RotateCcw,
  Search,
  Filter,
  Layers,
  ArrowRight,
  ExternalLink,
  ShieldAlert,
  CheckCircle2,
  Calendar,
} from "lucide-react";
import type { LineConflict } from "./lineConflict";

export type LineConflictDrawerProps = {
  open: boolean;
  onClose: () => void;
  conflicts: LineConflict[];
  onOpenSplitModal: (target: {
    planId: string;
    style: string;
    buyer: string;
    season?: string | null;
    orderQty: number;
    plannedQty: number;
    currentLine?: string;
    dailyTarget?: number;
    shipmentDate?: string;
  }) => void;
  onEditPlan: (planId: string) => void;
  onUnplan: (planId: string, style: string, buyer: string) => void;
  onFocusLine?: (lineName: string) => void;
};

export function LineConflictDrawer({
  open,
  onClose,
  conflicts,
  onOpenSplitModal,
  onEditPlan,
  onUnplan,
  onFocusLine,
}: LineConflictDrawerProps) {
  const [search, setSearch] = useState("");
  const [selectedLine, setSelectedLine] = useState<string>("all");

  const lineOptions = useMemo(() => {
    return Array.from(new Set(conflicts.map((c) => c.line))).sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true }),
    );
  }, [conflicts]);

  const filteredConflicts = useMemo(() => {
    return conflicts.filter((c) => {
      if (selectedLine !== "all" && c.line !== selectedLine) return false;
      if (!search.trim()) return true;
      const q = search.toLowerCase();
      return (
        c.line.toLowerCase().includes(q) ||
        c.barA.style.toLowerCase().includes(q) ||
        c.barA.buyer.toLowerCase().includes(q) ||
        c.barB.style.toLowerCase().includes(q) ||
        c.barB.buyer.toLowerCase().includes(q)
      );
    });
  }, [conflicts, selectedLine, search]);

  const distinctConflictingLines = lineOptions.length;
  const distinctStylesCount = useMemo(() => {
    const s = new Set<string>();
    conflicts.forEach((c) => {
      s.add(c.barA.style);
      s.add(c.barB.style);
    });
    return s.size;
  }, [conflicts]);

  const totalOverlappingDays = useMemo(() => {
    return conflicts.reduce((sum, c) => sum + c.overlapDays, 0);
  }, [conflicts]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} aria-hidden="true" />
      <div className="relative w-full max-w-2xl h-full bg-panel border-l border-border shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-border bg-gradient-to-r from-rose-950/40 via-panel-2 to-panel-2 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-foreground">
                  লাইন অ্যাসাইনমেন্ট কনফ্লিক্ট সতর্কবার্তা
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-300 font-mono font-bold text-xs">
                  {conflicts.length} টি সংঘর্ষ
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                একই প্রোডাকশন লাইনে একই সময়ে একাধিক স্টাইল নির্ধারিত হলে এই সিস্টেমে সতর্ক করা হয়।
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-panel-2 text-muted-foreground hover:text-foreground transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Summary Metric Cards */}
        <div className="p-4 bg-panel-2/30 border-b border-border grid grid-cols-3 gap-2.5 shrink-0">
          <div className="p-2.5 rounded-xl border border-rose-500/30 bg-rose-950/20 text-center">
            <span className="text-[10px] font-bold text-rose-300 uppercase block">
              কনফ্লিক্টিং লাইন
            </span>
            <span className="text-lg font-black font-mono text-rose-200 mt-0.5 block">
              {distinctConflictingLines} টি লাইন
            </span>
          </div>

          <div className="p-2.5 rounded-xl border border-amber-500/30 bg-amber-950/20 text-center">
            <span className="text-[10px] font-bold text-amber-300 uppercase block">
              সংঘর্ষপূর্ণ স্টাইল
            </span>
            <span className="text-lg font-black font-mono text-amber-200 mt-0.5 block">
              {distinctStylesCount} টি স্টাইল
            </span>
          </div>

          <div className="p-2.5 rounded-xl border border-purple-500/30 bg-purple-950/20 text-center">
            <span className="text-[10px] font-bold text-purple-300 uppercase block">
              মোট ওভারল্যাপ দিন
            </span>
            <span className="text-lg font-black font-mono text-purple-200 mt-0.5 block">
              {totalOverlappingDays} দিন
            </span>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="p-3 border-b border-border bg-panel-1 flex flex-wrap items-center gap-2 shrink-0">
          <div className="relative flex-1 min-w-[180px]">
            <Search className="w-3.5 h-3.5 text-muted-foreground absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="বায়ার বা স্টাইল সার্চ করুন..."
              className="w-full rounded-lg border border-border bg-input pl-8 pr-7 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-rose-500"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <Filter className="w-3 h-3 text-muted-foreground" />
            <select
              value={selectedLine}
              onChange={(e) => setSelectedLine(e.target.value)}
              className="rounded-lg border border-border bg-input px-2.5 py-1.5 text-xs text-foreground font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
            >
              <option value="all">সব লাইন ({conflicts.length})</option>
              {lineOptions.map((l) => {
                const count = conflicts.filter((c) => c.line === l).length;
                return (
                  <option key={l} value={l}>
                    {l} ({count})
                  </option>
                );
              })}
            </select>
          </div>
        </div>

        {/* Conflict List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
          {filteredConflicts.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-12 text-center text-muted-foreground space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <p className="font-extrabold text-foreground text-sm">
                  {conflicts.length === 0
                    ? "কোনো লাইন কনফ্লিক্ট নেই!"
                    : "ফিল্টারে কোনো ফলাফল পাওয়া যায়নি"}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {conflicts.length === 0
                    ? "সবগুলো প্রোডাকশন লাইনের তারিখ বরাদ্দ সম্পূর্ণ কনফ্লিক্ট-মুক্ত।"
                    : "অন্য কোনো বায়ার বা স্টাইল দিয়ে সার্চ করুন অথবা ফিল্টার রিসেট করুন।"}
                </p>
              </div>
            </div>
          ) : (
            filteredConflicts.map((c, idx) => (
              <div
                key={c.id || idx}
                className="rounded-xl border border-rose-500/40 bg-panel-2/60 p-4 space-y-3 hover:border-rose-400/80 transition shadow-sm"
              >
                {/* Header: Line & Overlap Window */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-border/60">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-lg bg-rose-600 text-white font-black text-xs shadow-xs">
                      📍 {c.line}
                    </span>
                    <span className="text-xs font-bold text-rose-300 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>{c.overlapDays} দিনের কনফ্লিক্ট</span>
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground bg-panel px-2.5 py-1 rounded-md border border-border">
                    <Calendar className="w-3.5 h-3.5 text-amber-400" />
                    <span className="font-mono text-amber-300 font-bold">
                      {c.overlapStart} → {c.overlapEnd}
                    </span>
                  </div>
                </div>

                {/* Conflicting Styles Comparison */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                  {/* Style A */}
                  <div className="rounded-lg border border-border/80 bg-panel p-3 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] text-muted-foreground uppercase font-bold block">
                          স্টাইল ১ (Style A)
                        </span>
                        <h4 className="font-extrabold text-foreground text-sm">{c.barA.style}</h4>
                        <span className="text-[11px] text-muted-foreground font-semibold">
                          বায়ার: {c.barA.buyer}
                        </span>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono font-bold text-[11px] shrink-0">
                        {c.barA.qty.toLocaleString()} pcs
                      </span>
                    </div>

                    <div className="text-[11px] text-muted-foreground font-mono space-y-0.5 pt-1 border-t border-border/40">
                      <div>
                        সময়কাল:{" "}
                        <b className="text-foreground">
                          {c.barA.start} → {c.barA.end}
                        </b>
                      </div>
                      {c.barA.dailyTarget && c.barA.dailyTarget > 0 && (
                        <div>
                          টার্গেট: <b className="text-yellow-300">{c.barA.dailyTarget}/দিন</b>
                        </div>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          onOpenSplitModal({
                            planId: c.barA.planId,
                            style: c.barA.style,
                            buyer: c.barA.buyer,
                            season: c.barA.season,
                            orderQty: c.barA.qty,
                            plannedQty: c.barA.qty,
                            currentLine: c.barA.line,
                            dailyTarget: c.barA.dailyTarget,
                          });
                          onClose();
                        }}
                        className="px-2 py-1 rounded bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 hover:text-white font-extrabold text-[10.5px] flex items-center gap-1 transition cursor-pointer"
                        title="এই স্টাইলটি স্প্লিট করে অন্য লাইনে পাঠান"
                      >
                        <Scissors className="w-3 h-3 text-purple-400" />
                        <span>স্প্লিট অর্ডার</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onEditPlan(c.barA.planId);
                          onClose();
                        }}
                        className="px-2 py-1 rounded bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 hover:text-white font-bold text-[10.5px] flex items-center gap-1 transition cursor-pointer"
                        title="প্ল্যান এডিট করে লাইন বা তারিখ পরিবর্তন করুন"
                      >
                        <Pencil className="w-3 h-3 text-blue-400" />
                        <span>এডিট</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onUnplan(c.barA.planId, c.barA.style, c.barA.buyer);
                          onClose();
                        }}
                        className="px-2 py-1 rounded hover:bg-amber-500/20 border border-border text-muted-foreground hover:text-amber-300 font-bold text-[10.5px] flex items-center gap-1 transition cursor-pointer"
                        title="লাইন ফাঁকা করতে আনপ্ল্যান্ড পুলে পাঠান"
                      >
                        <RotateCcw className="w-3 h-3 text-amber-400" />
                        <span>আনপ্ল্যান</span>
                      </button>
                    </div>
                  </div>

                  {/* Style B */}
                  <div className="rounded-lg border border-border/80 bg-panel p-3 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] text-muted-foreground uppercase font-bold block">
                          স্টাইল ২ (Style B)
                        </span>
                        <h4 className="font-extrabold text-foreground text-sm">{c.barB.style}</h4>
                        <span className="text-[11px] text-muted-foreground font-semibold">
                          বায়ার: {c.barB.buyer}
                        </span>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono font-bold text-[11px] shrink-0">
                        {c.barB.qty.toLocaleString()} pcs
                      </span>
                    </div>

                    <div className="text-[11px] text-muted-foreground font-mono space-y-0.5 pt-1 border-t border-border/40">
                      <div>
                        সময়কাল:{" "}
                        <b className="text-foreground">
                          {c.barB.start} → {c.barB.end}
                        </b>
                      </div>
                      {c.barB.dailyTarget && c.barB.dailyTarget > 0 && (
                        <div>
                          টার্গেট: <b className="text-yellow-300">{c.barB.dailyTarget}/দিন</b>
                        </div>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          onOpenSplitModal({
                            planId: c.barB.planId,
                            style: c.barB.style,
                            buyer: c.barB.buyer,
                            season: c.barB.season,
                            orderQty: c.barB.qty,
                            plannedQty: c.barB.qty,
                            currentLine: c.barB.line,
                            dailyTarget: c.barB.dailyTarget,
                          });
                          onClose();
                        }}
                        className="px-2 py-1 rounded bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 hover:text-white font-extrabold text-[10.5px] flex items-center gap-1 transition cursor-pointer"
                        title="এই স্টাইলটি স্প্লিট করে অন্য লাইনে পাঠান"
                      >
                        <Scissors className="w-3 h-3 text-purple-400" />
                        <span>স্প্লিট অর্ডার</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onEditPlan(c.barB.planId);
                          onClose();
                        }}
                        className="px-2 py-1 rounded bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 hover:text-white font-bold text-[10.5px] flex items-center gap-1 transition cursor-pointer"
                        title="প্ল্যান এডিট করে লাইন বা তারিখ পরিবর্তন করুন"
                      >
                        <Pencil className="w-3 h-3 text-blue-400" />
                        <span>এডিট</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onUnplan(c.barB.planId, c.barB.style, c.barB.buyer);
                          onClose();
                        }}
                        className="px-2 py-1 rounded hover:bg-amber-500/20 border border-border text-muted-foreground hover:text-amber-300 font-bold text-[10.5px] flex items-center gap-1 transition cursor-pointer"
                        title="লাইন ফাঁকা করতে আনপ্ল্যান্ড পুলে পাঠান"
                      >
                        <RotateCcw className="w-3 h-3 text-amber-400" />
                        <span>আনপ্ল্যান</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Footer with Focus Link */}
                {onFocusLine && (
                  <div className="pt-1 flex items-center justify-end">
                    <button
                      type="button"
                      onClick={() => {
                        onFocusLine(c.line);
                        onClose();
                      }}
                      className="text-[11px] font-bold text-teal-400 hover:text-teal-300 flex items-center gap-1 cursor-pointer"
                    >
                      <span>প্ল্যান বোর্ডে এই লাইনে স্ক্রোল করুন</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
