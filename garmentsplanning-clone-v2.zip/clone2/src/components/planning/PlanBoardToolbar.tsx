import React from "react";
import {
  Loader2,
  PackageOpen,
  CheckCircle2,
  AlertTriangle,
  Maximize2,
  Minimize2,
  ArrowUpDown,
  ChevronDown,
  Eye,
  AlignJustify,
  Scale,
  ListOrdered,
  ArrowRightLeft,
  CheckSquare,
  SlidersHorizontal,
} from "lucide-react";
import { FilterSelect } from "./LineSummaryView";

export type Density = "ultra" | "glance" | "compact" | "normal";
export type Zoom = "day" | "week" | "month";
export type VHeightMode = "standard" | "large" | "max";

export type PlanBoardToolbarProps = {
  compactHeader: boolean;
  onToggleCompactHeader: () => void;

  // Filters
  lineFilter: string[];
  onLineFilterChange: (val: string[]) => void;
  lineOptions: { label: string; value: string }[];

  buyerFilter: string[];
  onBuyerFilterChange: (val: string[]) => void;
  buyerOptions: { label: string; value: string }[];

  styleFilter: string[];
  onStyleFilterChange: (val: string[]) => void;
  styleOptions: { label: string; value: string }[];

  pastMonthFilter: string[];
  onPastMonthFilterChange: (val: string[]) => void;
  pastMonthOptions: { label: string; value: string }[];

  onClearFilters: () => void;
  visibleLinesCount: number;
  visibleBarsCount: number;

  // Toolbar Rows Option
  twoRowToolbar: boolean;
  onToggleTwoRowToolbar: () => void;

  // Undo / Redo
  undo: () => void;
  redo: () => void;
  undoStackLength: number;
  redoStackLength: number;
  undoLabel?: string;
  redoLabel?: string;
  busyHistory: "undo" | "redo" | null;

  // Display / Nav Controls
  zoom: Zoom;
  onZoomChange: (z: Zoom) => void;
  rowDensity: Density;
  onSetRowDensity: (d: Density) => void;
  onSetCustomColWidth: (w: number) => void;
  lineColWidth: number;
  vHeight: VHeightMode;
  onSetVHeight: (v: VHeightMode) => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  toggleAtAGlance: () => void;

  // Feature / Audit Buttons (Row 2)
  autoSaveOnDrop: boolean;
  onSetAutoSaveOnDrop: (val: boolean) => void;
  applying: boolean;

  showFabricEta: boolean;
  onSetShowFabricEta: (val: boolean) => void;
  fabricEtaBarsCount: number;
  totalBarsCount: number;

  varianceIssuesCount: number;
  onOpenVarianceModal: () => void;

  showVarianceBadges: boolean;
  onSetShowVarianceBadges: (val: boolean) => void;

  showDailyTarget: boolean;
  onSetShowDailyTarget: (val: boolean) => void;

  unplannedCount: number;
  onOpenUnplannedDrawer: () => void;

  onSwitchToStyleLines: () => void;

  bulkSelectedCount: number;
  onOpenBulkModal: () => void;

  isBulkSelectMode: boolean;
  onToggleBulkSelectMode: () => void;

  conflictsCount: number;
  conflictLinesCount: number;
  onOpenConflictDrawer: () => void;
  filterConflictingOnly: boolean;
  onToggleFilterConflictingOnly: () => void;
};

export function PlanBoardToolbar({
  compactHeader,
  onToggleCompactHeader,
  lineFilter,
  onLineFilterChange,
  lineOptions,
  buyerFilter,
  onBuyerFilterChange,
  buyerOptions,
  styleFilter,
  onStyleFilterChange,
  styleOptions,
  pastMonthFilter,
  onPastMonthFilterChange,
  pastMonthOptions,
  onClearFilters,
  visibleLinesCount,
  visibleBarsCount,
  twoRowToolbar,
  onToggleTwoRowToolbar,
  undo,
  redo,
  undoStackLength,
  redoStackLength,
  undoLabel,
  redoLabel,
  busyHistory,
  zoom,
  onZoomChange,
  rowDensity,
  onSetRowDensity,
  onSetCustomColWidth,
  lineColWidth,
  vHeight,
  onSetVHeight,
  isFullscreen,
  onToggleFullscreen,
  toggleAtAGlance,
  autoSaveOnDrop,
  onSetAutoSaveOnDrop,
  applying,
  showFabricEta,
  onSetShowFabricEta,
  fabricEtaBarsCount,
  totalBarsCount,
  varianceIssuesCount,
  onOpenVarianceModal,
  showVarianceBadges,
  onSetShowVarianceBadges,
  showDailyTarget,
  onSetShowDailyTarget,
  unplannedCount,
  onOpenUnplannedDrawer,
  onSwitchToStyleLines,
  bulkSelectedCount,
  onOpenBulkModal,
  isBulkSelectMode,
  onToggleBulkSelectMode,
  conflictsCount,
  conflictLinesCount,
  onOpenConflictDrawer,
  filterConflictingOnly,
  onToggleFilterConflictingOnly,
}: PlanBoardToolbarProps) {
  const hasActiveFilters =
    lineFilter.length > 0 ||
    buyerFilter.length > 0 ||
    styleFilter.length > 0 ||
    pastMonthFilter.length > 0;

  // Render the feature/audit title buttons
  const renderFeatureButtons = () => (
    <>
      {/* Auto-Save Database */}
      <label
        className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold rounded border cursor-pointer select-none transition shrink-0 ${
          autoSaveOnDrop
            ? "bg-emerald-600/15 border-emerald-500/50 text-emerald-300"
            : "bg-panel-2 border-border text-muted-foreground hover:bg-panel hover:text-foreground"
        }`}
        title="When checked, dragging and dropping immediately reschedules the line and saves to the database automatically"
      >
        <input
          type="checkbox"
          checked={autoSaveOnDrop}
          onChange={(e) => onSetAutoSaveOnDrop(e.target.checked)}
          className="rounded border-border text-emerald-600 focus:ring-emerald-500 w-3 h-3 cursor-pointer"
        />
        <span className="flex items-center gap-0.5">
          <span>⚡</span>
          <span>Auto-Save Database</span>
        </span>
      </label>
      {applying && (
        <span className="inline-flex items-center gap-1 text-[9.5px] text-amber-300 font-medium animate-pulse px-1.5 py-0.5 bg-amber-500/10 rounded border border-amber-500/30 shrink-0">
          <Loader2 className="w-2.5 h-2.5 animate-spin" />
          <span>Saving...</span>
        </span>
      )}

      {/* Fabric ETA */}
      <label
        className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold rounded border cursor-pointer select-none transition shrink-0 ${
          showFabricEta
            ? "bg-teal-500/20 border-teal-500/60 text-teal-300 font-bold shadow-xs"
            : "bg-panel-2 border-border text-muted-foreground hover:bg-panel hover:text-foreground"
        }`}
        title="প্ল্যান বোর্ড রো-তে ফ্যাব্রিক ETA প্রদর্শন চালু/বন্ধ করুন"
      >
        <input
          type="checkbox"
          checked={showFabricEta}
          onChange={(e) => onSetShowFabricEta(e.target.checked)}
          className="rounded border-border text-teal-600 focus:ring-teal-500 w-3 h-3 cursor-pointer"
        />
        <span className="flex items-center gap-1">
          <span>🧵 Fabric ETA</span>
          <span className="text-[9px] px-1 py-0.2 rounded bg-teal-500/25 text-teal-200 font-mono font-bold">
            {fabricEtaBarsCount}/{totalBarsCount}
          </span>
        </span>
      </label>

      {/* ভ্যারিয়েন্স অডিট (+/- %) */}
      <button
        type="button"
        onClick={onOpenVarianceModal}
        className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold rounded border transition cursor-pointer select-none shrink-0 ${
          varianceIssuesCount > 0
            ? "border-amber-500/60 bg-amber-500/15 text-amber-300 hover:bg-amber-500/25 ring-1 ring-amber-500/40"
            : "border-purple-500/40 bg-purple-500/15 text-purple-300 hover:bg-purple-500/25"
        }`}
        title="স্টাইল ভিত্তিক ওভার/আন্ডার প্ল্যান পার্সেন্টেজ অডিট ও রি-প্ল্যান/অটো-ফিক্স মডাল খুলুন"
      >
        <Scale className="w-3 h-3 text-purple-400" />
        <span>ভ্যারিয়েন্স অডিট (+/- %)</span>
        {varianceIssuesCount > 0 ? (
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/25 text-amber-200 font-mono font-bold animate-pulse">
            {varianceIssuesCount} অমিল
          </span>
        ) : (
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/25 text-emerald-200 font-mono font-bold">
            ১০০% ম্যাচ
          </span>
        )}
      </button>

      {/* +/- % ব্যাজ */}
      <label
        className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold rounded border cursor-pointer select-none transition shrink-0 ${
          showVarianceBadges
            ? "bg-purple-500/20 border-purple-500/60 text-purple-300 font-bold shadow-xs"
            : "bg-panel-2 border-border text-muted-foreground hover:bg-panel hover:text-foreground"
        }`}
        title="প্ল্যান বোর্ডে প্রতিটি স্টাইল বারে কম বা বেশি প্ল্যানের পার্সেন্টেজ (+/- %) ব্যাজ প্রদর্শন চালু/বন্ধ করুন"
      >
        <input
          type="checkbox"
          checked={showVarianceBadges}
          onChange={(e) => onSetShowVarianceBadges(e.target.checked)}
          className="rounded border-border text-purple-600 focus:ring-purple-500 w-3 h-3 cursor-pointer"
        />
        <span className="flex items-center gap-1">
          <span>⚖️ +/- % ব্যাজ</span>
          {varianceIssuesCount > 0 && (
            <span className="text-[9px] px-1 py-0.2 rounded bg-rose-500/25 text-rose-200 font-mono font-bold">
              {varianceIssuesCount}
            </span>
          )}
        </span>
      </label>

      {/* Target/Day/Line */}
      <label
        className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold rounded border cursor-pointer select-none transition shrink-0 ${
          showDailyTarget
            ? "bg-cyan-500/20 border-cyan-500/60 text-cyan-300 font-bold shadow-xs"
            : "bg-panel-2 border-border text-muted-foreground hover:bg-panel hover:text-foreground"
        }`}
        title="প্ল্যান বোর্ডে প্রতিটি স্টাইল বারে এবং কার্সরে Target/Day/Line প্রদর্শন চালু/বন্ধ করুন"
      >
        <input
          type="checkbox"
          checked={showDailyTarget}
          onChange={(e) => onSetShowDailyTarget(e.target.checked)}
          className="rounded border-border text-cyan-600 focus:ring-cyan-500 w-3 h-3 cursor-pointer"
        />
        <span className="flex items-center gap-0.5">
          <span>🎯 Target/Day/Line</span>
        </span>
      </label>

      {/* আনপ্ল্যান্ড পুল */}
      <button
        type="button"
        onClick={onOpenUnplannedDrawer}
        className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold rounded border border-amber-500/40 bg-amber-500/15 text-amber-300 hover:bg-amber-500/25 transition cursor-pointer select-none shrink-0"
        title="আনপ্ল্যান্ড অর্ডার তালিকা ও ব্যাকলগ দেখুন"
      >
        <PackageOpen className="w-3 h-3 text-amber-400" />
        <span>আনপ্ল্যান্ড পুল ({unplannedCount})</span>
      </button>

      {/* স্টাইল লাইন সামারি */}
      <button
        type="button"
        onClick={onSwitchToStyleLines}
        className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold rounded border border-teal-500/40 bg-teal-500/15 text-teal-300 hover:bg-teal-500/25 transition cursor-pointer select-none shadow-xs shrink-0"
        title="বায়ার, সিজন, স্টাইল অনুযায়ী মোট লাইন ও উল্লেখিত লাইনের সামারি দেখুন"
      >
        <ListOrdered className="w-3 h-3 text-teal-400" />
        <span>স্টাইল লাইন সামারি</span>
      </button>

      {/* বাল্ক লাইন অ্যাসাইন */}
      <button
        type="button"
        onClick={onOpenBulkModal}
        className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-black rounded border border-purple-500/60 bg-purple-600/20 text-purple-200 hover:bg-purple-600/35 transition cursor-pointer select-none shadow-xs shrink-0"
        title="একাধিক স্টাইল একসাথে নির্দিষ্ট লাইনে স্থানান্তর করুন (Bulk Line Assignment)"
      >
        <ArrowRightLeft className="w-3 h-3 text-purple-400" />
        <span>
          বাল্ক লাইন অ্যাসাইন{" "}
          {bulkSelectedCount > 0 && (
            <span className="px-1 py-0.2 rounded-full bg-purple-600 text-white font-mono text-[9px]">
              {bulkSelectedCount}
            </span>
          )}
        </span>
      </button>

      {/* মাল্টি-সিলেক্ট */}
      <button
        type="button"
        onClick={onToggleBulkSelectMode}
        className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold rounded border transition cursor-pointer select-none shrink-0 ${
          isBulkSelectMode
            ? "bg-purple-600 text-white border-purple-400 shadow-sm ring-1 ring-purple-400"
            : "bg-panel-2 border-border text-purple-300 hover:bg-panel hover:text-white"
        }`}
        title="প্ল্যান বোর্ড থেকে একাধিক স্টাইল বার ক্লিক করে সিলেক্ট করতে মোড অন/অফ করুন"
      >
        <CheckSquare className="w-3 h-3" />
        <span>{isBulkSelectMode ? "✓ সিলেক্ট চালু" : "মাল্টি-সিলেক্ট"}</span>
      </button>

      {/* লাইন কনফ্লিক্ট */}
      {conflictsCount > 0 ? (
        <div className="inline-flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={onOpenConflictDrawer}
            className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-black rounded border border-rose-500/80 bg-rose-600/25 text-rose-200 hover:bg-rose-600/35 transition cursor-pointer select-none shadow-sm animate-pulse ring-1 ring-rose-500/50"
            title={`${conflictsCount}টি লাইন কনফ্লিক্ট শনাক্ত হয়েছে! ক্লিক করে অডিট ও সমাধান প্যানেল দেখুন`}
          >
            <AlertTriangle className="w-3 h-3 text-rose-400" />
            <span>
              ⚠️ {conflictsCount} কনফ্লিক্ট ({conflictLinesCount}L)
            </span>
          </button>

          <button
            type="button"
            onClick={onToggleFilterConflictingOnly}
            className={`inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-bold rounded border transition cursor-pointer select-none ${
              filterConflictingOnly
                ? "bg-rose-600 text-white border-rose-400 shadow-sm"
                : "bg-panel-2 border-border text-rose-300 hover:bg-panel hover:text-white"
            }`}
            title="শুধু যে লাইনগুলোতে স্টাইল কনফ্লিক্ট আছে সেগুলো ফিল্টার করে দেখুন"
          >
            <span>{filterConflictingOnly ? "✓ ফিল্টার চালু" : "কনফ্লিক্ট ফিল্টার"}</span>
          </button>
        </div>
      ) : (
        <div
          className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold rounded border border-emerald-500/30 bg-emerald-500/10 text-emerald-300 select-none shrink-0"
          title="সবগুলো লাইনে স্টাইল বরাদ্দ সম্পূর্ণ কনফ্লিক্ট-মুক্ত"
        >
          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          <span>কনফ্লিক্ট মুক্ত</span>
        </div>
      )}
    </>
  );

  return (
    <div className="border-b border-border bg-panel/40 text-xs select-none">
      {/* ROW 1: Filters & Display/Navigation Controls */}
      <div className="px-2.5 py-1 flex items-center justify-between gap-1 flex-wrap">
        <div className="flex items-center gap-1 flex-wrap">
          {compactHeader && (
            <button
              type="button"
              onClick={onToggleCompactHeader}
              className="p-0.5 px-1.5 rounded border border-border/80 hover:bg-panel text-muted-foreground hover:text-foreground text-[10px] font-bold flex items-center gap-1 transition cursor-pointer"
              title="ব্যানার হেডার দেখান"
            >
              <ChevronDown className="w-3 h-3" />
              <span className="hidden sm:inline">হেডার</span>
            </button>
          )}

          <FilterSelect
            label="Line"
            value={lineFilter}
            onChange={onLineFilterChange}
            options={lineOptions}
          />
          <FilterSelect
            label="Buyer"
            value={buyerFilter}
            onChange={onBuyerFilterChange}
            options={buyerOptions}
          />
          <FilterSelect
            label="Style"
            value={styleFilter}
            onChange={onStyleFilterChange}
            options={styleOptions}
          />
          {pastMonthOptions.length > 0 && (
            <FilterSelect
              label="Display Month"
              value={pastMonthFilter}
              onChange={onPastMonthFilterChange}
              options={pastMonthOptions}
            />
          )}

          {hasActiveFilters && (
            <button
              onClick={onClearFilters}
              className="text-[10px] font-bold text-red-300 hover:text-red-200 underline ml-0.5 cursor-pointer"
            >
              Clear
            </button>
          )}

          {/* User Requested Option: 2-Row vs 1-Row Toolbar Toggle */}
          <button
            type="button"
            onClick={onToggleTwoRowToolbar}
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border transition cursor-pointer text-[10px] font-bold select-none ${
              twoRowToolbar
                ? "bg-purple-600/25 border-purple-400 text-purple-200 hover:bg-purple-600/35 shadow-xs"
                : "bg-panel-2 border-border text-muted-foreground hover:bg-panel hover:text-foreground"
            }`}
            title="টুলবার টাইটেলগুলো ২ সারিতে ছোট ফন্টে সব দৃশ্যমান করুন / ১ সারিতে রাখুন"
          >
            <SlidersHorizontal className="w-3 h-3 text-purple-400" />
            <span>{twoRowToolbar ? "২ সারি ভিউ (অন)" : "১ সারি ভিউ"}</span>
          </button>

          <span className="text-[10px] text-muted-foreground ml-1 hidden xl:inline">
            {visibleLinesCount} lines · {visibleBarsCount} styles
            {pastMonthFilter.length === 0 && pastMonthOptions.length > 0 && (
              <span className="text-amber-300 ml-1">· before yesterday hidden</span>
            )}
          </span>
        </div>

        {/* Right side of Row 1: Board Display & Nav Controls */}
        <div className="flex items-center gap-1 flex-wrap ml-auto">
          {/* Undo / Redo */}
          <div className="inline-flex rounded border border-border overflow-hidden">
            <button
              onClick={undo}
              disabled={undoStackLength === 0 || busyHistory !== null}
              title={undoStackLength ? `Undo: ${undoLabel}` : "Nothing to undo"}
              className="px-2 py-0.5 text-[10px] font-bold bg-panel-2 text-muted-foreground hover:bg-panel disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 cursor-pointer"
            >
              {busyHistory === "undo" ? <Loader2 className="w-2.5 h-2.5 animate-spin" /> : "↶"} Undo
              {undoStackLength > 0 ? ` (${undoStackLength})` : ""}
            </button>
            <button
              onClick={redo}
              disabled={redoStackLength === 0 || busyHistory !== null}
              title={redoStackLength ? `Redo: ${redoLabel}` : "Nothing to redo"}
              className="px-2 py-0.5 text-[10px] font-bold bg-panel-2 text-muted-foreground hover:bg-panel disabled:opacity-40 disabled:cursor-not-allowed border-l border-border flex items-center gap-1 cursor-pointer"
            >
              {busyHistory === "redo" ? <Loader2 className="w-2.5 h-2.5 animate-spin" /> : "↷"} Redo
              {redoStackLength > 0 ? ` (${redoStackLength})` : ""}
            </button>
          </div>

          {/* Zoom Controls */}
          <div className="inline-flex rounded border border-border overflow-hidden">
            {(["day", "week", "month"] as Zoom[]).map((z) => (
              <button
                key={z}
                onClick={() => onZoomChange(z)}
                className={`px-2 py-0.5 text-[10px] font-bold transition cursor-pointer ${
                  zoom === z
                    ? "bg-fuchsia-600 text-white"
                    : "bg-panel-2 text-muted-foreground hover:bg-panel"
                }`}
              >
                {z === "day" ? "Day" : z === "week" ? "Week" : "Month"}
              </button>
            ))}
          </div>

          {/* At a Glance One-Click Toggle */}
          <button
            type="button"
            onClick={toggleAtAGlance}
            className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold rounded border transition cursor-pointer select-none ${
              rowDensity === "glance" || rowDensity === "ultra"
                ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-emerald-400 shadow-md ring-1 ring-emerald-400/50"
                : "bg-panel-2 border-border text-muted-foreground hover:bg-panel hover:text-foreground"
            }`}
            title="সব লাইন একসাথে এক নজরে দেখার জন্য মোড অন/অফ করুন (এক ক্লিকে কমপ্যাক্ট মোড + ম্যাক্সিমাম ভার্টিক্যাল স্পেস)"
          >
            <Eye className="w-3 h-3 text-emerald-300" />
            <span>এক নজরে সব</span>
            {(rowDensity === "glance" || rowDensity === "ultra") && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse" />
            )}
          </button>

          {/* Row Height / Density Selector */}
          <div
            className="inline-flex rounded border border-border overflow-hidden"
            title="লাইনের রো উচ্চতা / ঘনত্ব নির্বাচন করুন"
          >
            <span className="px-1.5 py-0.5 text-[9.5px] font-bold bg-panel-2 text-muted-foreground flex items-center gap-0.5 border-r border-border">
              <AlignJustify className="w-2.5 h-2.5 text-emerald-400" />
              <span className="hidden sm:inline">রো</span>
            </span>
            <button
              type="button"
              onClick={() => {
                onSetRowDensity("ultra");
                onSetCustomColWidth(52);
              }}
              className={`px-1.5 py-0.5 text-[9.5px] font-bold transition cursor-pointer ${
                rowDensity === "ultra"
                  ? "bg-emerald-600 text-white"
                  : "bg-panel-2 text-muted-foreground hover:bg-panel"
              }`}
              title="আল্ট্রা কমপ্যাক্ট (২২px)"
            >
              ২২px
            </button>
            <button
              type="button"
              onClick={() => {
                onSetRowDensity("glance");
                onSetCustomColWidth(58);
              }}
              className={`px-1.5 py-0.5 text-[9.5px] font-bold transition cursor-pointer border-l border-border ${
                rowDensity === "glance"
                  ? "bg-emerald-600 text-white"
                  : "bg-panel-2 text-muted-foreground hover:bg-panel"
              }`}
              title="এক নজরে (২৬px)"
            >
              ২৬px
            </button>
            <button
              type="button"
              onClick={() => {
                onSetRowDensity("compact");
                onSetCustomColWidth(74);
              }}
              className={`px-1.5 py-0.5 text-[9.5px] font-bold transition cursor-pointer border-l border-border ${
                rowDensity === "compact"
                  ? "bg-emerald-600 text-white"
                  : "bg-panel-2 text-muted-foreground hover:bg-panel"
              }`}
              title="কমপ্যাক্ট (৩৪px)"
            >
              ৩৪px
            </button>
            <button
              type="button"
              onClick={() => {
                onSetRowDensity("normal");
                onSetCustomColWidth(94);
              }}
              className={`px-1.5 py-0.5 text-[9.5px] font-bold transition cursor-pointer border-l border-border ${
                rowDensity === "normal"
                  ? "bg-emerald-600 text-white"
                  : "bg-panel-2 text-muted-foreground hover:bg-panel"
              }`}
              title="স্বাভাবিক (৪৪px)"
            >
              ৪৪px
            </button>
          </div>

          {/* Line Column Width Selector */}
          <div
            className="inline-flex rounded border border-border overflow-hidden"
            title="লাইন কলামের প্রস্থ (Line Column Width)"
          >
            <span className="px-1.5 py-0.5 text-[9.5px] font-bold bg-panel-2 text-muted-foreground flex items-center gap-0.5 border-r border-border">
              <span className="hidden sm:inline">কলাম</span>
            </span>
            <button
              type="button"
              onClick={() => onSetCustomColWidth(52)}
              className={`px-1.5 py-0.5 text-[9.5px] font-bold transition cursor-pointer ${
                lineColWidth <= 56
                  ? "bg-teal-600 text-white"
                  : "bg-panel-2 text-muted-foreground hover:bg-panel"
              }`}
              title="সংক্ষিপ্ত কলাম (৫২px - L-01)"
            >
              ৫২px
            </button>
            <button
              type="button"
              onClick={() => onSetCustomColWidth(74)}
              className={`px-1.5 py-0.5 text-[9.5px] font-bold transition cursor-pointer border-l border-border ${
                lineColWidth > 56 && lineColWidth <= 80
                  ? "bg-teal-600 text-white"
                  : "bg-panel-2 text-muted-foreground hover:bg-panel"
              }`}
              title="মাঝারি কলাম (৭৪px - Line 01)"
            >
              ৭৪px
            </button>
            <button
              type="button"
              onClick={() => onSetCustomColWidth(94)}
              className={`px-1.5 py-0.5 text-[9.5px] font-bold transition cursor-pointer border-l border-border ${
                lineColWidth > 80
                  ? "bg-teal-600 text-white"
                  : "bg-panel-2 text-muted-foreground hover:bg-panel"
              }`}
              title="পূর্ণ কলাম (৯৪px - Line - 01)"
            >
              ৯৪px
            </button>
          </div>

          {/* Vertical Height Selector */}
          <div
            className="inline-flex rounded border border-border overflow-hidden"
            title="ভার্টিক্যাল স্ক্রলিং সাইজ নির্বাচন করুন"
          >
            <span className="px-1.5 py-0.5 text-[9.5px] font-bold bg-panel-2 text-muted-foreground flex items-center gap-0.5 border-r border-border">
              <ArrowUpDown className="w-2.5 h-2.5 text-fuchsia-400" />
              <span className="hidden sm:inline">সাইজ</span>
            </span>
            <button
              type="button"
              onClick={() => onSetVHeight("standard")}
              className={`px-1.5 py-0.5 text-[9.5px] font-bold transition cursor-pointer ${
                vHeight === "standard"
                  ? "bg-fuchsia-600 text-white"
                  : "bg-panel-2 text-muted-foreground hover:bg-panel"
              }`}
              title="স্বাভাবিক সাইজ (৭৫% স্ক্রিন)"
            >
              স্বাভাবিক
            </button>
            <button
              type="button"
              onClick={() => onSetVHeight("large")}
              className={`px-1.5 py-0.5 text-[9.5px] font-bold transition cursor-pointer border-l border-border ${
                vHeight === "large"
                  ? "bg-fuchsia-600 text-white"
                  : "bg-panel-2 text-muted-foreground hover:bg-panel"
              }`}
              title="বড় সাইজ (৮৮% স্ক্রিন হাইট - ডিফল্ট)"
            >
              বড়
            </button>
            <button
              type="button"
              onClick={() => onSetVHeight("max")}
              className={`px-1.5 py-0.5 text-[9.5px] font-bold transition cursor-pointer border-l border-border ${
                vHeight === "max"
                  ? "bg-fuchsia-600 text-white"
                  : "bg-panel-2 text-muted-foreground hover:bg-panel"
              }`}
              title="সর্বোচ্চ সাইজ (৯৪% স্ক্রিন হাইট)"
            >
              ম্যাক্স
            </button>
          </div>

          {/* Fullscreen Toggle */}
          <button
            type="button"
            onClick={onToggleFullscreen}
            className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold rounded border transition cursor-pointer select-none ${
              isFullscreen
                ? "bg-fuchsia-600 text-white border-fuchsia-500 shadow-lg"
                : "bg-panel-2 border-border text-muted-foreground hover:bg-panel hover:text-foreground"
            }`}
            title={
              isFullscreen
                ? "ফুল ভিউ বন্ধ করুন (Esc)"
                : "সম্পূর্ণ উইন্ডো জুড়ে বোর্ড বড় করুন (Fullscreen)"
            }
          >
            {isFullscreen ? (
              <>
                <Minimize2 className="w-3 h-3" />
                <span>ছোট করুন</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3 h-3 text-fuchsia-400" />
                <span>ফুল ভিউ</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* ROW 2: All Feature, Audit & Title Badges (Visible across the full width when twoRowToolbar is true) */}
      {twoRowToolbar ? (
        <div className="px-2.5 py-1 bg-panel-2/25 border-t border-border/40 flex items-center gap-1.5 overflow-x-auto scrollbar-thin">
          {renderFeatureButtons()}
        </div>
      ) : (
        /* Single-Row Fallback (when user turns off 2-row view) */
        <div className="px-2.5 py-1 bg-panel-2/15 border-t border-border/40 flex items-center gap-1.5 overflow-x-auto scrollbar-thin">
          {renderFeatureButtons()}
        </div>
      )}
    </div>
  );
}
