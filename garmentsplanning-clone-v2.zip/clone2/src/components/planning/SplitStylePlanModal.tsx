import { useEffect, useMemo, useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/hooks/use-current-user";
import {
  Scissors,
  Layers,
  Zap,
  RotateCcw,
  Pencil,
  X,
  CheckCircle2,
  Loader2,
  Info,
  GitFork,
  ArrowRight,
  ShieldCheck,
} from "lucide-react";
import { toast } from "sonner";
import { calculatePlan, type LineInput, type PlanResult } from "@/lib/plan-calc";
import { logActivity } from "@/lib/audit-logger";

export type SplitStylePlanModalProps = {
  open: boolean;
  onClose: () => void;
  planId: string | null;
  styleName: string;
  buyerName: string;
  season?: string | null;
  orderQty: number;
  plannedQty: number;
  lineQty?: number;
  currentLine?: string;
  dailyTarget?: number;
  shipmentDate?: string;
  linePresets: string[];
  globalHolidays: string[];
  onSuccess?: () => void;
  onOpenPlanInput?: (planId: string) => void;
};

function normalizeLine(name: string | null | undefined): string {
  if (!name) return "";
  return name.toLowerCase().replace(/[^a-z0-9]/g, "");
}

export function SplitStylePlanModal({
  open,
  onClose,
  planId,
  styleName,
  buyerName,
  season,
  orderQty,
  plannedQty,
  lineQty,
  currentLine,
  dailyTarget = 500,
  shipmentDate = "",
  linePresets,
  globalHolidays,
  onSuccess,
  onOpenPlanInput,
}: SplitStylePlanModalProps) {
  const { data: user } = useCurrentUser();

  // Mode: "unplanned" (Pool) | "schedule" (Direct Line) | "input" (Full Form)
  const [strategy, setStrategy] = useState<"unplanned" | "schedule" | "input">("schedule");

  // Allocation View Option: "line" (Only currentLine's allocation) vs "total" (Total across all lines)
  // Default to "line" as requested by the user.
  const [allocationScope, setAllocationScope] = useState<"line" | "total">("line");

  // Loaded fresh plan data from DB for accurate multi-line inspection
  const [planData, setPlanData] = useState<any | null>(null);

  useEffect(() => {
    if (open && planId) {
      let active = true;
      supabase
        .from("plans")
        .select("*")
        .eq("id", planId)
        .single()
        .then(({ data, error }) => {
          if (active && !error && data) {
            setPlanData(data);
          }
        });
      return () => {
        active = false;
      };
    } else {
      setPlanData(null);
    }
  }, [open, planId]);

  // Derive exact line allocation vs total planned
  const {
    effectiveLineQty,
    effectiveTotalPlanned,
    otherLinesTotal,
    hasMultipleLines,
    lineNameDisplay,
  } = useMemo(() => {
    const targetLineNorm = normalizeLine(currentLine);
    const dbLines: any[] = planData?.calc_result?.lines || planData?.config?.lines || [];

    let lineFoundAlloc: number | null = null;
    let sumTotal = 0;
    let detectedLineName = currentLine || "বর্তমান লাইন";

    if (dbLines.length > 0) {
      for (const l of dbLines) {
        const lNorm = normalizeLine(l?.name);
        const lAlloc =
          Number(l?.plannedQty) ||
          Number(l?.allocatedOrderQty) ||
          (Array.isArray(l?.dailyProduction)
            ? l.dailyProduction.reduce((s: number, d: any) => s + (Number(d?.qty) || 0), 0)
            : 0) ||
          0;

        sumTotal += lAlloc;

        if (targetLineNorm && lNorm === targetLineNorm && lineFoundAlloc === null) {
          lineFoundAlloc = lAlloc;
          if (l?.name) detectedLineName = l.name;
        }
      }
    }

    const totalAlloc = sumTotal > 0 ? sumTotal : plannedQty || orderQty;
    const resolvedLineQty =
      lineFoundAlloc !== null && lineFoundAlloc > 0
        ? lineFoundAlloc
        : lineQty !== undefined && lineQty > 0
          ? lineQty
          : totalAlloc;

    const otherTotal = Math.max(0, totalAlloc - resolvedLineQty);
    const multiLines = dbLines.length > 1 || otherTotal > 0;

    return {
      effectiveLineQty: resolvedLineQty,
      effectiveTotalPlanned: totalAlloc,
      otherLinesTotal: otherTotal,
      hasMultipleLines: multiLines,
      lineNameDisplay: detectedLineName,
    };
  }, [planData, currentLine, lineQty, plannedQty, orderQty]);

  // Quantities based on active allocationScope
  const activeBaseQty =
    allocationScope === "line" ? effectiveLineQty : effectiveTotalPlanned || orderQty;

  const [keptQty, setKeptQty] = useState<number>(activeBaseQty);
  const [splitQty, setSplitQty] = useState<number>(0);
  const [newStyleName, setNewStyleName] = useState<string>(`${styleName} (Part 2)`);

  // Available lines for scheduling
  const availableLines = useMemo(() => {
    const norm = normalizeLine(currentLine);
    return linePresets.filter((l) => normalizeLine(l) !== norm);
  }, [linePresets, currentLine]);

  const [targetLine, setTargetLine] = useState<string>("");
  const [startDate, setStartDate] = useState<string>(
    new Date(Date.now() + 86400000).toISOString().slice(0, 10),
  );
  const [targetPerDay, setTargetPerDay] = useState<number>(dailyTarget > 0 ? dailyTarget : 500);
  const [submitting, setSubmitting] = useState(false);

  // Sync state when modal opens or base quantity updates
  const prevSplitKeyRef = useRef<string>("");

  useEffect(() => {
    if (open) {
      const splitKey = `${open}:${planId}:${allocationScope}:${activeBaseQty}`;
      if (prevSplitKeyRef.current !== splitKey) {
        prevSplitKeyRef.current = splitKey;
        setKeptQty(activeBaseQty);
        setSplitQty(0);
        setNewStyleName(`${styleName} (Part 2)`);
        setStrategy("schedule");
        setTargetLine(availableLines[0] || linePresets[0] || "Line 01");
        setTargetPerDay(dailyTarget > 0 ? dailyTarget : 500);
        setStartDate(new Date(Date.now() + 86400000).toISOString().slice(0, 10));
      }
    } else {
      prevSplitKeyRef.current = "";
    }
  }, [
    open,
    planId,
    allocationScope,
    activeBaseQty,
    styleName,
    availableLines,
    linePresets,
    dailyTarget,
  ]);

  if (!open || !planId) return null;

  // Quantity change handlers
  const handleKeptChange = (val: number) => {
    const k = Math.max(1, Math.min(activeBaseQty, val));
    setKeptQty(k);
    setSplitQty(Math.max(0, activeBaseQty - k));
  };

  const handleSplitChange = (val: number) => {
    const s = Math.max(0, Math.min(activeBaseQty - 1, val));
    setSplitQty(s);
    setKeptQty(Math.max(1, activeBaseQty - s));
  };

  const applyPercentSplit = (pct: number) => {
    const s = Math.round((activeBaseQty * pct) / 100);
    const safeS = Math.max(0, Math.min(activeBaseQty - 1, s));
    setSplitQty(safeS);
    setKeptQty(Math.max(1, activeBaseQty - safeS));
  };

  const handleExecuteSplit = async () => {
    if (splitQty <= 0) {
      toast.error("আলাদা করার কোয়ান্টিটি অবশ্যই ০ এর বেশি হতে হবে।");
      return;
    }
    if (keptQty <= 0) {
      toast.error("মূল লাইনে রাখার কোয়ান্টিটি অবশ্যই ০ এর বেশি হতে হবে।");
      return;
    }
    if (strategy === "schedule" && !targetLine) {
      toast.error("অনুগ্রহ করে নতুন লাইনের নাম নির্বাচন করুন।");
      return;
    }

    setSubmitting(true);
    try {
      // 1. Fetch fresh plan from DB
      const { data: currentPlan, error: fetchErr } = await supabase
        .from("plans")
        .select("*")
        .eq("id", planId)
        .single();

      if (fetchErr || !currentPlan) {
        throw new Error("মূল প্ল্যান ডেটাবেজ থেকে পাওয়া যায়নি।");
      }

      const pConfig = (currentPlan.config as Record<string, any>) || {};
      const pCalc = (currentPlan.calc_result as PlanResult) || {};
      const excessPct = currentPlan.excess_pct ?? 0;
      const targetDaily = currentPlan.daily_target ?? targetPerDay;
      const shipDate = currentPlan.shipment_date || shipmentDate;
      const originalTotalOrder = Number(currentPlan.order_qty) || orderQty;

      let updatedConfigLines: LineInput[] = [];
      let newOrderQtyA = originalTotalOrder;

      if (allocationScope === "line" && currentLine) {
        // Line-specific split: only modify currentLine, preserve all other lines intact
        const normCurrent = normalizeLine(currentLine);
        const existingLines = pConfig.lines || pCalc?.lines || [];

        let lineUpdated = false;
        if (existingLines.length > 0) {
          updatedConfigLines = existingLines.map((l: any, idx: number) => {
            const lNorm = normalizeLine(l?.name);
            if (lNorm === normCurrent) {
              lineUpdated = true;
              return {
                id: l.id || idx + 1,
                name: l.name || currentLine,
                startDateStr:
                  l.startDateStr ||
                  l.startDate ||
                  pCalc?.lines?.[idx]?.startDateStr ||
                  new Date().toISOString().slice(0, 10),
                allocatedOrderQty: keptQty,
                applyLC: !!l.applyLC,
                chainAuto: l.chainAuto !== false,
                targetOverride: l.targetOverride ?? targetDaily,
              };
            }
            return {
              id: l.id || idx + 1,
              name: l.name,
              startDateStr:
                l.startDateStr ||
                l.startDate ||
                pCalc?.lines?.[idx]?.startDateStr ||
                new Date().toISOString().slice(0, 10),
              allocatedOrderQty: Number(l.allocatedOrderQty || l.plannedQty) || 0,
              applyLC: !!l.applyLC,
              chainAuto: l.chainAuto !== false,
              targetOverride: l.targetOverride,
            };
          });
        }

        if (!lineUpdated) {
          updatedConfigLines = [
            {
              id: 1,
              name: currentLine,
              startDateStr:
                pCalc?.lines?.[0]?.startDateStr || new Date().toISOString().slice(0, 10),
              allocatedOrderQty: keptQty,
              applyLC: false,
              chainAuto: true,
              targetOverride: targetDaily,
            },
          ];
        }

        // New total order qty of Plan A is original order minus splitQty
        newOrderQtyA = Math.max(1, originalTotalOrder - splitQty);
      } else {
        // Order-wide split
        newOrderQtyA = keptQty;
        const originalLines: LineInput[] = (pConfig.lines || []).map(
          (l: LineInput, idx: number) => ({
            ...l,
            id: l.id || idx + 1,
            allocatedOrderQty: keptQty,
          }),
        );

        updatedConfigLines =
          originalLines.length > 0
            ? originalLines
            : [
                {
                  id: 1,
                  name: currentLine || "Line 01",
                  startDateStr:
                    pCalc?.lines?.[0]?.startDateStr || new Date().toISOString().slice(0, 10),
                  allocatedOrderQty: keptQty,
                  applyLC: false,
                  chainAuto: true,
                  targetOverride: targetDaily,
                },
              ];
      }

      // Recalculate Plan A
      const recalculatedPlanA = calculatePlan({
        buyer: currentPlan.buyer,
        style: currentPlan.style,
        orderQty: newOrderQtyA,
        excessPct,
        dailyTargetPerLine: targetDaily,
        shipmentDate: shipDate,
        lines: updatedConfigLines,
        customHolidays: globalHolidays,
        targetAdjustments: pConfig.targetAdjustments || [],
        targetAdjustmentsEnabled: !!pConfig.targetAdjustmentsEnabled,
        learningCurve: pConfig.learningCurve,
      });

      // Update Plan A in DB
      const { error: updatePlanAErr } = await supabase
        .from("plans")
        .update({
          order_qty: newOrderQtyA,
          calc_result: recalculatedPlanA as any,
          config: {
            ...pConfig,
            lines: recalculatedPlanA.lines,
            split_info: {
              split_date: new Date().toISOString(),
              original_order_qty: originalTotalOrder,
              split_scope: allocationScope,
              split_line: currentLine,
              kept_qty: keptQty,
              split_qty: splitQty,
              split_to_style: newStyleName.trim(),
            },
          },
        } as any)
        .eq("id", planId);

      if (updatePlanAErr) throw updatePlanAErr;

      logActivity({
        action: "PLAN_EDIT",
        details: `স্টাইল স্প্লিট: "${styleName}" (${allocationScope === "line" ? currentLine : "সকল লাইন"}) থেকে ${splitQty.toLocaleString()} pcs আলাদা করা হয়েছে (মূল লাইনে রইলো ${keptQty.toLocaleString()} pcs)`,
        targetId: planId,
        targetName: styleName,
      });

      // 3. Handle Plan B based on chosen strategy
      let newPlanId: string | null = null;

      if (strategy === "unplanned" || strategy === "input") {
        // Create Unplanned Plan Record
        const unplannedPayload = {
          buyer: currentPlan.buyer,
          style: newStyleName.trim(),
          season: currentPlan.season || season || null,
          order_qty: splitQty,
          excess_pct: excessPct,
          daily_target: targetDaily,
          num_lines: 0,
          shipment_date: shipDate,
          config: {
            status: "unplanned",
            isUnplanned: true,
            lines: [],
            split_from_plan_id: planId,
            split_from_style: styleName,
            split_from_line: currentLine,
            created_via: "split_style_modal",
          },
          calc_result: {
            buyer: currentPlan.buyer,
            style: newStyleName.trim(),
            orderQty: splitQty,
            excessPct,
            dailyTargetPerLine: targetDaily,
            hasLineAllocation: false,
            lines: [],
            totalPlannedQty: splitQty,
            totalLineDaysSum: 0,
          },
          created_by: user?.id || currentPlan.created_by,
        };

        const { data: inserted, error: insertErr } = await supabase
          .from("plans")
          .insert(unplannedPayload as any)
          .select("id")
          .single();

        if (insertErr) throw insertErr;
        newPlanId = inserted?.id ?? null;

        logActivity({
          action: "PLAN_CREATE",
          details: `স্টাইল স্প্লিটের নতুন অংশ: "${newStyleName}" (${splitQty.toLocaleString()} pcs) আনপ্ল্যান্ড পুলে তৈরি হয়েছে`,
          targetId: newPlanId ?? undefined,
          targetName: newStyleName,
        });

        if (strategy === "input" && newPlanId) {
          toast.success(
            `স্টাইল স্প্লিট সম্পন্ন! বাকি ${splitQty.toLocaleString()} pcs নিয়ে প্ল্যান ইনপুট ফর্ম খোলা হচ্ছে...`,
          );
          onOpenPlanInput?.(newPlanId);
          window.dispatchEvent(new CustomEvent("cg:edit-plan", { detail: newPlanId }));
          onClose();
          onSuccess?.();
          return;
        }

        toast.success(
          `সফলভাবে স্প্লিট হয়েছে! মূল লাইনে (${currentLine || "মূল"}) রইলো ${keptQty.toLocaleString()} pcs এবং বাকি ${splitQty.toLocaleString()} pcs আনপ্ল্যান্ড পুলে যোগ হয়েছে।`,
        );
      } else if (strategy === "schedule") {
        // Direct schedule on targetLine
        const targetLineInput: LineInput = {
          id: 1,
          name: targetLine,
          startDateStr: startDate,
          allocatedOrderQty: splitQty,
          applyLC: false,
          chainAuto: true,
          targetOverride: targetPerDay > 0 ? targetPerDay : undefined,
        };

        const scheduledCalc = calculatePlan({
          buyer: currentPlan.buyer,
          style: newStyleName.trim(),
          orderQty: splitQty,
          excessPct,
          dailyTargetPerLine: targetPerDay,
          shipmentDate: shipDate,
          lines: [targetLineInput],
          customHolidays: globalHolidays,
          targetAdjustments: [],
          targetAdjustmentsEnabled: false,
        });

        const scheduledPayload = {
          buyer: currentPlan.buyer,
          style: newStyleName.trim(),
          season: currentPlan.season || season || null,
          order_qty: splitQty,
          excess_pct: excessPct,
          daily_target: targetPerDay,
          num_lines: 1,
          shipment_date: shipDate,
          config: {
            status: "planned",
            lines: scheduledCalc.lines,
            split_from_plan_id: planId,
            split_from_style: styleName,
            split_from_line: currentLine,
            created_via: "split_style_modal",
          },
          calc_result: scheduledCalc as any,
          created_by: user?.id || currentPlan.created_by,
        };

        const { data: inserted, error: insertSchedErr } = await supabase
          .from("plans")
          .insert(scheduledPayload as any)
          .select("id")
          .single();

        if (insertSchedErr) throw insertSchedErr;
        newPlanId = inserted?.id ?? null;

        logActivity({
          action: "PLAN_CREATE",
          details: `স্টাইল স্প্লিটের নতুন অংশ: "${newStyleName}" (${splitQty.toLocaleString()} pcs) সরাসরি ${targetLine}-এ শিডিউল করা হয়েছে`,
          targetId: newPlanId ?? undefined,
          targetName: newStyleName,
        });

        toast.success(
          `অভিনন্দন! মূল লাইনে (${currentLine || "মূল"}) ${keptQty.toLocaleString()} pcs রাখা হয়েছে এবং ${targetLine}-এ নতুন অংশ হিসেবে ${splitQty.toLocaleString()} pcs প্ল্যান বোর্ডে যুক্ত হয়েছে!`,
        );
      }

      onSuccess?.();
      onClose();
    } catch (err: any) {
      console.error(err);
      toast.error(err?.message || "স্টাইল স্প্লিট করার সময় সমস্যা হয়েছে।");
    } finally {
      setSubmitting(false);
    }
  };

  const varianceDiff = effectiveTotalPlanned - orderQty;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-xl rounded-2xl border border-purple-500/40 bg-panel shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-border bg-gradient-to-r from-purple-950/60 via-panel-2 to-panel-2 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <Scissors className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-foreground flex items-center gap-2">
                <span>Split Order</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30">
                  স্টাইল স্প্লিট ও নতুন লাইন এন্ট্রি
                </span>
              </h3>
              <p className="text-xs text-muted-foreground">
                বায়ার: <b className="text-foreground">{buyerName}</b> · স্টাইল:{" "}
                <b className="text-purple-300">{styleName}</b>
                {currentLine && (
                  <span className="ml-2 inline-flex items-center gap-1 px-1.5 py-0.2 rounded bg-purple-900/50 text-purple-200 border border-purple-500/40 font-mono text-[10.5px]">
                    📍 {currentLine}
                  </span>
                )}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-panel-2 text-muted-foreground hover:text-foreground transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto text-xs flex-1">
          {/* User Requested Option: Allocation View Switcher */}
          <div className="rounded-xl border border-purple-500/30 bg-purple-950/30 p-2.5 space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
              <span className="text-[11px] font-extrabold text-purple-200 flex items-center gap-1.5">
                <GitFork className="w-3.5 h-3.5 text-purple-400" />
                বরাদ্দ প্রদর্শন ও স্প্লিট অপশন:
              </span>
              <span className="text-[10px] text-purple-300/80">
                {hasMultipleLines ? "মাল্টি-লাইন প্ল্যান চিহ্নিত হয়েছে" : "একক লাইনের প্ল্যান"}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-lg bg-panel border border-border">
              <button
                type="button"
                onClick={() => setAllocationScope("line")}
                className={`py-1.5 px-2.5 rounded-md text-[11px] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  allocationScope === "line"
                    ? "bg-purple-600 text-white shadow-xs font-black"
                    : "text-muted-foreground hover:text-foreground hover:bg-panel-2"
                }`}
                title={`শুধুমাত্র ${lineNameDisplay}-এর বরাদ্দ (${effectiveLineQty.toLocaleString()} pcs) প্রদর্শন ও স্প্লিট করুন`}
              >
                <span>📍 শুধুমাত্র {lineNameDisplay}-এর বরাদ্দ</span>
                <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-black/25">
                  {effectiveLineQty.toLocaleString()} pcs
                </span>
              </button>

              <button
                type="button"
                onClick={() => setAllocationScope("total")}
                className={`py-1.5 px-2.5 rounded-md text-[11px] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  allocationScope === "total"
                    ? "bg-purple-600 text-white shadow-xs font-black"
                    : "text-muted-foreground hover:text-foreground hover:bg-panel-2"
                }`}
                title={`সকল লাইনের মোট প্ল্যান (${effectiveTotalPlanned.toLocaleString()} pcs) প্রদর্শন ও স্প্লিট করুন`}
              >
                <span>🌐 সকল লাইনের মোট প্ল্যান</span>
                <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-black/25">
                  {effectiveTotalPlanned.toLocaleString()} pcs
                </span>
              </button>
            </div>
          </div>

          {/* Status Breakdown Banner */}
          <div className="rounded-xl border border-border bg-panel-2/60 p-3.5 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-muted-foreground flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                বর্তমান অর্ডারের অবস্থা:
              </span>
              {varianceDiff >= 0 ? (
                <span className="text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md font-mono font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  ১০০% প্ল্যান সম্পন্ন
                  {varianceDiff > 0 && ` (+${varianceDiff.toLocaleString()} pcs)`}
                </span>
              ) : (
                <span className="text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded-md font-mono font-black">
                  বাকি আছে: {Math.abs(varianceDiff).toLocaleString()} pcs
                </span>
              )}
            </div>

            <div className="grid grid-cols-3 gap-2 text-center pt-1">
              {/* Card 1: Total Order */}
              <div className="p-2 rounded-lg bg-panel border border-border/70">
                <span className="text-[10px] text-muted-foreground block font-bold uppercase">
                  মোট অর্ডার
                </span>
                <span className="font-extrabold font-mono text-foreground text-sm mt-0.5 block">
                  {orderQty.toLocaleString()} pcs
                </span>
                <span className="text-[9.5px] text-muted-foreground block opacity-80 mt-0.5">
                  অর্ডার কোয়ান্টিটি
                </span>
              </div>

              {/* Card 2: Line Allocation (or Total based on Option) */}
              <div className="p-2 rounded-lg bg-panel border border-purple-500/40 relative overflow-hidden">
                <div className="absolute top-0 right-0 px-1 py-0.2 bg-purple-500/20 text-purple-300 font-mono text-[8.5px] font-bold rounded-bl">
                  {allocationScope === "line" ? "লাইন ফোকাস" : "মোট"}
                </div>
                <span className="text-[10px] text-purple-300 block font-bold uppercase truncate">
                  {allocationScope === "line"
                    ? `${lineNameDisplay}-এ বরাদ্দ`
                    : "সকল লাইনে মোট বরাদ্দ"}
                </span>
                <span className="font-extrabold font-mono text-emerald-400 text-sm mt-0.5 block">
                  {activeBaseQty.toLocaleString()} pcs
                </span>
                <span className="text-[9.5px] text-muted-foreground block opacity-80 mt-0.5 truncate">
                  {allocationScope === "line"
                    ? `(সকল লাইন মোট: ${effectiveTotalPlanned.toLocaleString()} pcs)`
                    : `(${otherLinesTotal.toLocaleString()} pcs অন্যান্য লাইনে)`}
                </span>
              </div>

              {/* Card 3: Deficit or Remaining */}
              <div className="p-2 rounded-lg bg-panel border border-border/70">
                <span className="text-[10px] text-muted-foreground block font-bold uppercase">
                  ঘাটতি / বাকি অংশ
                </span>
                <span className="font-extrabold font-mono text-amber-300 text-sm mt-0.5 block">
                  {varianceDiff >= 0 ? "0 pcs" : `${Math.abs(varianceDiff).toLocaleString()} pcs`}
                </span>
                <span className="text-[9.5px] text-muted-foreground block opacity-80 mt-0.5">
                  {varianceDiff >= 0 ? "অর্ডার সম্পূর্ণ কভারড" : "ঘাটতি বিদ্যমান"}
                </span>
              </div>
            </div>
          </div>

          {/* Quantity Allocation Adjuster */}
          <div className="rounded-xl border border-border bg-panel-2/40 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-extrabold text-foreground flex items-center gap-1.5">
                <span>✂️</span>
                <span>কোয়ান্টিটি কীভাবে ভাগ করতে চান?</span>
              </h4>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => applyPercentSplit(25)}
                  className="px-1.5 py-0.5 rounded bg-panel border border-border hover:bg-panel-2 text-[10px] text-muted-foreground hover:text-foreground font-mono"
                  title="২৫% স্প্লিট করুন"
                >
                  ২৫%
                </button>
                <button
                  type="button"
                  onClick={() => applyPercentSplit(50)}
                  className="px-1.5 py-0.5 rounded bg-panel border border-border hover:bg-panel-2 text-[10px] text-muted-foreground hover:text-foreground font-mono"
                  title="৫০% স্প্লিট করুন"
                >
                  ৫০%
                </button>
                <button
                  type="button"
                  onClick={() => applyPercentSplit(75)}
                  className="px-1.5 py-0.5 rounded bg-panel border border-border hover:bg-panel-2 text-[10px] text-muted-foreground hover:text-foreground font-mono"
                  title="৭৫% স্প্লিট করুন"
                >
                  ৭৫%
                </button>
                <button
                  type="button"
                  onClick={() => applyPercentSplit(0)}
                  className="px-1.5 py-0.5 rounded bg-panel border border-border hover:bg-panel-2 text-[10px] text-muted-foreground hover:text-foreground"
                  title="রিসেট করুন (০%)"
                >
                  রিসেট
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-muted-foreground block">
                  মূল লাইনে থাকবে (
                  <span className="text-emerald-400">
                    {allocationScope === "line" ? lineNameDisplay : "মূল প্ল্যান"}
                  </span>
                  ):
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min={1}
                    max={activeBaseQty - 1}
                    value={keptQty}
                    onChange={(e) => handleKeptChange(Number(e.target.value))}
                    className="w-full rounded-lg border border-border bg-input px-3 py-2 text-xs font-mono font-bold text-emerald-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-[10px]">
                    pcs
                  </span>
                </div>
                <span className="text-[10px] text-muted-foreground block">
                  ✓ এই লাইনে{" "}
                  <b className="text-emerald-400 font-mono">{keptQty.toLocaleString()} pcs</b> বহাল
                  থাকবে
                </span>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-purple-300 block">
                  আলাদা / স্প্লিট হবে (নতুন অংশ):
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min={0}
                    max={activeBaseQty - 1}
                    value={splitQty}
                    onChange={(e) => handleSplitChange(Number(e.target.value))}
                    className="w-full rounded-lg border border-purple-500/50 bg-input px-3 py-2 text-xs font-mono font-bold text-purple-300 focus:outline-none focus:ring-1 focus:ring-purple-500"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-[10px]">
                    pcs
                  </span>
                </div>
                <span className="text-[10px] text-muted-foreground block">
                  ✓ এই পরিমাণ নতুন অংশে বরাদ্দ হবে (
                  <b className="text-purple-300 font-mono">{splitQty.toLocaleString()} pcs</b>)
                </span>
              </div>
            </div>

            {/* Other lines safety note */}
            {allocationScope === "line" && otherLinesTotal > 0 && (
              <div className="p-2.5 rounded-lg bg-teal-950/30 border border-teal-500/30 text-[11px] text-teal-200 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-teal-400 shrink-0" />
                <span>
                  সুরক্ষিত: স্টাইলের অন্যান্য লাইনের মোট{" "}
                  <b className="font-mono font-bold text-teal-300">
                    {otherLinesTotal.toLocaleString()} pcs
                  </b>{" "}
                  বরাদ্দ সম্পূর্ণ অক্ষত ও অপরিবর্তিত থাকবে।
                </span>
              </div>
            )}

            {/* New Style Name */}
            <div className="pt-2 border-t border-border/50">
              <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                নতুন স্প্লিট অংশের স্টাইল নাম:
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newStyleName}
                  onChange={(e) => setNewStyleName(e.target.value)}
                  placeholder="যেমন: 542371-AB (Part 2)"
                  className="flex-1 rounded-lg border border-border bg-input px-3 py-1.5 text-xs text-foreground font-semibold focus:outline-none focus:ring-1 focus:ring-purple-500"
                />
                <button
                  type="button"
                  onClick={() => setNewStyleName(styleName)}
                  className="px-2.5 py-1.5 rounded-lg border border-border hover:bg-panel text-[11px] text-muted-foreground hover:text-foreground cursor-pointer shrink-0"
                  title="মূল নামই হুবহু রাখুন"
                >
                  একই নাম রাখুন
                </button>
              </div>
            </div>
          </div>

          {/* Strategy Selection: Where to plan remaining quantity */}
          <div className="space-y-2">
            <label className="text-xs font-extrabold text-foreground block">
              বাকি {splitQty.toLocaleString()} pcs কোথায় প্ল্যান করতে চান?
            </label>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setStrategy("unplanned")}
                className={`p-3 rounded-xl border text-left flex flex-col justify-between transition cursor-pointer select-none ${
                  strategy === "unplanned"
                    ? "bg-amber-500/15 border-amber-500/70 text-amber-200 ring-1 ring-amber-500/40"
                    : "bg-panel-2/50 border-border text-muted-foreground hover:bg-panel-2 hover:text-foreground"
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-xs">
                    <RotateCcw className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>আনপ্ল্যান্ড পুল</span>
                  </div>
                  <p className="text-[10px] opacity-80 leading-snug">
                    বাকি অংশ আনপ্ল্যান্ড পুলে সেভ হবে, পরে বোর্ডে ড্র্যাগ করবেন
                  </p>
                </div>
                {strategy === "unplanned" && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 mt-2 self-end" />
                )}
              </button>

              <button
                type="button"
                onClick={() => setStrategy("schedule")}
                className={`p-3 rounded-xl border text-left flex flex-col justify-between transition cursor-pointer select-none ${
                  strategy === "schedule"
                    ? "bg-teal-500/15 border-teal-500/70 text-teal-200 ring-1 ring-teal-500/40"
                    : "bg-panel-2/50 border-border text-muted-foreground hover:bg-panel-2 hover:text-foreground"
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-xs">
                    <Zap className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                    <span>সরাসরি নতুন লাইনে</span>
                  </div>
                  <p className="text-[10px] opacity-80 leading-snug">
                    এখনই অন্য কোনো লাইনে তারিখ ও টার্গেট দিয়ে প্ল্যান করুন
                  </p>
                </div>
                {strategy === "schedule" && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 mt-2 self-end" />
                )}
              </button>

              <button
                type="button"
                onClick={() => setStrategy("input")}
                className={`p-3 rounded-xl border text-left flex flex-col justify-between transition cursor-pointer select-none ${
                  strategy === "input"
                    ? "bg-blue-500/15 border-blue-500/70 text-blue-200 ring-1 ring-blue-500/40"
                    : "bg-panel-2/50 border-border text-muted-foreground hover:bg-panel-2 hover:text-foreground"
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-xs">
                    <Pencil className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>প্ল্যান ইনপুট ফর্ম</span>
                  </div>
                  <p className="text-[10px] opacity-80 leading-snug">
                    ইনপুট ফর্মে গিয়ে কাস্টম লার্নিং কার্ভ বা মাল্টি-লাইন সেট করুন
                  </p>
                </div>
                {strategy === "input" && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 mt-2 self-end" />
                )}
              </button>
            </div>
          </div>

          {/* Conditional Fields for Direct Schedule Strategy */}
          {strategy === "schedule" && (
            <div className="rounded-xl border border-teal-500/40 bg-teal-950/20 p-3.5 space-y-3 animate-in fade-in duration-100">
              <h5 className="font-extrabold text-teal-200 text-xs flex items-center gap-1.5">
                <span>🏭</span>
                <span>নতুন লাইনের তথ্য নির্বাচন করুন:</span>
              </h5>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="text-[10px] font-bold text-muted-foreground block mb-1">
                    টার্গেট লাইন:
                  </label>
                  <select
                    value={targetLine}
                    onChange={(e) => setTargetLine(e.target.value)}
                    className="w-full rounded-lg border border-border bg-input px-2.5 py-1.5 text-xs text-foreground font-semibold focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    {availableLines.map((l) => (
                      <option key={l} value={l}>
                        {l}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-muted-foreground block mb-1">
                    শুরুর তারিখ:
                  </label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full rounded-lg border border-border bg-input px-2.5 py-1.5 text-xs text-foreground font-semibold focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-muted-foreground block mb-1">
                    দৈনিক টার্গেট:
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min={50}
                      step={50}
                      value={targetPerDay}
                      onChange={(e) => setTargetPerDay(Number(e.target.value))}
                      className="w-full rounded-lg border border-border bg-input px-2.5 py-1.5 text-xs font-mono font-bold text-foreground focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                    <span className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground text-[10px]">
                      /দিন
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-[11px] text-teal-300">
                <Info className="w-3.5 h-3.5 shrink-0" />
                <span>
                  {targetLine}-এ {splitQty.toLocaleString()} pcs প্ল্যান তৈরি হবে (আনুমানিক{" "}
                  {Math.ceil(splitQty / (targetPerDay || 500))} কার্যদিবস)।
                </span>
              </div>
            </div>
          )}

          {strategy === "unplanned" && (
            <div className="p-3 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-200 text-xs flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                স্প্লিট করার পর {splitQty.toLocaleString()} pcs স্বয়ংক্রিয়ভাবে{" "}
                <strong>আনপ্ল্যান্ড পুল (Unplanned Orders Pool)</strong>-এ চলে যাবে। আপনি যেকোনো সময়
                প্ল্যান বোর্ডের ড্রয়ার থেকে এটি দেখতে ও ড্র্যাগ করতে পারবেন।
              </span>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-border bg-panel-2/60 flex items-center justify-between gap-3">
          <div className="text-[11px] text-muted-foreground hidden sm:block">
            {allocationScope === "line" ? (
              <span>
                লাইন মোট: <b className="text-emerald-400">{activeBaseQty.toLocaleString()}</b> ={" "}
                {keptQty.toLocaleString()} ({lineNameDisplay}) + {splitQty.toLocaleString()} (নতুন
                অংশ)
                <span className="text-muted-foreground/70 ml-2">
                  · মোট অর্ডার: {orderQty.toLocaleString()} pcs
                </span>
              </span>
            ) : (
              <span>
                মোট: <b className="text-foreground">{orderQty.toLocaleString()}</b> ={" "}
                {keptQty.toLocaleString()} (মূল) + {splitQty.toLocaleString()} (বাকি)
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              disabled={submitting}
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-border hover:bg-panel-2 text-xs font-bold text-muted-foreground hover:text-foreground transition cursor-pointer"
            >
              বাতিল
            </button>

            <button
              type="button"
              disabled={submitting || splitQty <= 0 || keptQty <= 0}
              onClick={handleExecuteSplit}
              className={`px-5 py-2 rounded-xl font-black text-xs text-white shadow-lg transition flex items-center gap-2 cursor-pointer disabled:opacity-50 ${
                strategy === "schedule"
                  ? "bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 shadow-teal-600/20"
                  : strategy === "input"
                    ? "bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-blue-600/20"
                    : "bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-purple-600/20"
              }`}
            >
              {submitting ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>স্প্লিট প্রসেস হচ্ছে...</span>
                </>
              ) : (
                <>
                  <Scissors className="w-3.5 h-3.5" />
                  <span>
                    {strategy === "schedule"
                      ? `স্প্লিট করুন ও ${targetLine}-এ শিডিউল করুন`
                      : strategy === "input"
                        ? "স্প্লিট করুন ও প্ল্যান ইনপুটে যান"
                        : "স্প্লিট করে আনপ্ল্যান্ড পুলে পাঠান"}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
