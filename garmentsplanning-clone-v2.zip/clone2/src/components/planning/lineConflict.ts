import { normLine, canonicalLineName } from "./lineLookup";

export type ConflictBar = {
  planId: string;
  line: string; // canonical
  rawLine: string;
  buyer: string;
  style: string;
  season?: string | null;
  qty: number;
  start: string;
  end: string;
  dailyTarget?: number;
  shipmentDate?: string;
  status?: "exact" | "over" | "under";
  diffQty?: number;
};

export type LineConflict = {
  id: string;
  line: string; // canonical line name
  overlapStart: string; // YYYY-MM-DD
  overlapEnd: string; // YYYY-MM-DD
  overlapDays: number;
  barA: ConflictBar;
  barB: ConflictBar;
};

export type LineConflictGroup = {
  line: string;
  conflicts: LineConflict[];
  distinctStyles: string[];
  earliestOverlap: string;
  latestOverlap: string;
};

/**
 * Calculates calendar days between two YYYY-MM-DD date strings (inclusive).
 */
export function countOverlapDays(startStr: string, endStr: string): number {
  if (!startStr || !endStr) return 0;
  const s = new Date(startStr);
  const e = new Date(endStr);
  if (isNaN(s.getTime()) || isNaN(e.getTime())) return 0;
  const diffTime = e.getTime() - s.getTime();
  const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(0, diffDays + 1);
}

/**
 * Checks if two date intervals [startA, endA] and [startB, endB] overlap.
 */
export function doIntervalsOverlap(
  startA: string,
  endA: string,
  startB: string,
  endB: string,
): boolean {
  if (!startA || !endA || !startB || !endB) return false;
  return startA <= endB && startB <= endA;
}

/**
 * Given a list of planned bars, detects any conflicts where the same production line
 * is allocated to multiple different styles during the same time period.
 */
export function detectLineConflicts(bars: ConflictBar[]): LineConflict[] {
  const conflicts: LineConflict[] = [];
  const seenPairKeys = new Set<string>();

  // Group bars by canonical/normalized line
  const byLine = new Map<string, ConflictBar[]>();
  for (const b of bars) {
    if (!b.start || !b.end || !b.line) continue;
    const key = normLine(b.line);
    if (!key) continue;
    const arr = byLine.get(key) ?? [];
    arr.push(b);
    byLine.set(key, arr);
  }

  // Check each line group for overlapping styles
  for (const lineBars of byLine.values()) {
    const len = lineBars.length;
    if (len < 2) continue;

    for (let i = 0; i < len; i++) {
      const a = lineBars[i];
      for (let j = i + 1; j < len; j++) {
        const b = lineBars[j];

        // Only flag if they are different styles or different plan records
        const isDifferentStyle =
          a.style.trim().toLowerCase() !== b.style.trim().toLowerCase() || a.planId !== b.planId;

        if (!isDifferentStyle) continue;

        // Check date overlap: startA <= endB && startB <= endA
        if (doIntervalsOverlap(a.start, a.end, b.start, b.end)) {
          const overlapStart = a.start > b.start ? a.start : b.start;
          const overlapEnd = a.end < b.end ? a.end : b.end;
          const overlapDays = countOverlapDays(overlapStart, overlapEnd);

          if (overlapDays <= 0) continue;

          // Stable pair key to avoid duplicates
          const pairKey =
            a.planId < b.planId
              ? `${normLine(a.line)}::${a.planId}::${a.start}__${b.planId}::${b.start}`
              : `${normLine(a.line)}::${b.planId}::${b.start}__${a.planId}::${a.start}`;

          if (seenPairKeys.has(pairKey)) continue;
          seenPairKeys.add(pairKey);

          conflicts.push({
            id: pairKey,
            line: a.line,
            overlapStart,
            overlapEnd,
            overlapDays,
            barA: a,
            barB: b,
          });
        }
      }
    }
  }

  // Sort conflicts by line, then earliest overlap start
  return conflicts.sort((x, y) => {
    const lineCmp = x.line.localeCompare(y.line, undefined, { numeric: true });
    if (lineCmp !== 0) return lineCmp;
    return x.overlapStart.localeCompare(y.overlapStart);
  });
}

/**
 * Builds a fast lookup map from bar identifier to all conflicts involving that bar.
 * Key formats supported:
 * 1. `${bar.planId}::${bar.rawLine}`
 * 2. `${bar.planId}`
 */
export function getBarConflictMap(conflicts: LineConflict[]): Map<string, LineConflict[]> {
  const map = new Map<string, LineConflict[]>();

  const add = (k: string, c: LineConflict) => {
    const list = map.get(k) ?? [];
    list.push(c);
    map.set(k, list);
  };

  for (const c of conflicts) {
    // Exact bar key
    add(`${c.barA.planId}::${c.barA.rawLine}`, c);
    add(`${c.barA.planId}::${c.barA.start}`, c);
    add(c.barA.planId, c);

    add(`${c.barB.planId}::${c.barB.rawLine}`, c);
    add(`${c.barB.planId}::${c.barB.start}`, c);
    add(c.barB.planId, c);
  }

  return map;
}

/**
 * Groups conflicts by canonical line name for line header badges and drawer filtering.
 */
export function groupConflictsByLine(conflicts: LineConflict[]): Map<string, LineConflictGroup> {
  const map = new Map<string, LineConflictGroup>();

  for (const c of conflicts) {
    const lineKey = c.line;
    if (!map.has(lineKey)) {
      map.set(lineKey, {
        line: lineKey,
        conflicts: [],
        distinctStyles: [],
        earliestOverlap: c.overlapStart,
        latestOverlap: c.overlapEnd,
      });
    }

    const group = map.get(lineKey)!;
    group.conflicts.push(c);

    if (c.overlapStart < group.earliestOverlap) group.earliestOverlap = c.overlapStart;
    if (c.overlapEnd > group.latestOverlap) group.latestOverlap = c.overlapEnd;

    const stylesSet = new Set(group.distinctStyles);
    stylesSet.add(c.barA.style);
    stylesSet.add(c.barB.style);
    group.distinctStyles = Array.from(stylesSet);
  }

  return map;
}

/**
 * Checks in real-time whether dragging a bar to a new line and shifted dates would
 * collide with another style already planned on that target line.
 */
export function checkDragCollision(
  draggedPlanId: string,
  draggedStyle: string,
  targetLine: string,
  newStart: string,
  newEnd: string,
  allBars: ConflictBar[],
): { conflictingBar: ConflictBar; overlapDays: number } | null {
  const targetKey = normLine(targetLine);
  if (!targetKey || !newStart || !newEnd) return null;

  for (const b of allBars) {
    if (b.planId === draggedPlanId) continue;
    if (normLine(b.line) !== targetKey) continue;

    // Different style
    if (b.style.trim().toLowerCase() === draggedStyle.trim().toLowerCase()) continue;

    if (doIntervalsOverlap(newStart, newEnd, b.start, b.end)) {
      const overlapStart = newStart > b.start ? newStart : b.start;
      const overlapEnd = newEnd < b.end ? newEnd : b.end;
      const overlapDays = countOverlapDays(overlapStart, overlapEnd);
      if (overlapDays > 0) {
        return { conflictingBar: b, overlapDays };
      }
    }
  }

  return null;
}
