import { useState, useEffect, useMemo } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  listAppUsers,
  createAppUser,
  deleteAppUser,
  resetAppUserPassword,
  setAppUserRole,
  setUserTeamLeader,
  listFactories,
  createFactory,
  renameFactory,
  deleteFactory,
  setUserFactory,
  setUserActive,
  setSystemLocked,
  saveUserPermissions,
  getUserPermissions,
  applyBulkPermissions,
  grantSuperAdmin,
  revokeSuperAdmin,
  listSuperAdmins,
} from "@/lib/admin-users.functions";
import { listAuditLogs, clearAuditLogs } from "@/lib/audit-logs.functions";
import {
  type AuditLogEntry,
  type AuditActionType,
  AUDIT_ACTION_CONFIG,
} from "@/lib/audit-logs.types";
import { logActivity } from "@/lib/audit-logger";
import {
  SUPER_ADMIN_EMAIL,
  isSuperAdminUser,
  WORK_PERMISSIONS_LIST,
  PERMISSION_CATEGORIES,
  PERMISSION_PRESETS,
  type PermissionPresetKey,
  type PermissionCategory,
} from "@/lib/permissions.types";
import {
  X,
  Loader2,
  UserPlus,
  Trash2,
  Lock,
  Unlock,
  Key,
  ShieldCheck,
  Shield,
  Users,
  Building2,
  Sliders,
  Check,
  ChevronRight,
  Search,
  AlertCircle,
  Edit2,
  Sparkles,
  Plus,
  Layers,
  Crown,
  UserCheck,
  ShieldAlert,
  ClipboardList,
  RefreshCw,
  RotateCcw,
  CheckSquare,
  XSquare,
  ShieldOff,
} from "lucide-react";
import { useCurrentUser } from "@/hooks/use-current-user";

type AppRole = "admin" | "team_leader" | "user";

type AppUser = {
  id: string;
  username: string;
  active: boolean;
  role: AppRole;
  is_super_admin?: boolean;
  team_leader_id: string | null;
  factory_id: string | null;
  permissions?: Record<string, boolean>;
  created_at: string;
};

type Factory = { id: string; name: string; created_at?: string };

type AdminTab = "hierarchy" | "factories" | "permissions" | "create_user" | "audit_logs" | "bulk";

export function AdminPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const qc = useQueryClient();
  const { data: currentUser } = useCurrentUser();

  // Server functions
  const listFn = useServerFn(listAppUsers);
  const createFn = useServerFn(createAppUser);
  const deleteFn = useServerFn(deleteAppUser);
  const resetFn = useServerFn(resetAppUserPassword);
  const setRoleFn = useServerFn(setAppUserRole);
  const setTLFn = useServerFn(setUserTeamLeader);
  const listFactoriesFn = useServerFn(listFactories);
  const createFactoryFn = useServerFn(createFactory);
  const renameFactoryFn = useServerFn(renameFactory);
  const deleteFactoryFn = useServerFn(deleteFactory);
  const setUserFactoryFn = useServerFn(setUserFactory);
  const setUserActiveFn = useServerFn(setUserActive);
  const setSystemLockedFn = useServerFn(setSystemLocked);
  const savePermsFn = useServerFn(saveUserPermissions);
  const getPermsFn = useServerFn(getUserPermissions);
  const applyBulkPermsFn = useServerFn(applyBulkPermissions);
  const grantSuperAdminFn = useServerFn(grantSuperAdmin);
  const revokeSuperAdminFn = useServerFn(revokeSuperAdmin);
  const listAuditFn = useServerFn(listAuditLogs);
  const clearAuditFn = useServerFn(clearAuditLogs);

  // Active Tab
  const [activeTab, setActiveTab] = useState<AdminTab>("hierarchy");

  // Filters for Users
  const [filterFactory, setFilterFactory] = useState<string>("");
  const [filterRole, setFilterRole] = useState<string>("");
  const [filterSearch, setFilterSearch] = useState<string>("");
  const [viewMode, setViewMode] = useState<"tree" | "table">("tree");

  // Filters for Audit Logs
  const [auditActionFilter, setAuditActionFilter] = useState<string>("");
  const [auditFactoryFilter, setAuditFactoryFilter] = useState<string>("");
  const [auditSearch, setAuditSearch] = useState<string>("");

  // New User Form State
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newRole, setNewRole] = useState<AppRole>("user");
  const [newUserFactory, setNewUserFactory] = useState<string>("");
  const [newTeamLeader, setNewTeamLeader] = useState<string>("");
  const [newPreset, setNewPreset] = useState<PermissionPresetKey>("full_planner");

  // Factory Form State
  const [newFactoryName, setNewFactoryName] = useState("");
  const [editingFactoryId, setEditingFactoryId] = useState<string | null>(null);
  const [editingFactoryName, setEditingFactoryName] = useState("");

  // Permissions Modal / Selected User for Permissions
  const [permTargetUser, setPermTargetUser] = useState<AppUser | null>(null);
  const [activeUserPerms, setActiveUserPerms] = useState<Record<string, boolean>>({});
  const [savingPerms, setSavingPerms] = useState(false);

  // Bulk Selection
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkRole, setBulkRole] = useState<AppRole | "">("");
  const [bulkTL, setBulkTL] = useState<string>("__keep__");
  const [bulkFactory, setBulkFactory] = useState<string>("__keep__");
  const [bulkPreset, setBulkPreset] = useState<string>("__keep__");
  const [bulkBusy, setBulkBusy] = useState(false);

  // Password reset inline modal
  const [passwordModalUser, setPasswordModalUser] = useState<AppUser | null>(null);
  const [newResetPassword, setNewResetPassword] = useState("");

  // Queries
  const factories = useQuery({
    queryKey: ["admin-factories"],
    queryFn: () => listFactoriesFn() as Promise<Factory[]>,
    enabled: !!open,
  });

  const factoryMap = useMemo(() => {
    const m = new Map<string, string>();
    for (const f of factories.data ?? []) m.set(f.id, f.name);
    return m;
  }, [factories.data]);

  const users = useQuery({
    queryKey: ["admin-users"],
    queryFn: () => listFn() as Promise<AppUser[]>,
    enabled: !!open,
  });

  const diskPermsQuery = useQuery({
    queryKey: ["admin-disk-perms"],
    queryFn: () => getPermsFn() as Promise<Record<string, Record<string, boolean>>>,
    enabled: !!open,
  });

  // Audit Logs Query
  const auditLogsQuery = useQuery({
    queryKey: ["admin-audit-logs", auditActionFilter, auditFactoryFilter, auditSearch],
    queryFn: () =>
      listAuditFn({
        data: {
          action: auditActionFilter || undefined,
          factoryId: auditFactoryFilter || undefined,
          search: auditSearch || undefined,
          limit: 300,
        },
      }) as Promise<AuditLogEntry[]>,
    enabled: !!open && activeTab === "audit_logs",
    refetchInterval: activeTab === "audit_logs" ? 8000 : false,
  });

  // System lock query
  const lockQ = useQuery({
    queryKey: ["system-lock"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("system_settings")
        .select("locked")
        .eq("id", 1)
        .maybeSingle();
      if (error) throw error;
      return !!data?.locked;
    },
    enabled: !!open,
  });

  useEffect(() => {
    if (!open) return;
    const ch = supabase
      .channel("admin-lock-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "system_settings" }, () =>
        qc.invalidateQueries({ queryKey: ["system-lock"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [open, qc]);

  // Mutations
  const toggleLock = useMutation({
    mutationFn: async (locked: boolean) => setSystemLockedFn({ data: { locked } }),
    onSuccess: (_d, v) => {
      qc.invalidateQueries({ queryKey: ["system-lock"] });
      logActivity({
        action: "SYSTEM_LOCK_TOGGLE",
        details: v ? "সিস্টেম লক করা হয়েছে (Maintenance Mode)" : "সিস্টেম আনলক করা হয়েছে",
      });
      toast.success(v ? "🔒 সিস্টেম সফলভাবে লক করা হয়েছে।" : "🔓 সিস্টেম আনলক করা হয়েছে।");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) =>
      setUserActiveFn({ data: { userId: id, active } }),
    onSuccess: (_d, v) => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      logActivity({
        action: "USER_STATUS_CHANGE",
        details: v.active
          ? "ইউজার অ্যাকাউন্ট আনব্লক / সক্রিয় করা হয়েছে"
          : "ইউজার অ্যাকাউন্ট ব্লক করা হয়েছে",
        targetId: v.id,
      });
      toast.success("ইউজারের স্ট্যাটাস আপডেট হয়েছে।");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const createUser = useMutation({
    mutationFn: async () => {
      if (!newUsername.trim() || newPassword.length < 6) {
        throw new Error("ইউজারনেম দিন ও পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।");
      }
      if (newRole === "user" && !newTeamLeader) {
        throw new Error("User রোলের জন্য টিম লিডার নির্বাচন বাধ্যতামূলক।");
      }
      const initialPerms = PERMISSION_PRESETS[newPreset]?.permissions;
      return createFn({
        data: {
          username: newUsername.trim(),
          password: newPassword,
          role: newRole,
          teamLeaderId: newRole === "user" ? newTeamLeader || null : null,
          factoryId: newUserFactory || null,
          permissions: initialPerms,
        },
      });
    },
    onSuccess: async (res) => {
      toast.success("✅ নতুন ব্যবহারকারী সফলভাবে তৈরি করা হয়েছে!");
      logActivity({
        action: "PLAN_CREATE",
        details: `নতুন ব্যবহারকারী অ্যাকাউন্ট তৈরি: ${res.username} (${newRole.toUpperCase()})`,
        targetName: res.username,
        factoryId: newUserFactory || null,
        factoryName: factoryMap.get(newUserFactory) || null,
      });
      setNewUsername("");
      setNewPassword("");
      setNewRole("user");
      setNewTeamLeader("");
      setNewUserFactory("");
      setNewPreset("full_planner");
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      qc.invalidateQueries({ queryKey: ["admin-disk-perms"] });
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
      setActiveTab("hierarchy");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removeUser = useMutation({
    mutationFn: async (id: string) => deleteFn({ data: { userId: id } }),
    onSuccess: (_d, id) => {
      toast.success("ইউজার সফলভাবে মুছে ফেলা হয়েছে।");
      logActivity({
        action: "PLAN_DELETE",
        details: `ব্যবহারকারী অ্যাকাউন্ট মুছে ফেলা হয়েছে (ID: ${id})`,
        targetId: id,
      });
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      qc.invalidateQueries({ queryKey: ["admin-disk-perms"] });
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const resetPass = useMutation({
    mutationFn: async ({ id, pw }: { id: string; pw: string }) =>
      resetFn({ data: { userId: id, password: pw } }),
    onSuccess: () => {
      toast.success("পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে।");
      setPasswordModalUser(null);
      setNewResetPassword("");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const changeRole = useMutation({
    mutationFn: async ({ id, role }: { id: string; role: AppRole }) =>
      setRoleFn({ data: { userId: id, role } }),
    onSuccess: (_d, v) => {
      toast.success("ব্যবহারকারীর রোল পরিবর্তিত হয়েছে।");
      logActivity({
        action: "USER_ROLE_CHANGE",
        details: `ব্যবহারকারীর রোল পরিবর্তন করে ${v.role.toUpperCase()} করা হয়েছে`,
        targetId: v.id,
      });
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  // Dynamic Super Admin Grant & Revoke Mutations
  const grantSuperMutation = useMutation({
    mutationFn: async (userId: string) => grantSuperAdminFn({ data: { userId } }),
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      qc.invalidateQueries({ queryKey: ["current-user"] });
      try {
        const raw = localStorage.getItem("cg_super_admins");
        const list = raw ? JSON.parse(raw) : [];
        if (!list.includes(res.userId)) list.push(res.userId);
        if (res.username && !list.includes(res.username.toLowerCase())) {
          list.push(res.username.toLowerCase());
        }
        localStorage.setItem("cg_super_admins", JSON.stringify(list));
      } catch {
        /* ignore */
      }
      logActivity({
        action: "PERMISSION_GRANT",
        details: `👑 ${res.username}-কে সুপার অ্যাডমিন পারমিশন প্রদান করা হয়েছে (Full 100% Access)`,
        targetId: res.userId,
        targetName: res.username,
      });
      toast.success(`👑 ${res.username}-কে সুপার অ্যাডমিন পারমিশন প্রদান করা হয়েছে!`);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const revokeSuperMutation = useMutation({
    mutationFn: async ({ userId, newRole }: { userId: string; newRole?: AppRole }) =>
      revokeSuperAdminFn({ data: { userId, newRole: newRole || "admin" } }),
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      qc.invalidateQueries({ queryKey: ["current-user"] });
      try {
        const raw = localStorage.getItem("cg_super_admins");
        if (raw) {
          const list = JSON.parse(raw);
          const filtered = list.filter(
            (s: string) => s !== res.userId && s !== res.username?.toLowerCase(),
          );
          localStorage.setItem("cg_super_admins", JSON.stringify(filtered));
        }
      } catch {
        /* ignore */
      }
      logActivity({
        action: "PERMISSION_REVOKE",
        details: `${res.username}-এর সুপার অ্যাডমিন পারমিশন বাতিল করা হয়েছে`,
        targetId: res.userId,
        targetName: res.username,
      });
      toast.info(`সুপার অ্যাডমিন পারমিশন বাতিল করা হয়েছে (${res.username})।`);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const changeTL = useMutation({
    mutationFn: async ({ id, tl }: { id: string; tl: string | null }) =>
      setTLFn({ data: { userId: id, teamLeaderId: tl } }),
    onSuccess: () => {
      toast.success("টিম লিডার সফলভাবে পরিবর্তিত হয়েছে।");
      qc.invalidateQueries({ queryKey: ["admin-users"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const changeFactory = useMutation({
    mutationFn: async ({ id, factoryId }: { id: string; factoryId: string | null }) =>
      setUserFactoryFn({ data: { userId: id, factoryId } }),
    onSuccess: (_d, v) => {
      toast.success("ফ্যাক্টরি অ্যাসাইনমেন্ট সফল হয়েছে।");
      logActivity({
        action: "USER_FACTORY_ASSIGN",
        details: `কারখানা পরিবর্তন: ${factoryMap.get(v.factoryId ?? "") ?? "ফ্যাক্টরি রিমুভ"}`,
        targetId: v.id,
        factoryId: v.factoryId,
        factoryName: factoryMap.get(v.factoryId ?? ""),
      });
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const addFactory = useMutation({
    mutationFn: async (name: string) => createFactoryFn({ data: { name } }),
    onSuccess: (_d, name) => {
      toast.success("নতুন কারখানা যোগ করা হয়েছে।");
      setNewFactoryName("");
      logActivity({
        action: "USER_FACTORY_ASSIGN",
        details: `নতুন কারখানা তৈরি: ${name}`,
      });
      qc.invalidateQueries({ queryKey: ["admin-factories"] });
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const editFactory = useMutation({
    mutationFn: async ({ id, name }: { id: string; name: string }) =>
      renameFactoryFn({ data: { id, name } }),
    onSuccess: () => {
      toast.success("কারখানার নাম আপডেট হয়েছে।");
      setEditingFactoryId(null);
      setEditingFactoryName("");
      qc.invalidateQueries({ queryKey: ["admin-factories"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removeFactory = useMutation({
    mutationFn: async (id: string) => deleteFactoryFn({ data: { id } }),
    onSuccess: () => {
      toast.success("কারখানা মুছে ফেলা হয়েছে।");
      qc.invalidateQueries({ queryKey: ["admin-factories"] });
      qc.invalidateQueries({ queryKey: ["admin-users"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const clearAudit = useMutation({
    mutationFn: async () => clearAuditFn(),
    onSuccess: () => {
      toast.success("অডিট হিস্টোরি লগ সম্পূর্ণ ক্লিয়ার করা হয়েছে।");
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  // Open Permission Modal for a specific user
  const handleOpenPermissions = (u: AppUser) => {
    setPermTargetUser(u);
    const disk = diskPermsQuery.data?.[u.id] ?? {};
    const base =
      u.permissions ??
      PERMISSION_PRESETS[u.role === "team_leader" ? "team_leader" : "full_planner"].permissions;
    setActiveUserPerms({ ...base, ...disk });
  };

  // Grant All Permissions (1-click)
  const grantAllPermissions = () => {
    const allGranted: Record<string, boolean> = {};
    WORK_PERMISSIONS_LIST.forEach((p) => {
      allGranted[p.key] = true;
    });
    setActiveUserPerms(allGranted);
    toast.success("সকল কাজের অনুমতি সক্রিয় করা হয়েছে। সংরক্ষণে ক্লিক করুন।");
  };

  // Revoke All Permissions (1-click removal)
  const revokeAllPermissions = () => {
    const allRevoked: Record<string, boolean> = {};
    WORK_PERMISSIONS_LIST.forEach((p) => {
      allRevoked[p.key] = false;
    });
    setActiveUserPerms(allRevoked);
    toast.info("সকল কাজের অনুমতি প্রত্যাহার / রিমুভ করা হয়েছে (Read-Only)। সংরক্ষণে ক্লিক করুন।");
  };

  // Save Permissions with Audit Logging
  const handleSavePermissions = async () => {
    if (!permTargetUser) return;
    setSavingPerms(true);
    try {
      await savePermsFn({
        data: {
          userId: permTargetUser.id,
          permissions: activeUserPerms,
        },
      });
      // cache in localStorage for immediate client feedback
      try {
        localStorage.setItem(`cg_perms_${permTargetUser.id}`, JSON.stringify(activeUserPerms));
      } catch {
        /* ignore */
      }

      const grantedCount = Object.values(activeUserPerms).filter(Boolean).length;
      const totalCount = WORK_PERMISSIONS_LIST.length;
      const isFullRevoked = grantedCount === 0;

      logActivity({
        action: isFullRevoked ? "PERMISSION_REVOKE" : "PERMISSION_GRANT",
        details: `'${permTargetUser.username}'-এর কাজের পারমিশন আপডেট: ${grantedCount}/${totalCount} টি সক্রিয়`,
        targetId: permTargetUser.id,
        targetName: permTargetUser.username,
        factoryId: permTargetUser.factory_id,
        factoryName: factoryMap.get(permTargetUser.factory_id ?? ""),
      });

      toast.success(
        `'${permTargetUser.username}'-এর কাজের পারমিশন সংরক্ষিত হয়েছে (${grantedCount}/${totalCount} টি সক্রিয়)!`,
      );
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      qc.invalidateQueries({ queryKey: ["admin-disk-perms"] });
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
      setPermTargetUser(null);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSavingPerms(false);
    }
  };

  const applyPresetToActivePerms = (presetKey: PermissionPresetKey) => {
    const preset = PERMISSION_PRESETS[presetKey];
    if (preset) {
      setActiveUserPerms({ ...preset.permissions });
      toast.info(`'${preset.label}' টেমপ্লেট প্রয়োগ করা হয়েছে।`);
    }
  };

  // Hierarchy Data Organization
  const allUsersList = useMemo(() => users.data ?? [], [users.data]);

  // Filtered Users
  const filteredUsers = useMemo(() => {
    return allUsersList.filter((u) => {
      const q = filterSearch.trim().toLowerCase();
      if (q && !u.username.toLowerCase().includes(q)) return false;
      if (filterRole && u.role !== filterRole) return false;
      if (filterFactory) {
        if (filterFactory === "none" && u.factory_id) return false;
        if (filterFactory !== "none" && u.factory_id !== filterFactory) return false;
      }
      return true;
    });
  }, [allUsersList, filterSearch, filterRole, filterFactory]);

  // List of Team Leaders
  const teamLeadersList = useMemo(() => {
    return allUsersList.filter((u) => u.role === "team_leader" || u.role === "admin");
  }, [allUsersList]);

  // Team Leaders filtered for the new user's selected factory
  const teamLeadersForSelectedFactory = useMemo(() => {
    if (!newUserFactory) return teamLeadersList;
    return teamLeadersList.filter((tl) => !tl.factory_id || tl.factory_id === newUserFactory);
  }, [teamLeadersList, newUserFactory]);

  // Grouped by Factory for Hierarchy View
  const hierarchyData = useMemo(() => {
    const factoriesList = factories.data ?? [];

    const factoryGroups = factoriesList.map((f) => {
      const usersInFactory = filteredUsers.filter((u) => u.factory_id === f.id);
      const tlsInFactory = usersInFactory.filter(
        (u) => u.role === "team_leader" || u.role === "admin",
      );

      const leadersWithSubs = tlsInFactory.map((tl) => {
        const subs = usersInFactory.filter((u) => u.role === "user" && u.team_leader_id === tl.id);
        return { leader: tl, subordinates: subs };
      });

      const accountedIds = new Set<string>();
      tlsInFactory.forEach((tl) => accountedIds.add(tl.id));
      leadersWithSubs.forEach((item) => item.subordinates.forEach((s) => accountedIds.add(s.id)));

      const unassignedInFactory = usersInFactory.filter((u) => !accountedIds.has(u.id));

      return {
        factory: f,
        leadersWithSubs,
        unassignedInFactory,
        totalUsers: usersInFactory.length,
      };
    });

    const unassignedFactoryUsers = filteredUsers.filter((u) => !u.factory_id);

    return {
      factoryGroups,
      unassignedFactoryUsers,
    };
  }, [factories.data, filteredUsers]);

  // Statistics
  const stats = useMemo(() => {
    const totalUsers = allUsersList.length;
    const totalFactories = (factories.data ?? []).length;
    const totalTLs = allUsersList.filter((u) => u.role === "team_leader").length;
    const totalAdmins = allUsersList.filter((u) => u.role === "admin").length;
    const activeCount = allUsersList.filter((u) => u.active).length;
    return { totalUsers, totalFactories, totalTLs, totalAdmins, activeCount };
  }, [allUsersList, factories.data]);

  // Bulk Operations
  const toggleSelectId = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAllFiltered = () => {
    const ids = filteredUsers
      .filter((u) => !isSuperAdminUser(u.username, u.username) && u.id !== currentUser?.id)
      .map((u) => u.id);
    setSelectedIds(new Set(ids));
  };

  const clearSelection = () => setSelectedIds(new Set());

  const handleRunBulk = async () => {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;
    if (!confirm(`${ids.length} জন নির্বাচিত ব্যবহারকারীতে বাল্ক অ্যাকশন প্রয়োগ করবেন?`)) return;

    setBulkBusy(true);
    let successCount = 0;
    try {
      for (const id of ids) {
        if (bulkRole) {
          await setRoleFn({ data: { userId: id, role: bulkRole as AppRole } });
        }
        if (bulkFactory !== "__keep__") {
          await setUserFactoryFn({
            data: { userId: id, factoryId: bulkFactory === "" ? null : bulkFactory },
          });
        }
        if (bulkTL !== "__keep__") {
          await setTLFn({
            data: { userId: id, teamLeaderId: bulkTL === "" ? null : bulkTL },
          });
        }
        successCount++;
      }

      if (bulkPreset !== "__keep__") {
        const presetPerms = PERMISSION_PRESETS[bulkPreset as PermissionPresetKey]?.permissions;
        if (presetPerms) {
          await applyBulkPermsFn({
            data: { userIds: ids, permissions: presetPerms },
          });
        }
      }

      toast.success(`${successCount} জন ব্যবহারকারীতে সফলভাবে পরিবর্তন প্রয়োগ করা হয়েছে!`);
      setSelectedIds(new Set());
      setBulkRole("");
      setBulkFactory("__keep__");
      setBulkTL("__keep__");
      setBulkPreset("__keep__");
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      qc.invalidateQueries({ queryKey: ["admin-disk-perms"] });
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBulkBusy(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-6xl max-h-[94vh] flex flex-col rounded-3xl border border-indigo-500/30 bg-slate-950/95 text-slate-100 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* ================= HEADER BANNER ================= */}
        <div className="shrink-0 border-b border-border/60 bg-gradient-to-r from-purple-950/80 via-indigo-950/70 to-slate-950/90 px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-600/30">
              <Crown className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-1.5">
                  Cloud Garments ERP — অ্যাডমিন কন্ট্রোল প্যানেল
                </h2>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-purple-500/20 text-purple-200 border border-purple-400/40">
                  <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
                  সুপার অ্যাডমিন: {SUPER_ADMIN_EMAIL}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                ফ্যাক্টরি ভিত্তিক হায়ারার্কি, টিম লিডার, কাজের পারমিশন ও অ্যাক্টিভিটি মনিটরিং
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* System Maintenance Lock Toggle */}
            <button
              onClick={() => toggleLock.mutate(!lockQ.data)}
              disabled={toggleLock.isPending || lockQ.isLoading}
              title={lockQ.data ? "সিস্টেম আনলক করতে ক্লিক করুন" : "সিস্টেম লক করতে ক্লিক করুন"}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
                lockQ.data
                  ? "bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30"
                  : "bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20"
              }`}
            >
              {toggleLock.isPending ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : lockQ.data ? (
                <Lock className="w-3.5 h-3.5 text-rose-400" />
              ) : (
                <Unlock className="w-3.5 h-3.5 text-emerald-400" />
              )}
              <span>{lockQ.data ? "সিস্টেম লক্ড" : "সিস্টেম উন্মুক্ত"}</span>
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ================= STATS COUNTER STRIP ================= */}
        <div className="shrink-0 bg-slate-900/60 border-b border-border/40 px-4 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-4 flex-wrap text-slate-300 font-semibold">
            <div className="flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-sky-400" />
              <span>কারখানা:</span>
              <span className="font-extrabold text-white bg-slate-800 px-2 py-0.5 rounded-md border border-slate-700">
                {stats.totalFactories} টি
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <UserCheck className="w-4 h-4 text-indigo-400" />
              <span>টিম লিডার:</span>
              <span className="font-extrabold text-white bg-slate-800 px-2 py-0.5 rounded-md border border-slate-700">
                {stats.totalTLs} জন
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <Users className="w-4 h-4 text-emerald-400" />
              <span>মোট ইউজার:</span>
              <span className="font-extrabold text-white bg-slate-800 px-2 py-0.5 rounded-md border border-slate-700">
                {stats.totalUsers} জন
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-purple-400" />
              <span>সক্রিয়:</span>
              <span className="font-extrabold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-md border border-emerald-500/30">
                {stats.activeCount}
              </span>
            </div>
          </div>

          <div className="text-[11px] text-slate-400">
            লগইন করা অ্যাকাউন্ট:{" "}
            <strong className="text-purple-300">
              {currentUser?.email || currentUser?.username}
            </strong>
          </div>
        </div>

        {/* ================= TAB NAVIGATION ================= */}
        <div className="shrink-0 bg-slate-900/90 border-b border-border/50 px-4 sm:px-6 py-2 flex items-center justify-between gap-2 overflow-x-auto">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab("hierarchy")}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                activeTab === "hierarchy"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                  : "bg-slate-800/60 text-slate-300 hover:bg-slate-800"
              }`}
            >
              <Users className="w-4 h-4" />
              <span>টিম ও ইউজার কাঠামো</span>
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-slate-950/60">
                {stats.totalUsers}
              </span>
            </button>

            <button
              onClick={() => setActiveTab("factories")}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                activeTab === "factories"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                  : "bg-slate-800/60 text-slate-300 hover:bg-slate-800"
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>ফ্যাক্টরি ব্যবস্থাপনা</span>
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-slate-950/60">
                {stats.totalFactories}
              </span>
            </button>

            <button
              onClick={() => setActiveTab("permissions")}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                activeTab === "permissions"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                  : "bg-slate-800/60 text-slate-300 hover:bg-slate-800"
              }`}
            >
              <Sliders className="w-4 h-4 text-purple-400" />
              <span>কাজের পারমিশন ম্যাট্রিক্স</span>
            </button>

            <button
              onClick={() => setActiveTab("create_user")}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                activeTab === "create_user"
                  ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30"
                  : "bg-slate-800/60 text-slate-300 hover:bg-slate-800"
              }`}
            >
              <UserPlus className="w-4 h-4 text-emerald-400" />
              <span>নতুন ইউজার তৈরি</span>
            </button>

            {/* AUDIT LOG TAB */}
            <button
              onClick={() => setActiveTab("audit_logs")}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                activeTab === "audit_logs"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                  : "bg-slate-800/60 text-slate-300 hover:bg-slate-800"
              }`}
            >
              <ClipboardList className="w-4 h-4 text-emerald-400" />
              <span>অডিট লগ ও টিম মনিটর</span>
              {auditLogsQuery.data && auditLogsQuery.data.length > 0 && (
                <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-slate-950/60 text-emerald-300">
                  {auditLogsQuery.data.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab("bulk")}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                activeTab === "bulk"
                  ? "bg-purple-600 text-white shadow-md shadow-purple-600/30"
                  : "bg-slate-800/60 text-slate-300 hover:bg-slate-800"
              }`}
            >
              <Layers className="w-4 h-4 text-purple-300" />
              <span>বাল্ক অ্যাকশন</span>
              {selectedIds.size > 0 && (
                <span className="ml-1 px-2 py-0.2 rounded-full text-[10px] font-extrabold bg-amber-400 text-slate-950">
                  {selectedIds.size}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* ================= TAB CONTENTS ================= */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-950/70">
          {/* ================= TAB 1: HIERARCHY & USERS ================= */}
          {activeTab === "hierarchy" && (
            <div className="space-y-4">
              {/* Filter & Search Bar */}
              <div className="bg-slate-900/80 border border-border/50 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 flex-1 min-w-[240px]">
                  <Search className="w-4 h-4 text-slate-400 shrink-0" />
                  <input
                    type="text"
                    value={filterSearch}
                    onChange={(e) => setFilterSearch(e.target.value)}
                    placeholder="ইউজারনেম বা নাম দিয়ে সার্চ করুন..."
                    className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                  {filterSearch && (
                    <button
                      onClick={() => setFilterSearch("")}
                      className="text-xs text-slate-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Factory Filter */}
                  <select
                    value={filterFactory}
                    onChange={(e) => setFilterFactory(e.target.value)}
                    className="bg-slate-950/80 border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="">🏢 সকল কারখানা</option>
                    {(factories.data ?? []).map((f) => (
                      <option key={f.id} value={f.id}>
                        🏢 {f.name}
                      </option>
                    ))}
                    <option value="none">⚠️ ফ্যাক্টরি ছাড়া</option>
                  </select>

                  {/* Role Filter */}
                  <select
                    value={filterRole}
                    onChange={(e) => setFilterRole(e.target.value)}
                    className="bg-slate-950/80 border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="">👥 সকল রোল</option>
                    <option value="admin">👑 অ্যাডমিন</option>
                    <option value="team_leader">🎯 টিম লিডার</option>
                    <option value="user">👤 ইউজার / প্ল্যানার</option>
                  </select>

                  {/* View Mode Toggle */}
                  <div className="flex items-center rounded-xl bg-slate-950 border border-slate-800 p-0.5">
                    <button
                      onClick={() => setViewMode("tree")}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                        viewMode === "tree"
                          ? "bg-indigo-600 text-white"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      গাঠনিক ট্রি
                    </button>
                    <button
                      onClick={() => setViewMode("table")}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                        viewMode === "table"
                          ? "bg-indigo-600 text-white"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      তালিকা
                    </button>
                  </div>

                  {selectedIds.size > 0 ? (
                    <button
                      onClick={clearSelection}
                      className="px-2.5 py-1.5 rounded-xl text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                    >
                      সিলেকশন বাতিল ({selectedIds.size})
                    </button>
                  ) : (
                    <button
                      onClick={selectAllFiltered}
                      className="px-2.5 py-1.5 rounded-xl text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                    >
                      সব সিলেক্ট
                    </button>
                  )}
                </div>
              </div>

              {/* TREE VIEW */}
              {viewMode === "tree" ? (
                <div className="space-y-4">
                  {hierarchyData.factoryGroups.map((group) => (
                    <div
                      key={group.factory.id}
                      className="rounded-2xl border border-indigo-900/40 bg-slate-900/50 overflow-hidden shadow-lg"
                    >
                      {/* Factory Header */}
                      <div className="bg-gradient-to-r from-indigo-950/70 via-slate-900/80 to-slate-900/60 px-4 py-2.5 border-b border-indigo-900/30 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <Building2 className="w-5 h-5 text-sky-400" />
                          <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                            {group.factory.name}
                            <span className="text-[11px] font-normal text-slate-400">
                              (টিম লিডার: {group.leadersWithSubs.length} জন • ইউজার:{" "}
                              {group.totalUsers} জন)
                            </span>
                          </h3>
                        </div>

                        <button
                          onClick={() => {
                            setNewUserFactory(group.factory.id);
                            setActiveTab("create_user");
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/30 transition"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>এই কারখানায় ইউজার যোগ করুন</span>
                        </button>
                      </div>

                      {/* Leaders and Subordinates inside Factory */}
                      <div className="p-3 space-y-3">
                        {group.leadersWithSubs.length === 0 &&
                        group.unassignedInFactory.length === 0 ? (
                          <div className="text-center py-4 text-xs text-slate-500 italic">
                            এই কারখানায় এখনও কোনো টিম লিডার বা ব্যবহারকারী যুক্ত করা হয়নি।
                          </div>
                        ) : null}

                        {/* Each Leader Card */}
                        {group.leadersWithSubs.map(({ leader, subordinates }) => (
                          <div
                            key={leader.id}
                            className="rounded-xl border border-slate-800 bg-slate-950/60 overflow-hidden"
                          >
                            {/* Team Leader Row */}
                            <div className="px-3.5 py-2.5 bg-indigo-950/20 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
                              <div className="flex items-center gap-2.5">
                                <input
                                  type="checkbox"
                                  checked={selectedIds.has(leader.id)}
                                  onChange={() => toggleSelectId(leader.id)}
                                  className="rounded border-slate-700 text-indigo-600 focus:ring-0"
                                />
                                <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                                  <UserCheck className="w-4 h-4" />
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-bold text-white">
                                      {leader.username}
                                    </span>
                                    {isSuperAdminUser(leader.username, leader.username) ? (
                                      <span className="px-2 py-0.5 rounded text-[10px] font-black bg-purple-500/20 text-purple-300 border border-purple-500/30">
                                        👑 সুপার অ্যাডমিন
                                      </span>
                                    ) : (
                                      <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                                        🎯 টিম লিডার
                                      </span>
                                    )}
                                    <span
                                      className={`px-1.5 py-0.2 rounded text-[10px] font-semibold ${
                                        leader.active
                                          ? "bg-emerald-950/40 text-emerald-400 border border-emerald-500/30"
                                          : "bg-rose-950/40 text-rose-400 border border-rose-500/30"
                                      }`}
                                    >
                                      {leader.active ? "সক্রিয়" : "ব্লক"}
                                    </span>
                                  </div>
                                  <div className="text-[10px] text-slate-400">
                                    অধীনস্থ প্ল্যানার: {subordinates.length} জন
                                  </div>
                                </div>
                              </div>

                              {/* Leader Action Buttons */}
                              <div className="flex items-center gap-1.5 flex-wrap">
                                {leader.is_super_admin ? (
                                  <button
                                    onClick={() =>
                                      revokeSuperMutation.mutate({
                                        userId: leader.id,
                                        newRole: "team_leader",
                                      })
                                    }
                                    disabled={revokeSuperMutation.isPending}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 transition active:scale-95"
                                    title="সুপার অ্যাডমিন পারমিশন বাতিল করুন"
                                  >
                                    <ShieldOff className="w-3.5 h-3.5 text-amber-400" />
                                    <span>সুপার অ্যাডমিন বাতিল</span>
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => grantSuperMutation.mutate(leader.id)}
                                    disabled={grantSuperMutation.isPending}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/40 transition active:scale-95"
                                    title="এই ব্যবহারকারীকে সুপার অ্যাডমিন পারমিশন প্রদান করুন"
                                  >
                                    <Crown className="w-3.5 h-3.5 text-amber-300" />
                                    <span>👑 সুপার অ্যাডমিন বানান</span>
                                  </button>
                                )}

                                <button
                                  onClick={() => handleOpenPermissions(leader)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/30 transition"
                                  title="কাজের পারমিশন পরিবর্তন বা প্রত্যাহার করুন"
                                >
                                  <Sliders className="w-3.5 h-3.5 text-purple-400" />
                                  <span>পারমিশন</span>
                                </button>

                                <button
                                  onClick={() => setPasswordModalUser(leader)}
                                  className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                                  title="পাসওয়ার্ড রিসেট"
                                >
                                  <Key className="w-3 h-3 text-amber-400" />
                                </button>

                                {!isSuperAdminUser(leader.username, leader.username) && (
                                  <button
                                    onClick={() =>
                                      toggleActive.mutate({ id: leader.id, active: !leader.active })
                                    }
                                    className={`px-2 py-1 rounded-lg text-xs font-semibold transition ${
                                      leader.active
                                        ? "bg-rose-950/30 text-rose-400 hover:bg-rose-950/50"
                                        : "bg-emerald-950/30 text-emerald-400 hover:bg-emerald-950/50"
                                    }`}
                                  >
                                    {leader.active ? "ব্লক" : "আনব্লক"}
                                  </button>
                                )}
                              </div>
                            </div>

                            {/* Subordinates Under this Leader */}
                            {subordinates.length > 0 ? (
                              <div className="p-2 space-y-1.5 pl-6 bg-slate-950/40 border-t border-slate-900">
                                <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1 flex items-center gap-1">
                                  <ChevronRight className="w-3 h-3 text-indigo-400" />
                                  <span>
                                    অধীনস্থ প্ল্যানার ও ইউজারবৃন্দ ({subordinates.length} জন):
                                  </span>
                                </div>
                                {subordinates.map((sub) => (
                                  <div
                                    key={sub.id}
                                    className="flex items-center justify-between gap-3 px-3 py-1.5 rounded-lg bg-slate-900/60 hover:bg-slate-900 border border-slate-800/60 text-xs transition"
                                  >
                                    <div className="flex items-center gap-2">
                                      <input
                                        type="checkbox"
                                        checked={selectedIds.has(sub.id)}
                                        onChange={() => toggleSelectId(sub.id)}
                                        className="rounded border-slate-700 text-indigo-600 focus:ring-0"
                                      />
                                      <span className="font-semibold text-slate-200">
                                        {sub.username}
                                      </span>
                                      <span className="px-1.5 py-0.2 rounded text-[10px] font-medium bg-slate-800 text-slate-300">
                                        👤 প্ল্যানার
                                      </span>
                                      <span
                                        className={`px-1.5 py-0.2 rounded text-[9px] font-semibold ${
                                          sub.active
                                            ? "text-emerald-400 bg-emerald-950/30"
                                            : "text-rose-400 bg-rose-950/30"
                                        }`}
                                      >
                                        {sub.active ? "সক্রিয়" : "ব্লক"}
                                      </span>
                                    </div>

                                    <div className="flex items-center gap-1.5">
                                      {/* Quick TL change */}
                                      <select
                                        value={sub.team_leader_id ?? ""}
                                        onChange={(e) =>
                                          changeTL.mutate({
                                            id: sub.id,
                                            tl: e.target.value || null,
                                          })
                                        }
                                        className="bg-slate-950 border border-slate-700/80 rounded-lg px-2 py-0.5 text-[11px] text-slate-300 focus:outline-none"
                                        title="টিম লিডার পরিবর্তন"
                                      >
                                        {teamLeadersList.map((tl) => (
                                          <option key={tl.id} value={tl.id}>
                                            🎯 {tl.username}
                                          </option>
                                        ))}
                                      </select>

                                      <button
                                        onClick={() => handleOpenPermissions(sub)}
                                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/30"
                                      >
                                        <Sliders className="w-3 h-3 text-purple-400" />
                                        <span>পারমিশন</span>
                                      </button>

                                      <button
                                        onClick={() => setPasswordModalUser(sub)}
                                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-400"
                                        title="পাসওয়ার্ড রিসেট"
                                      >
                                        <Key className="w-3 h-3" />
                                      </button>

                                      <button
                                        onClick={() =>
                                          toggleActive.mutate({ id: sub.id, active: !sub.active })
                                        }
                                        className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                                          sub.active
                                            ? "text-rose-400 hover:bg-rose-950/40"
                                            : "text-emerald-400 hover:bg-emerald-950/40"
                                        }`}
                                      >
                                        {sub.active ? "ব্লক" : "আনব্লক"}
                                      </button>

                                      <button
                                        onClick={() => {
                                          if (
                                            confirm(`'${sub.username}' ব্যবহারকারীকে মুছে ফেলবেন?`)
                                          ) {
                                            removeUser.mutate(sub.id);
                                          }
                                        }}
                                        className="p-1 rounded bg-rose-950/30 hover:bg-rose-900/50 text-rose-400 transition"
                                        title="ডিলিট"
                                      >
                                        <Trash2 className="w-3 h-3" />
                                      </button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : null}
                          </div>
                        ))}

                        {/* Unassigned in Factory */}
                        {group.unassignedInFactory.length > 0 && (
                          <div className="p-3 rounded-xl border border-amber-500/30 bg-amber-950/15">
                            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300 mb-2">
                              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                              <span>
                                টিম লিডার নির্ধারণ করা হয়নি ({group.unassignedInFactory.length}{" "}
                                জন):
                              </span>
                            </div>
                            <div className="space-y-1.5">
                              {group.unassignedInFactory.map((u) => (
                                <div
                                  key={u.id}
                                  className="flex items-center justify-between gap-3 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800 text-xs"
                                >
                                  <div className="flex items-center gap-2">
                                    <input
                                      type="checkbox"
                                      checked={selectedIds.has(u.id)}
                                      onChange={() => toggleSelectId(u.id)}
                                      className="rounded border-slate-700 text-indigo-600 focus:ring-0"
                                    />
                                    <span className="font-semibold text-slate-200">
                                      {u.username}
                                    </span>
                                    <span className="text-[10px] text-amber-400">⚠️ লিডারহীন</span>
                                  </div>

                                  <div className="flex items-center gap-2">
                                    <select
                                      value=""
                                      onChange={(e) =>
                                        changeTL.mutate({
                                          id: u.id,
                                          tl: e.target.value || null,
                                        })
                                      }
                                      className="bg-indigo-950/60 border border-indigo-500/40 rounded-lg px-2 py-1 text-xs text-indigo-200 focus:outline-none"
                                    >
                                      <option value="">🎯 টিম লিডার নির্বাচন করুন...</option>
                                      {teamLeadersList.map((tl) => (
                                        <option key={tl.id} value={tl.id}>
                                          {tl.username} (
                                          {factoryMap.get(tl.factory_id ?? "") ?? "ফ্যাক্টরি ছাড়া"})
                                        </option>
                                      ))}
                                    </select>

                                    <button
                                      onClick={() => handleOpenPermissions(u)}
                                      className="px-2 py-1 rounded-md text-xs font-semibold bg-purple-500/20 text-purple-200 border border-purple-500/30"
                                    >
                                      পারমিশন
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}

                  {/* Users without factory */}
                  {hierarchyData.unassignedFactoryUsers.length > 0 && (
                    <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
                      <div className="flex items-center gap-2 text-sm font-bold text-slate-300 mb-3">
                        <AlertCircle className="w-4 h-4 text-amber-400" />
                        <span>
                          ফ্যাক্টরি ছাড়া ইউজারবৃন্দ ({hierarchyData.unassignedFactoryUsers.length}{" "}
                          জন):
                        </span>
                      </div>
                      <div className="space-y-2">
                        {hierarchyData.unassignedFactoryUsers.map((u) => (
                          <div
                            key={u.id}
                            className="flex items-center justify-between gap-3 px-3.5 py-2 rounded-xl bg-slate-950/70 border border-slate-800 text-xs"
                          >
                            <div className="flex items-center gap-2.5">
                              <input
                                type="checkbox"
                                checked={selectedIds.has(u.id)}
                                onChange={() => toggleSelectId(u.id)}
                                className="rounded border-slate-700 text-indigo-600 focus:ring-0"
                              />
                              <span className="font-bold text-white">{u.username}</span>
                              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300">
                                {u.role === "admin"
                                  ? "👑 অ্যাডমিন"
                                  : u.role === "team_leader"
                                    ? "🎯 টিম লিডার"
                                    : "👤 ইউজার"}
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              {u.is_super_admin ? (
                                <button
                                  onClick={() =>
                                    revokeSuperMutation.mutate({
                                      userId: u.id,
                                      newRole: "admin",
                                    })
                                  }
                                  disabled={revokeSuperMutation.isPending}
                                  className="px-2 py-1 rounded-lg text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/30 flex items-center gap-1"
                                  title="সুপার অ্যাডমিন পারমিশন বাতিল করুন"
                                >
                                  <ShieldOff className="w-3.5 h-3.5 text-amber-400" />
                                  <span>বাতিল</span>
                                </button>
                              ) : (
                                <button
                                  onClick={() => grantSuperMutation.mutate(u.id)}
                                  disabled={grantSuperMutation.isPending}
                                  className="px-2 py-1 rounded-lg text-xs font-bold bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/30 flex items-center gap-1"
                                  title="সুপার অ্যাডমিন পারমিশন দিন"
                                >
                                  <Crown className="w-3.5 h-3.5 text-amber-300" />
                                  <span>সুপার অ্যাডমিন</span>
                                </button>
                              )}

                              <select
                                value={u.factory_id ?? ""}
                                onChange={(e) =>
                                  changeFactory.mutate({
                                    id: u.id,
                                    factoryId: e.target.value || null,
                                  })
                                }
                                className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-200"
                              >
                                <option value="">🏢 ফ্যাক্টরি অ্যাসাইন করুন...</option>
                                {(factories.data ?? []).map((f) => (
                                  <option key={f.id} value={f.id}>
                                    🏢 {f.name}
                                  </option>
                                ))}
                              </select>

                              <button
                                onClick={() => handleOpenPermissions(u)}
                                className="px-2.5 py-1 rounded-lg text-xs bg-purple-500/20 text-purple-200 border border-purple-500/30 font-semibold"
                              >
                                পারমিশন
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* TABLE VIEW */
                <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 font-bold">
                        <tr>
                          <th className="p-3 w-10 text-center">
                            <input
                              type="checkbox"
                              checked={
                                selectedIds.size > 0 && selectedIds.size === filteredUsers.length
                              }
                              onChange={selectedIds.size > 0 ? clearSelection : selectAllFiltered}
                              className="rounded border-slate-700 text-indigo-600 focus:ring-0"
                            />
                          </th>
                          <th className="p-3">ব্যবহারকারী</th>
                          <th className="p-3">রোল</th>
                          <th className="p-3">কারখানা (Factory)</th>
                          <th className="p-3">টিম লিডার (TL)</th>
                          <th className="p-3">স্ট্যাটাস</th>
                          <th className="p-3 text-right">অ্যাকশন</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {filteredUsers.map((u) => {
                          const isSuper = isSuperAdminUser(u.username, u.username);
                          const checked = selectedIds.has(u.id);
                          return (
                            <tr
                              key={u.id}
                              className={`hover:bg-slate-800/40 transition ${
                                checked ? "bg-indigo-950/20" : ""
                              }`}
                            >
                              <td className="p-3 text-center">
                                {!isSuper && (
                                  <input
                                    type="checkbox"
                                    checked={checked}
                                    onChange={() => toggleSelectId(u.id)}
                                    className="rounded border-slate-700 text-indigo-600 focus:ring-0"
                                  />
                                )}
                              </td>
                              <td className="p-3">
                                <div className="font-bold text-white flex items-center gap-1.5">
                                  {u.username}
                                  {isSuper && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                                </div>
                                <div className="text-[10px] text-slate-500">
                                  {new Date(u.created_at).toLocaleDateString()}
                                </div>
                              </td>
                              <td className="p-3">
                                <select
                                  value={isSuper ? "super_admin" : u.role}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    if (val === "super_admin") {
                                      grantSuperMutation.mutate(u.id);
                                    } else {
                                      if (isSuper) {
                                        revokeSuperMutation.mutate({
                                          userId: u.id,
                                          newRole: val as AppRole,
                                        });
                                      } else {
                                        changeRole.mutate({
                                          id: u.id,
                                          role: val as AppRole,
                                        });
                                      }
                                    }
                                  }}
                                  className={`border rounded-lg px-2 py-1 text-xs font-bold transition ${
                                    isSuper
                                      ? "bg-purple-950/80 border-purple-500/50 text-purple-200"
                                      : "bg-slate-950 border-slate-700 text-slate-200"
                                  }`}
                                >
                                  <option value="super_admin">👑 সুপার অ্যাডমিন</option>
                                  <option value="admin">⭐ Admin</option>
                                  <option value="team_leader">🎯 Team Leader</option>
                                  <option value="user">👤 User</option>
                                </select>
                              </td>
                              <td className="p-3">
                                <select
                                  value={u.factory_id ?? ""}
                                  onChange={(e) =>
                                    changeFactory.mutate({
                                      id: u.id,
                                      factoryId: e.target.value || null,
                                    })
                                  }
                                  className="bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-200 max-w-[140px]"
                                >
                                  <option value="">(ফ্যাক্টরি ছাড়া)</option>
                                  {(factories.data ?? []).map((f) => (
                                    <option key={f.id} value={f.id}>
                                      🏢 {f.name}
                                    </option>
                                  ))}
                                </select>
                              </td>
                              <td className="p-3">
                                {u.role === "user" ? (
                                  <select
                                    value={u.team_leader_id ?? ""}
                                    onChange={(e) =>
                                      changeTL.mutate({
                                        id: u.id,
                                        tl: e.target.value || null,
                                      })
                                    }
                                    className="bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-200 max-w-[140px]"
                                  >
                                    <option value="">(টিম লিডার ছাড়া)</option>
                                    {teamLeadersList.map((tl) => (
                                      <option key={tl.id} value={tl.id}>
                                        🎯 {tl.username}
                                      </option>
                                    ))}
                                  </select>
                                ) : (
                                  <span className="text-[11px] text-slate-500">—</span>
                                )}
                              </td>
                              <td className="p-3">
                                <span
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    u.active
                                      ? "bg-emerald-950/40 text-emerald-400 border border-emerald-500/30"
                                      : "bg-rose-950/40 text-rose-400 border border-rose-500/30"
                                  }`}
                                >
                                  {u.active ? "সক্রিয়" : "ব্লক"}
                                </span>
                              </td>
                              <td className="p-3 text-right">
                                <div className="inline-flex items-center gap-1.5">
                                  {isSuper ? (
                                    <button
                                      onClick={() =>
                                        revokeSuperMutation.mutate({
                                          userId: u.id,
                                          newRole: "admin",
                                        })
                                      }
                                      disabled={revokeSuperMutation.isPending}
                                      className="px-2 py-1 rounded-lg text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/30 transition flex items-center gap-1"
                                      title="সুপার অ্যাডমিন পারমিশন বাতিল করুন"
                                    >
                                      <ShieldOff className="w-3.5 h-3.5 text-amber-400" />
                                      <span>বাতিল</span>
                                    </button>
                                  ) : (
                                    <button
                                      onClick={() => grantSuperMutation.mutate(u.id)}
                                      disabled={grantSuperMutation.isPending}
                                      className="px-2 py-1 rounded-lg text-xs font-bold bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/30 transition flex items-center gap-1"
                                      title="এই ইউজারকে সুপার অ্যাডমিন পারমিশন দিন"
                                    >
                                      <Crown className="w-3.5 h-3.5 text-amber-300" />
                                      <span>সুপার অ্যাডমিন</span>
                                    </button>
                                  )}

                                  <button
                                    onClick={() => handleOpenPermissions(u)}
                                    className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/30"
                                  >
                                    <Sliders className="w-3 h-3 inline mr-1 text-purple-400" />
                                    পারমিশন
                                  </button>
                                  <button
                                    onClick={() => setPasswordModalUser(u)}
                                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400"
                                    title="পাসওয়ার্ড রিসেট"
                                  >
                                    <Key className="w-3.5 h-3.5" />
                                  </button>
                                  {!isSuper && (
                                    <>
                                      <button
                                        onClick={() =>
                                          toggleActive.mutate({ id: u.id, active: !u.active })
                                        }
                                        className={`px-2 py-1 rounded-lg text-xs font-semibold ${
                                          u.active
                                            ? "text-rose-400 bg-rose-950/30 hover:bg-rose-950/50"
                                            : "text-emerald-400 bg-emerald-950/30 hover:bg-emerald-950/50"
                                        }`}
                                      >
                                        {u.active ? "ব্লক" : "আনব্লক"}
                                      </button>
                                      <button
                                        onClick={() => {
                                          if (confirm(`'${u.username}' কে ডিলিট করবেন?`)) {
                                            removeUser.mutate(u.id);
                                          }
                                        }}
                                        className="p-1.5 rounded-lg bg-rose-950/30 hover:bg-rose-900/50 text-rose-400"
                                        title="মুছে ফেলুন"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ================= TAB 2: FACTORY MANAGEMENT ================= */}
          {activeTab === "factories" && (
            <div className="space-y-6 max-w-4xl mx-auto">
              {/* Add New Factory Card */}
              <div className="rounded-2xl border border-indigo-500/30 bg-gradient-to-r from-indigo-950/40 to-slate-900/60 p-5 shadow-lg">
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2 mb-2">
                  <Plus className="w-4 h-4 text-emerald-400" />
                  নতুন কারখানা / ফ্যাক্টরি যোগ করুন
                </h3>
                <p className="text-xs text-slate-400 mb-4">
                  যেমন: Apex Sewing Plant 1, Standard Washing Unit, ইত্যাদি। ফ্যাক্টরি যোগ করার পর
                  টিম লিডার ও ইউজারদের অ্যাসাইন করুন।
                </p>
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={newFactoryName}
                    onChange={(e) => setNewFactoryName(e.target.value)}
                    placeholder="কারখানার নাম লিখুন..."
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    onClick={() => {
                      if (!newFactoryName.trim()) {
                        toast.error("কারখানার নাম দিন।");
                        return;
                      }
                      addFactory.mutate(newFactoryName.trim());
                    }}
                    disabled={addFactory.isPending}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition shadow-md shadow-indigo-600/30 disabled:opacity-50"
                  >
                    {addFactory.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Building2 className="w-4 h-4" />
                    )}
                    <span>কারখানা যোগ করুন</span>
                  </button>
                </div>
              </div>

              {/* Existing Factories Grid */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-400 font-bold px-1">
                  <span>বিদ্যমান কারখানা তালিকা ({(factories.data ?? []).length} টি):</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(factories.data ?? []).map((f) => {
                    const usersInF = allUsersList.filter((u) => u.factory_id === f.id);
                    const tlsInF = usersInF.filter(
                      (u) => u.role === "team_leader" || u.role === "admin",
                    );
                    const isEditing = editingFactoryId === f.id;

                    return (
                      <div
                        key={f.id}
                        className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 flex flex-col justify-between gap-4 hover:border-slate-700 transition"
                      >
                        <div>
                          {isEditing ? (
                            <div className="flex items-center gap-2 mb-2">
                              <input
                                type="text"
                                value={editingFactoryName}
                                onChange={(e) => setEditingFactoryName(e.target.value)}
                                className="flex-1 bg-slate-950 border border-indigo-500 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none"
                              />
                              <button
                                onClick={() => {
                                  if (!editingFactoryName.trim()) return;
                                  editFactory.mutate({ id: f.id, name: editingFactoryName.trim() });
                                }}
                                className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-600 text-white"
                              >
                                সেভ
                              </button>
                              <button
                                onClick={() => setEditingFactoryId(null)}
                                className="px-2.5 py-1 rounded-lg text-xs bg-slate-800 text-slate-400"
                              >
                                বাতিল
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <Building2 className="w-5 h-5 text-sky-400 shrink-0" />
                                <h4 className="text-sm font-extrabold text-white">{f.name}</h4>
                              </div>
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => {
                                    setEditingFactoryId(f.id);
                                    setEditingFactoryName(f.name);
                                  }}
                                  className="p-1 rounded text-slate-400 hover:text-white"
                                  title="নাম পরিবর্তন"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => {
                                    if (
                                      confirm(
                                        `'${f.name}' কারখানাটি মুছে ফেলবেন? এটি মুছলে সংশ্লিষ্ট ইউজারদের ফ্যাক্টরি রিমুভ হবে।`,
                                      )
                                    ) {
                                      removeFactory.mutate(f.id);
                                    }
                                  }}
                                  className="p-1 rounded text-rose-400 hover:text-rose-300"
                                  title="কারখানা মুছুন"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          )}

                          <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                            <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800">
                              <span className="text-[10px] text-slate-400 block">টিম লিডার:</span>
                              <span className="text-sm font-extrabold text-indigo-300">
                                {tlsInF.length} জন
                              </span>
                            </div>
                            <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800">
                              <span className="text-[10px] text-slate-400 block">মোট ইউজার:</span>
                              <span className="text-sm font-extrabold text-emerald-300">
                                {usersInF.length} জন
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px]">
                          <button
                            onClick={() => {
                              setFilterFactory(f.id);
                              setActiveTab("hierarchy");
                            }}
                            className="text-indigo-400 hover:underline flex items-center gap-1"
                          >
                            <span>এই কারখানার ইউজারদের দেখুন</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>

                          <button
                            onClick={() => {
                              setNewUserFactory(f.id);
                              setActiveTab("create_user");
                            }}
                            className="text-emerald-400 hover:underline flex items-center gap-1"
                          >
                            <Plus className="w-3 h-3" />
                            <span>ইউজার যোগ</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ================= TAB 3: WORK PERMISSIONS MATRIX ================= */}
          {activeTab === "permissions" && (
            <div className="space-y-6 max-w-4xl mx-auto">
              <div className="rounded-2xl border border-purple-500/30 bg-purple-950/20 p-4">
                <div className="flex items-center gap-2 text-sm font-bold text-purple-200 mb-1">
                  <ShieldCheck className="w-4 h-4 text-purple-400" />
                  <span>কাজের পারমিশন নিয়ন্ত্রণ ও অনুমতি প্রত্যাহার (Grant / Revoke)</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  সুপার অ্যাডমিন হিসেবে আপনি যেকোনো ব্যবহারকারীকে যেমন যেকোনো কাজের অনুমতি
                  (Permission) প্রদান করতে পারেন, তেমনি প্রয়োজন অনুসারে মুহূর্তেই তা প্রত্যাহার বা
                  রিমুভ (Revoke / Remove) করে দিতে পারেন।
                </p>
              </div>

              {/* User Selector for Permission Customization */}
              <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-slate-300">ইউজার নির্বাচন করুন:</span>
                    <select
                      value={permTargetUser?.id ?? ""}
                      onChange={(e) => {
                        const target = allUsersList.find((u) => u.id === e.target.value);
                        if (target) handleOpenPermissions(target);
                        else setPermTargetUser(null);
                      }}
                      className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500 min-w-[200px]"
                    >
                      <option value="">(ব্যবহারকারী সিলেক্ট করুন)</option>
                      {allUsersList.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.username} — {u.role.toUpperCase()} (
                          {factoryMap.get(u.factory_id ?? "") ?? "ফ্যাক্টরি ছাড়া"})
                        </option>
                      ))}
                    </select>
                  </div>

                  {permTargetUser && (
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[11px] text-slate-400 font-semibold mr-1">
                        টেমপ্লেট:
                      </span>
                      {(Object.keys(PERMISSION_PRESETS) as PermissionPresetKey[]).map((pkey) => {
                        const p = PERMISSION_PRESETS[pkey];
                        return (
                          <button
                            key={pkey}
                            type="button"
                            onClick={() => applyPresetToActivePerms(pkey)}
                            className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                          >
                            {p.label.split(" ")[0]} {p.label.split(" ")[1]}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                {permTargetUser ? (
                  <div className="space-y-4 pt-3 border-t border-slate-800">
                    {/* Super Admin Promotion / Revocation Banner */}
                    <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/50 via-indigo-950/40 to-slate-900 border border-purple-500/40 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-xl bg-purple-600/30 text-amber-300">
                          <Crown className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="text-xs font-black text-purple-200 flex items-center gap-1.5">
                            <span>সুপার অ্যাডমিন পারমিশন কন্ট্রোল</span>
                            {permTargetUser.is_super_admin && (
                              <span className="px-1.5 py-0.2 rounded text-[10px] bg-purple-500/30 text-purple-200 border border-purple-400/40">
                                সক্রিয়
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {permTargetUser.is_super_admin
                              ? "এই ইউজার বর্তমানে সুপার অ্যাডমিন — সকল কারখানা ও ফিচারে ১০০% পূর্ণ এক্সেস রয়েছে।"
                              : "এই ইউজারকে সুপার অ্যাডমিন পারমিশন দিলে তিনি সকল ফ্যাক্টরি ও ফিচারের শতভাগ ক্ষমতা পাবেন।"}
                          </div>
                        </div>
                      </div>

                      {permTargetUser.is_super_admin ? (
                        <button
                          type="button"
                          onClick={() => {
                            revokeSuperMutation.mutate({
                              userId: permTargetUser.id,
                              newRole: permTargetUser.role,
                            });
                            setPermTargetUser((prev) =>
                              prev ? { ...prev, is_super_admin: false } : null,
                            );
                          }}
                          disabled={revokeSuperMutation.isPending}
                          className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-600/30 hover:bg-amber-600/50 text-amber-200 border border-amber-500/40 transition flex items-center gap-1.5 active:scale-95"
                        >
                          <ShieldOff className="w-3.5 h-3.5" />
                          <span>সুপার অ্যাডমিন পারমিশন বাতিল করুন</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            grantSuperMutation.mutate(permTargetUser.id);
                            setPermTargetUser((prev) =>
                              prev ? { ...prev, is_super_admin: true } : null,
                            );
                          }}
                          disabled={grantSuperMutation.isPending}
                          className="px-3 py-1.5 rounded-xl text-xs font-black bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/30 transition flex items-center gap-1.5 active:scale-95"
                        >
                          <Crown className="w-3.5 h-3.5 text-amber-300" />
                          <span>👑 সুপার অ্যাডমিন পারমিশন দিন</span>
                        </button>
                      )}
                    </div>

                    {/* Grant All vs Revoke All Master Controls */}
                    <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950/80 p-3.5 rounded-2xl border border-indigo-500/30">
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-2">
                          <span>ব্যবহারকারী: {permTargetUser.username}</span>
                          <span className="px-2 py-0.2 rounded text-[10px] bg-indigo-500/20 text-indigo-300 font-semibold">
                            {permTargetUser.role.toUpperCase()}
                          </span>
                          {permTargetUser.factory_id && (
                            <span className="text-[10px] text-slate-400">
                              • 🏢 {factoryMap.get(permTargetUser.factory_id)}
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          সক্রিয় অনুমতি:{" "}
                          <span className="font-extrabold text-emerald-400">
                            {Object.values(activeUserPerms).filter(Boolean).length}
                          </span>
                          /{WORK_PERMISSIONS_LIST.length} টি
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Grant All Button */}
                        <button
                          type="button"
                          onClick={grantAllPermissions}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/40 transition"
                          title="এই ইউজারের সকল পারমিশন সক্রিয় করুন"
                        >
                          <CheckSquare className="w-3.5 h-3.5" />
                          <span>সব পারমিশন দিন</span>
                        </button>

                        {/* Revoke All Button */}
                        <button
                          type="button"
                          onClick={revokeAllPermissions}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 border border-rose-500/40 transition"
                          title="এই ইউজারের সমস্ত পারমিশন বাতিল / রিমুভ করুন"
                        >
                          <ShieldOff className="w-3.5 h-3.5" />
                          <span>সকল পারমিশন রিমুভ / প্রত্যাহার</span>
                        </button>

                        {/* Save Button */}
                        <button
                          type="button"
                          onClick={handleSavePermissions}
                          disabled={savingPerms}
                          className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-extrabold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white transition shadow-md shadow-emerald-600/30 disabled:opacity-50"
                        >
                          {savingPerms ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Check className="w-3.5 h-3.5" />
                          )}
                          <span>সেভ করুন</span>
                        </button>
                      </div>
                    </div>

                    {/* Permissions Category Cards */}
                    <div className="space-y-4">
                      {PERMISSION_CATEGORIES.map((cat) => {
                        const permsInCat = WORK_PERMISSIONS_LIST.filter(
                          (p) => p.category === cat.id,
                        );
                        const allActive = permsInCat.every((p) => activeUserPerms[p.key]);

                        return (
                          <div
                            key={cat.id}
                            className="rounded-2xl border border-slate-800/80 bg-slate-950/40 p-4 space-y-3"
                          >
                            <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
                              <h4 className="text-xs font-extrabold text-white flex items-center gap-2">
                                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                                <span>{cat.label}</span>
                              </h4>
                              <div className="flex items-center gap-3">
                                <button
                                  type="button"
                                  onClick={() => {
                                    const next = { ...activeUserPerms };
                                    permsInCat.forEach((p) => {
                                      next[p.key] = true;
                                    });
                                    setActiveUserPerms(next);
                                  }}
                                  className="text-[11px] text-emerald-400 hover:underline font-semibold"
                                >
                                  + এই ক্যাটাগরি অনুমোদন
                                </button>
                                <span className="text-slate-600">•</span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const next = { ...activeUserPerms };
                                    permsInCat.forEach((p) => {
                                      next[p.key] = false;
                                    });
                                    setActiveUserPerms(next);
                                  }}
                                  className="text-[11px] text-rose-400 hover:underline font-semibold"
                                >
                                  - এই ক্যাটাগরি প্রত্যাহার
                                </button>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                              {permsInCat.map((p) => {
                                const checked = !!activeUserPerms[p.key];
                                return (
                                  <div
                                    key={p.key}
                                    onClick={() =>
                                      setActiveUserPerms((prev) => ({
                                        ...prev,
                                        [p.key]: !checked,
                                      }))
                                    }
                                    className={`flex items-start justify-between gap-3 p-3 rounded-xl border transition cursor-pointer select-none ${
                                      checked
                                        ? "bg-indigo-950/30 border-indigo-500/40 text-white"
                                        : "bg-slate-900/40 border-slate-800/80 text-slate-400 hover:border-slate-700"
                                    }`}
                                  >
                                    <div className="flex items-start gap-2.5 min-w-0">
                                      <input
                                        type="checkbox"
                                        checked={checked}
                                        onChange={() => {}}
                                        className="mt-0.5 rounded border-slate-700 text-indigo-600 focus:ring-0 shrink-0"
                                      />
                                      <div className="min-w-0">
                                        <div className="text-xs font-bold leading-tight">
                                          {p.label}
                                        </div>
                                        <div className="text-[10px] text-slate-500 mt-0.5 leading-tight">
                                          {p.description}
                                        </div>
                                      </div>
                                    </div>

                                    <span
                                      className={`shrink-0 px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${
                                        checked
                                          ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
                                          : "bg-rose-500/10 text-rose-400 border-rose-500/20"
                                      }`}
                                    >
                                      {checked ? "অনুমোদিত" : "প্রত্যাহার"}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-10 text-slate-500 text-xs">
                    উপরের ড্রপডাউন থেকে একজন ব্যবহারকারী সিলেক্ট করুন অথবা টিম ও ইউজার কাঠামো ট্যাব
                    থেকে সরাসরি পারমিশন বাটনে ক্লিক করুন।
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================= TAB 4: ADD USER ================= */}
          {activeTab === "create_user" && (
            <div className="max-w-2xl mx-auto rounded-3xl border border-indigo-500/30 bg-slate-900/70 p-6 shadow-2xl space-y-5">
              <div className="border-b border-border/60 pb-3">
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-emerald-400" />
                  নতুন ব্যবহারকারী (User / Leader / Admin) তৈরি করুন
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  কারখানা ভিত্তিক টিম গঠন করতে ইউজারকে সংশ্লিষ্ট ফ্যাক্টরি এবং টিম লিডারের অধীনে
                  যুক্ত করুন।
                </p>
              </div>

              <div className="space-y-4">
                {/* Username */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    ইউজারনেম বা ইমেইল <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    placeholder="যেমন: plan_unit1 বা planner_rahim"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    শুধুমাত্র নাম দিলে স্বয়ংক্রিয়ভাবে সিস্টেমের লোকাল ডোমেইনে কনভার্ট হবে।
                  </span>
                </div>

                {/* Password */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    পাসওয়ার্ড <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                {/* Factory Selection */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    কারখানা / ফ্যাক্টরি নির্বাচন
                  </label>
                  <select
                    value={newUserFactory}
                    onChange={(e) => setNewUserFactory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="">🏢 ফ্যাক্টরি নির্বাচন করুন (বা ফাঁকা রাখুন)</option>
                    {(factories.data ?? []).map((f) => (
                      <option key={f.id} value={f.id}>
                        🏢 {f.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Role Selection */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    রোল (Role) <span className="text-rose-400">*</span>
                  </label>
                  <div className="grid grid-cols-3 gap-2.5">
                    {[
                      {
                        key: "user",
                        label: "👤 প্ল্যানার / ইউজার",
                        desc: "টিম লিডারের অধীনে কাজ করবে",
                      },
                      {
                        key: "team_leader",
                        label: "🎯 টিম লিডার",
                        desc: "ফ্যাক্টরির টিম পরিচালনা করবে",
                      },
                      { key: "admin", label: "👑 অ্যাডমিন", desc: "পূর্ণ সিস্টেম অ্যাডমিন রোল" },
                    ].map((r) => (
                      <button
                        key={r.key}
                        type="button"
                        onClick={() => {
                          setNewRole(r.key as AppRole);
                          if (r.key === "team_leader") setNewPreset("team_leader");
                          else if (r.key === "admin") setNewPreset("super_admin");
                          else setNewPreset("full_planner");
                        }}
                        className={`p-3 rounded-xl border text-left transition ${
                          newRole === r.key
                            ? "bg-indigo-600/30 border-indigo-500 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700"
                        }`}
                      >
                        <div className="text-xs font-bold">{r.label}</div>
                        <div className="text-[10px] text-slate-500 mt-0.5">{r.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Team Leader Selection (Conditional for User role) */}
                {newRole === "user" && (
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      টিম লিডার (Team Leader) <span className="text-rose-400">*</span>
                    </label>
                    <select
                      value={newTeamLeader}
                      onChange={(e) => setNewTeamLeader(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                    >
                      <option value="">🎯 টিম লিডার নির্বাচন করুন...</option>
                      {teamLeadersForSelectedFactory.map((tl) => (
                        <option key={tl.id} value={tl.id}>
                          {tl.username} ({factoryMap.get(tl.factory_id ?? "") ?? "ফ্যাক্টরি ছাড়া"})
                        </option>
                      ))}
                    </select>
                    {teamLeadersForSelectedFactory.length === 0 && (
                      <span className="text-[11px] text-amber-400 mt-1 block">
                        ⚠️ এই কারখানায় কোনো টিম লিডার নেই। প্রথমে একজন টিম লিডার তৈরি করুন।
                      </span>
                    )}
                  </div>
                )}

                {/* Initial Permission Preset */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    প্রাথমিক পারমিশন টেমপ্লেট
                  </label>
                  <select
                    value={newPreset}
                    onChange={(e) => setNewPreset(e.target.value as PermissionPresetKey)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    {(Object.keys(PERMISSION_PRESETS) as PermissionPresetKey[]).map((pkey) => {
                      const p = PERMISSION_PRESETS[pkey];
                      return (
                        <option key={pkey} value={pkey}>
                          {p.label} — {p.description}
                        </option>
                      );
                    })}
                  </select>
                </div>

                {/* Submit Button */}
                <button
                  onClick={() => createUser.mutate()}
                  disabled={createUser.isPending}
                  className="w-full py-3 rounded-2xl text-xs font-extrabold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white transition shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 disabled:opacity-50 mt-2"
                >
                  {createUser.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <UserPlus className="w-4 h-4" />
                  )}
                  <span>ব্যবহারকারী অ্যাকাউন্ট তৈরি করুন</span>
                </button>
              </div>
            </div>
          )}

          {/* ================= TAB 5: AUDIT LOGS & ACTIVITY MONITOR ================= */}
          {activeTab === "audit_logs" && (
            <div className="space-y-4 max-w-5xl mx-auto">
              {/* Header explanation & Filter Bar */}
              <div className="bg-slate-900/80 border border-border/50 rounded-2xl p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                      <ClipboardList className="w-4 h-4 text-emerald-400" />
                      <span>প্ল্যানিং বোর্ড ও টিম অ্যাক্টিভিটি অডিট লগ</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      প্ল্যান বোর্ডে কে কী পরিবর্তন করেছে, কাকে পারমিশন দেওয়া বা নেওয়া হয়েছে —
                      সবকিছুর রিয়েল-টাইম ট্র্যাকিং
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => auditLogsQuery.refetch()}
                      disabled={auditLogsQuery.isFetching}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                    >
                      <RefreshCw
                        className={`w-3.5 h-3.5 ${auditLogsQuery.isFetching ? "animate-spin" : ""}`}
                      />
                      <span>রিফ্রেশ</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (confirm("আপনি কি নিশ্চিতভাবে সমস্ত অডিট হিস্টোরি মুছে ফেলতে চান?")) {
                          clearAudit.mutate();
                        }
                      }}
                      disabled={clearAudit.isPending}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 border border-rose-500/30 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>লগ মুছুন</span>
                    </button>
                  </div>
                </div>

                {/* Filters */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={auditSearch}
                      onChange={(e) => setAuditSearch(e.target.value)}
                      placeholder="স্টাইল, ইউজার বা বিবরণ দিয়ে খুঁজুন..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <select
                    value={auditActionFilter}
                    onChange={(e) => setAuditActionFilter(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="">সকল অ্যাকশন টাইপ</option>
                    {(Object.keys(AUDIT_ACTION_CONFIG) as AuditActionType[]).map((actKey) => (
                      <option key={actKey} value={actKey}>
                        {AUDIT_ACTION_CONFIG[actKey].label}
                      </option>
                    ))}
                  </select>

                  <select
                    value={auditFactoryFilter}
                    onChange={(e) => setAuditFactoryFilter(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="">🏢 সকল কারখানা</option>
                    {(factories.data ?? []).map((f) => (
                      <option key={f.id} value={f.id}>
                        🏢 {f.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Logs Table / List */}
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden shadow-xl">
                {auditLogsQuery.isLoading ? (
                  <div className="flex justify-center items-center py-16">
                    <Loader2 className="w-7 h-7 animate-spin text-indigo-400" />
                  </div>
                ) : (auditLogsQuery.data ?? []).length === 0 ? (
                  <div className="text-center py-16 text-slate-500 space-y-2">
                    <ClipboardList className="w-10 h-10 text-slate-600 mx-auto" />
                    <div className="text-sm font-bold text-slate-400">
                      কোনো অডিট রেকর্ড পাওয়া যায়নি
                    </div>
                    <p className="text-xs text-slate-500">
                      প্ল্যান বোর্ডে ড্র্যাগ, প্ল্যান তৈরি বা পারমিশন পরিবর্তন করলে এখানে
                      স্বয়ংক্রিয়ভাবে রেকর্ড জমা হবে।
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-800/80">
                    {(auditLogsQuery.data ?? []).map((entry) => {
                      const cfg = AUDIT_ACTION_CONFIG[entry.action] ?? {
                        label: entry.action,
                        badgeClass: "bg-slate-800 text-slate-300 border-slate-700",
                      };
                      const logDate = new Date(entry.timestamp);
                      const formattedTime = logDate.toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                        second: "2-digit",
                      });
                      const formattedDate = logDate.toLocaleDateString();

                      return (
                        <div
                          key={entry.id}
                          className="p-3.5 hover:bg-slate-800/30 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                        >
                          <div className="space-y-1 min-w-0 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${cfg.badgeClass}`}
                              >
                                {cfg.label}
                              </span>

                              <span className="font-bold text-white flex items-center gap-1">
                                {entry.isSuperAdmin && (
                                  <Crown className="w-3 h-3 text-amber-400 shrink-0" />
                                )}
                                {entry.username}
                              </span>

                              <span className="px-1.5 py-0.2 rounded text-[9px] font-semibold bg-slate-800 text-slate-300">
                                {entry.userRole.toUpperCase()}
                              </span>

                              {entry.factoryName && (
                                <span className="text-[10px] text-sky-400 flex items-center gap-0.5">
                                  🏢 {entry.factoryName}
                                </span>
                              )}
                            </div>

                            <p className="text-xs text-slate-200 font-medium leading-relaxed pl-0.5">
                              {entry.details}
                            </p>
                          </div>

                          <div className="shrink-0 text-right text-[11px] text-slate-400">
                            <div className="font-semibold text-slate-300">{formattedTime}</div>
                            <div className="text-[10px] text-slate-500">{formattedDate}</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================= TAB 6: BULK ACTIONS ================= */}
          {activeTab === "bulk" && (
            <div className="max-w-2xl mx-auto rounded-3xl border border-purple-500/30 bg-slate-900/70 p-6 shadow-2xl space-y-5">
              <div className="border-b border-border/60 pb-3">
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <Layers className="w-5 h-5 text-purple-400" />
                  একসাথে একাধিক ব্যবহারকারীর সেটিং পরিবর্তন (Bulk Operations)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  নির্বাচিত ব্যবহারকারীদের একসাথে ফ্যাক্টরি অ্যাসাইন, টিম লিডার পরিবর্তন বা পারমিশন
                  টেমপ্লেট প্রয়োগ করুন।
                </p>
              </div>

              {selectedIds.size === 0 ? (
                <div className="text-center py-10 bg-slate-950/60 rounded-2xl border border-slate-800 p-6">
                  <AlertCircle className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                  <div className="text-sm font-bold text-white mb-1">
                    কোনো ইউজার সিলেক্ট করা হয়নি
                  </div>
                  <p className="text-xs text-slate-400 mb-4">
                    টিম ও ইউজার কাঠামো ট্যাবে গিয়ে ব্যবহারকারীদের নামের বামে চেকবক্স সিলেক্ট করুন।
                  </p>
                  <button
                    onClick={() => setActiveTab("hierarchy")}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 text-white"
                  >
                    ইউজার তালিকায় যান
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between bg-purple-950/30 border border-purple-500/30 p-3 rounded-xl text-xs">
                    <span className="font-bold text-purple-200">
                      মোট নির্বাচিত: {selectedIds.size} জন ব্যবহারকারী
                    </span>
                    <button
                      onClick={clearSelection}
                      className="text-[11px] text-slate-400 hover:text-white underline"
                    >
                      সিলেকশন বাতিল
                    </button>
                  </div>

                  {/* Bulk Role */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      রোল পরিবর্তন (ঐচ্ছিক)
                    </label>
                    <select
                      value={bulkRole}
                      onChange={(e) => setBulkRole(e.target.value as AppRole | "")}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white"
                    >
                      <option value="">(রোল অপরিবর্তিত রাখুন)</option>
                      <option value="admin">👑 Admin</option>
                      <option value="team_leader">🎯 Team Leader</option>
                      <option value="user">👤 User</option>
                    </select>
                  </div>

                  {/* Bulk Factory */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      কারখানা / ফ্যাক্টরি অ্যাসাইন (ঐচ্ছিক)
                    </label>
                    <select
                      value={bulkFactory}
                      onChange={(e) => setBulkFactory(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white"
                    >
                      <option value="__keep__">(ফ্যাক্টরি অপরিবর্তিত রাখুন)</option>
                      <option value="">(ফ্যাক্টরি রিমুভ করুন)</option>
                      {(factories.data ?? []).map((f) => (
                        <option key={f.id} value={f.id}>
                          🏢 {f.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Bulk Team Leader */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      টিম লিডার অ্যাসাইন (ঐচ্ছিক)
                    </label>
                    <select
                      value={bulkTL}
                      onChange={(e) => setBulkTL(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white"
                    >
                      <option value="__keep__">(টিম লিডার অপরিবর্তিত রাখুন)</option>
                      <option value="">(টিম লিডার রিমুভ করুন)</option>
                      {teamLeadersList.map((tl) => (
                        <option key={tl.id} value={tl.id}>
                          🎯 {tl.username} (
                          {factoryMap.get(tl.factory_id ?? "") ?? "ফ্যাক্টরি ছাড়া"})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Bulk Permission Preset */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      কাজের পারমিশন টেমপ্লেট প্রয়োগ (ঐচ্ছিক)
                    </label>
                    <select
                      value={bulkPreset}
                      onChange={(e) => setBulkPreset(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white"
                    >
                      <option value="__keep__">(পারমিশন অপরিবর্তিত রাখুন)</option>
                      {(Object.keys(PERMISSION_PRESETS) as PermissionPresetKey[]).map((pkey) => (
                        <option key={pkey} value={pkey}>
                          {PERMISSION_PRESETS[pkey].label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    onClick={handleRunBulk}
                    disabled={bulkBusy}
                    className="w-full py-3 rounded-2xl text-xs font-extrabold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white transition shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 disabled:opacity-50 mt-4"
                  >
                    {bulkBusy ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                    <span>{selectedIds.size} জনে পরিবর্তন প্রয়োগ করুন</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* ================= MODAL: INDIVIDUAL PERMISSION POPUP ================= */}
        {permTargetUser && activeTab !== "permissions" && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
            <div className="relative w-full max-w-2xl rounded-3xl border border-purple-500/40 bg-slate-950 p-6 text-white shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-purple-600/30 text-purple-300">
                    <Sliders className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                      কাজের পারমিশন নিয়ন্ত্রণ: {permTargetUser.username}
                      <span className="text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded">
                        {permTargetUser.role.toUpperCase()}
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      {factoryMap.get(permTargetUser.factory_id ?? "")
                        ? `ফ্যাক্টরি: ${factoryMap.get(permTargetUser.factory_id ?? "")}`
                        : "ফ্যাক্টরি নির্ধারণ করা হয়নি"}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setPermTargetUser(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Master Grant / Revoke Controls */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/50 via-indigo-950/40 to-slate-900 border border-purple-500/40 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-purple-600/30 text-amber-300">
                    <Crown className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-black text-purple-200 flex items-center gap-1.5">
                      <span>সুপার অ্যাডমিন পারমিশন</span>
                      {permTargetUser.is_super_admin && (
                        <span className="px-1.5 py-0.2 rounded text-[10px] bg-purple-500/30 text-purple-200 border border-purple-400/40">
                          সক্রিয়
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {permTargetUser.is_super_admin
                        ? "এই ব্যবহারকারী সুপার অ্যাডমিন। চাইলে পারমিশন বাতিল করতে পারেন।"
                        : "যেকোনো ব্যবহারকারীকে সুপার অ্যাডমিন পারমিশন দিন বা রিমুভ করুন।"}
                    </div>
                  </div>
                </div>

                {permTargetUser.is_super_admin ? (
                  <button
                    type="button"
                    onClick={() => {
                      revokeSuperMutation.mutate({
                        userId: permTargetUser.id,
                        newRole: permTargetUser.role,
                      });
                      setPermTargetUser((prev) =>
                        prev ? { ...prev, is_super_admin: false } : null,
                      );
                    }}
                    disabled={revokeSuperMutation.isPending}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-600/30 hover:bg-amber-600/50 text-amber-200 border border-amber-500/40 transition flex items-center gap-1.5"
                  >
                    <ShieldOff className="w-3.5 h-3.5" />
                    <span>সুপার অ্যাডমিন বাতিল করুন</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      grantSuperMutation.mutate(permTargetUser.id);
                      setPermTargetUser((prev) =>
                        prev ? { ...prev, is_super_admin: true } : null,
                      );
                    }}
                    disabled={grantSuperMutation.isPending}
                    className="px-3 py-1.5 rounded-xl text-xs font-black bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/30 transition flex items-center gap-1.5"
                  >
                    <Crown className="w-3.5 h-3.5 text-amber-300" />
                    <span>👑 সুপার অ্যাডমিন বানান</span>
                  </button>
                )}
              </div>

              {/* Master Grant / Revoke Controls */}
              <div className="bg-slate-900/90 p-3.5 rounded-2xl border border-indigo-500/30 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-bold text-white block">দ্রুত অনুমতি অ্যাকশন:</span>
                  <span className="text-[11px] text-slate-400">
                    সক্রিয়: {Object.values(activeUserPerms).filter(Boolean).length}/
                    {WORK_PERMISSIONS_LIST.length}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={grantAllPermissions}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/40 transition"
                  >
                    <CheckSquare className="w-3.5 h-3.5" />
                    <span>সব অনুমতি দিন</span>
                  </button>

                  <button
                    type="button"
                    onClick={revokeAllPermissions}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 border border-rose-500/40 transition"
                  >
                    <ShieldOff className="w-3.5 h-3.5" />
                    <span>সব প্রত্যাহার করুন</span>
                  </button>
                </div>
              </div>

              {/* 1-Click Preset Bar */}
              <div className="bg-slate-900/60 p-3 rounded-2xl border border-slate-800 space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 block">
                  টেমপ্লেট নির্বাচন করুন (১-ক্লিক):
                </span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {(Object.keys(PERMISSION_PRESETS) as PermissionPresetKey[]).map((pkey) => (
                    <button
                      key={pkey}
                      type="button"
                      onClick={() => applyPresetToActivePerms(pkey)}
                      className="px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                    >
                      {PERMISSION_PRESETS[pkey].label.split(" ")[0]}{" "}
                      {PERMISSION_PRESETS[pkey].label.split(" ")[1]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Categorized Checkbox List */}
              <div className="space-y-3">
                {PERMISSION_CATEGORIES.map((cat) => {
                  const perms = WORK_PERMISSIONS_LIST.filter((p) => p.category === cat.id);
                  return (
                    <div
                      key={cat.id}
                      className="rounded-2xl border border-slate-800 bg-slate-900/40 p-3.5 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>{cat.label}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              const next = { ...activeUserPerms };
                              perms.forEach((p) => (next[p.key] = true));
                              setActiveUserPerms(next);
                            }}
                            className="text-[10px] text-emerald-400 hover:underline"
                          >
                            +অনুমোদন
                          </button>
                          <span className="text-slate-600">•</span>
                          <button
                            type="button"
                            onClick={() => {
                              const next = { ...activeUserPerms };
                              perms.forEach((p) => (next[p.key] = false));
                              setActiveUserPerms(next);
                            }}
                            className="text-[10px] text-rose-400 hover:underline"
                          >
                            -প্রত্যাহার
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {perms.map((p) => {
                          const checked = !!activeUserPerms[p.key];
                          return (
                            <div
                              key={p.key}
                              onClick={() =>
                                setActiveUserPerms((prev) => ({
                                  ...prev,
                                  [p.key]: !checked,
                                }))
                              }
                              className={`flex items-start justify-between gap-2.5 p-2 rounded-xl border text-xs cursor-pointer select-none transition ${
                                checked
                                  ? "bg-indigo-950/40 border-indigo-500/40 text-white"
                                  : "bg-slate-950/40 border-slate-800 text-slate-400"
                              }`}
                            >
                              <div className="flex items-start gap-2 min-w-0">
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  onChange={() => {}}
                                  className="mt-0.5 rounded border-slate-700 text-indigo-600 focus:ring-0 shrink-0"
                                />
                                <div className="min-w-0">
                                  <div className="font-semibold leading-tight">{p.label}</div>
                                  <div className="text-[10px] text-slate-500 leading-tight">
                                    {p.description}
                                  </div>
                                </div>
                              </div>

                              <span
                                className={`shrink-0 px-1.5 py-0.2 rounded text-[9px] font-extrabold border ${
                                  checked
                                    ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
                                    : "bg-rose-500/10 text-rose-400 border-rose-500/20"
                                }`}
                              >
                                {checked ? "সক্রিয়" : "রিমুভড"}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setPermTargetUser(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={handleSavePermissions}
                  disabled={savingPerms}
                  className="inline-flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition shadow-md shadow-emerald-600/30 disabled:opacity-50"
                >
                  {savingPerms ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Check className="w-4 h-4" />
                  )}
                  <span>পারমিশন সংরক্ষণ করুন</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ================= MODAL: PASSWORD RESET ================= */}
        {passwordModalUser && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <div className="relative w-full max-w-md rounded-3xl border border-amber-500/40 bg-slate-950 p-6 text-white shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300">
                    <Key className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-white">পাসওয়ার্ড রিসেট করুন</h3>
                    <p className="text-xs text-slate-400">{passwordModalUser.username}</p>
                  </div>
                </div>
                <button
                  onClick={() => setPasswordModalUser(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  নতুন পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)
                </label>
                <input
                  type="password"
                  value={newResetPassword}
                  onChange={(e) => setNewResetPassword(e.target.value)}
                  placeholder="নতুন পাসওয়ার্ড লিখুন..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => setPasswordModalUser(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 text-slate-300"
                >
                  বাতিল
                </button>
                <button
                  onClick={() => {
                    if (newResetPassword.length < 6) {
                      toast.error("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।");
                      return;
                    }
                    resetPass.mutate({ id: passwordModalUser.id, pw: newResetPassword });
                  }}
                  disabled={resetPass.isPending}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-500 text-white transition flex items-center gap-2"
                >
                  {resetPass.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>রিসেট নিশ্চিত করুন</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
