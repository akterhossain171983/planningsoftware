ALTER TABLE public.plans ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ NULL;
CREATE INDEX IF NOT EXISTS plans_completed_at_idx ON public.plans (completed_at);