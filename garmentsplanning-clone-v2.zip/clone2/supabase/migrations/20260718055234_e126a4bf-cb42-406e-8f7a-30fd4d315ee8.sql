
DROP POLICY IF EXISTS "Auth users can view production updates" ON public.production_updates;
DROP POLICY IF EXISTS "Auth users can insert production updates" ON public.production_updates;
DROP POLICY IF EXISTS "Auth users can update production updates" ON public.production_updates;
DROP POLICY IF EXISTS "Auth users can delete production updates" ON public.production_updates;

CREATE POLICY "prod updates select own or admin" ON public.production_updates
FOR SELECT USING (
  public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.plans p WHERE p.id = production_updates.plan_id AND p.created_by = auth.uid())
);

CREATE POLICY "prod updates insert own or admin" ON public.production_updates
FOR INSERT WITH CHECK (
  auth.uid() = created_by AND (
    public.has_role(auth.uid(), 'admin')
    OR EXISTS (SELECT 1 FROM public.plans p WHERE p.id = production_updates.plan_id AND p.created_by = auth.uid())
  )
);

CREATE POLICY "prod updates update own or admin" ON public.production_updates
FOR UPDATE USING (
  public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.plans p WHERE p.id = production_updates.plan_id AND p.created_by = auth.uid())
) WITH CHECK (
  public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.plans p WHERE p.id = production_updates.plan_id AND p.created_by = auth.uid())
);

CREATE POLICY "prod updates delete own or admin" ON public.production_updates
FOR DELETE USING (
  public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.plans p WHERE p.id = production_updates.plan_id AND p.created_by = auth.uid())
);
