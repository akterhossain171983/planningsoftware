
-- 1) Add explicit INSERT policy on profiles (self-only), complementing the trigger
CREATE POLICY "profiles self insert"
ON public.profiles
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

-- 2) Restrict system_settings SELECT to authenticated only (remove anon exposure)
DROP POLICY IF EXISTS "system_settings readable" ON public.system_settings;
CREATE POLICY "system_settings readable authenticated"
ON public.system_settings
FOR SELECT
TO authenticated
USING (true);
REVOKE SELECT ON public.system_settings FROM anon;

-- 3) Lock down SECURITY DEFINER trigger function so end users cannot invoke it via PostgREST.
--    handle_new_user is only meant to run from the auth.users trigger.
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- same_team is a SECURITY DEFINER helper used inside RLS policies. Keep it callable by
-- authenticated (RLS needs EXECUTE) but revoke from anon and PUBLIC to reduce exposure.
REVOKE EXECUTE ON FUNCTION public.same_team(uuid, uuid) FROM PUBLIC, anon;
