REVOKE EXECUTE ON FUNCTION public.same_team(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.same_team(uuid, uuid) TO authenticated;