
CREATE TABLE public.plan_revisions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  plan_id UUID NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,
  revision_no INTEGER NOT NULL,
  buyer TEXT,
  style TEXT,
  finish_date TEXT,
  lines JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (plan_id, revision_no)
);

CREATE INDEX plan_revisions_plan_id_idx ON public.plan_revisions(plan_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.plan_revisions TO authenticated;
GRANT ALL ON public.plan_revisions TO service_role;

ALTER TABLE public.plan_revisions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "team can view plan revisions"
ON public.plan_revisions FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.plans p
    WHERE p.id = plan_revisions.plan_id
      AND (
        p.created_by = auth.uid()
        OR public.has_role(auth.uid(), 'admin')
        OR public.same_team(auth.uid(), p.created_by)
      )
  )
);

CREATE POLICY "team can insert plan revisions"
ON public.plan_revisions FOR INSERT
TO authenticated
WITH CHECK (
  created_by = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.plans p
    WHERE p.id = plan_revisions.plan_id
      AND (
        p.created_by = auth.uid()
        OR public.has_role(auth.uid(), 'admin')
        OR public.same_team(auth.uid(), p.created_by)
      )
  )
);

CREATE POLICY "admin can delete plan revisions"
ON public.plan_revisions FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));
