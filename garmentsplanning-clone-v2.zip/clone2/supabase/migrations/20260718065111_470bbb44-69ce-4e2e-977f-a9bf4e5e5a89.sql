
-- 1. factories table
CREATE TABLE public.factories (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.factories TO authenticated;
GRANT ALL ON public.factories TO service_role;

ALTER TABLE public.factories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view factories"
  ON public.factories FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins manage factories insert"
  ON public.factories FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins manage factories update"
  ON public.factories FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins manage factories delete"
  ON public.factories FOR DELETE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER factories_set_updated_at
  BEFORE UPDATE ON public.factories
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- 2. Add factory_id to profiles
ALTER TABLE public.profiles
  ADD COLUMN factory_id uuid REFERENCES public.factories(id) ON DELETE SET NULL;

CREATE INDEX profiles_factory_id_idx ON public.profiles(factory_id);

-- 3. Update same_team to also treat same factory as same team
CREATE OR REPLACE FUNCTION public.same_team(_a uuid, _b uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    _a = _b
    OR public.has_role(_a, 'admin')
    OR EXISTS (
      SELECT 1 FROM public.profiles pa, public.profiles pb
      WHERE pa.id = _a AND pb.id = _b
        AND (
          -- same factory
          (pa.factory_id IS NOT NULL AND pa.factory_id = pb.factory_id)
          -- same team leader
          OR (pa.team_leader_id IS NOT NULL AND pa.team_leader_id = pb.team_leader_id)
          -- a is team leader of b
          OR pb.team_leader_id = pa.id
          -- b is team leader of a
          OR pa.team_leader_id = pb.id
        )
    )
$$;
