
-- Drop redundant permissive policies on production_updates
DROP POLICY IF EXISTS pu_select ON public.production_updates;
DROP POLICY IF EXISTS pu_insert ON public.production_updates;
DROP POLICY IF EXISTS pu_update ON public.production_updates;
DROP POLICY IF EXISTS pu_delete ON public.production_updates;

-- Consolidate plans policies: drop broader team_leader-only ones, keep team/factory-scoped
DROP POLICY IF EXISTS plans_select ON public.plans;
DROP POLICY IF EXISTS plans_update ON public.plans;
DROP POLICY IF EXISTS plans_delete ON public.plans;
DROP POLICY IF EXISTS plans_insert ON public.plans;

-- Revoke anon/public execute on internal SECURITY DEFINER trigger function
REVOKE ALL ON FUNCTION public.plans_set_team_leader_id() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.plans_set_team_leader_id() FROM anon;
REVOKE ALL ON FUNCTION public.plans_set_team_leader_id() FROM authenticated;
