-- Standardize entry_date to be NOT NULL with default today
ALTER TABLE public.budget_line_details ALTER COLUMN entry_date SET DEFAULT CURRENT_DATE;
UPDATE public.budget_line_details SET entry_date = CURRENT_DATE WHERE entry_date IS NULL;
ALTER TABLE public.budget_line_details ALTER COLUMN entry_date SET NOT NULL;

-- Standardize budget_department_details as well
ALTER TABLE public.budget_department_details ALTER COLUMN entry_date SET DEFAULT CURRENT_DATE;
UPDATE public.budget_department_details SET entry_date = CURRENT_DATE WHERE entry_date IS NULL;
ALTER TABLE public.budget_department_details ALTER COLUMN entry_date SET NOT NULL;

-- Re-verify or Create Unique Constraints to ensure upsert works correctly
ALTER TABLE public.budget_line_details DROP CONSTRAINT IF EXISTS budget_line_details_factory_id_month_line_name_cost_head_en_key;
ALTER TABLE public.budget_line_details ADD CONSTRAINT budget_line_details_factory_id_month_line_name_cost_head_en_key UNIQUE (factory_id, month, line_name, cost_head, entry_date);

ALTER TABLE public.budget_department_details DROP CONSTRAINT IF EXISTS budget_department_details_factory_id_month_department_cost_he_key;
ALTER TABLE public.budget_department_details ADD CONSTRAINT budget_department_details_factory_id_month_department_cost_he_key UNIQUE (factory_id, month, department, cost_head, entry_date);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_line_details TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_department_details TO authenticated;
GRANT ALL ON public.budget_line_details TO service_role;
GRANT ALL ON public.budget_department_details TO service_role;
