CREATE TABLE public.production_updates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  plan_id UUID NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,
  line_name TEXT NOT NULL,
  update_date DATE NOT NULL,
  actual_qty INTEGER NOT NULL DEFAULT 0,
  remarks TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (plan_id, line_name, update_date)
);

CREATE INDEX idx_prod_updates_date ON public.production_updates(update_date);
CREATE INDEX idx_prod_updates_plan ON public.production_updates(plan_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.production_updates TO authenticated;
GRANT ALL ON public.production_updates TO service_role;

ALTER TABLE public.production_updates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Auth users can view production updates"
  ON public.production_updates FOR SELECT TO authenticated USING (true);

CREATE POLICY "Auth users can insert production updates"
  ON public.production_updates FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Auth users can update production updates"
  ON public.production_updates FOR UPDATE TO authenticated
  USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Auth users can delete production updates"
  ON public.production_updates FOR DELETE TO authenticated
  USING (auth.uid() IS NOT NULL);

CREATE TRIGGER trg_prod_updates_updated_at
  BEFORE UPDATE ON public.production_updates
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();