CREATE TABLE IF NOT EXISTS public.budget_line_details (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    factory_id uuid NOT NULL REFERENCES public.factories(id),
    month date NOT NULL,
    line_name text NOT NULL,
    cost_head text NOT NULL,
    budget_value numeric DEFAULT 0,
    actual_value numeric DEFAULT 0,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    UNIQUE(factory_id, month, line_name, cost_head)
);

CREATE TABLE IF NOT EXISTS public.budget_department_details (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    factory_id uuid NOT NULL REFERENCES public.factories(id),
    month date NOT NULL,
    department text NOT NULL, -- 'Cutting', 'Finishing', etc.
    cost_head text NOT NULL,
    budget_value numeric DEFAULT 0,
    actual_value numeric DEFAULT 0,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    UNIQUE(factory_id, month, department, cost_head)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_line_details TO authenticated;
GRANT ALL ON public.budget_line_details TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_department_details TO authenticated;
GRANT ALL ON public.budget_department_details TO service_role;

ALTER TABLE public.budget_line_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budget_department_details ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Manage factory budget line details" ON public.budget_line_details
    FOR ALL TO authenticated
    USING ((SELECT factory_id FROM public.profiles WHERE id = auth.uid()) = factory_id)
    WITH CHECK ((SELECT factory_id FROM public.profiles WHERE id = auth.uid()) = factory_id);

CREATE POLICY "Manage factory budget dept details" ON public.budget_department_details
    FOR ALL TO authenticated
    USING ((SELECT factory_id FROM public.profiles WHERE id = auth.uid()) = factory_id)
    WITH CHECK ((SELECT factory_id FROM public.profiles WHERE id = auth.uid()) = factory_id);
