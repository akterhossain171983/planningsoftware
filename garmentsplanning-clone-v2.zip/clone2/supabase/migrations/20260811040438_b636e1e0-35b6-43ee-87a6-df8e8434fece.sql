
CREATE TABLE IF NOT EXISTS public.monthly_budgets (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    factory_id uuid NOT NULL REFERENCES public.factories(id),
    month date NOT NULL,
    budget_amount numeric NOT NULL DEFAULT 0,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    UNIQUE(factory_id, month)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.monthly_budgets TO authenticated;
GRANT ALL ON public.monthly_budgets TO service_role;

ALTER TABLE public.monthly_budgets ENABLE ROW LEVEL SECURITY;

DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'monthly_budgets' AND policyname = 'Users can manage their factory budgets'
    ) THEN
        CREATE POLICY "Users can manage their factory budgets"
            ON public.monthly_budgets
            FOR ALL
            TO authenticated
            USING (
                (SELECT factory_id FROM public.profiles WHERE id = auth.uid()) = factory_id
            )
            WITH CHECK (
                (SELECT factory_id FROM public.profiles WHERE id = auth.uid()) = factory_id
            );
    END IF;
END $$;
