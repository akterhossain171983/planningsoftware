CREATE TABLE public.global_holidays (
  date DATE NOT NULL PRIMARY KEY,
  label TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.global_holidays TO authenticated;
GRANT ALL ON public.global_holidays TO service_role;
ALTER TABLE public.global_holidays ENABLE ROW LEVEL SECURITY;
CREATE POLICY "holidays readable to authenticated" ON public.global_holidays FOR SELECT TO authenticated USING (true);
CREATE POLICY "holidays admin insert" ON public.global_holidays FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "holidays admin update" ON public.global_holidays FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "holidays admin delete" ON public.global_holidays FOR DELETE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));