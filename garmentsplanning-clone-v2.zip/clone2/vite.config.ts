// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

function filterModuleDirectiveWarning(
  warning: { message?: string; code?: string } | string | unknown,
  defaultHandler?: (warning: unknown) => void,
) {
  const str =
    typeof warning === "string" ? warning : `${warning?.message || ""} ${warning?.code || ""}`;
  if (
    warning?.code === "MODULE_LEVEL_DIRECTIVE" ||
    str.includes("MODULE_LEVEL_DIRECTIVE") ||
    str.includes('"use client"') ||
    str.includes("module level directive")
  ) {
    return;
  }
  defaultHandler?.(warning);
}

const isNetlify = !!process.env.NETLIFY;
const nitroPreset = isNetlify ? "netlify" : process.env.NITRO_PRESET || "cloudflare-pages";

export default defineConfig({
  vite: {
    build: {
      rollupOptions: {
        onwarn: filterModuleDirectiveWarning,
      },
    },
  },
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  nitro: {
    preset: nitroPreset,
    rollupConfig: {
      onwarn: filterModuleDirectiveWarning,
    },
    ...(isNetlify
      ? {
          output: {
            dir: "dist",
            serverDir: "dist/server",
            publicDir: "dist/client",
          },
        }
      : {}),
  },
});
