//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B3Li5OXR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/app/applet/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth"
		],
		preloads: ["/assets/index-Uy4qQGQk.js", "/assets/react-Dgwpegte.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Uy4qQGQk.js"
		} }]
	},
	"/": {
		filePath: "/app/applet/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BUquMLcY.js"]
	},
	"/_authenticated": {
		filePath: "/app/applet/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/app"],
		preloads: ["/assets/route-cTo67Cv7.js"]
	},
	"/auth": {
		filePath: "/app/applet/src/routes/auth.tsx",
		children: void 0,
		preloads: ["/assets/auth-V4BfK_yv.js", "/assets/permissions.types-PJdk6A-1.js"]
	},
	"/_authenticated/app": {
		filePath: "/app/applet/src/routes/_authenticated/app.tsx",
		children: void 0,
		preloads: ["/assets/app-BBlQ5JqU.js", "/assets/permissions.types-PJdk6A-1.js"]
	}
} });
//#endregion
export { tsrStartManifest };
