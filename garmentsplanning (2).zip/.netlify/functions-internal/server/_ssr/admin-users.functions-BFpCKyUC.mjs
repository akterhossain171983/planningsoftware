import { r as createServerFn } from "./server-S2Zky892.mjs";
import { t as createServerRpc } from "./createServerRpc-BoQcNE_w.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CeXlgLRg.mjs";
import { a as getDefaultPermissionsForRole, o as isSuperAdminUser, r as SUPER_ADMIN_EMAIL } from "./permissions.types-yTTMt8IS.mjs";
import { a as objectType, n as booleanType, o as recordType, r as enumType, s as stringType, t as arrayType } from "../_libs/zod.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-users.functions-BFpCKyUC.js
var EMAIL_DOMAIN = "cloud-garments.local";
var getStorage = async () => import("./server-storage.server-K2YKSFeg.mjs");
async function assertAdmin(supabase, userId, claims) {
	const email = claims?.email;
	const username = claims?.user_metadata?.username;
	const { loadSuperAdminsFromDisk } = await getStorage();
	const superList = await loadSuperAdminsFromDisk();
	if (isSuperAdminUser(email, username, superList) || superList.includes(userId.toLowerCase()) || username && superList.includes(username.toLowerCase()) || email && superList.includes(email.toLowerCase())) {
		try {
			await supabase.from("user_roles").upsert({
				user_id: userId,
				role: "admin"
			}, { onConflict: "user_id,role" });
		} catch {}
		return;
	}
	try {
		const { data, error } = await supabase.rpc("has_role", {
			_user_id: userId,
			_role: "admin"
		});
		if (!error && data) return;
	} catch {}
	try {
		const { data: roleRow } = await supabase.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
		if (roleRow) return;
	} catch {}
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const { data: roleRowAdmin } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
	if (!roleRowAdmin) throw new Error("Forbidden: admin only.");
}
async function pickTopRole(supabase, userId) {
	const { data } = await supabase.from("user_roles").select("role").eq("user_id", userId);
	const set = new Set((data ?? []).map((r) => r.role));
	if (set.has("admin")) return "admin";
	if (set.has("team_leader")) return "team_leader";
	return "user";
}
var listAppUsers_createServerFn_handler = createServerRpc({
	id: "18a52846064de54c02432e991eea4ab62b183a1fc1a48d39461c93e573f06611",
	name: "listAppUsers",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => listAppUsers.__executeServer(opts));
var listAppUsers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listAppUsers_createServerFn_handler, async ({ context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { data: initialProfiles, error: pErr } = await context.supabase.from("profiles").select("id, username, active, created_at, team_leader_id, factory_id").order("created_at", { ascending: true });
	let profiles = initialProfiles;
	if (pErr || !profiles) {
		const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
		profiles = (await supabaseAdmin.from("profiles").select("id, username, active, created_at, team_leader_id, factory_id").order("created_at", { ascending: true })).data;
	}
	const { data: initialRoles, error: rErr } = await context.supabase.from("user_roles").select("user_id, role");
	let roles = initialRoles;
	if (rErr || !roles) {
		const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
		roles = (await supabaseAdmin.from("user_roles").select("user_id, role")).data;
	}
	const roleMap = /* @__PURE__ */ new Map();
	for (const r of roles ?? []) {
		const cur = roleMap.get(r.user_id);
		if (r.role === "admin") roleMap.set(r.user_id, "admin");
		else if (r.role === "team_leader" && cur !== "admin") roleMap.set(r.user_id, "team_leader");
		else if (!cur) roleMap.set(r.user_id, r.role);
	}
	const { loadPermissionsFromDisk, loadSuperAdminsFromDisk } = await getStorage();
	const [allSavedPerms, superAdminsList] = await Promise.all([loadPermissionsFromDisk(), loadSuperAdminsFromDisk()]);
	return (profiles ?? []).map((p) => {
		const isSuper = isSuperAdminUser(p.username, p.username, superAdminsList) || superAdminsList.includes(p.id.toLowerCase()) || superAdminsList.includes(p.username.toLowerCase());
		const effectiveRole = isSuper ? "admin" : roleMap.get(p.id) ?? "user";
		const defaultPerms = getDefaultPermissionsForRole(effectiveRole, isSuper);
		const userPerms = isSuper ? defaultPerms : {
			...defaultPerms,
			...allSavedPerms[p.id] ?? {}
		};
		return {
			id: p.id,
			username: p.username,
			active: p.active ?? true,
			role: effectiveRole,
			is_super_admin: isSuper,
			team_leader_id: p.team_leader_id,
			factory_id: p.factory_id,
			permissions: userPerms,
			created_at: p.created_at
		};
	});
});
var listFactories_createServerFn_handler = createServerRpc({
	id: "9636419b22391588b014a7bc6295e66d761f9ee36aea1d6649c878e92876a99f",
	name: "listFactories",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => listFactories.__executeServer(opts));
var listFactories = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listFactories_createServerFn_handler, async ({ context }) => {
	await assertAdmin(context.supabase, context.userId);
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const { data, error } = await supabaseAdmin.from("factories").select("id, name, created_at").order("name", { ascending: true });
	if (error) throw new Error(error.message);
	return data ?? [];
});
var factoryNameSchema = objectType({ name: stringType().trim().min(1).max(80) });
var createFactory_createServerFn_handler = createServerRpc({
	id: "f7e6fbaab4f039db853d0f526521051bdd3d6b13e2f9d962ea4cff7c7cce3dab",
	name: "createFactory",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => createFactory.__executeServer(opts));
var createFactory = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => factoryNameSchema.parse(d)).handler(createFactory_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId);
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const { data: row, error } = await supabaseAdmin.from("factories").insert({ name: data.name.trim() }).select("id, name").single();
	if (error) throw new Error(error.message);
	return row;
});
var renameFactorySchema = objectType({
	id: stringType().uuid(),
	name: stringType().trim().min(1).max(80)
});
var renameFactory_createServerFn_handler = createServerRpc({
	id: "85da37f4d0aa30a95b13b7dc15d0a4ad9c1636a5babf09829feb7f2bb07f22b2",
	name: "renameFactory",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => renameFactory.__executeServer(opts));
var renameFactory = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => renameFactorySchema.parse(d)).handler(renameFactory_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId);
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const { error } = await supabaseAdmin.from("factories").update({ name: data.name.trim() }).eq("id", data.id);
	if (error) throw new Error(error.message);
	return { ok: true };
});
var deleteFactorySchema = objectType({ id: stringType().uuid() });
var deleteFactory_createServerFn_handler = createServerRpc({
	id: "8d4e1dc5b8a652b7c9b3ba18fa85883d295daf1747f272fd2003b0788ab9ab15",
	name: "deleteFactory",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => deleteFactory.__executeServer(opts));
var deleteFactory = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => deleteFactorySchema.parse(d)).handler(deleteFactory_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId);
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	await supabaseAdmin.from("profiles").update({ factory_id: null }).eq("factory_id", data.id);
	await supabaseAdmin.from("plans").update({ factory_id: null }).eq("factory_id", data.id);
	const { error } = await supabaseAdmin.from("factories").delete().eq("id", data.id);
	if (error) throw new Error(error.message);
	return { ok: true };
});
var setUserFactorySchema = objectType({
	userId: stringType().uuid(),
	factoryId: stringType().uuid().nullable().optional()
});
var setUserFactory_createServerFn_handler = createServerRpc({
	id: "d4b88cf4bddd27f1685891c64234dcc5c60bb75fdd087fe29c4b5fd3ed525b08",
	name: "setUserFactory",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => setUserFactory.__executeServer(opts));
var setUserFactory = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => setUserFactorySchema.parse(d)).handler(setUserFactory_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId);
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const { error } = await supabaseAdmin.from("profiles").update({ factory_id: data.factoryId ?? null }).eq("id", data.userId);
	if (error) throw new Error(error.message);
	return { ok: true };
});
var createSchema = objectType({
	username: stringType().trim().min(2).max(50),
	password: stringType().min(6).max(200),
	role: enumType([
		"admin",
		"team_leader",
		"user"
	]),
	teamLeaderId: stringType().uuid().nullable().optional(),
	factoryId: stringType().uuid().nullable().optional(),
	permissions: recordType(booleanType()).optional()
});
var createAppUser_createServerFn_handler = createServerRpc({
	id: "7b8416df0fd9a1185a3b3b6c3d25ed708f1df63619f4a7ca60cd46eb64a2b574",
	name: "createAppUser",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => createAppUser.__executeServer(opts));
var createAppUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => createSchema.parse(data)).handler(createAppUser_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const username = data.username.trim().toLowerCase();
	const email = username.includes("@") ? username : `${username}@${EMAIL_DOMAIN}`;
	if (data.role === "user") {
		if (!data.teamLeaderId) throw new Error("User-এর জন্য Team Leader নির্বাচন করুন।");
		const tlRole = await pickTopRole(context.supabase, data.teamLeaderId);
		if (tlRole !== "team_leader" && tlRole !== "admin") throw new Error("নির্বাচিত ব্যবহারকারী Team Leader নন।");
	}
	let newUserId;
	try {
		const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
			email,
			password: data.password,
			email_confirm: true,
			user_metadata: { username }
		});
		if (error || !created?.user) throw error || /* @__PURE__ */ new Error("Admin createUser failed");
		newUserId = created.user.id;
	} catch {
		const { createClient } = await import("../_libs/supabase__supabase-js.mjs").then((n) => n.n);
		const { data: created, error } = await createClient(processModule.env.SUPABASE_URL || processModule.env.VITE_SUPABASE_URL || "https://pjkzraycfudmayxqdktk.supabase.co", processModule.env.SUPABASE_PUBLISHABLE_KEY || processModule.env.VITE_SUPABASE_PUBLISHABLE_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBqa3pyYXljZnVkbWF5eHFka3RrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODMwOTExNDIsImV4cCI6MjA5ODY2NzE0Mn0.y0wwzBOKFagR80Tn6U5LTcynygvU40T_4yR3xea5_LY", { auth: {
			persistSession: false,
			autoRefreshToken: false
		} }).auth.signUp({
			email,
			password: data.password,
			options: { data: { username } }
		});
		if (error || !created?.user) throw new Error(error?.message ?? "ব্যবহারকারী তৈরি ব্যর্থ হয়েছে।");
		newUserId = created.user.id;
	}
	try {
		await supabaseAdmin.from("user_roles").delete().eq("user_id", newUserId);
		await supabaseAdmin.from("user_roles").insert({
			user_id: newUserId,
			role: data.role
		});
	} catch {
		await context.supabase.from("user_roles").delete().eq("user_id", newUserId);
		await context.supabase.from("user_roles").insert({
			user_id: newUserId,
			role: data.role
		});
	}
	const profilePayload = {
		id: newUserId,
		username,
		active: true,
		team_leader_id: data.role === "user" ? data.teamLeaderId ?? null : null,
		factory_id: data.factoryId ?? null
	};
	try {
		await supabaseAdmin.from("profiles").upsert(profilePayload, { onConflict: "id" });
	} catch {
		await context.supabase.from("profiles").upsert(profilePayload, { onConflict: "id" });
	}
	const perms = data.permissions ?? getDefaultPermissionsForRole(data.role, isSuperAdminUser(email, username));
	const { loadPermissionsFromDisk, savePermissionsToDisk } = await getStorage();
	const diskPerms = await loadPermissionsFromDisk();
	diskPerms[newUserId] = perms;
	await savePermissionsToDisk(diskPerms);
	return {
		id: newUserId,
		username
	};
});
var deleteSchema = objectType({ userId: stringType().uuid() });
var deleteAppUser_createServerFn_handler = createServerRpc({
	id: "5cae714715f87171e2dbb8b1145a1dc86bf08436993e0fe73a425c03bd929f59",
	name: "deleteAppUser",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => deleteAppUser.__executeServer(opts));
var deleteAppUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => deleteSchema.parse(data)).handler(deleteAppUser_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	if (data.userId === context.userId) throw new Error("নিজেকে ডিলিট করা যাবে না।");
	const { data: targetProf } = await context.supabase.from("profiles").select("username").eq("id", data.userId).maybeSingle();
	const uname = (targetProf?.username ?? "").toLowerCase();
	if (uname === "akterplanning83" || uname === "akterplanning83@gmail.com".toLowerCase()) throw new Error("মূল সুপার অ্যাডমিন (akterplanning83)-কে ডিলিট করা সম্ভব নয়।");
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	await supabaseAdmin.from("profiles").update({ team_leader_id: null }).eq("team_leader_id", data.userId);
	await supabaseAdmin.from("plans").update({ created_by: context.userId }).eq("created_by", data.userId);
	await supabaseAdmin.from("plans").update({ team_leader_id: null }).eq("team_leader_id", data.userId);
	await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
	await supabaseAdmin.from("profiles").delete().eq("id", data.userId);
	const { loadPermissionsFromDisk, savePermissionsToDisk } = await getStorage();
	const diskPerms = await loadPermissionsFromDisk();
	delete diskPerms[data.userId];
	await savePermissionsToDisk(diskPerms);
	try {
		await supabaseAdmin.auth.admin.deleteUser(data.userId);
	} catch {}
	return { ok: true };
});
var resetSchema = objectType({
	userId: stringType().uuid(),
	password: stringType().min(6).max(200)
});
var resetAppUserPassword_createServerFn_handler = createServerRpc({
	id: "2eab00679a8a6a8dd53206af181dc86636c542b86a43b5bde7b6ca8e1956a26e",
	name: "resetAppUserPassword",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => resetAppUserPassword.__executeServer(opts));
var resetAppUserPassword = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => resetSchema.parse(data)).handler(resetAppUserPassword_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const { error } = await supabaseAdmin.auth.admin.updateUserById(data.userId, { password: data.password });
	if (error) throw new Error(error.message);
	return { ok: true };
});
var setUserActiveSchema = objectType({
	userId: stringType().uuid(),
	active: booleanType()
});
var setUserActive_createServerFn_handler = createServerRpc({
	id: "61fcbe9805f4b336d92b0e82169e045de44ff3572c349ad0e481cf7ba2f61396",
	name: "setUserActive",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => setUserActive.__executeServer(opts));
var setUserActive = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => setUserActiveSchema.parse(data)).handler(setUserActive_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	if (data.userId === context.userId) throw new Error("নিজের অ্যাক্টিভ স্ট্যাটাস পরিবর্তন করা যাবে না।");
	const { data: targetProf } = await context.supabase.from("profiles").select("username").eq("id", data.userId).maybeSingle();
	const uname = (targetProf?.username ?? "").toLowerCase();
	if (uname === "akterplanning83" || uname === "akterplanning83@gmail.com".toLowerCase()) throw new Error("মূল সুপার অ্যাডমিনকে ব্লক করা যাবে না।");
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const { error } = await supabaseAdmin.from("profiles").update({ active: data.active }).eq("id", data.userId);
	if (error) throw new Error(error.message);
	return { ok: true };
});
var setSystemLockSchema = objectType({ locked: booleanType() });
var setSystemLocked_createServerFn_handler = createServerRpc({
	id: "4f8adcd3205bf7b085f9a31353b16377d09eeb3cd4dd773a2437a645e94b74f0",
	name: "setSystemLocked",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => setSystemLocked.__executeServer(opts));
var setSystemLocked = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => setSystemLockSchema.parse(data)).handler(setSystemLocked_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const { error } = await supabaseAdmin.from("system_settings").upsert({
		id: 1,
		locked: data.locked
	}, { onConflict: "id" });
	if (error) throw new Error(error.message);
	return {
		ok: true,
		locked: data.locked
	};
});
var setRoleSchema = objectType({
	userId: stringType().uuid(),
	role: enumType([
		"admin",
		"team_leader",
		"user"
	])
});
var setAppUserRole_createServerFn_handler = createServerRpc({
	id: "cb8b6193b3bc81d94c8575847f2f40de07a38b1c06e9899305672121b60d9ad6",
	name: "setAppUserRole",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => setAppUserRole.__executeServer(opts));
var setAppUserRole = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => setRoleSchema.parse(data)).handler(setAppUserRole_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { data: targetProf } = await context.supabase.from("profiles").select("username").eq("id", data.userId).maybeSingle();
	const uname = (targetProf?.username ?? "").toLowerCase();
	if ((uname === "akterplanning83" || uname === "akterplanning83@gmail.com".toLowerCase()) && data.role !== "admin") throw new Error("মূল সুপার অ্যাডমিনের রোল পরিবর্তন করা যাবে না।");
	if (data.userId === context.userId && data.role !== "admin") throw new Error("নিজের অ্যাডমিন রোল সরানো যাবে না।");
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	if (data.role !== "admin") {
		const { loadSuperAdminsFromDisk, saveSuperAdminsToDisk } = await getStorage();
		await saveSuperAdminsToDisk((await loadSuperAdminsFromDisk()).filter((s) => s.toLowerCase() !== data.userId.toLowerCase() && s.toLowerCase() !== uname));
	}
	await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
	const { error } = await supabaseAdmin.from("user_roles").insert({
		user_id: data.userId,
		role: data.role
	});
	if (error) throw new Error(error.message);
	if (data.role !== "user") await supabaseAdmin.from("profiles").update({ team_leader_id: null }).eq("id", data.userId);
	if (data.role !== "team_leader" && data.role !== "admin") await supabaseAdmin.from("profiles").update({ team_leader_id: null }).eq("team_leader_id", data.userId);
	return { ok: true };
});
var setTeamLeaderSchema = objectType({
	userId: stringType().uuid(),
	teamLeaderId: stringType().uuid().nullable().optional()
});
var setUserTeamLeader_createServerFn_handler = createServerRpc({
	id: "36c63908ce9eb5ca6debfc89e1bb1ffed0036afc284cfc0f0379ebc9214a2dde",
	name: "setUserTeamLeader",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => setUserTeamLeader.__executeServer(opts));
var setUserTeamLeader = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => setTeamLeaderSchema.parse(data)).handler(setUserTeamLeader_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	if (data.userId === data.teamLeaderId) throw new Error("একজন ব্যবহারকারী নিজেই নিজের Team Leader হতে পারবেন না।");
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	if (data.teamLeaderId) {
		const tlRole = await pickTopRole(context.supabase, data.teamLeaderId);
		if (tlRole !== "team_leader" && tlRole !== "admin") throw new Error("নির্বাচিত ব্যবহারকারী Team Leader নন।");
	}
	const { error } = await supabaseAdmin.from("profiles").update({ team_leader_id: data.teamLeaderId ?? null }).eq("id", data.userId);
	if (error) throw new Error(error.message);
	return { ok: true };
});
var savePermissionsSchema = objectType({
	userId: stringType().uuid(),
	permissions: recordType(booleanType())
});
var saveUserPermissions_createServerFn_handler = createServerRpc({
	id: "e372b66494e731b46c162f049970423a3ff195b56345e2ccce24acd0e72c5cfb",
	name: "saveUserPermissions",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => saveUserPermissions.__executeServer(opts));
var saveUserPermissions = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => savePermissionsSchema.parse(data)).handler(saveUserPermissions_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { data: targetProf } = await context.supabase.from("profiles").select("username").eq("id", data.userId).maybeSingle();
	if (isSuperAdminUser(targetProf?.username, targetProf?.username)) throw new Error("সুপার অ্যাডমিনের পারমিশন সর্বদা শতভাগ উন্মুক্ত।");
	const { loadPermissionsFromDisk, savePermissionsToDisk } = await getStorage();
	const diskPerms = await loadPermissionsFromDisk();
	diskPerms[data.userId] = data.permissions;
	await savePermissionsToDisk(diskPerms);
	return {
		ok: true,
		permissions: data.permissions
	};
});
var getUserPermissions_createServerFn_handler = createServerRpc({
	id: "cfd27464f7213d12e4633b981cf4e536982746b350838a8835ca9a75a8b759d9",
	name: "getUserPermissions",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => getUserPermissions.__executeServer(opts));
var getUserPermissions = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getUserPermissions_createServerFn_handler, async ({ context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { loadPermissionsFromDisk } = await getStorage();
	return loadPermissionsFromDisk();
});
var bulkPermissionsSchema = objectType({
	userIds: arrayType(stringType().uuid()),
	permissions: recordType(booleanType())
});
var applyBulkPermissions_createServerFn_handler = createServerRpc({
	id: "96378a346f39685bfd7e8d85edfc41f442020b39e0e7d028a8861f94789aa44f",
	name: "applyBulkPermissions",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => applyBulkPermissions.__executeServer(opts));
var applyBulkPermissions = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => bulkPermissionsSchema.parse(data)).handler(applyBulkPermissions_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { loadPermissionsFromDisk, savePermissionsToDisk } = await getStorage();
	const diskPerms = await loadPermissionsFromDisk();
	for (const uid of data.userIds) diskPerms[uid] = { ...data.permissions };
	await savePermissionsToDisk(diskPerms);
	return {
		ok: true,
		count: data.userIds.length
	};
});
var grantSuperAdminSchema = objectType({ userId: stringType().uuid() });
var grantSuperAdmin_createServerFn_handler = createServerRpc({
	id: "a745fe204a5182b1292e93ad4cc22e3392beee2b0c8b3cdfbb9f61b66ce50bf7",
	name: "grantSuperAdmin",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => grantSuperAdmin.__executeServer(opts));
var grantSuperAdmin = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => grantSuperAdminSchema.parse(data)).handler(grantSuperAdmin_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const { data: prof } = await context.supabase.from("profiles").select("username").eq("id", data.userId).maybeSingle();
	const username = prof?.username ?? data.userId;
	const { loadSuperAdminsFromDisk, saveSuperAdminsToDisk, loadPermissionsFromDisk, savePermissionsToDisk } = await getStorage();
	const list = await loadSuperAdminsFromDisk();
	const set = new Set(list.map((s) => s.toLowerCase()));
	set.add(data.userId.toLowerCase());
	if (prof?.username) set.add(prof.username.toLowerCase());
	await saveSuperAdminsToDisk(Array.from(set));
	try {
		await supabaseAdmin.from("user_roles").upsert({
			user_id: data.userId,
			role: "admin"
		}, { onConflict: "user_id,role" });
	} catch {
		await context.supabase.from("user_roles").upsert({
			user_id: data.userId,
			role: "admin"
		}, { onConflict: "user_id,role" });
	}
	const diskPerms = await loadPermissionsFromDisk();
	const { PERMISSION_PRESETS } = await import("./permissions.types-yTTMt8IS.mjs").then((n) => n.s).then((n) => n.s);
	diskPerms[data.userId] = { ...PERMISSION_PRESETS.super_admin.permissions };
	await savePermissionsToDisk(diskPerms);
	return {
		ok: true,
		userId: data.userId,
		username,
		is_super_admin: true
	};
});
var revokeSuperAdminSchema = objectType({
	userId: stringType().uuid(),
	newRole: enumType([
		"admin",
		"team_leader",
		"user"
	]).optional().default("admin")
});
var revokeSuperAdmin_createServerFn_handler = createServerRpc({
	id: "e938db4db223ff52875f2e06d54ab8346afb886c092b47887617000e173749b3",
	name: "revokeSuperAdmin",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => revokeSuperAdmin.__executeServer(opts));
var revokeSuperAdmin = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => revokeSuperAdminSchema.parse(data)).handler(revokeSuperAdmin_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { supabaseAdmin } = await import("./client.server-CeyIYN9A.mjs");
	const { data: prof } = await context.supabase.from("profiles").select("username").eq("id", data.userId).maybeSingle();
	const username = (prof?.username ?? "").toLowerCase();
	if ((username === "akterplanning83" || username === "akterplanning83@gmail.com".toLowerCase()) && context.userId !== data.userId) throw new Error("মূল সুপার অ্যাডমিন (akterplanning83)-কে পরিবর্তন করা যাবে না।");
	const { loadSuperAdminsFromDisk, writeSuperAdminsDirect, loadPermissionsFromDisk, savePermissionsToDisk } = await getStorage();
	const filtered = (await loadSuperAdminsFromDisk()).filter((s) => s.toLowerCase() !== data.userId.toLowerCase() && s.toLowerCase() !== username);
	const set = new Set(filtered.map((s) => s.toLowerCase().trim()));
	if (username !== "akterplanning83" && username !== "akterplanning83@gmail.com".toLowerCase()) {
		set.add(SUPER_ADMIN_EMAIL.toLowerCase());
		set.add("akterplanning83");
	}
	await writeSuperAdminsDirect(Array.from(set));
	if (data.newRole) try {
		await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
		await supabaseAdmin.from("user_roles").insert({
			user_id: data.userId,
			role: data.newRole
		});
	} catch {
		await context.supabase.from("user_roles").delete().eq("user_id", data.userId);
		await context.supabase.from("user_roles").insert({
			user_id: data.userId,
			role: data.newRole
		});
	}
	const diskPerms = await loadPermissionsFromDisk();
	diskPerms[data.userId] = getDefaultPermissionsForRole(data.newRole || "admin", false);
	await savePermissionsToDisk(diskPerms);
	return {
		ok: true,
		userId: data.userId,
		username: prof?.username,
		is_super_admin: false,
		role: data.newRole
	};
});
var listSuperAdmins_createServerFn_handler = createServerRpc({
	id: "529cd09f0f96d3a875576da6dcb8f8db48e5a5c305ff21f2a6e17176ce60d271",
	name: "listSuperAdmins",
	filename: "src/lib/admin-users.functions.ts"
}, (opts) => listSuperAdmins.__executeServer(opts));
var listSuperAdmins = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listSuperAdmins_createServerFn_handler, async ({ context }) => {
	await assertAdmin(context.supabase, context.userId, context.claims);
	const { loadSuperAdminsFromDisk } = await getStorage();
	return loadSuperAdminsFromDisk();
});
//#endregion
export { applyBulkPermissions_createServerFn_handler, createAppUser_createServerFn_handler, createFactory_createServerFn_handler, deleteAppUser_createServerFn_handler, deleteFactory_createServerFn_handler, getUserPermissions_createServerFn_handler, grantSuperAdmin_createServerFn_handler, listAppUsers_createServerFn_handler, listFactories_createServerFn_handler, listSuperAdmins_createServerFn_handler, renameFactory_createServerFn_handler, resetAppUserPassword_createServerFn_handler, revokeSuperAdmin_createServerFn_handler, saveUserPermissions_createServerFn_handler, setAppUserRole_createServerFn_handler, setSystemLocked_createServerFn_handler, setUserActive_createServerFn_handler, setUserFactory_createServerFn_handler, setUserTeamLeader_createServerFn_handler };
