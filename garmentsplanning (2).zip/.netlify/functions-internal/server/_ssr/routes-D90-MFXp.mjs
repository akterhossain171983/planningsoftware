import { a as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@emotion/react+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D90-MFXp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function Index() {
	(0, import_react.useEffect)(() => {}, []);
	return null;
}
//#endregion
export { Index as component };
