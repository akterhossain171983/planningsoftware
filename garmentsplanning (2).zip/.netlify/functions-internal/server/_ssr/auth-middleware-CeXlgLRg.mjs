import { n as createMiddleware, o as getRequest } from "./server-S2Zky892.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-middleware-CeXlgLRg.js
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		return fetch(input, {
			...init,
			headers
		});
	};
}
var DEFAULT_SUPABASE_URL = "https://pjkzraycfudmayxqdktk.supabase.co";
var DEFAULT_SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBqa3pyYXljZnVkbWF5eHFka3RrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODMwOTExNDIsImV4cCI6MjA5ODY2NzE0Mn0.y0wwzBOKFagR80Tn6U5LTcynygvU40T_4yR3xea5_LY";
var requireSupabaseAuth = createMiddleware({ type: "function" }).server(async ({ next }) => {
	const envUrl = processModule.env.SUPABASE_URL || processModule.env.VITE_SUPABASE_URL;
	const envKey = processModule.env.SUPABASE_PUBLISHABLE_KEY || processModule.env.VITE_SUPABASE_PUBLISHABLE_KEY;
	const SUPABASE_URL = envUrl && envUrl.trim() !== "" ? envUrl : DEFAULT_SUPABASE_URL;
	const SUPABASE_PUBLISHABLE_KEY = envKey && envKey.trim() !== "" ? envKey : DEFAULT_SUPABASE_PUBLISHABLE_KEY;
	const request = getRequest();
	if (!request?.headers) throw new Error("Unauthorized: No request headers available");
	const authHeader = request.headers.get("authorization");
	if (!authHeader) throw new Error("Unauthorized: No authorization header provided");
	if (!authHeader.startsWith("Bearer ")) throw new Error("Unauthorized: Only Bearer tokens are supported");
	const token = authHeader.replace("Bearer ", "");
	if (!token) throw new Error("Unauthorized: No token provided");
	if (token.split(".").length !== 3) throw new Error("Unauthorized: Invalid token");
	const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
		global: {
			fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY),
			headers: { Authorization: `Bearer ${token}` }
		},
		auth: {
			storage: void 0,
			persistSession: false,
			autoRefreshToken: false
		}
	});
	const { data, error } = await supabase.auth.getClaims(token);
	if (error || !data?.claims) throw new Error("Unauthorized: Invalid token");
	if (!data.claims.sub) throw new Error("Unauthorized: No user ID found in token");
	return next({ context: {
		supabase,
		userId: data.claims.sub,
		claims: data.claims
	} });
});
//#endregion
export { requireSupabaseAuth as t };
