import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/client.server-CeyIYN9A.js
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		return fetch(input, {
			...init,
			headers
		});
	};
}
var DEFAULT_SUPABASE_URL = "https://pjkzraycfudmayxqdktk.supabase.co";
var DEFAULT_SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBqa3pyYXljZnVkbWF5eHFka3RrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODMwOTExNDIsImV4cCI6MjA5ODY2NzE0Mn0.y0wwzBOKFagR80Tn6U5LTcynygvU40T_4yR3xea5_LY";
function createSupabaseAdminClient() {
	const envUrl = processModule.env.SUPABASE_URL || processModule.env.VITE_SUPABASE_URL;
	const envKey = processModule.env.SUPABASE_SERVICE_ROLE_KEY || processModule.env.SUPABASE_PUBLISHABLE_KEY || processModule.env.VITE_SUPABASE_PUBLISHABLE_KEY;
	const SUPABASE_URL = envUrl && envUrl.trim() !== "" ? envUrl : DEFAULT_SUPABASE_URL;
	const SUPABASE_SERVICE_ROLE_KEY = envKey && envKey.trim() !== "" ? envKey : DEFAULT_SUPABASE_PUBLISHABLE_KEY;
	return createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
		global: { fetch: createSupabaseFetch(SUPABASE_SERVICE_ROLE_KEY) },
		auth: {
			storage: void 0,
			persistSession: false,
			autoRefreshToken: false
		}
	});
}
var _supabaseAdmin;
var supabaseAdmin = new Proxy({}, { get(_, prop, receiver) {
	if (!_supabaseAdmin) _supabaseAdmin = createSupabaseAdminClient();
	return Reflect.get(_supabaseAdmin, prop, receiver);
} });
//#endregion
export { supabaseAdmin };
