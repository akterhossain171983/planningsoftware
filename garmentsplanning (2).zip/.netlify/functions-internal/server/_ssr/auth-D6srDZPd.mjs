import { a as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@emotion/react+[...].mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as isSuperAdminUser, r as SUPER_ADMIN_EMAIL } from "./permissions.types-yTTMt8IS.mjs";
import { t as supabase } from "./client-9aFMv9SR.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { C as ShieldAlert, Ct as CircleQuestionMark, Ft as Building2, Rt as ArrowRight, St as ClipboardList, Y as LoaderCircle, _ as Sparkles, i as User, mt as EyeOff, pt as Eye, q as Lock, r as Users, vt as Crown } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-D6srDZPd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var _jsxFileName = "/app/applet/src/routes/auth.tsx?tsr-split=component";
var emailFromUsername = (username) => {
	const v = username.trim().toLowerCase();
	return v.includes("@") ? v : `${v}@cloud-garments.local`;
};
function AuthPage() {
	const navigate = useNavigate();
	const [mode, setMode] = (0, import_react.useState)("login");
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [showConfirmPassword, setShowConfirmPassword] = (0, import_react.useState)(false);
	const [rememberMe, setRememberMe] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [systemLocked, setSystemLocked] = (0, import_react.useState)(false);
	const [checkingLock, setCheckingLock] = (0, import_react.useState)(true);
	const [firstUser, setFirstUser] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		supabase.auth.getSession().then(({ data }) => {
			if (data.session) navigate({
				to: "/app",
				replace: true
			});
		});
	}, [navigate]);
	(0, import_react.useEffect)(() => {
		try {
			const savedUser = localStorage.getItem("cg_remember_user");
			if (savedUser) setUsername(savedUser);
		} catch {}
		(async () => {
			try {
				const { data } = await supabase.from("system_settings").select("locked").eq("id", 1).maybeSingle();
				setSystemLocked(!!data?.locked);
				const { count } = await supabase.from("user_roles").select("*", {
					count: "exact",
					head: true
				}).eq("role", "admin");
				setFirstUser((count ?? 0) === 0);
			} catch {} finally {
				setCheckingLock(false);
			}
		})();
	}, []);
	async function handleSubmit(e) {
		e.preventDefault();
		const cleanUser = username.trim();
		if (!cleanUser) {
			toast.error("অনুগ্রহ করে ইউজারনেম বা ইমেইল প্রদান করুন।");
			return;
		}
		if (!password) {
			toast.error("অনুগ্রহ করে পাসওয়ার্ড দিন।");
			return;
		}
		if (mode === "signup") {
			if (password.length < 6) {
				toast.error("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।");
				return;
			}
			if (password !== confirmPassword) {
				toast.error("পাসওয়ার্ড এবং কনফার্ম পাসওয়ার্ড মিলছে না।");
				return;
			}
		}
		try {
			if (rememberMe) localStorage.setItem("cg_remember_user", cleanUser);
			else localStorage.removeItem("cg_remember_user");
		} catch {}
		setBusy(true);
		try {
			const email = emailFromUsername(cleanUser);
			if (mode === "signup") {
				const { error } = await supabase.auth.signUp({
					email,
					password,
					options: {
						data: { username: cleanUser },
						emailRedirectTo: window.location.origin
					}
				});
				if (error) throw error;
				toast.success("অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে — সিস্টেমে প্রবেশ করা হচ্ছে…");
				navigate({
					to: "/app",
					replace: true
				});
				return;
			}
			const { error, data } = await supabase.auth.signInWithPassword({
				email,
				password
			});
			if (error) {
				if (error.message.includes("Invalid login credentials") || error.message.includes("invalid")) throw new Error("ইউজারনেম বা পাসওয়ার্ড সঠিক নয়। পুনরায় চেষ্টা করুন।");
				throw error;
			}
			const uid = data.user.id;
			const userEmail = data.user.email ?? "";
			const [{ data: profile }, { data: roleRow }] = await Promise.all([supabase.from("profiles").select("username, active").eq("id", uid).maybeSingle(), supabase.from("user_roles").select("role").eq("user_id", uid).eq("role", "admin").maybeSingle()]);
			let localSuperList = [];
			try {
				const raw = localStorage.getItem("cg_super_admins");
				if (raw) localSuperList = JSON.parse(raw);
			} catch {}
			const isSuper = isSuperAdminUser(userEmail, cleanUser, localSuperList) || isSuperAdminUser(userEmail, profile?.username, localSuperList) || localSuperList.includes(uid.toLowerCase()) || localSuperList.includes(cleanUser.toLowerCase());
			const isAdmin = !!roleRow || isSuper;
			if (isSuper) try {
				await supabase.from("user_roles").upsert({
					user_id: uid,
					role: "admin"
				}, { onConflict: "user_id,role" });
			} catch {}
			if (!isSuper && profile && profile.active === false) {
				await supabase.auth.signOut();
				toast.error("আপনার অ্যাকাউন্ট নিষ্ক্রিয় বা ব্লক করা হয়েছে। সুপার অ্যাডমিনের সাথে যোগাযোগ করুন।");
				return;
			}
			if (systemLocked && !isAdmin) {
				await supabase.auth.signOut();
				toast.error("সিস্টেম বর্তমানে লক করা আছে। শুধুমাত্র অ্যাডমিন লগইন করতে পারবেন।");
				return;
			}
			toast.success(isSuper ? `👑 স্বাগতম সুপার অ্যাডমিন (${profile?.username ?? cleanUser})! পূর্ণ এক্সেস সক্রিয়।` : `স্বাগতম ${profile?.username ?? cleanUser}! লগইন সফল হয়েছে।`);
			navigate({
				to: "/app",
				replace: true
			});
		} catch (err) {
			const msg = err instanceof Error ? err.message : String(err);
			toast.error(msg);
		} finally {
			setBusy(false);
		}
	}
	const fillSuperAdmin = () => {
		setUsername(SUPER_ADMIN_EMAIL);
		toast.info("সুপার অ্যাডমিন ইমেইল প্রদান করা হয়েছে। আপনার পাসওয়ার্ড দিন।");
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/70 text-slate-100",
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "w-full max-w-lg rounded-3xl border border-indigo-500/30 bg-slate-950/85 backdrop-blur-2xl p-6 sm:p-8 shadow-2xl shadow-indigo-950/60 transition",
			children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "text-center mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "inline-flex p-3 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-sky-600 text-white shadow-xl shadow-indigo-600/30 mb-3.5 ring-4 ring-indigo-500/20",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Crown, { className: "w-7 h-7 text-amber-300" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 201,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", {
						className: "text-2xl sm:text-3xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-indigo-100 to-indigo-300",
						children: "Cloud Garments ERP"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 204,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "text-xs text-slate-400 mt-1.5 font-medium leading-relaxed",
						children: "গার্মেন্টস প্ল্যানিং, মাল্টি-ফ্যাক্টরি লাইন কন্ট্রোল ও পারমিশন সিস্টেম"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 207,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 200,
				columnNumber: 9
			}, this), checkingLock ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex flex-col items-center justify-center py-12 gap-3 text-slate-400 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LoaderCircle, { className: "w-8 h-8 animate-spin text-indigo-400" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 213,
					columnNumber: 13
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "সিস্টেম স্ট্যাটাস লোড হচ্ছে…" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 214,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 25
			}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [
				systemLocked && /* @__PURE__ */ (void 0)("div", {
					className: "mb-4 flex items-start gap-3 rounded-2xl border border-rose-500/40 bg-rose-500/10 p-3.5 text-xs text-rose-300",
					children: [/* @__PURE__ */ (void 0)(ShieldAlert, { className: "w-4 h-4 text-rose-400 shrink-0 mt-0.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 218,
						columnNumber: 17
					}, this), /* @__PURE__ */ (void 0)("div", {
						className: "leading-snug",
						children: [/* @__PURE__ */ (void 0)("span", {
							className: "font-bold",
							children: "সিস্টেম মেইনটেন্যান্স মোডে রয়েছে:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 19
						}, this), " বর্তমানে সাধারণ ব্যবহারকারীদের প্রবেশ স্থগিত। শুধুমাত্র সুপার অ্যাডমিন ও অ্যাডমিন লগইন করতে পারবেন।"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 219,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 217,
					columnNumber: 30
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mb-5 grid grid-cols-2 gap-1 rounded-2xl bg-slate-900/90 border border-slate-800 p-1.5 shadow-inner",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => setMode("login"),
						className: `rounded-xl py-2.5 text-xs font-black transition flex items-center justify-center gap-1.5 ${mode === "login" ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-indigo-600/30" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Lock, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 17
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "লগইন (Sign In)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 230,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 228,
						columnNumber: 15
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => setMode("signup"),
						className: `rounded-xl py-2.5 text-xs font-black transition flex items-center justify-center gap-1.5 ${mode === "signup" ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-indigo-600/30" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 233,
							columnNumber: 17
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "নতুন অ্যাকাউন্ট (Sign Up)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 232,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 227,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mb-5 bg-gradient-to-r from-purple-950/50 via-indigo-950/40 to-slate-900/60 rounded-2xl border border-purple-500/30 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-2.5 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "p-1.5 rounded-xl bg-purple-500/20 text-purple-300 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Crown, { className: "w-4 h-4 text-amber-300" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 242,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 241,
							columnNumber: 17
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "text-[12px] font-black text-purple-200 truncate flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "সুপার অ্যাডমিন এক্সেস" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 246,
									columnNumber: 21
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "text-[10px] px-1.5 py-0.2 rounded bg-purple-500/30 text-purple-200 border border-purple-400/30",
									children: "Master"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 247,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 19
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "text-[10px] text-slate-400 truncate",
								children: "সকল ইউজারকে সুপার অ্যাডমিন পারমিশন প্রদান ও বাতিল নিয়ন্ত্রণ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 251,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 244,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 240,
						columnNumber: 15
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: fillSuperAdmin,
						className: "shrink-0 px-3 py-1.5 rounded-xl text-[11px] font-extrabold bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-400/40 transition active:scale-95 flex items-center justify-center gap-1",
						title: "সুপার অ্যাডমিন ইমেইল পূরণ করুন",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "কুইক প্রি-ফিল" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 257,
							columnNumber: 17
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArrowRight, { className: "w-3 h-3 text-purple-300" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 258,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 256,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 239,
					columnNumber: 13
				}, this),
				mode === "signup" && firstUser && /* @__PURE__ */ (void 0)("div", {
					className: "mb-4 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-xs text-emerald-300 flex items-center gap-2",
					children: [/* @__PURE__ */ (void 0)(Sparkles, { className: "w-4 h-4 text-emerald-400 shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 263,
						columnNumber: 17
					}, this), /* @__PURE__ */ (void 0)("span", { children: [
						"🎉 আপনি প্রথম অ্যাকাউন্ট তৈরি করছেন — সাইন আপ সম্পন্ন হলে স্বয়ংক্রিয়ভাবে",
						" ",
						/* @__PURE__ */ (void 0)("b", { children: "সুপার অ্যাডমিন" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 266,
							columnNumber: 19
						}, this),
						" রোল সক্রিয় হবে।"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 264,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 262,
					columnNumber: 48
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("form", {
					onSubmit: handleSubmit,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
							className: "block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "ইউজারনেম বা ইমেইল" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 274,
								columnNumber: 19
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "text-[10px] text-slate-400 font-normal",
								children: "Username / Email"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 275,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 273,
							columnNumber: 17
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(User, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 278,
								columnNumber: 19
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
								type: "text",
								autoComplete: "username",
								value: username,
								onChange: (e) => setUsername(e.target.value),
								placeholder: "যেমন: akterplanning83 বা akterplanning83@gmail.com",
								className: "w-full rounded-xl border border-slate-700 bg-slate-900/90 pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/30 transition"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 281,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 277,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
							className: "block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "পাসওয়ার্ড" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 287,
								columnNumber: 19
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "text-[10px] text-slate-400 font-normal",
								children: "Password"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 286,
							columnNumber: 17
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500",
									children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Lock, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 292,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 291,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
									type: showPassword ? "text" : "password",
									autoComplete: mode === "signup" ? "new-password" : "current-password",
									value: password,
									onChange: (e) => setPassword(e.target.value),
									placeholder: "••••••••",
									className: "w-full rounded-xl border border-slate-700 bg-slate-900/90 pl-10 pr-10 py-2.5 text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/30 transition"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 294,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
									type: "button",
									onClick: () => setShowPassword((v) => !v),
									className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1",
									title: showPassword ? "পাসওয়ার্ড লুকান" : "পাসওয়ার্ড দেখুন",
									children: showPassword ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(EyeOff, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 296,
										columnNumber: 37
									}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Eye, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 296,
										columnNumber: 70
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 295,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 290,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 285,
							columnNumber: 15
						}, this),
						mode === "signup" && /* @__PURE__ */ (void 0)("div", { children: [
							/* @__PURE__ */ (void 0)("label", {
								className: "block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between",
								children: [/* @__PURE__ */ (void 0)("span", { children: "পাসওয়ার্ড নিশ্চিত করুন" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 304,
									columnNumber: 21
								}, this), /* @__PURE__ */ (void 0)("span", {
									className: "text-[10px] text-slate-400 font-normal",
									children: "Confirm Password"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 305,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ (void 0)("div", {
								className: "relative",
								children: [
									/* @__PURE__ */ (void 0)("div", {
										className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500",
										children: /* @__PURE__ */ (void 0)(Lock, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 309,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 308,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (void 0)("input", {
										type: showConfirmPassword ? "text" : "password",
										autoComplete: "new-password",
										value: confirmPassword,
										onChange: (e) => setConfirmPassword(e.target.value),
										placeholder: "পাসওয়ার্ড পুনরায় লিখুন",
										className: "w-full rounded-xl border border-slate-700 bg-slate-900/90 pl-10 pr-10 py-2.5 text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/30 transition"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 311,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (void 0)("button", {
										type: "button",
										onClick: () => setShowConfirmPassword((v) => !v),
										className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1",
										title: showConfirmPassword ? "পাসওয়ার্ড লুকান" : "পাসওয়ার্ড দেখুন",
										children: showConfirmPassword ? /* @__PURE__ */ (void 0)(EyeOff, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 313,
											columnNumber: 46
										}, this) : /* @__PURE__ */ (void 0)(Eye, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 313,
											columnNumber: 79
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 312,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ (void 0)("p", {
								className: "mt-1 text-[10px] text-slate-400",
								children: "কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 316,
								columnNumber: 19
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 302,
							columnNumber: 37
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center justify-between text-xs pt-1",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "inline-flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white select-none",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
									type: "checkbox",
									checked: rememberMe,
									onChange: (e) => setRememberMe(e.target.checked),
									className: "w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 324,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "আমাকে মনে রাখুন" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "text-[11px] text-slate-400 flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleQuestionMark, { className: "w-3 h-3 text-indigo-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 328,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "পাসওয়ার্ড ভুলে গেলে অ্যাডমিনের সাথে যোগাযোগ করুন" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 329,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 327,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 322,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "submit",
							disabled: busy,
							className: "w-full rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-indigo-700 hover:from-purple-500 hover:to-indigo-500 py-3 text-xs font-black text-white shadow-lg shadow-indigo-600/30 transition active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer",
							children: busy ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "inline-flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LoaderCircle, { className: "w-4 h-4 animate-spin" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 336,
									columnNumber: 21
								}, this), " প্রক্রিয়াধীন…"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 25
							}, this) : mode === "login" ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Lock, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 338,
								columnNumber: 21
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "লগইন করুন (Sign In)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 339,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 48
							}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 21
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "নতুন অ্যাকাউন্ট তৈরি করুন (Sign Up)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 340,
								columnNumber: 25
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 271,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mt-6 pt-5 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-[11px] text-slate-400",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-1.5 p-2 rounded-xl bg-slate-900/50 border border-slate-800/80",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Building2, { className: "w-3.5 h-3.5 text-sky-400 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 350,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "truncate",
								children: "মাল্টি-ফ্যাক্টরি হায়ারার্কি"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 351,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 349,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-1.5 p-2 rounded-xl bg-slate-900/50 border border-slate-800/80",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Users, { className: "w-3.5 h-3.5 text-indigo-400 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 354,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "truncate",
								children: "টিম লিডার ও প্ল্যানার রোল"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 355,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 353,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-1.5 p-2 rounded-xl bg-slate-900/50 border border-slate-800/80",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Crown, { className: "w-3.5 h-3.5 text-purple-400 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 358,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "truncate",
								children: "সুপার অ্যাডমিন পারমিশন কন্ট্রোল"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 359,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-1.5 p-2 rounded-xl bg-slate-900/50 border border-slate-800/80",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ClipboardList, { className: "w-3.5 h-3.5 text-emerald-400 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 362,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "truncate",
								children: "রিয়েলটাইম অডিট লগ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 363,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 361,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 348,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 215,
				columnNumber: 20
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 198,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 197,
		columnNumber: 10
	}, this);
}
//#endregion
export { AuthPage as component };
