import { h as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-BhRHKMYZ.js
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var _jsxFileName = "/app/applet/src/routes/_authenticated/route.tsx?tsr-split=component";
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Outlet, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 5,
	columnNumber: 30
}, void 0);
//#endregion
export { SplitComponent as component };
