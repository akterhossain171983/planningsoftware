import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/client-9aFMv9SR.js
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		return fetch(input, {
			...init,
			headers
		});
	};
}
var DEFAULT_SUPABASE_URL = "https://pjkzraycfudmayxqdktk.supabase.co";
var DEFAULT_SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBqa3pyYXljZnVkbWF5eHFka3RrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODMwOTExNDIsImV4cCI6MjA5ODY2NzE0Mn0.y0wwzBOKFagR80Tn6U5LTcynygvU40T_4yR3xea5_LY";
function createSupabaseClient() {
	const envUrl = "https://pjkzraycfudmayxqdktk.supabase.co";
	const envKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBqa3pyYXljZnVkbWF5eHFka3RrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODMwOTExNDIsImV4cCI6MjA5ODY2NzE0Mn0.y0wwzBOKFagR80Tn6U5LTcynygvU40T_4yR3xea5_LY";
	const SUPABASE_URL = envUrl.trim() !== "" ? envUrl : DEFAULT_SUPABASE_URL;
	const SUPABASE_PUBLISHABLE_KEY = envKey.trim() !== "" ? envKey : DEFAULT_SUPABASE_PUBLISHABLE_KEY;
	return createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
		global: { fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY) },
		auth: {
			storage: typeof window !== "undefined" ? localStorage : void 0,
			persistSession: true,
			autoRefreshToken: true
		}
	});
}
var _supabase;
var supabase = new Proxy({}, { get(_, prop, receiver) {
	if (!_supabase) _supabase = createSupabaseClient();
	return Reflect.get(_supabase, prop, receiver);
} });
//#endregion
export { supabase as t };
