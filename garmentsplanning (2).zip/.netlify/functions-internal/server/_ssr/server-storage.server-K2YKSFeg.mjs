import { r as SUPER_ADMIN_EMAIL } from "./permissions.types-yTTMt8IS.mjs";
import processModule from "node:process";
import * as fs from "node:fs/promises";
import * as path from "node:path";
//#region node_modules/.nitro/vite/services/ssr/assets/server-storage.server-K2YKSFeg.js
var getBaseDir = () => {
	if (typeof processModule !== "undefined" && typeof processModule.cwd === "function") return processModule.cwd();
	return ".";
};
var PERMS_FILE = path.join(getBaseDir(), "data", "work_permissions.json");
var SUPER_ADMINS_FILE = path.join(getBaseDir(), "data", "super_admins.json");
var AUDIT_FILE = path.join(getBaseDir(), "data", "audit_logs.json");
var MAX_LOG_ENTRIES = 1200;
async function loadPermissionsFromDisk() {
	try {
		const raw = await fs.readFile(PERMS_FILE, "utf-8");
		return JSON.parse(raw);
	} catch {
		return {};
	}
}
async function savePermissionsToDisk(data) {
	try {
		await fs.mkdir(path.dirname(PERMS_FILE), { recursive: true });
		await fs.writeFile(PERMS_FILE, JSON.stringify(data, null, 2), "utf-8");
	} catch (err) {
		console.error("Failed to save permissions to disk:", err);
	}
}
async function loadSuperAdminsFromDisk() {
	try {
		const raw = await fs.readFile(SUPER_ADMINS_FILE, "utf-8");
		const parsed = JSON.parse(raw);
		const set = new Set((Array.isArray(parsed) ? parsed : []).map((s) => s.toLowerCase().trim()));
		set.add(SUPER_ADMIN_EMAIL.toLowerCase());
		set.add("akterplanning83");
		return Array.from(set);
	} catch {
		return [SUPER_ADMIN_EMAIL.toLowerCase(), "akterplanning83"];
	}
}
async function saveSuperAdminsToDisk(list) {
	try {
		await fs.mkdir(path.dirname(SUPER_ADMINS_FILE), { recursive: true });
		const set = new Set(list.map((s) => s.toLowerCase().trim()));
		set.add(SUPER_ADMIN_EMAIL.toLowerCase());
		set.add("akterplanning83");
		await fs.writeFile(SUPER_ADMINS_FILE, JSON.stringify(Array.from(set), null, 2), "utf-8");
	} catch (err) {
		console.error("Failed to save super admins to disk:", err);
	}
}
async function writeSuperAdminsDirect(list) {
	try {
		await fs.mkdir(path.dirname(SUPER_ADMINS_FILE), { recursive: true });
		await fs.writeFile(SUPER_ADMINS_FILE, JSON.stringify(list, null, 2), "utf-8");
	} catch (err) {
		console.error("Failed to direct write super admins to disk:", err);
	}
}
async function readAuditLogsFromDisk() {
	try {
		const raw = await fs.readFile(AUDIT_FILE, "utf-8");
		return JSON.parse(raw);
	} catch {
		return [];
	}
}
async function writeAuditLogsToDisk(entries) {
	try {
		await fs.mkdir(path.dirname(AUDIT_FILE), { recursive: true });
		const trimmed = entries.slice(0, MAX_LOG_ENTRIES);
		await fs.writeFile(AUDIT_FILE, JSON.stringify(trimmed, null, 2), "utf-8");
	} catch (err) {
		console.error("Failed to write audit logs to disk:", err);
	}
}
//#endregion
export { loadPermissionsFromDisk, loadSuperAdminsFromDisk, readAuditLogsFromDisk, savePermissionsToDisk, saveSuperAdminsToDisk, writeAuditLogsToDisk, writeSuperAdminsDirect };
