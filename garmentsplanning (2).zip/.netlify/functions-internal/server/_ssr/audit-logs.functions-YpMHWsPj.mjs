import { r as createServerFn } from "./server-42tn7q3O.mjs";
import { t as createServerRpc } from "./createServerRpc-B1vjJoCb.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-C_sIQ2DQ.mjs";
import { o as isSuperAdminUser } from "./permissions.types-yTTMt8IS.mjs";
import { a as objectType, c as unknownType, i as numberType, o as recordType, s as stringType } from "../_libs/zod.mjs";
import { t as AUDIT_ACTION_CONFIG } from "./audit-logs.types-YWLYPOLb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-logs.functions-YpMHWsPj.js
var recordAuditSchema = objectType({
	action: stringType(),
	details: stringType(),
	targetId: stringType().optional(),
	targetName: stringType().optional(),
	factoryId: stringType().nullable().optional(),
	factoryName: stringType().nullable().optional(),
	metadata: recordType(unknownType()).optional()
});
var recordAuditLog_createServerFn_handler = createServerRpc({
	id: "8bdefb76b23d2e746ea7bf91fbd4795e5fccf9ccdd7428025509557b9741cb67",
	name: "recordAuditLog",
	filename: "src/lib/audit-logs.functions.ts"
}, (opts) => recordAuditLog.__executeServer(opts));
var recordAuditLog = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => recordAuditSchema.parse(d)).handler(recordAuditLog_createServerFn_handler, async ({ data, context }) => {
	const userId = context.userId;
	const email = context.claims?.email ?? "";
	const rawUsername = context.claims?.user_metadata?.username ?? (email ? email.split("@")[0] : "unknown");
	const isSuper = isSuperAdminUser(email, rawUsername);
	let username = rawUsername;
	let role = isSuper ? "admin" : "user";
	let factoryId = data.factoryId ?? null;
	let factoryName = data.factoryName ?? null;
	try {
		const [{ data: prof }, { data: rRow }] = await Promise.all([context.supabase.from("profiles").select("username, factory_id").eq("id", userId).maybeSingle(), context.supabase.from("user_roles").select("role").eq("user_id", userId).maybeSingle()]);
		if (prof?.username) username = prof.username;
		if (prof?.factory_id && !factoryId) factoryId = prof.factory_id;
		if (rRow?.role && !isSuper) role = rRow.role;
		if (factoryId && !factoryName) {
			const { data: fData } = await context.supabase.from("factories").select("name").eq("id", factoryId).maybeSingle();
			if (fData?.name) factoryName = fData.name;
		}
	} catch {}
	const actionKey = data.action;
	const actionConfig = AUDIT_ACTION_CONFIG[actionKey];
	const actionLabel = actionConfig ? actionConfig.label : data.action;
	const entry = {
		id: `audit_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
		timestamp: (/* @__PURE__ */ new Date()).toISOString(),
		userId,
		username,
		userRole: role,
		isSuperAdmin: isSuper,
		factoryId,
		factoryName,
		action: actionKey,
		actionLabel,
		details: data.details,
		targetId: data.targetId,
		targetName: data.targetName,
		metadata: data.metadata
	};
	const { readAuditLogsFromDisk, writeAuditLogsToDisk } = await import("./server-storage.server-K2YKSFeg.mjs");
	const existing = await readAuditLogsFromDisk();
	existing.unshift(entry);
	await writeAuditLogsToDisk(existing);
	return {
		ok: true,
		entryId: entry.id
	};
});
var listAuditSchema = objectType({
	action: stringType().optional(),
	userId: stringType().optional(),
	factoryId: stringType().optional(),
	search: stringType().optional(),
	limit: numberType().optional().default(200)
});
var listAuditLogs_createServerFn_handler = createServerRpc({
	id: "2b4ed06802cac32c5adc57cbc1d215e3ed5802ca06a4295efc40d25c370ebcfe",
	name: "listAuditLogs",
	filename: "src/lib/audit-logs.functions.ts"
}, (opts) => listAuditLogs.__executeServer(opts));
var listAuditLogs = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).inputValidator((d) => listAuditSchema.parse(d ?? {})).handler(listAuditLogs_createServerFn_handler, async ({ data, context }) => {
	const email = context.claims?.email;
	const username = context.claims?.user_metadata?.username;
	if (!isSuperAdminUser(email, username)) {
		const { data: roleRow } = await context.supabase.from("user_roles").select("role").eq("user_id", context.userId).eq("role", "admin").maybeSingle();
		if (!roleRow) throw new Error("Forbidden: audit logs are accessible only by administrators.");
	}
	const { readAuditLogsFromDisk } = await import("./server-storage.server-K2YKSFeg.mjs");
	let logs = await readAuditLogsFromDisk();
	if (data.action) logs = logs.filter((l) => l.action === data.action);
	if (data.userId) logs = logs.filter((l) => l.userId === data.userId);
	if (data.factoryId) logs = logs.filter((l) => l.factoryId === data.factoryId);
	if (data.search) {
		const q = data.search.trim().toLowerCase();
		logs = logs.filter((l) => l.username.toLowerCase().includes(q) || l.details.toLowerCase().includes(q) || l.targetName && l.targetName.toLowerCase().includes(q) || l.factoryName && l.factoryName.toLowerCase().includes(q));
	}
	return logs.slice(0, data.limit ?? 200);
});
var clearAuditLogs_createServerFn_handler = createServerRpc({
	id: "2bab20bef11672b1fa8594726d4562ba6a0c3d1263a124b2a5d87aee3b89f4ff",
	name: "clearAuditLogs",
	filename: "src/lib/audit-logs.functions.ts"
}, (opts) => clearAuditLogs.__executeServer(opts));
var clearAuditLogs = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(clearAuditLogs_createServerFn_handler, async ({ context }) => {
	const email = context.claims?.email;
	const username = context.claims?.user_metadata?.username;
	if (!isSuperAdminUser(email, username)) throw new Error("শুধুমাত্র সুপার অ্যাডমিন অডিট হিস্টোরি ক্লিয়ার করতে পারবেন।");
	const { writeAuditLogsToDisk } = await import("./server-storage.server-K2YKSFeg.mjs");
	await writeAuditLogsToDisk([]);
	return { ok: true };
});
//#endregion
export { clearAuditLogs_createServerFn_handler, listAuditLogs_createServerFn_handler, recordAuditLog_createServerFn_handler };
