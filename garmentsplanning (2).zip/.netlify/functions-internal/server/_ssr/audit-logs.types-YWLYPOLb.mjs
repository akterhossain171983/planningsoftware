//#region node_modules/.nitro/vite/services/ssr/assets/audit-logs.types-YWLYPOLb.js
var AUDIT_ACTION_CONFIG = {
	BOARD_RESCHEDULE: {
		label: "বোর্ড রিসিডিউল (ড্র্যাগ)",
		badgeClass: "bg-blue-500/20 text-blue-300 border-blue-500/40",
		icon: "CalendarRange"
	},
	BOARD_SPLIT: {
		label: "অর্ডার স্প্লিট",
		badgeClass: "bg-indigo-500/20 text-indigo-300 border-indigo-500/40",
		icon: "Scissors"
	},
	BOARD_UNPLAN: {
		label: "আনপ্ল্যান্ড করা",
		badgeClass: "bg-amber-500/20 text-amber-300 border-amber-500/40",
		icon: "RotateCcw"
	},
	PLAN_CREATE: {
		label: "নতুন প্ল্যান তৈরি",
		badgeClass: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
		icon: "PlusCircle"
	},
	PLAN_EDIT: {
		label: "প্ল্যান এডিট / পরিবর্তন",
		badgeClass: "bg-cyan-500/20 text-cyan-300 border-cyan-500/40",
		icon: "Edit3"
	},
	PLAN_DELETE: {
		label: "প্ল্যান বাতিল / ডিলিট",
		badgeClass: "bg-rose-500/20 text-rose-300 border-rose-500/40",
		icon: "Trash2"
	},
	PRODUCTION_ENTRY: {
		label: "প্রোডাকশন আপডেট",
		badgeClass: "bg-teal-500/20 text-teal-300 border-teal-500/40",
		icon: "Factory"
	},
	PERMISSION_GRANT: {
		label: "পারমিশন প্রদান",
		badgeClass: "bg-purple-500/20 text-purple-300 border-purple-500/40",
		icon: "ShieldCheck"
	},
	PERMISSION_REVOKE: {
		label: "পারমিশন প্রত্যাহার / রিমুভ",
		badgeClass: "bg-rose-500/20 text-rose-300 border-rose-500/40",
		icon: "ShieldAlert"
	},
	USER_ROLE_CHANGE: {
		label: "ইউজার রোল পরিবর্তন",
		badgeClass: "bg-purple-500/20 text-purple-300 border-purple-500/40",
		icon: "UserCheck"
	},
	USER_FACTORY_ASSIGN: {
		label: "কারখানা পরিবর্তন",
		badgeClass: "bg-sky-500/20 text-sky-300 border-sky-500/40",
		icon: "Building2"
	},
	USER_STATUS_CHANGE: {
		label: "স্ট্যাটাস পরিবর্তন (ব্লক/সক্রিয়)",
		badgeClass: "bg-amber-500/20 text-amber-300 border-amber-500/40",
		icon: "Lock"
	},
	SYSTEM_LOCK_TOGGLE: {
		label: "সিস্টেম লক / আনলক",
		badgeClass: "bg-orange-500/20 text-orange-300 border-orange-500/40",
		icon: "Shield"
	}
};
//#endregion
export { AUDIT_ACTION_CONFIG as t };
