//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BLGuzMFC.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/app/applet/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth"
		],
		preloads: ["/assets/index-DBE2sBCl.js", "/assets/react-Dgwpegte.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DBE2sBCl.js"
		} }]
	},
	"/": {
		filePath: "/app/applet/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BUquMLcY.js"]
	},
	"/_authenticated": {
		filePath: "/app/applet/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/app"],
		preloads: ["/assets/route-CGIGFLFW.js"]
	},
	"/auth": {
		filePath: "/app/applet/src/routes/auth.tsx",
		children: void 0,
		preloads: ["/assets/auth-DBxi1ryb.js", "/assets/permissions.types-PJdk6A-1.js"]
	},
	"/_authenticated/app": {
		filePath: "/app/applet/src/routes/_authenticated/app.tsx",
		children: void 0,
		preloads: ["/assets/app-BtXInDdX.js", "/assets/permissions.types-PJdk6A-1.js"]
	}
} });
//#endregion
export { tsrStartManifest };
